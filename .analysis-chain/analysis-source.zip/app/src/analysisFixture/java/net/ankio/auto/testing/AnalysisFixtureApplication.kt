package net.ankio.auto.testing
import net.ankio.auto.App
import net.ankio.auto.autoApp
import com.tencent.mmkv.MMKV
/** No App.onCreate: no license/account, queue, update, export, backup or crash init. */
class AnalysisFixtureApplication : App() {
    override fun onCreate() {
        check(packageName == "net.ankio.auto.analysisfixture")
        autoApp = this
        MMKV.initialize(this)
    }
}
