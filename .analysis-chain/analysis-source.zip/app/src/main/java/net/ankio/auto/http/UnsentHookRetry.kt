package net.ankio.auto.http

import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import okhttp3.Call
import okhttp3.EventListener

/** Conservative proof: no request headers began on ANY exchange in this call. */
internal class HookSendBoundary : EventListener() {
    private val headersStarted = AtomicBoolean(false)
    override fun requestHeadersStart(call: Call) {
        // OkHttp may follow up some HTTP statuses even with connection retry disabled.
        // Cancel before ANY second exchange writes its headers; never silently replay a POST.
        if (headersStarted.getAndSet(true)) call.cancel()
    }
    fun classify(error: IOException): IOException =
        if (headersStarted.get()) error else UnsentHookRequest(error)
}

/** Typed locally; never inferred from exception text or a server-provided message. */
internal class UnsentHookRequest(cause: IOException) : IOException("hook_not_sent", cause)

internal suspend fun <T> retryUnsentHookRequest(
    pause: suspend (Long) -> Unit = { delay(it) },
    attempt: suspend () -> T,
): T {
    var retries = 0
    while (true) {
        coroutineContext.ensureActive()
        try { return attempt() }
        catch (notSent: UnsentHookRequest) {
            if (retries >= 2) throw notSent
            pause(if (retries++ == 0) 1_000 else 2_000)
        }
    }
}
