package net.ankio.auto.service
import android.content.Intent
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.service.api.ICoreService
import net.ankio.auto.service.host.OwnerHttpRuntime
/** OCR/LSPatch adapter; lifecycle ownership is shared, never stop another client's engine. */
class BackgroundHttpService : ICoreService() {
    private val lease = Any()
    private var acquired = false
    override fun onCreate(coreService: CoreService) {
        super.onCreate(coreService)
        acquired = true; OwnerHttpRuntime.acquire(lease)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) {}
    override fun onDestroy() {
        if (acquired) { acquired = false; OwnerHttpRuntime.release(lease) }
    }
}
