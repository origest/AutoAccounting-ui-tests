package net.ankio.auto.service

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Base64
import androidx.core.graphics.scale
import androidx.lifecycle.lifecycleScope
import com.google.android.accessibility.selecttospeak.SelectToSpeakService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.ankio.auto.R
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.http.api.JsAPI
import net.ankio.auto.service.OcrService.Companion.OCR_MAX_SHORT_EDGE
import net.ankio.auto.service.api.ICoreService
import net.ankio.auto.service.api.IService
import net.ankio.auto.service.ocr.OcrTools
import net.ankio.auto.service.ocr.OcrViews
import net.ankio.auto.service.ocr.PageSignatureManager
import net.ankio.auto.service.ocr.ChatGptOcrTextPipeline
import net.ankio.auto.service.overlay.SaveProgressView
import net.ankio.auto.storage.Logger
import net.ankio.auto.ui.dialog.RememberPageDialog
import net.ankio.auto.ui.utils.DisplayUtils
import net.ankio.auto.utils.PrefManager
import net.ankio.ocr.OcrProcessor
import org.ezbook.server.constant.DataType
import org.ezbook.server.constant.LogLevel
import org.ezbook.server.intent.IntentType
import org.ezbook.server.models.BillResultModel
import org.ezbook.server.models.ResultModel
import org.ezbook.server.tools.runCatchingExceptCancel
import java.io.File

/**
 * OCR 服务：截取屏幕并完成 OCR / AI 分析。
 *
 * **双击背部触发**由独立子服务 [BackTapOcrTriggerService] 负责，通过 OCR Intent 与本服务协作。
 */
class OcrService : ICoreService() {

    // OCR处理器
    private lateinit var ocrProcessor: OcrProcessor
    private var saveProgressView: SaveProgressView? = null

    private val ocrView = OcrViews()

    /**
     * 服务创建时的初始化
     * 检查必要权限并初始化相关组件
     */
    override fun onCreate(coreService: CoreService) {
        super.onCreate(coreService)

        ocrProcessor = OcrProcessor().debug(PrefManager.debugMode).attach(coreService)
            .log { string, type -> Logger.log(LogLevel.fromAndroidLevel(type), string) }

        serverStarted = true
        Logger.i("OCR service initialized")

        if (WorkMode.isOcrOrLSPatch()) {
            saveProgressView = SaveProgressView()
            saveProgressView?.show(this)
        }


    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) {

        if (intent?.getStringExtra("intentType") == IntentType.OCR.name) {
            coreService.lifecycleScope.launch {
                val manual = intent.getBooleanExtra("manual", false)
                triggerOcr(manual)
            }
        }

    }

    /**
     * 服务销毁时的清理工作
     */
    override fun onDestroy() {
        // 释放 OCR 引擎资源，确保跟随服务生命周期关闭。
        ocrProcessor.close()
        // 确保状态横幅被清理
        ocrView.dismiss()

        saveProgressView?.destroy()

    }

    /* -------------------------------- 业务逻辑 ------------------------------- */

    private var ocrDoing = false
    private var waitingForHost = false

    /**
     * 触发振动反馈
     * 在OCR识别开始时提供触觉反馈
     */
    private fun triggerVibration() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+ 使用VibratorManager
                val vibratorManager =
                    coreService.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                // Android 12以下使用传统Vibrator
                @Suppress("DEPRECATION")
                coreService.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }

            if (!vibrator.hasVibrator()) {
                Logger.w("Device does not support vibration")
                return
            }

            val vibrationEffect =
                VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
            vibrator.vibrate(vibrationEffect)
        } catch (e: Exception) {
            Logger.e("Vibration failed", e)
        }
    }

    /**
     * 触发OCR识别
     * 支持多种触发方式：双击背部、Intent、磁贴等
     * 所有异常和状态通过顶部横幅展示。
     */
    private suspend fun triggerOcr(manual: Boolean) {
        if (ocrDoing || waitingForHost) {
            Logger.d("[TapBack→OCR] skip: pipeline busy (ocrDoing=true) manual=$manual")
            return
        }

        waitingForHost = true
        val hostReady = try { net.ankio.auto.service.host.OwnerHttpRuntime.awaitReady() }
            finally { waitingForHost = false }
        if (!hostReady) {
            if (manual) ocrView.showError(coreService, "本机接收服务尚未就绪，请稍后重试")
            return
        }

        val keyguardManager =
            coreService.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        if (keyguardManager.isKeyguardLocked) {
            Logger.d("[TapBack→OCR] skip: keyguard locked manual=$manual")
            return
        }

        if (PrefManager.landscapeDnd && DisplayUtils.isWindowLandscape(coreService)) {
            Logger.d("[TapBack→OCR] skip: landscape DND enabled manual=$manual")
            return
        }

        if (!OcrTools.requestPermission()) {
            Logger.d("[TapBack→OCR] skip: accessibility not ready manual=$manual")
            if (manual) ocrView.showError(
                coreService,
                coreService.getString(R.string.ocr_error_accessibility_not_ready)
            )
            ocrDoing = false
            return
        }

        ocrDoing = true
        OcrTools.collapseStatusBar()
        val pkg = OcrTools.getTopApp() ?: run {
            Logger.d("[TapBack→OCR] skip: getTopApp() null (no foreground package) manual=$manual")
            if (manual) ocrView.showError(
                coreService,
                coreService.getString(R.string.ocr_error_no_foreground_app)
            )
            ocrDoing = false
            return
        }

        val packageName = when {
            manual -> pkg
            pkg in PrefManager.appWhiteList -> pkg
            else -> {
                Logger.d(
                    "[TapBack→OCR] skip: package not in whitelist pkg=$pkg manual=$manual " +
                            "(double-tap only runs OCR for whitelisted apps)",
                )
                ocrDoing = false
                return
            }
        }

        triggerVibration()
        Logger.i("[TapBack→OCR] proceed: pkg=$packageName manual=$manual")
        executeOcrFlow(packageName, manual)
    }

    /**
     * 执行OCR识别的完整流程
     *
     * 关键顺序：先截图（屏幕干净），再弹横幅告知用户进度。
     * 所有错误和结果均通过横幅展示，不使用 Toast。
     * @param manual 是否手动触发，手动且识别成功时弹窗询问是否记住此页面
     */
    private fun executeOcrFlow(packageName: String, manual: Boolean = false) {

        coreService.lifecycleScope.launch {
            val startTime = System.currentTimeMillis()
            try {
                val structFp = SelectToSpeakService.structFp ?: ""
                // 1. 先在IO线程截图（视觉模式返回图片Base64，规则模式返回OCR文本）
                val useChatGptText = WorkMode.isOcr() && ChatGptOcrTextPipeline.isSelected(coreService)
                val captureTicket = if (useChatGptText) net.ankio.chatgpt.ChatGptAccounts.get(coreService).ocrTextTicket() else null
                val useVision = !useChatGptText && PrefManager.aiVisionRecognition
                val data = withContext(Dispatchers.IO) { performOcrCapture(useVision) }
                    ?: return@launch  // performOcrCapture 内部已通过横幅展示错误

                if (!useVision && !AnalysisUtils.inWhitelist(data)) {
                    Logger.d("OCR text filtered by keyword rules")
                    ocrView.showError(
                        coreService,
                        coreService.getString(R.string.ocr_error_keyword_filtered)
                    )
                    return@launch
                }

                Logger.d("OCR data length: ${data.length}")

                // 2. 更新横幅：正在AI识别
                ocrView.updateStatus(coreService.getString(R.string.ocr_status_ai_analyzing))

                if (useChatGptText) {
                    val outcome = ChatGptOcrTextPipeline.analyze(coreService, data, packageName, captureTicket = captureTicket)
                    if (outcome.bill != null) {
                        ocrView.dismiss()
                        if (!ChatGptOcrTextPipeline.present(coreService, outcome)) {
                            ocrView.showError(coreService, "建议已保留在待编辑账单，当前授权或页面状态已变化。")
                        }
                    } else ocrView.showError(coreService, outcome.message)
                    return@launch
                }

                // 3. 发送给JS引擎（视觉模式传图，规则模式传文本）
                val result = withContext(Dispatchers.IO) {
                    send2JsEngine(data, packageName, manual)
                }

                val totalTime = System.currentTimeMillis() - startTime
                Logger.d("OCR completed in ${totalTime}ms")

                // 4. 在横幅上显示最终结果（展示服务端返回的具体信息）
                val billData = result.data
                if (billData != null) {
                    val moneyText = String.format("¥%.2f", billData.billInfoModel.money)

                    ocrView.showSuccess(coreService, moneyText) {
                        if (PrefManager.ocrAccessibilityAutoTrigger) {
                            val activityName = SelectToSpeakService.topActivity ?: ""
                            showRememberPageDialog(structFp, packageName, activityName)
                        }
                    }
                } else {
                    ocrView.showError(coreService, result.msg)
                }

            } catch (e: Exception) {
                Logger.e("OCR flow error", e)
                ocrView.dismiss()
            } finally {
                ocrDoing = false
                // 支付截图也依赖用户已启用的无障碍服务；OCR 结束不能撤销它。
                if (!PrefManager.ocrAccessibilityKeepAlive &&
                    !coreService.getSharedPreferences("payment-capture", android.content.Context.MODE_PRIVATE).getBoolean("enabled", false)) {
                    SelectToSpeakService.instance?.disableSelf()
                }
            }
        }

    }
    /**
     * 展示记住页面弹窗
     * 若已有匹配规则则不再弹窗。Service 环境下 BaseSheetDialog 自动使用悬浮窗模式
     */
    private fun showRememberPageDialog(
        structFp: String,
        packageName: String,
        activityName: String,
    ) {
        if (PageSignatureManager.matches(packageName, activityName, structFp)) return
        coreService.lifecycleScope.launch {
            withContext(Dispatchers.Main) {
                RememberPageDialog.show(
                    context = coreService,
                    packageName = packageName,
                    activityName = activityName,
                    structureFingerprint = structFp,
                )
            }
        }
    }


    /**
     * 执行屏幕截图，可选 OCR 识别
     *
     * 流程：截图 → 弹横幅 → 压缩 → [useVision=false 时 OCR] → 返回结果
     * @param useVision 为 true 时跳过 OCR，仅返回图片 Base64；否则返回 OCR 文本
     * @return 视觉模式返回图片 Base64，规则模式返回 OCR 文本，失败返回 null
     */
    private suspend fun performOcrCapture(useVision: Boolean): String? {
        val captureStartTime = System.currentTimeMillis()

        // 截图输出路径
        val outFile = File(coreService.externalCacheDir, "screen.png")
        if (outFile.exists()) outFile.delete()

        // 通过 OcrTools 执行截图（根据授权方式分别调用 Root/Shizuku/无障碍）
        runCatchingExceptCancel {
            val success = OcrTools.takeScreenshot(outFile)
            if (!success) throw IllegalStateException("Screenshot failed")
        }.onFailure {
            Logger.e(it.message ?: "", it)

            withContext(Dispatchers.Main) {
                ocrView.showError(
                    coreService,
                    coreService.getString(R.string.ocr_error_capture_failed)
                )
            }
            return null
        }

        val captureTime = System.currentTimeMillis() - captureStartTime
        Logger.d("Screenshot captured in ${captureTime}ms")

        withContext(Dispatchers.Main) {
            ocrView.show(
                coreService,
                coreService.getString(R.string.ocr_status_processing_screenshot)
            )
        }

        // 解码截图
        val bitmap = BitmapFactory.decodeFile(outFile.absolutePath)
        if (bitmap == null) {
            Logger.e("Failed to decode screenshot")
            outFile.delete()
            withContext(Dispatchers.Main) {
                ocrView.showError(
                    coreService,
                    coreService.getString(R.string.ocr_error_capture_failed)
                )
            }
            return null
        }

        // 裁剪状态栏区域
        val croppedBitmap = cropScreenshotTop(bitmap).also { cropped ->
            if (cropped !== bitmap) bitmap.recycle()
        }

        // 缩小图片加速 OCR（短边缩到 OCR_MAX_SHORT_EDGE，像素量大幅减少）
        val (srcW, srcH) = croppedBitmap.width to croppedBitmap.height
        val scaledBitmap = scaleDownForOcr(croppedBitmap).also { scaled ->
            if (scaled !== croppedBitmap) croppedBitmap.recycle()
        }
        Logger.d("Image scaled: ${srcW}x${srcH} -> ${scaledBitmap.width}x${scaledBitmap.height}")

        // 将缩小后的图片编码为 JPEG Base64（供后续存储/发AI）
        val imageBase64 = bitmapToBase64(scaledBitmap)

        val text = if (useVision) {
            ""
        } else {
            // 截图完成，显示顶部横幅"正在OCR识别"（截图干净，不会被污染）
            withContext(Dispatchers.Main) {
                ocrView.show(coreService, coreService.getString(R.string.ocr_status_recognizing))
            }
            // 规则模式：需 OCR 文本做规则匹配
            runCatching {
                ocrProcessor.startProcess(scaledBitmap)
            }.getOrElse {
                Logger.e("OCR recognition failed: ${it.message}")
                outFile.delete()
                scaledBitmap.recycle()
                withContext(Dispatchers.Main) {
                    ocrView.showError(
                        coreService,
                        coreService.getString(R.string.ocr_error_ocr_failed)
                    )
                }
                return null
            }.also {
                // 识别结果为空
                if (it.isBlank()) {
                    withContext(Dispatchers.Main) {
                        ocrView.showError(
                            coreService,
                            coreService.getString(R.string.ocr_error_empty_result)
                        )
                    }
                    outFile.delete()
                    return null
                }
            }
        }

        scaledBitmap.recycle()
        outFile.delete()

        return if (useVision) "data:image/png;base64,${imageBase64}" else text
    }

    /**
     * 缩小 Bitmap 加速 OCR：短边不超过 [OCR_MAX_SHORT_EDGE]。
     * 对于 OCR 文字识别，720px 短边足够清晰，像素量比 1440p 减少 75%。
     * @return 缩小后的 Bitmap，如果已足够小则原样返回
     */
    private fun scaleDownForOcr(source: Bitmap): Bitmap {
        val shortSide = minOf(source.width, source.height)
        if (shortSide <= OCR_MAX_SHORT_EDGE) return source

        val scale = OCR_MAX_SHORT_EDGE.toFloat() / shortSide
        val newW = (source.width * scale).toInt()
        val newH = (source.height * scale).toInt()
        return source.scale(newW, newH)
    }

    /**
     * 将 Bitmap 压缩为 JPEG 并编码为 Base64
     * @param bitmap 位图（不回收，调用方负责）
     * @return Base64 字符串
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 60, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * 裁剪截图顶部区域，移除系统导航栏与状态栏。
     * @param source 原始截图
     * @return 去掉顶部导航栏后的位图
     */
    private fun cropScreenshotTop(source: Bitmap): Bitmap {
        val cropHeight = DisplayUtils.getStatusBarHeight(coreService)
        if (cropHeight <= 0) return source
        if (source.height <= cropHeight) return source
        return Bitmap.createBitmap(source, 0, cropHeight, source.width, source.height - cropHeight)
    }
    /**
     * 将识别结果交给 JS 引擎做规则/AI 识别。
     * 开启视觉识别时传 image，body 为 data:image/xxx;base64,xxx，服务端据此识别为图片。
     */
    private suspend fun send2JsEngine(
        text: String,
        app: String,
        manual: Boolean = false
    ): ResultModel<BillResultModel> {
        val useVision = PrefManager.aiVisionRecognition
        Logger.d("app=$app, text=${text.take(80)}..., useVision=$useVision, manual=$manual")
        val result = JsAPI.analysis(
            DataType.OCR,
            text,
            app,
            fromAppData = false,
            manual = manual,
        )

        if (result.data != null) {
            Logger.i("Bill recognized: ${result.data?.billInfoModel}")
        } else {
            Logger.w("Analysis failed(${result.code}): ${result.msg}")
        }
        return result
    }

    companion object : IService {

        /** 服务启动状态 */
        var serverStarted = false

        /**
         * 检查是否有使用情况访问权限
         */
        override fun hasPermission(): Boolean {
            return OcrTools.hasPermission()
        }

        /**
         * 启动权限设置页面
         */
        override fun startPermissionActivity(context: Context) {

        }

        /**
         * OCR 识别时图片短边最大值（px）。
         * 720px 对文字识别足够清晰，像素量比 1440p 减少约 75%，OCR 速度显著提升。
         */
        private const val OCR_MAX_SHORT_EDGE = 720

    }
}



