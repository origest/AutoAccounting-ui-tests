package net.ankio.auto.service

import android.app.Service
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*
import androidx.core.app.NotificationCompat
import net.ankio.auto.R
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.service.host.OwnerHttpRuntime
import net.ankio.auto.ui.activity.MainActivity
import net.ankio.auto.storage.Logger

/** Minimal Xposed app host. No OCR, sensor, overlay, new process or credential storage. */
class OwnerHostForegroundService : Service() {
    private var lease = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var acquired = false
    private var promoted = false
    override fun onCreate() {
        super.onCreate()
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("owner_http", "自动记账接收服务", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val retry = PendingIntent.getService(this, 1, Intent(this, OwnerHostForegroundService::class.java).setAction("RETRY"), PendingIntent.FLAG_IMMUTABLE)
            val builder = NotificationCompat.Builder(this, "owner_http")
                .setSmallIcon(R.drawable.icon_auto).setContentTitle("自动记账接收服务")
                .setContentText("本机接收服务启动中")
                .setContentIntent(open).addAction(R.drawable.icon_auto, "重试连接", retry).setOngoing(true).setSilent(true)
            val notification = builder.build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(1001, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1001, notification)
            promoted = true
            scope.launch {
                OwnerHttpRuntime.status.collect { state ->
                    val text = when (state) {
                        "RUNNING" -> "本机接收服务已就绪"
                        "WAITING_PORT" -> "端口被占用，尚未就绪"
                        "EXHAUSTED", "CLEANUP_UNKNOWN", "UNAVAILABLE" -> "接收服务不可用，请打开应用检查"
                        "STOPPED", "DISABLED" -> "接收服务已停止"
                        else -> "接收服务正在启动或有限重试"
                    }
                    nm.notify(1001, builder.setContentText(text).build())
                }
            }
        } catch (_: RuntimeException) {
            Logger.w("Owner foreground service promotion failed")
            stopSelf()
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!promoted || !WorkMode.isXposed()) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == "RETRY" && acquired) OwnerHttpRuntime.retryExplicitly()
        if (!acquired) { acquired = true; OwnerHttpRuntime.acquire(lease) }
        return START_STICKY
    }
    override fun onDestroy() {
        scope.cancel()
        if (acquired) { acquired = false; OwnerHttpRuntime.release(lease) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        /** Called from visible activities, never from hook callbacks or background broadcasts. */
        fun reconcile(activity: android.app.Activity) {
            val intent = Intent(activity, OwnerHostForegroundService::class.java)
            if (WorkMode.isXposed()) {
                runCatching { activity.startForegroundService(intent) }
                    .onFailure { Logger.w("Owner foreground start unavailable") }
            } else activity.stopService(intent)
        }
    }
}
