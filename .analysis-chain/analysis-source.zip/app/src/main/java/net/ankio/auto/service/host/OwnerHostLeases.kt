package net.ankio.auto.service.host

import net.ankio.auto.xposed.hooks.common.HostRecoveryController

/** All methods run on one non-main executor. Generation invalidates delayed/stale work.
 * Only this object owns the engine; releasing an old service cannot stop a newer lease.
 */
internal class OwnerHostLeases(
    private val running: () -> Boolean,
    private val cleanupUnknown: () -> Boolean,
    private val occupied: () -> Boolean,
    private val start: () -> Unit,
    private val stop: () -> Unit,
    private val ready: (Boolean) -> Unit,
) {
    private val leases = mutableSetOf<Any>()
    private var controller: HostRecoveryController? = null
    var generation = 0L; private set
    val state get() = controller?.state
    val active get() = leases.isNotEmpty()
    fun acquire(token: Any): Long? {
        if (!leases.add(token) || leases.size != 1) { ready(running() && !cleanupUnknown()); return null }
        generation++
        controller = HostRecoveryController(running, cleanupUnknown, occupied, start, stop)
        return generation
    }
    fun retryExplicitly(): Long? {
        if (!active || cleanupUnknown() || running()) return null
        controller?.disable()
        generation++
        controller = HostRecoveryController(running, cleanupUnknown, occupied, start, stop)
        return generation
    }
    fun tick(expected: Long): Long? {
        if (expected != generation || !active) return null
        val delay = controller?.tick()
        ready(running() && !cleanupUnknown())
        return delay
    }
    fun release(token: Any) {
        if (!leases.remove(token)) return
        if (active) { ready(running() && !cleanupUnknown()); return }
        generation++
        controller?.disable()
        ready(false)
        try { stop() } finally { controller = null }
    }
}
