package net.ankio.auto.service.host

import java.util.concurrent.Executor
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

/** Caller cancellation/timeout never waits for a blocked executor task to finish. */
internal suspend fun awaitOwnerReady(worker: Executor, state: StateFlow<Boolean>, timeoutMillis: Long = 8_000): Boolean =
    withTimeoutOrNull(timeoutMillis) {
        val accepted = CompletableDeferred<Unit>()
        worker.execute { accepted.complete(Unit) }
        accepted.await() // FIFO: earlier service acquire/release has been processed.
        state.first { it }
    } == true
