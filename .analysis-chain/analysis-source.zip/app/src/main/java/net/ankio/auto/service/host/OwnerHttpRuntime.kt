package net.ankio.auto.service.host

import net.ankio.auto.BuildConfig
import net.ankio.auto.autoApp
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.storage.Logger
import net.ankio.auto.xposed.core.utils.AppRuntime
import net.ankio.auto.xposed.hooks.auto.AutoHooker
import net.ankio.auto.xposed.hooks.common.JsEngine
import net.ankio.auto.xposed.hooks.common.UnLockScreen
import org.ezbook.server.Server
import org.ezbook.server.ai.tools.ChatGptCategoryGateway
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** App-classloader only. Xposed hooks never enter this runtime. Same app Context/DB/UID. */
internal object OwnerHttpRuntime {
    private val worker = ScheduledThreadPoolExecutor(1) { r ->
        Thread(r, "AutoAccounting-owner-http").apply { isDaemon = true }
    }.apply { removeOnCancelPolicy = true }
    private val mutableStatus = kotlinx.coroutines.flow.MutableStateFlow("STOPPED")
    val status: kotlinx.coroutines.flow.StateFlow<String> = mutableStatus
    private var pending: java.util.concurrent.ScheduledFuture<*>? = null
    private var server: Server? = null
    private var nativeReady = false
    private var unlockRegistered = false
    @Volatile private var serving = false
    @Volatile private var currentGeneration = 0L
    private var lastMode: net.ankio.auto.constant.WorkMode? = null
    private val readyState = kotlinx.coroutines.flow.MutableStateFlow(false)
    suspend fun awaitReady(): Boolean = awaitOwnerReady(worker, readyState)
    private val leases = OwnerHostLeases(
        running = { server?.isRunning == true },
        cleanupUnknown = { server?.cleanupUnknown == true },
        occupied = { Server.isPortOccupied() },
        start = {
            val app = autoApp
            if (!nativeReady) {
                AppRuntime.manifest = AutoHooker()
                AppRuntime.modulePath = app.applicationInfo.sourceDir
                AppRuntime.classLoader = app.classLoader
                AppRuntime.application = app
                JsEngine.init()
                nativeReady = true
            }
            val host = server ?: Server(app, controlledRecovery = true, bindHost = "127.0.0.1").also { server = it }
            Server.packageName = BuildConfig.APPLICATION_ID
            Server.versionName = BuildConfig.VERSION_NAME
            Server.versionCode = BuildConfig.VERSION_CODE
            Server.debugPackage = BuildConfig.DEBUG
            host.startServer()
            if (!unlockRegistered) {
                // Register once, with an explicit inactive gate. No package-update kill receiver.
                unlockRegistered = true
                runCatching { UnLockScreen.init({ serving && WorkMode.isXposed() }, { currentGeneration }) }
                    .onFailure { Logger.w("Owner HTTP unlock registration unavailable") }
            }
        },
        stop = { server?.stopServer() },
        ready = {
            val mode = net.ankio.auto.utils.PrefManager.workMode
            if (lastMode != mode || serving != it) currentGeneration++
            lastMode = mode
            serving = it
            readyState.value = it
            // Direct gateway stays OCR/LSPatch-only; Xposed uses its existing owner queue.
            ChatGptCategoryGateway.ownerReady = it && WorkMode.isOcrOrLSPatch()
        },
    )
    fun acquire(token: Any) {
        worker.execute { runCatching { leases.acquire(token)?.let { pending?.cancel(false); tick(it) } }.onFailure { unavailable() } }
    }
    fun retryExplicitly() {
        worker.execute {
            runCatching { leases.retryExplicitly()?.let { pending?.cancel(false); tick(it) } }
                .onFailure { unavailable() }
        }
    }
    fun release(token: Any) {
        worker.execute {
            try {
                leases.release(token)
                if (!leases.active) mutableStatus.value = "STOPPED"
            } catch (_: Exception) { unavailable() }
            finally { if (!leases.active) { pending?.cancel(false); pending = null } }
        }
    }
    private fun tick(generation: Long) {
        if (generation != leases.generation || !leases.active) return
        val delay = runCatching { leases.tick(generation) }.getOrElse { unavailable(); return }
        mutableStatus.value = leases.state?.name ?: "STOPPED"
        if (delay != null) pending = worker.schedule({ tick(generation) }, delay, TimeUnit.MILLISECONDS)
    }
    private fun unavailable() {
        mutableStatus.value = if (server?.cleanupUnknown == true) "CLEANUP_UNKNOWN" else "UNAVAILABLE"
        currentGeneration++
        serving = false
        readyState.value = false
        ChatGptCategoryGateway.ownerReady = false
        Logger.w("Owner HTTP unavailable; no unbounded restart or foreign listener cleanup")
    }
}
