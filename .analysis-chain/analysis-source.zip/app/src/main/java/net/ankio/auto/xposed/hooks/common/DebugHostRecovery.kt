package net.ankio.auto.xposed.hooks.common

import android.app.Application
import net.ankio.auto.BuildConfig
import net.ankio.auto.xposed.core.logger.XposedLogger
import net.ankio.auto.xposed.core.utils.AppRuntime
import org.ezbook.server.Server
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** Lives only inside the existing debug owner process. Does not keep or restart that process alive. */
internal object DebugHostRecovery {
    private var initialized = false
    private var controller: HostRecoveryController? = null
    private var executor: ScheduledThreadPoolExecutor? = null

    fun eligible(debug: Boolean, manifestPackage: String, ownerPackage: String): Boolean =
        debug && manifestPackage == ownerPackage

    @Synchronized fun begin(application: Application) {
        if (!BuildConfig.DEBUG || application.packageName != BuildConfig.APPLICATION_ID) return
        if (initialized) return
        initialized = true
        var server: Server? = null
        var librariesInitialized = false
        var registrationsAttempted = false
        val worker = ScheduledThreadPoolExecutor(1) { task ->
            Thread(task, "AutoAccounting-owned-host-recovery").apply { isDaemon = true }
        }.apply {
            removeOnCancelPolicy = true
            setExecuteExistingDelayedTasksAfterShutdownPolicy(false)
        }
        val recovery = HostRecoveryController(
            isRunning = { server?.isRunning == true },
            cleanupUnknown = { server?.cleanupUnknown == true },
            portOccupied = { Server.isPortOccupied() },
            startOwned = {
                if (!librariesInitialized) { JsEngine.init(); librariesInitialized = true }
                val host = server ?: Server(application, controlledRecovery = true).also { server = it }
                Server.versionName = BuildConfig.VERSION_NAME
                Server.packageName = BuildConfig.APPLICATION_ID
                Server.versionCode = BuildConfig.VERSION_CODE
                Server.debugPackage = BuildConfig.DEBUG
                host.startServer()
                if (!registrationsAttempted) {
                    // Set before either registration: partial failure must not duplicate receivers.
                    registrationsAttempted = true
                    AppInstaller.init(application, host) {
                        disable()
                        // The existing upgrade flow immediately terminates this process.
                        // Do not block its main thread on a concurrently admitted startup.
                        host.tryStopBeforeProcessExit()
                    }
                    runCatching { UnLockScreen.init() }
                        .onFailure { XposedLogger.w("OwnedHost stage=unlock_registration_failed") }
                }
            },
            stopOwned = { server?.stopServer() },
        )
        controller = recovery
        executor = worker
        var lastState: HostRecoveryController.State? = null
        val task = object : Runnable {
            override fun run() {
                val delay = recovery.tick()
                val state = recovery.state
                if (state != lastState || state != HostRecoveryController.State.RUNNING) {
                    runCatching { XposedLogger.i("OwnedHost stage=${state.name.lowercase()} attempt=${recovery.attempts}") }
                    lastState = state
                }
                if (delay != null && !worker.isShutdown) {
                    runCatching { worker.schedule(this, delay, TimeUnit.MILLISECONDS) }
                } else worker.shutdown()
            }
        }
        worker.execute(task)
    }

    @Synchronized fun disable() {
        controller?.disable()
        executor?.shutdown()
    }
}
