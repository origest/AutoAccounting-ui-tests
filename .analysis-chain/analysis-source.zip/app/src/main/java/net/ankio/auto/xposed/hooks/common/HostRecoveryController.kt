package net.ankio.auto.xposed.hooks.common

import java.util.concurrent.atomic.AtomicBoolean

/** One process-lifetime attempt budget. Call tick on one worker; no business request replay. */
internal class HostRecoveryController(
    private val isRunning: () -> Boolean,
    private val cleanupUnknown: () -> Boolean,
    private val portOccupied: () -> Boolean,
    private val startOwned: () -> Unit,
    private val stopOwned: () -> Unit,
    private val maxAttempts: Int = 8,
) {
    enum class State { NEW, STARTING, RUNNING, WAITING_PORT, RETRY_WAIT, CLEANUP_UNKNOWN, DISABLED, EXHAUSTED }
    private val disabled = AtomicBoolean(false)
    @Volatile var state = State.NEW; private set
    var attempts = 0; private set
    fun disable() { disabled.set(true) }

    @Synchronized fun tick(): Long? {
        if (disabled.get()) { state = if (cleanupUnknown()) State.CLEANUP_UNKNOWN else State.DISABLED; return null }
        if (cleanupUnknown()) { state = State.CLEANUP_UNKNOWN; return null }
        if (isRunning()) { state = State.RUNNING; return 30_000 }
        if (attempts >= maxAttempts) { state = State.EXHAUSTED; return null }
        attempts++
        try {
            // Reclaim only our already-stopped engine before probing the shared port.
            // Otherwise its own remaining listener could be mistaken for a foreign occupant.
            stopOwned()
            if (portOccupied()) { state = State.WAITING_PORT; return backoff() }
            if (disabled.get()) { state = if (cleanupUnknown()) State.CLEANUP_UNKNOWN else State.DISABLED; return null }
            state = State.STARTING
            startOwned()
            if (disabled.get()) {
                try { stopOwned() } finally { state = State.DISABLED }
                return null
            }
            state = if (isRunning()) State.RUNNING else State.RETRY_WAIT
        } catch (_: Throwable) {
            state = when {
                cleanupUnknown() -> State.CLEANUP_UNKNOWN
                disabled.get() -> State.DISABLED
                else -> State.RETRY_WAIT
            }
        }
        return when (state) {
            State.DISABLED, State.CLEANUP_UNKNOWN -> null
            State.RUNNING -> 30_000
            else -> backoff()
        }
    }

    private fun backoff(): Long = longArrayOf(1_000, 2_000, 5_000, 10_000, 30_000, 60_000)[(attempts - 1).coerceIn(0, 5)]
}
