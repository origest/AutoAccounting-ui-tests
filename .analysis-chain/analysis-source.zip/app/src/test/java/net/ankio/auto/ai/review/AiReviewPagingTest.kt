package net.ankio.auto.ai.review

import org.junit.Assert.*
import org.junit.Test

class AiReviewPagingTest {
    @Test fun predicatePrecedesBoundAndStateMappingIsComplete() {
        for (tab in AiReviewTab.entries) {
            val query = AiReviewPaging.query(tab, null, 100)
            assertTrue(query.sql.contains("WHERE ${AiReviewPaging.where(tab)} ORDER BY created DESC,id ASC LIMIT ?"))
            assertEquals(listOf("101"), query.args.toList())
        }
        assertEquals(AiReviewTab.QUEUE, AiReviewTab.from("unknown"))
        assertTrue(AiReviewPaging.PENDING_WHERE.contains("REVIEW"))
    }
    @Test fun sameTimestampTieIsExclusiveAndNewerRowsDoNotShiftOlderPage() {
        val query = AiReviewPaging.query(AiReviewTab.PENDING, AiReviewCursor(1000, "middle"), 100)
        assertTrue(query.sql.contains("created<=? AND (created<? OR id>?)"))
        assertEquals(listOf("1000", "1000", "middle", "101"), query.args.toList())
        assertFalse(query.sql.contains("OFFSET"))
    }
    @Test fun pageLimitCannotBeDisabledOrInflated() {
        for (size in listOf(0, -1, 101, Int.MAX_VALUE)) {
            try { AiReviewPaging.query(AiReviewTab.HISTORY, null, size); fail("Expected bounded limit") }
            catch (_: IllegalArgumentException) { }
        }
        assertEquals("2", AiReviewPaging.query(AiReviewTab.HISTORY, null, 1).args.last())
    }
    @Test fun migrationIndexesAreAdditiveAndCoverEachTabAndEvidence() {
        val indexes = AiReviewPaging.indexes()
        assertTrue(indexes.all { it.startsWith("CREATE INDEX IF NOT EXISTS") })
        assertEquals(3, indexes.count { it.contains("WHERE state") })
        assertTrue(indexes.any { it.contains("task(state,owner)") })
        assertTrue(indexes.any { it.contains("event(task_id,action,sequence DESC)") })
    }
}
