package net.ankio.auto.ai.review

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.junit.Assert.*
import org.junit.Test

/** A controlled tick channel replaces the wall clock; no Android/device or timing benchmark. */
class AiReviewRefreshTest {
    @Test fun stopPausesPollingAndManualRefreshAndResumeStartsOneLoop() = runBlocking {
        val tick = Channel<Unit>(Channel.UNLIMITED)
        val delivered = Channel<Int>(Channel.UNLIMITED)
        var reads = 0
        val controller = AiReviewRefresh(read = { ++reads }, deliver = { delivered.trySend(it) }, failure = { fail("Unexpected error") }, tick = { tick.receive() })
        val first = launch { controller.runWhileVisible() }
        assertEquals(1, withTimeout(1000) { delivered.receive() })
        first.cancelAndJoin()
        repeat(5) { controller.refresh(); tick.trySend(Unit) }
        yield()
        assertEquals(1, reads)
        while (tick.tryReceive().isSuccess) { }
        val second = launch { controller.runWhileVisible() }
        assertEquals(2, withTimeout(1000) { delivered.receive() })
        tick.send(Unit)
        assertEquals(3, withTimeout(1000) { delivered.receive() })
        second.cancelAndJoin()
    }
    @Test fun stoppedSlowReadCannotUpdateUiOrLaunchHistory() = runBlocking {
        val entered = CompletableDeferred<Unit>()
        var rendered = 0
        var cancelled = false
        val controller = AiReviewRefresh<Int>(read = {
            entered.complete(Unit)
            try { awaitCancellation() } finally { cancelled = true }
        }, deliver = { rendered++ }, failure = { fail("Cancellation is not failure") }, tick = { awaitCancellation() })
        val visible = launch { controller.runWhileVisible() }
        entered.await(); visible.cancelAndJoin()
        assertTrue(cancelled); assertEquals(0, rendered)
        assertNull(controller.launchVisible { rendered++ })
        controller.refresh(); yield(); assertEquals(0, rendered)
    }
    @Test fun repeatedTicksAndTapsNeverStackSlowQueries() = runBlocking {
        val tick = Channel<Unit>(Channel.UNLIMITED)
        val entered = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>()
        val done = CompletableDeferred<Unit>(); var reads = 0
        val controller = AiReviewRefresh(read = { reads++; entered.complete(Unit); release.await(); reads },
            deliver = { done.complete(Unit) }, failure = { fail("Unexpected error") }, tick = { tick.receive() })
        val visible = launch { controller.runWhileVisible() }; entered.await()
        repeat(20) { tick.send(Unit); controller.refresh() }; yield()
        assertEquals(1, reads)
        release.complete(Unit); done.await(); visible.cancelAndJoin()
    }
    @Test fun changedTabDiscardsOldResultEvenIfReadFinishesLate() = runBlocking {
        val oldEntered = CompletableDeferred<Unit>(); val releaseOld = CompletableDeferred<Unit>()
        val nextDelivered = CompletableDeferred<Unit>(); val values = mutableListOf<Int>(); var reads = 0
        val controller = AiReviewRefresh(read = {
            val number = ++reads
            if (number == 1) withContext(NonCancellable) { oldEntered.complete(Unit); releaseOld.await() }
            number
        }, deliver = { values.add(it); if (it == 2) nextDelivered.complete(Unit) }, failure = { fail("Unexpected error") }, tick = { awaitCancellation() })
        val visible = launch { controller.runWhileVisible() }; oldEntered.await()
        controller.invalidateAndRefresh(); yield()
        assertEquals(1, reads) // Even an uncancellable old database read cannot overlap the next one.
        releaseOld.complete(Unit); nextDelivered.await(); visible.cancelAndJoin()
        assertEquals(listOf(2), values)
    }
    @Test fun periodicRefreshDoesNotResetSelectedPage() = runBlocking {
        val tick = Channel<Unit>(Channel.UNLIMITED); val delivered = Channel<Int>(Channel.UNLIMITED)
        var selectedPage = 4
        val controller = AiReviewRefresh(read = { selectedPage }, deliver = { delivered.trySend(it) }, failure = { fail() }, tick = { tick.receive() })
        val visible = launch { controller.runWhileVisible() }
        assertEquals(4, delivered.receive())
        tick.send(Unit); assertEquals(4, delivered.receive())
        selectedPage = 0; controller.invalidateAndRefresh(); assertEquals(0, delivered.receive())
        visible.cancelAndJoin()
    }
}
