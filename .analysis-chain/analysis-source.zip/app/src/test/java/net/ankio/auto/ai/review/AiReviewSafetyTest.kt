package net.ankio.auto.ai.review

import org.junit.Assert.*
import org.junit.Test

class AiReviewSafetyTest {
    @Test fun safeLocalReferencesOnly() {
        assertTrue(AiReviewSafety.target(AiReviewTarget("ocr-local", 1, 0, "a".repeat(32))))
        assertFalse(AiReviewSafety.target(AiReviewTarget("merchant text", 1, 0, "raw OCR text")))
        assertTrue(AiReviewSafety.changes(AiReviewKind.ASSET, listOf(AiReviewChange("ASSET_FROM", "1", "2"))))
        assertFalse(AiReviewSafety.changes(AiReviewKind.ASSET, listOf(AiReviewChange("ASSET_FROM", "1", "bank name"))))
        assertTrue(AiReviewSafety.changes(AiReviewKind.OCR, listOf(AiReviewChange("OCR_BILL", "", "42"))))
        assertFalse(AiReviewSafety.changes(AiReviewKind.OCR, listOf(AiReviewChange("OCR_BILL", "", "payment 42 CNY"))))
    }
    @Test fun structuredNewAssetsHaveNoAccountIdentifiers() {
        assertTrue(AiReviewSafety.changes(AiReviewKind.ASSET, listOf(AiReviewChange("ASSET_FROM", "", "", true, "CASH", "CNY"))))
        assertFalse(AiReviewSafety.changes(AiReviewKind.ASSET, listOf(AiReviewChange("ASSET_FROM", "", "123", true, "CASH", "CNY"))))
        assertFalse(AiReviewSafety.changes(AiReviewKind.ASSET, listOf(AiReviewChange("ASSET_FROM", "", "", true, "user bank name", "CNY"))))
    }
    @Test fun rejectWrongFieldsDuplicatesAndUnsafeCategoryNames() {
        assertFalse(AiReviewSafety.changes(AiReviewKind.CATEGORY, emptyList()))
        assertFalse(AiReviewSafety.changes(AiReviewKind.CATEGORY, listOf(AiReviewChange("RAW_RESPONSE", "", "text"))))
        val category = AiReviewChange("CATEGORY", "其他", "餐饮")
        assertTrue(AiReviewSafety.changes(AiReviewKind.CATEGORY, listOf(category)))
        assertFalse(AiReviewSafety.changes(AiReviewKind.CATEGORY, listOf(category, category)))
        assertFalse(AiReviewSafety.changes(AiReviewKind.CATEGORY, listOf(category.copy(after = "user@example.com"))))
        assertFalse(AiReviewSafety.changes(AiReviewKind.CATEGORY, listOf(category.copy(after = "账号12345", createsNew = true))))
        assertEquals("REQUEST_FAILED", AiReviewSafety.error("exception containing secret or raw bill"))
    }
    @Test fun conservativeDefaultsAndIndependentRiskAcknowledgedCreationPreference() {
        val change = listOf(AiReviewChange("CATEGORY", "其他", "宠物", true))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(), AiReviewKind.CATEGORY, change))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(autoApplyCategory = true), AiReviewKind.CATEGORY, change))
        assertTrue(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(autoApplyCategory = true, confirmNewCategory = false), AiReviewKind.CATEGORY, change))
        assertTrue(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(confirmNewCategory = false), AiReviewKind.CATEGORY, change))
        val mixed = listOf(AiReviewChange("ASSET_FROM", "1", "2"), AiReviewChange("ASSET_TO", "", "", true, "CASH", "CNY"))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(confirmNewAsset = false), AiReviewKind.ASSET, mixed))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(autoApplyAssets = true), AiReviewKind.ASSET, mixed))
        assertTrue(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(autoApplyAssets = true, confirmNewAsset = false), AiReviewKind.ASSET, mixed))
    }
    @Test fun ownerCategoryUsesCategoryValidationAndPolicy() {
        val change = listOf(AiReviewChange("CATEGORY", "其他", "餐饮"))
        assertTrue(AiReviewSafety.changes(AiReviewKind.OWNER_CATEGORY, change))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(), AiReviewKind.OWNER_CATEGORY, change))
        assertTrue(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(autoApplyCategory = true), AiReviewKind.OWNER_CATEGORY, change))
        assertFalse(AiReviewSafety.changes(AiReviewKind.OWNER_CATEGORY, listOf(AiReviewChange("ASSET_FROM", "1", "2"))))
    }

    @Test fun ocrCategoryRemainsSeparateAndRequiresMatchingPolicy() {
        val existing = listOf(AiReviewChange("CATEGORY", "其他", "餐饮"))
        val created = listOf(AiReviewChange("CATEGORY", "其他", "宠物", true))
        assertTrue(AiReviewSafety.changes(AiReviewKind.OCR_CATEGORY, existing))
        assertFalse(AiReviewSafety.changes(AiReviewKind.OCR_CATEGORY, listOf(AiReviewChange("OCR_BILL", "", "42"))))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(), AiReviewKind.OCR_CATEGORY, existing))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(autoApplyCategory = true), AiReviewKind.OCR_CATEGORY, created))
        assertTrue(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(confirmNewCategory = false), AiReviewKind.OCR_CATEGORY, created))
        assertFalse(AiReviewPolicy.permitsAutomatic(AiReviewPolicy.Settings(confirmNewCategory = false), AiReviewKind.OCR_CATEGORY, existing))
    }

}
