package net.ankio.auto.ai.review

import org.ezbook.server.constant.BillState
import org.ezbook.server.db.model.BillInfoModel
import org.junit.Assert.*
import org.junit.Test

class ManualEditEvidenceTest {
    private val original = BillInfoModel(id = 42, categoryRevision = 3, cateName = "其他")
    private val target = AiReviewTarget("ocr-local", 42, 3, original.hash())
    private val expected = original.copy(cateName = "餐饮", state = BillState.Edited, auto = false)
    private val saved = expected.copy(categoryRevision = 4, categoryOrigin = "MANUAL")
    @Test fun confirmedManualSaveMatches() { assertTrue(ManualEditEvidence.matches(saved, expected, target)) }
    @Test fun syncCanAdvanceStateBeforeReadback() { assertTrue(ManualEditEvidence.matches(saved.copy(state = BillState.Synced, categoryRevision = 5), expected, target)) }
    @Test fun anotherEditIsNotMistakenForThisSave() { assertFalse(ManualEditEvidence.matches(saved.copy(money = expected.money + 1), expected, target)) }
    @Test fun unconfirmedDraftAndAiOriginCannotCompleteManualHistory() {
        assertFalse(ManualEditEvidence.matches(saved.copy(state = BillState.Wait2Edit), expected, target))
        assertFalse(ManualEditEvidence.matches(saved.copy(categoryOrigin = "AI"), expected, target))
    }
    @Test fun unchangedRevisionAndDifferentIdentityAreRejected() {
        assertFalse(ManualEditEvidence.matches(saved.copy(categoryRevision = 3), expected, target))
        assertFalse(ManualEditEvidence.matches(saved.copy(id = 43), expected, target))
    }
}
