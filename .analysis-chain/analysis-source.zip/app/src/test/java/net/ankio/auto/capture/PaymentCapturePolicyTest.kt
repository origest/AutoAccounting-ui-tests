package net.ankio.auto.capture

import org.junit.Assert.*
import org.junit.Test

class PaymentCapturePolicyTest {
    private val pkg = "com.tencent.mm"
    private val activity = "fixture.Success"
    private val shape = "0:Root;1:Title;1:Done"
    private val saved = PaymentCapturePolicy.digest(activity + "\n" + shape)
    private val success = listOf("支付成功", "完成", "¥1.00")
    @Test fun automaticCaptureRequiresRegistrationAndExactPage() {
        assertFalse(PaymentCapturePolicy.matches(pkg, activity, shape, null, success))
        assertTrue(PaymentCapturePolicy.matches(pkg, activity, shape, saved, success))
        assertFalse(PaymentCapturePolicy.matches(pkg, "fixture.Chat", shape, saved, success))
        assertFalse(PaymentCapturePolicy.matches(pkg, activity, shape + "1:Chat", saved, success))
    }
    @Test fun spoofedOtherPackageCannotTriggerEvenWithMatchingText() {
        assertFalse(PaymentCapturePolicy.matches("attacker.app", activity, shape, saved, success))
        assertFalse(PaymentCapturePolicy.matches("com.tencent.mm.fake", activity, shape, saved, success))
    }
    @Test fun conversationAndFailureTextAreNotPaymentSuccess() {
        for (texts in listOf(listOf("支付成功了吗？", "完成"), listOf("支付失败", "完成"), listOf("支付成功"), listOf("支付中", "完成")))
            assertFalse(PaymentCapturePolicy.matches(pkg, activity, shape, saved, texts))
    }
    @Test fun fingerprintDoesNotCollapseDistinctAmountsAndRepeatedContentIsStable() {
        assertEquals(PaymentCapturePolicy.digest("fixture\n1.00"), PaymentCapturePolicy.digest("fixture\n1.00"))
        assertNotEquals(PaymentCapturePolicy.digest("fixture\n1.00"), PaymentCapturePolicy.digest("fixture\n2.00"))
    }
}
