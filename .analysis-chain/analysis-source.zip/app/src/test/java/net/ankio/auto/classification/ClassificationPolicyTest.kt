package net.ankio.auto.classification

import net.ankio.auto.classification.ClassificationPolicy.Mode
import net.ankio.auto.classification.ClassificationPolicy.Origin
import net.ankio.auto.classification.ClassificationPolicy.State
import net.ankio.auto.classification.ClassificationPolicy.Snapshot
import net.ankio.auto.classification.ClassificationPolicy.Ticket
import org.junit.Assert.*
import org.junit.Test

class ClassificationPolicyTest {
    private val bill = Snapshot("source-a", 42, 5, Mode.XPOSED, Origin.RULE, "其他")
    private fun reserved() = ClassificationPolicy.reserve(Ticket(bill, 3), bill, 3, "attempt-a")!!
    private fun dispatched() = ClassificationPolicy.dispatch(reserved(), bill, 3, true)

    @Test fun xposedRulesKeepAssignedCategories() {
        for (category in listOf("其他", "其它", " 其他 "))
            assertTrue(ClassificationPolicy.eligible(bill.copy(category = category)))
        for (category in listOf("", "餐饮", "餐饮 - 其他", "Other"))
            assertFalse(ClassificationPolicy.eligible(bill.copy(category = category)))
    }
    @Test fun ocrKeepsRuleCategoriesAndNeverOverwritesManualOrAi() {
        for (category in listOf("", "餐饮", "餐饮 - 其他", "交通", "Other"))
            assertFalse(ClassificationPolicy.eligible(bill.copy(mode = Mode.OCR, category = category)))
        for (category in listOf("其他", "其它", " 其他 "))
            assertTrue(ClassificationPolicy.eligible(bill.copy(mode = Mode.OCR, category = category)))
        for (mode in Mode.entries) for (origin in listOf(Origin.MANUAL, Origin.AI, Origin.LEGACY_UNKNOWN))
            assertFalse(ClassificationPolicy.eligible(bill.copy(mode = mode, origin = origin)))
    }
    @Test fun pendingCategoryAndGroupedChildrenNeverStartAnotherRequest() {
        assertFalse(ClassificationPolicy.eligible(bill.copy(pendingProposal = true)))
        assertFalse(ClassificationPolicy.eligible(bill.copy(groupedChild = true)))
    }
    @Test fun offlineBeforeDispatchRemainsRetryableWithoutAnAttempt() {
        val retry = ClassificationPolicy.dispatch(reserved(), bill, 3, false)
        assertEquals(State.READY, retry.state)
        assertEquals("", retry.attemptId)
        assertNotNull(ClassificationPolicy.reserve(retry, bill, 3, "attempt-b"))
    }
    @Test fun timeoutAfterDispatchCannotBeAutomaticallyRetried() {
        val uncertain = ClassificationPolicy.uncertain(dispatched())
        assertEquals(State.UNKNOWN, uncertain.state)
        assertNull(ClassificationPolicy.reserve(uncertain, bill, 3, "attempt-b"))
    }
    @Test fun processDeathDistinguishesReservedFromPossiblySent() {
        assertEquals(State.READY, ClassificationPolicy.recover(reserved()).state)
        assertEquals(State.UNKNOWN, ClassificationPolicy.recover(dispatched()).state)
    }
    @Test fun doubleClaimAndReplayedCompletionAreRejected() {
        assertNull(ClassificationPolicy.reserve(reserved(), bill, 3, "attempt-b"))
        val sent = dispatched()
        assertNull(ClassificationPolicy.complete(sent, bill, 3, "attempt-b"))
        val done = ClassificationPolicy.complete(sent, bill, 3, "attempt-a")!!
        assertNull(ClassificationPolicy.complete(done, bill, 3, "attempt-a"))
        assertNull(ClassificationPolicy.reserve(done, bill, 3, "attempt-c"))
    }
    @Test fun manualEditWhileInferenceRunsRejectsLateResult() {
        assertNull(ClassificationPolicy.complete(dispatched(), bill.copy(origin = Origin.MANUAL), 3, "attempt-a"))
        assertNull(ClassificationPolicy.complete(dispatched(), bill.copy(revision = 6), 3, "attempt-a"))
    }
    @Test fun reusedNumericIdInAnotherSourceCannotReceiveResult() {
        assertNull(ClassificationPolicy.complete(dispatched(), bill.copy(source = "source-b"), 3, "attempt-a"))
    }
    @Test fun revocationBeforeDispatchAndAfterDispatchBothPreventApply() {
        assertEquals(State.CANCELLED, ClassificationPolicy.dispatch(reserved(), bill, 4, true).state)
        assertNull(ClassificationPolicy.complete(dispatched(), bill, 4, "attempt-a"))
    }
    @Test fun cancellationOfSentWorkNeverMakesItAutomaticallyRetryable() {
        val cancelled = ClassificationPolicy.cancel(dispatched())
        assertEquals(State.UNKNOWN, cancelled.state)
        assertNull(ClassificationPolicy.complete(cancelled, bill, 3, "attempt-a"))
    }
    @Test fun sourceEditsBeforeDispatchMakeTicketStale() {
        assertEquals(State.STALE, ClassificationPolicy.dispatch(reserved(), bill.copy(revision = 6), 3, true).state)
    }
}
