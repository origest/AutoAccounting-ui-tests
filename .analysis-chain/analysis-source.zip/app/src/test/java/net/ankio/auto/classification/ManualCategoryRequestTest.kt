package net.ankio.auto.classification

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import org.ezbook.server.constant.BillState
import org.ezbook.server.constant.BillType
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.CategoryModel
import org.ezbook.server.server.OwnerQueueInput
import org.junit.Assert.*
import org.junit.Test

/** Synthetic bills and in-memory provider only. No real account or network access. */
class ManualCategoryRequestTest {
    private val category = CategoryModel().apply { name = "餐饮"; remoteId = "food"; remoteParentId = "-1"; type = BillType.Expend }
    private val bill = BillInfoModel(id = 42, type = BillType.Expend, bookName = "Synthetic", cateName = "手选", categoryOrigin = "MANUAL")
    private var current = OwnerQueueInput("fixture-source", bill.copy(), listOf(category), emptyList())
    private var authority = "account:model:grant-a"
    private var calls = 0
    private var writes = 0
    private var response = """{"existing":"餐饮","proposed":""}"""
    private var afterInference: () -> Unit = {}
    private var afterRead: () -> Unit = {}
    private fun service(mutex: Mutex = Mutex()) = ManualCategoryRequest(
        authority = { authority },
        read = { current.copy(bill = current.bill.copy()).also { afterRead() } },
        payload = { "synthetic-only" },
        infer = { _, _ -> calls++; afterInference(); response },
        write = { request ->
            writes++
            assertEquals(42L, request.id)
            request.revision == current.bill.categoryRevision && request.original == current.bill.hash()
        }, mutex = mutex)
    private suspend fun ManualCategoryRequest.preview() = request(bill.id, bill.categoryRevision, bill.hash()) {}
    private suspend fun fails(code: String, block: suspend () -> Unit) {
        try { block(); fail("Expected $code") } catch (e: ManualCategoryRequest.Failure) { assertEquals(code, e.code) }
    }

    @Test fun explicitTapUsesManualBillButOnlySuggestsUntilConfirmation() = runBlocking {
        val service = service()
        val preview = service.preview()
        assertEquals("餐饮", preview.suggestion.existing)
        assertEquals(1, calls)
        assertEquals(0, writes)
        assertEquals("手选", current.bill.cateName)
        assertTrue(service.apply(preview))
        assertEquals(1, writes)
    }
    @Test fun staleListRowNeverSends() = runBlocking {
        current.bill.categoryRevision++
        fails("STALE") { service().preview() }
        assertEquals(0, calls)
    }
    @Test fun manualEditDuringInferenceRejectsLateResult() = runBlocking {
        afterInference = { current.bill.categoryRevision++; current.bill.cateName = "最新手选" }
        fails("STALE") { service().preview() }
        assertEquals("最新手选", current.bill.cateName)
        assertEquals(0, writes)
    }
    @Test fun changedContentEvenWithoutRevisionCannotReceiveResult() = runBlocking {
        afterInference = { current.bill.shopName = "Changed merchant" }
        fails("STALE") { service().preview() }
    }
    @Test fun sameNumericIdFromAnotherSourceIsStale() = runBlocking {
        afterInference = { current = current.copy(source = "other-source") }
        fails("STALE") { service().preview() }
    }
    @Test fun revokeBeforeDispatchDoesNotSend() = runBlocking {
        afterRead = { authority = "revoked" }
        fails("AUTH_CHANGED") { service().preview() }
        assertEquals(0, calls)
    }
    @Test fun switchingAccountDuringInferenceRejectsResult() = runBlocking {
        afterInference = { authority = "new-account:model:grant-b" }
        fails("AUTH_CHANGED") { service().preview() }
        assertEquals(0, writes)
    }
    @Test fun invalidAndEmptyRepliesHaveNoWriteOrAutomaticRetry() = runBlocking {
        for (value in listOf("not-json", """{"existing":"","proposed":""}""", """{"existing":"unknown","proposed":""}""")) {
            response = value
            fails("NO_RESULT") { service().preview() }
        }
        assertEquals(3, calls)
        assertEquals(0, writes)
    }
    @Test fun newCategoryIsOnlyAPreview() = runBlocking {
        response = """{"existing":"","proposed":"宠物"}"""
        assertEquals("宠物", service().preview().suggestion.proposed)
        assertEquals(0, writes)
    }
    @Test fun existingPendingSuggestionCannotBeOverwritten() = runBlocking {
        current.bill.pendingCategory = "宠物"
        fails("PENDING") { service().request(42, 0, current.bill.hash()) {} }
        assertEquals(0, calls)
    }
    @Test fun syncedBillsAreReadOnlySuggestions() = runBlocking {
        current.bill.state = BillState.Synced
        val service = service()
        val preview = service.request(42, 0, current.bill.hash()) {}
        assertTrue(preview.readOnly)
        fails("READ_ONLY") { service.apply(preview) }
        assertEquals(0, writes)
    }
    @Test fun editBeforeConfirmationPreventsWrite() = runBlocking {
        val service = service()
        val preview = service.preview()
        current.bill.categoryRevision++
        fails("STALE") { service.apply(preview) }
        assertEquals(0, writes)
    }
    @Test fun revocationBeforeConfirmationPreventsWrite() = runBlocking {
        val service = service()
        val preview = service.preview()
        authority = "revoked"
        fails("AUTH_CHANGED") { service.apply(preview) }
        assertEquals(0, writes)
    }
    @Test fun changedSourceIsRejectedBeforeProviderDispatch() = runBlocking {
        fails("STALE") { service().request(42, 0, bill.hash(), "old-source") {} }
        assertEquals(0, calls)
    }
    @Test fun restoredSuggestionDoesNotContactProvider() = runBlocking {
        val restored = service().restore(current.source, 42, 0, bill.hash(),
            org.ezbook.server.ai.tools.HistoryCategoryTool.Suggestion(existing = "餐饮"))
        assertEquals("餐饮", restored.suggestion.existing)
        assertEquals(0, calls)
        assertEquals(0, writes)
    }
    @Test fun restoredSuggestionChecksSourceAndSnapshot() = runBlocking {
        fails("STALE") { service().restore("wrong-source", 42, 0, bill.hash(),
            org.ezbook.server.ai.tools.HistoryCategoryTool.Suggestion(existing = "餐饮")) }
        assertEquals(0, calls)
    }
    @Test fun changedPolicyImmediatelyBeforeWritePreventsDispatch() = runBlocking {
        val service = service()
        val preview = service.preview()
        fails("POLICY_CHANGED") { service.apply(preview) { throw ManualCategoryRequest.Failure("POLICY_CHANGED") } }
        assertEquals(0, writes)
    }
    @Test fun sharedLockRejectsDoubleTapAndCancellationReleasesIt() = runBlocking {
        val entered = CompletableDeferred<Unit>()
        val result = CompletableDeferred<String>()
        val lock = Mutex()
        val first = ManualCategoryRequest({ authority }, { current }, { "synthetic" }, { _, _ ->
            calls++; entered.complete(Unit); result.await()
        }, { writes++; true }, lock)
        val job = async { first.preview() }
        entered.await()
        fails("BUSY") { service(lock).preview() }
        job.cancelAndJoin()
        assertEquals(1, calls)
        assertEquals(0, writes)
        assertFalse(lock.isLocked)
        assertNotNull(service(lock).preview())
    }
}
