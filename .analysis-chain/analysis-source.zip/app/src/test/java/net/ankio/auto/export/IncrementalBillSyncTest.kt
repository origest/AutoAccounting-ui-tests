package net.ankio.auto.export

import org.junit.Assert.*
import org.junit.Test

class IncrementalBillSyncTest {
    @Test fun initialBackupRestartAndHistoricalEdit() {
        val journal = mutableMapOf<String, String>()
        fun sync() = IncrementalBillSync(journal::get) { id, hash -> journal[id] = hash }
        var sent = 0
        assertTrue(sync().sendIfChanged("old-bill", "original") { sent++ })
        assertFalse(sync().sendIfChanged("old-bill", "original") { sent++ })
        assertTrue(sync().sendIfChanged("old-bill", "edited") { sent++ })
        assertTrue(sync().sendIfChanged("new-bill", "new") { sent++ })
        assertEquals(3, sent)
    }

    @Test fun failedUploadRetriesWithoutResendingAcknowledgedBills() {
        val journal = mutableMapOf<String, String>()
        val sync = IncrementalBillSync(journal::get) { id, hash -> journal[id] = hash }
        sync.sendIfChanged("1", "first") {}
        try {
            sync.sendIfChanged("2", "second") { throw java.io.IOException("offline") }
            fail("Upload must fail")
        } catch (_: java.io.IOException) { }
        assertFalse(sync.sendIfChanged("1", "first") { fail("Already acknowledged") })
        assertTrue(sync.sendIfChanged("2", "second") {})
    }

    @Test fun changedDestinationRequiresFullBackup() {
        val journals = mutableMapOf<String, MutableMap<String, String>>()
        fun sync(destination: String): IncrementalBillSync {
            val journal = journals.getOrPut(IncrementalBillSync.digest(destination)) { mutableMapOf() }
            return IncrementalBillSync(journal::get) { id, hash -> journal[id] = hash }
        }
        assertTrue(sync("first").sendIfChanged("1", "bill") {})
        assertTrue(sync("second").sendIfChanged("1", "bill") {})
        assertFalse(sync("first").sendIfChanged("1", "bill") {})
    }
}
