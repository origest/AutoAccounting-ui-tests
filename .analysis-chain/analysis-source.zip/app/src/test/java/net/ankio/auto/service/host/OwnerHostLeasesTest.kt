package net.ankio.auto.service.host
import org.junit.Assert.*
import org.junit.Test

class OwnerHostLeasesTest {
    internal class Fixture {
        var running = false; var unknown = false; var occupied = false
        var starts = 0; var stops = 0; var ready = false; var fail = false
        val host = OwnerHostLeases({ running }, { unknown }, { occupied }, {
            starts++; if (fail) error("synthetic"); running = true
        }, { stops++; running = false }, { ready = it })
    }
    @Test fun repeatedStartIsSingleton() {
        val f=Fixture();val token=Any();val g=f.host.acquire(token)!!
        assertNull(f.host.acquire(token));f.host.tick(g);f.host.tick(g)
        assertEquals(1,f.starts);assertTrue(f.ready)
    }
    @Test fun overlappingModeLeasesKeepSameEngineAndOldReleaseCannotStopNew() {
        val f=Fixture();val old=Any();val next=Any();val g=f.host.acquire(old)!!
        f.host.tick(g);assertNull(f.host.acquire(next));f.host.release(old);f.host.release(old)
        assertTrue(f.running);assertTrue(f.ready);assertEquals(1,f.starts)
        f.host.release(next);assertFalse(f.running);assertFalse(f.ready)
    }
    @Test fun stopBeforeFirstTickDoesNotStart() {
        val f=Fixture();val t=Any();val g=f.host.acquire(t)!!;f.host.release(t)
        assertNull(f.host.tick(g));assertEquals(0,f.starts)
    }
    @Test fun staleDelayedTickCannotResurrectOrStopNewGeneration() {
        val f=Fixture();val old=Any();val next=Any();val g=f.host.acquire(old)!!
        f.host.tick(g);f.host.release(old);val n=f.host.acquire(next)!!
        assertNull(f.host.tick(g));f.host.tick(n);f.host.release(old)
        assertTrue(f.running);assertEquals(2,f.starts)
    }
    @Test fun foreignPortNeverMeansReadyAndIsNotStopped() {
        val f=Fixture();f.occupied=true;val g=f.host.acquire(Any())!!
        assertEquals(1000L,f.host.tick(g));assertEquals(0,f.starts);assertFalse(f.ready)
    }
    @Test fun startupFailureRetriesAreBounded() {
        val f=Fixture();f.fail=true;val g=f.host.acquire(Any())!!
        repeat(9) { f.host.tick(g) }
        assertEquals(8,f.starts);assertNull(f.host.tick(g));assertFalse(f.ready)
    }
    @Test fun cleanupUnknownBlocksEveryNewLease() {
        val f=Fixture();f.unknown=true;val t=Any();var g=f.host.acquire(t)!!
        assertNull(f.host.tick(g));f.host.release(t);g=f.host.acquire(Any())!!
        assertNull(f.host.tick(g));assertEquals(0,f.starts)
    }
    @Test fun healthyEngineUsesThirtySecondCadenceAndNoRestarts() {
        val f=Fixture();val g=f.host.acquire(Any())!!
        repeat(1000) { assertEquals(30000L,f.host.tick(g)) }
        assertEquals(1,f.starts)
    }
    @Test fun explicitRetryWorksWithTwoLeasesAfterExhaustion() {
        val f=Fixture();f.fail=true;val a=Any();val b=Any();val old=f.host.acquire(a)!!
        f.host.acquire(b);repeat(9) { f.host.tick(old) };assertEquals(8,f.starts)
        f.fail=false;val fresh=f.host.retryExplicitly()!!
        assertNull(f.host.tick(old));f.host.tick(fresh);f.host.release(a)
        assertTrue(f.running);assertEquals(9,f.starts);f.host.release(b);assertFalse(f.running)
    }
    @Test fun retryNeverRestartsHealthyOrUnknownCleanupEngine() {
        val f=Fixture();val g=f.host.acquire(Any())!!;f.host.tick(g)
        assertNull(f.host.retryExplicitly());assertEquals(1,f.starts)
        f.running=false;f.unknown=true;assertNull(f.host.retryExplicitly())
    }

}
