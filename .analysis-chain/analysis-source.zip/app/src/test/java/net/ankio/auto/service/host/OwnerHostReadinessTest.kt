package net.ankio.auto.service.host
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class OwnerHostReadinessTest {
    @Test fun blockedWorkerDoesNotBlockReadinessTimeout() = runBlocking {
        val worker=Executors.newSingleThreadExecutor();val entered=CountDownLatch(1);val release=CountDownLatch(1)
        try {
            worker.execute { entered.countDown(); release.await() };assertTrue(entered.await(1,TimeUnit.SECONDS))
            val start=System.nanoTime()
            assertFalse(awaitOwnerReady(worker,MutableStateFlow(true),50))
            assertTrue(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start)<1000)
        } finally { release.countDown();worker.shutdown();assertTrue(worker.awaitTermination(2,TimeUnit.SECONDS)) }
    }
    @Test fun earlierReleaseIsObservedBeforeOldReadyValue() = runBlocking {
        val worker=Executors.newSingleThreadExecutor();val state=MutableStateFlow(true)
        try { worker.execute { state.value=false };assertFalse(awaitOwnerReady(worker,state,50)) }
        finally { worker.shutdown();assertTrue(worker.awaitTermination(2,TimeUnit.SECONDS)) }
    }
    @Test fun currentReadyPassesAfterBarrier() = runBlocking {
        val worker=Executors.newSingleThreadExecutor()
        try { assertTrue(awaitOwnerReady(worker,MutableStateFlow(true),1000)) }
        finally { worker.shutdown();assertTrue(worker.awaitTermination(2,TimeUnit.SECONDS)) }
    }
}
