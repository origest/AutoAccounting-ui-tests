package net.ankio.auto.service.ocr

import net.ankio.auto.ai.review.*
import org.junit.Assert.*
import org.junit.Test

class OcrReviewIdentityTest {
    private fun record() = AiReviewRecord("synthetic", AiReviewTarget("ocr-local", 0, 0, "a".repeat(32)),
        AiReviewKind.OCR, AiReviewState.REVIEW, listOf(AiReviewChange("OCR_BILL", "", "42")), "", 1, 0, 0)
    @Test fun exactDurableMappingMayOpen() { assertTrue(OcrReviewBridge.matchesLocalDraft(record(), 42, 42)) }
    @Test fun reusedNumericIdWithoutMappingMustNotOpen() { assertFalse(OcrReviewBridge.matchesLocalDraft(record(), null, 42)) }
    @Test fun changedMappingMustNotOpen() { assertFalse(OcrReviewBridge.matchesLocalDraft(record(), 43, 42)) }
    @Test fun mappedNewIdMustNotOverrideKnownReviewId() { assertFalse(OcrReviewBridge.matchesLocalDraft(record(), 43, 43)) }
    @Test fun interruptedRequestMayRecoverOnlyFromExactMapping() {
        val interrupted = record().copy(state = AiReviewState.FAILED, changes = emptyList(), errorCode = "REQUEST_INTERRUPTED")
        assertTrue(OcrReviewBridge.matchesLocalDraft(interrupted, 42, 42))
        assertFalse(OcrReviewBridge.matchesLocalDraft(interrupted, null, 42))
    }
    @Test fun otherSourceAndKindCannotClaimLocalDraft() {
        assertFalse(OcrReviewBridge.matchesLocalDraft(record().copy(kind = AiReviewKind.OCR_CATEGORY), 42, 42))
        assertFalse(OcrReviewBridge.matchesLocalDraft(record().copy(target = record().target.copy(source = "different")), 42, 42))
    }
}
