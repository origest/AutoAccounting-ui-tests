package net.ankio.auto.stability

import kotlinx.coroutines.*
import net.ankio.auto.xposed.core.utils.AsyncDebugFlag
import net.ankio.auto.utils.DiagnosticQueue
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class HookStabilityTest {
    @Test(timeout = 5000) fun stalledDebugRefreshNeverBlocksHookReadsOrMultipliesRequests() = runBlocking {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val started = CompletableDeferred<Unit>(); val release = CompletableDeferred<Boolean>()
        val calls = AtomicInteger()
        val flag = AsyncDebugFlag(scope) { calls.incrementAndGet(); started.complete(Unit); release.await() }
        try {
            assertFalse(flag.get()); flag.refresh(); withTimeout(2000) { started.await() }
            repeat(100_000) { assertFalse(flag.get()); flag.refresh() }
            assertEquals(1, calls.get())
            release.complete(true)
            withTimeout(2000) { while (!flag.get()) yield() }
        } finally { scope.cancel() }
    }
    @Test(timeout = 5000) fun failedDebugFetchDefaultsOff() = runBlocking {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        val attempted = CompletableDeferred<Unit>()
        val flag = AsyncDebugFlag(scope) { attempted.complete(Unit); throw java.io.IOException("synthetic") }
        try {
            flag.refresh(); withTimeout(2000) { attempted.await() }
            assertFalse(flag.get())
        } finally { scope.cancel() }
    }
    @Test(timeout = 5000) fun stalledDiagnosticConsumerHasFixedBacklogUnderBurst() {
        val queue = DiagnosticQueue<String>(64)
        var accepted = 0
        repeat(100_000) { if (queue.offer("synthetic metadata")) accepted++ }
        assertEquals(64, accepted)
        assertEquals(99_936L, queue.dropped.get())
        var retained = 0
        while (queue.messages.tryReceive().isSuccess) retained++
        assertEquals(64, retained)
        queue.messages.close()
    }
    @Test(timeout = 5000) fun coroutineTimeoutAloneDoesNotInterruptBlockingWork() = runBlocking {
        val entered = CompletableDeferred<Job>()
        val release = CountDownLatch(1)
        val blockingFinished = AtomicBoolean(false)
        val wrapperReturned = AtomicBoolean(false)
        // Start the timeout only after IO dispatch. A busy runner may otherwise
        // consume the whole timeout before the blocking body has even entered.
        val worker = async(Dispatchers.IO) {
            val result = withTimeoutOrNull(20) {
                entered.complete(currentCoroutineContext().job)
                try {
                    check(release.await(3, TimeUnit.SECONDS)) { "Observer did not release blocking work" }
                } finally {
                    blockingFinished.set(true)
                }
                // Observe cancellation explicitly after the non-cooperative call.
                currentCoroutineContext().ensureActive()
                true
            }
            wrapperReturned.set(true)
            result
        }
        try {
            val timedJob = withTimeout(2000) { entered.await() }
            withTimeout(2000) { while (!timedJob.isCancelled) delay(1) }
            assertFalse("Timeout must not interrupt the blocking call", blockingFinished.get())
            assertFalse("Wrapper must wait for the blocking call", wrapperReturned.get())
            assertFalse(worker.isCompleted)
            release.countDown()
            assertNull(withTimeout(2000) { worker.await() })
            assertTrue(blockingFinished.get())
            assertTrue(wrapperReturned.get())
        } finally {
            release.countDown()
            worker.cancelAndJoin()
        }
    }
}
