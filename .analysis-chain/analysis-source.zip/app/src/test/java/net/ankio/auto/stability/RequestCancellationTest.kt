package net.ankio.auto.stability

import kotlinx.coroutines.*
import net.ankio.auto.http.RequestsUtils
import org.junit.Assert.*
import org.junit.Test
import java.net.InetAddress
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Loopback synthetic HTTP only. Never uses a bill service, real data or external host. */
class RequestCancellationTest {
    @Test(timeout = 10000) fun cancellationClosesSocketWaitingForHeaders() = cancelStalled(false)
    @Test(timeout = 10000) fun cancellationClosesSocketWhileReadingBody() = cancelStalled(true)
    private fun cancelStalled(sendHeaders: Boolean) = runBlocking {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val executor = Executors.newSingleThreadExecutor()
        val received = CountDownLatch(1)
        val peer = executor.submit<Boolean> {
            server.accept().use { socket ->
                socket.soTimeout = 3000
                val reader = socket.getInputStream().bufferedReader()
                while (!reader.readLine().isNullOrEmpty()) { }
                if (sendHeaders) {
                    socket.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 1048576\r\n\r\n".toByteArray())
                    socket.getOutputStream().flush()
                }
                received.countDown()
                reader.read() == -1
            }
        }
        val request = async(Dispatchers.IO) { RequestsUtils().get("http://127.0.0.1:${server.localPort}/synthetic") }
        try {
            assertTrue(withContext(Dispatchers.IO) { received.await(3, TimeUnit.SECONDS) })
            if (sendHeaders) delay(100) // let the response callback start its body read
            request.cancel()
            withTimeout(1500) { request.join() }
            assertTrue(withContext(Dispatchers.IO) { peer.get(2, TimeUnit.SECONDS) })
        } finally { request.cancel(); server.close(); executor.shutdownNow() }
    }
    @Test(timeout = 10000) fun successAndHttpFailureStillReturnExpectedResults() = runBlocking {
        for (status in listOf(200, 503)) {
            val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
            val executor = Executors.newSingleThreadExecutor()
            try {
                val peer = executor.submit {
                    server.accept().use { socket ->
                        socket.soTimeout = 3000
                        val reader = socket.getInputStream().bufferedReader()
                        while (!reader.readLine().isNullOrEmpty()) { }
                        socket.getOutputStream().write("HTTP/1.1 $status Synthetic\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok".toByteArray())
                        socket.getOutputStream().flush()
                    }
                }
                val result = withTimeout(3000) { RequestsUtils().get("http://127.0.0.1:${server.localPort}/synthetic") }
                if (status == 200) assertEquals("ok", result.getOrThrow())
                else assertEquals(503, (result.exceptionOrNull() as RequestsUtils.HttpException).code)
                peer.get(2, TimeUnit.SECONDS)
            } finally { server.close(); executor.shutdownNow() }
        }
    }
}
