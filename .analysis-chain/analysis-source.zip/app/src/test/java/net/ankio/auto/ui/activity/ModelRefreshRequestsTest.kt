package net.ankio.auto.ui.activity

import org.junit.Assert.*
import org.junit.Test

class ModelRefreshRequestsTest {
    @Test fun returnDuringLoginIsRetainedUntilReady() {
        val state = ModelRefreshRequests()
        state.request()
        assertFalse(state.takeIfReady(busy = true, signedIn = false))
        assertTrue(state.takeIfReady(busy = false, signedIn = true))
        assertFalse(state.takeIfReady(busy = false, signedIn = true))
    }

    @Test fun returnsDuringTheSameModelRequestAreCoalesced() {
        val state = ModelRefreshRequests()
        state.request()
        assertTrue(state.takeIfReady(busy = false, signedIn = true))
        state.request()
        state.request()
        assertFalse(state.takeIfReady(busy = true, signedIn = true))
        state.complete()
        assertFalse(state.takeIfReady(busy = false, signedIn = true))
    }

    @Test fun signedOutReturnDoesNotFetchModelsOrLeaveAHiddenRetry() {
        val state = ModelRefreshRequests()
        state.request()
        assertFalse(state.takeIfReady(busy = false, signedIn = false))
        assertFalse(state.takeIfReady(busy = false, signedIn = true))
    }

    @Test fun failureOrCancellationRequiresANewReturnOrExplicitRefresh() {
        val state = ModelRefreshRequests()
        state.request()
        state.complete()
        assertFalse(state.takeIfReady(busy = false, signedIn = true))
        state.request()
        assertTrue(state.takeIfReady(busy = false, signedIn = true))
    }
}
