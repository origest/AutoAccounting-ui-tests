package net.ankio.auto.xposed.hooks.common

import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class HostRecoveryControllerTest {
    private class Host {
        var running = false; var blocked = false; var occupied = false
        var starts = 0; var stops = 0; var failStart = false
        fun controller(budget: Int = 8) = HostRecoveryController(
            { running }, { blocked }, { occupied },
            { starts++; if (failStart) error("synthetic"); running = true },
            { stops++; running = false }, budget)
    }
    @Test fun initialPortOccupationCanRecoverWithoutClaimingHealth() {
        val host = Host().apply { occupied = true }; val c = host.controller()
        assertEquals(1000L, c.tick()); assertEquals(HostRecoveryController.State.WAITING_PORT, c.state)
        assertEquals(0, host.starts)
        host.occupied = false; assertEquals(30000L, c.tick()); assertEquals(1, host.starts)
        repeat(20) { c.tick() }; assertEquals(1, host.starts); assertEquals(2, c.attempts)
    }
    @Test fun permanentOccupationExhaustsFiniteBudget() {
        val host = Host().apply { occupied = true }; val c = host.controller(3)
        repeat(3) { assertNotNull(c.tick()) }; assertNull(c.tick())
        assertEquals(HostRecoveryController.State.EXHAUSTED, c.state); assertEquals(0, host.starts)
        repeat(20) { assertNull(c.tick()) }; assertEquals(3, c.attempts)
    }
    @Test fun stoppedEngineRestartsButLifetimeBudgetDoesNotReset() {
        val host = Host(); val c = host.controller(2)
        c.tick(); host.running = false; c.tick(); assertEquals(2, host.starts)
        host.running = false; assertNull(c.tick()); assertEquals(HostRecoveryController.State.EXHAUSTED, c.state)
    }
    @Test fun initializationFailureRetriesButUncertainCleanupBlocks() {
        val host = Host().apply { failStart = true }; val c = host.controller()
        c.tick(); assertEquals(HostRecoveryController.State.RETRY_WAIT, c.state)
        host.failStart = false; c.tick(); assertTrue(host.running)
        host.running = false; host.blocked = true; assertNull(c.tick())
        assertEquals(HostRecoveryController.State.CLEANUP_UNKNOWN, c.state); assertEquals(2, host.starts)
    }
    @Test fun disableWhileStartAdmittedCleansAfterItReturnsAndNeverRestarts() {
        val entered = CountDownLatch(1); val release = CountDownLatch(1)
        var running = false; var starts = 0; var stops = 0
        val c = HostRecoveryController({ running }, { false }, { false },
            { starts++; entered.countDown(); check(release.await(3, TimeUnit.SECONDS)); running = true },
            { stops++; running = false })
        val result = AtomicReference<Result<Long?>>()
        val thread = Thread { result.set(runCatching { c.tick() }) }.apply { start() }
        try { assertTrue(entered.await(3, TimeUnit.SECONDS)); c.disable() }
        finally { release.countDown(); thread.join(3000) }
        assertFalse(thread.isAlive); assertNull(result.get().getOrThrow())
        assertFalse(running); assertEquals(1, starts)
        assertEquals(HostRecoveryController.State.DISABLED, c.state)
        repeat(10) { assertNull(c.tick()) }; assertEquals(1, starts)
    }
    @Test fun concurrentTicksStartOnlyOneOwnedEngine() {
        val host = Host(); val c = host.controller(); val pool = Executors.newFixedThreadPool(8)
        try { (1..30).map { pool.submit<Long?> { c.tick() } }.forEach { it.get(3, TimeUnit.SECONDS) } }
        finally { pool.shutdownNow() }
        assertEquals(1, host.starts); assertEquals(1, c.attempts)
    }
    @Test fun onlyDebugOwnerIsEligible() {
        assertTrue(DebugHostRecovery.eligible(true, "owner", "owner"))
        assertFalse(DebugHostRecovery.eligible(false, "owner", "owner"))
        assertFalse(DebugHostRecovery.eligible(true, "wechat", "owner"))
        assertFalse(DebugHostRecovery.eligible(true, "android", "owner"))
    }
}
