package net.ankio.chatgpt

import androidx.test.platform.app.InstrumentationRegistry
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import com.nimbusds.jose.*
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jose.jwk.JWKSet
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator
import com.nimbusds.jwt.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.async
import kotlinx.coroutines.CoroutineStart
import org.junit.Assert.*
import org.junit.Test
import java.net.Socket
import java.net.URI
import java.util.Date
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AccountIntegrationTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    @Test fun keystoreCiphertextRoundTripsAndTamperingFailsClosed() {
        val name = "fixture-${UUID.randomUUID()}"
        val store = CredentialStore(context, name)
        try {
            val state = AccountState().apply { accounts.add(AccountRecord().apply { client = "oaiapp_fixture"; access = "synthetic-secret-access"; refresh = "synthetic-secret-refresh" }) }
            store.save(state)
            val file = java.io.File(context.noBackupFilesDir, "$name.enc")
            assertFalse(file.readText().contains("synthetic-secret"))
            assertEquals("synthetic-secret-refresh", CredentialStore(context, name).load().accounts.single().refresh)
            val bytes = file.readBytes(); bytes[bytes.lastIndex] = (bytes.last().toInt() xor 1).toByte(); file.writeBytes(bytes)
            try { store.load(); fail() } catch (e: AccountFailure) { assertEquals("STORE_UNAVAILABLE", e.code); assertNull(e.cause) }
        } finally { store.clear() }
    }
    @Test fun loginDoesNotAuthorizeBillsAndSignOutClearsTokens() = fixture { f ->
        f.login(); f.manager.models()
        runBlocking {
            try { f.manager.classify("synthetic", "{}"); fail() } catch (e: AccountFailure) { assertEquals("CLASSIFICATION_PAUSED", e.code) }
            assertEquals(0, f.inferences)
            f.manager.enable("fixture-model")
            assertEquals("{\"existing\":\"餐饮\",\"proposed\":\"\"}", f.manager.classify("synthetic", "{}"))
        }
        assertTrue(f.manager.signOut())
        val saved = f.store.load().accounts.single()
        assertEquals("oaiapp_fixture", saved.client)
        assertTrue(saved.access.isEmpty() && saved.refresh.isEmpty() && saved.idToken.isEmpty() && !saved.consent && !saved.ocrTextConsent)
    }
    @Test fun categoryConsentNeverAuthorizesOcrText() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enable("fixture-model")
        runBlocking {
            try { f.manager.recognizeOcrText("synthetic", "synthetic OCR text"); fail() }
            catch (e: AccountFailure) { assertEquals("OCR_TEXT_PAUSED", e.code) }
        }
        assertEquals(0, f.inferences)
        assertTrue(f.manager.view().accounts.single().enabled)
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
    }
    @Test fun ocrTextConsentIsIndependentAndUsesOnlyText() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enableOcrText("fixture-model")
        assertTrue(f.manager.view().accounts.single().ocrEnabled)
        assertFalse(f.manager.view().accounts.single().enabled)
        runBlocking {
            try { f.manager.classify("synthetic", "{}"); fail() }
            catch (e: AccountFailure) { assertEquals("CLASSIFICATION_PAUSED", e.code) }
            assertEquals(0, f.inferences)
            assertEquals("{\"existing\":\"餐饮\",\"proposed\":\"\"}", f.manager.recognizeOcrText("synthetic OCR instruction", "synthetic OCR text"))
        }
        val input = com.google.gson.JsonParser.parseString(f.inferenceBody).asJsonObject.getAsJsonArray("input")
        assertEquals(2, input.size())
        assertEquals("synthetic OCR instruction", input[0].asJsonObject["content"].asString)
        assertEquals("synthetic OCR text", input[1].asJsonObject["content"].asString)
        assertTrue(input.all { it.asJsonObject["content"].isJsonPrimitive && it.asJsonObject["content"].asJsonPrimitive.isString })
        assertEquals(1, f.inferences)
    }
    @Test fun ocrTextRequiresCurrentCatalogModel() = fixture { f ->
        f.login()
        try { f.manager.enableOcrText("fixture-model"); fail() }
        catch (e: AccountFailure) { assertEquals("MODEL_REQUIRED", e.code) }
        f.manager.models()
        try { f.manager.enableOcrText("not-in-catalog"); fail() }
        catch (e: AccountFailure) { assertEquals("MODEL_REQUIRED", e.code) }
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        assertEquals(0, f.inferences)
    }
    @Test fun ocrTextTicketsBindCaptureToTheExactGrant() = fixture { f ->
        assertNull(f.manager.ocrTextTicket())
        f.login(); f.manager.models(); f.manager.enable("fixture-model")
        assertNull(f.manager.ocrTextTicket())
        f.manager.enableOcrText("fixture-model")
        val first = f.manager.ocrTextTicket()!!
        assertEquals("oaiapp_fixture", first.account)
        assertEquals("fixture-model", first.model)
        assertTrue(f.manager.isOcrTextTicketCurrent(first))
        assertFalse(f.manager.isOcrTextTicketCurrent(first.copy(account = "another-account")))
        assertFalse(f.manager.isOcrTextTicketCurrent(first.copy(model = "another-model")))
        f.manager.enableOcrText("fixture-model")
        assertFalse(f.manager.isOcrTextTicketCurrent(first))
        val current = f.manager.ocrTextTicket()!!
        runBlocking {
            try { f.manager.recognizeOcrText("s", "synthetic stale OCR", first); fail() }
            catch (e: AccountFailure) { assertEquals("CANCELLED", e.code) }
            assertEquals(0, f.inferences)
            f.manager.recognizeOcrText("s", "synthetic current OCR", current)
        }
        assertEquals(1, f.inferences)
        f.manager.pause()
        assertNull(f.manager.ocrTextTicket())
        assertFalse(f.manager.isOcrTextTicketCurrent(current))
    }
    @Test fun disablingOcrLeavesCategoryConsentAndBlocksFurtherOcr() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enable("fixture-model"); f.manager.enableOcrText("fixture-model")
        f.manager.disableOcrText()
        assertTrue(f.manager.view().accounts.single().enabled)
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        runBlocking {
            try { f.manager.recognizeOcrText("s", "synthetic OCR text"); fail() }
            catch (e: AccountFailure) { assertEquals("OCR_TEXT_PAUSED", e.code) }
            f.manager.classify("s", "{}")
        }
        assertEquals(1, f.inferences)
        assertFalse(f.store.load().accounts.single().ocrTextConsent)
    }
    @Test fun pauseSelectReauthorizationAndSignOutRevokeOcrConsent() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enableOcrText("fixture-model")
        f.manager.pause()
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        f.manager.enableOcrText("fixture-model")
        f.manager.select("oaiapp_fixture")
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        f.manager.models(); f.manager.enableOcrText("fixture-model")
        f.login("oaiapp_fixture")
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        f.manager.models(); f.manager.enableOcrText("fixture-model")
        assertTrue(f.manager.signOut())
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        assertFalse(f.store.load().accounts.single().ocrTextConsent)
    }
    @Test fun ocrQuotaFailurePausesBothPurposesWithoutReplay() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enable("fixture-model"); f.manager.enableOcrText("fixture-model"); f.quota = true
        runBlocking {
            try { f.manager.recognizeOcrText("s", "synthetic OCR text"); fail() }
            catch (e: DiagnosticFailure) { assertEquals(429, e.http) }
            try { f.manager.recognizeOcrText("s", "synthetic OCR text"); fail() }
            catch (e: AccountFailure) { assertEquals("OCR_TEXT_PAUSED", e.code) }
            try { f.manager.classify("s", "{}"); fail() }
            catch (e: AccountFailure) { assertEquals("CLASSIFICATION_PAUSED", e.code) }
        }
        assertEquals(1, f.inferences)
        assertFalse(f.manager.view().accounts.single().enabled)
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
    }
    @Test fun disablingOcrDiscardsActiveAndQueuedTextEvenAfterReenabling() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enableOcrText("fixture-model"); f.waitResponse = true
        runBlocking {
            val first = async(start = CoroutineStart.UNDISPATCHED) {
                runCatching { f.manager.recognizeOcrText("s", "synthetic first OCR") }
            }
            assertTrue(f.entered.await(10, TimeUnit.SECONDS))
            val queued = async(start = CoroutineStart.UNDISPATCHED) {
                runCatching { f.manager.recognizeOcrText("s", "synthetic queued OCR") }
            }
            f.manager.disableOcrText(); f.manager.enableOcrText("fixture-model"); f.release.countDown()
            assertTrue(first.await().isFailure)
            assertTrue(queued.await().isFailure)
        }
        assertEquals(1, f.inferences)
        assertTrue(f.manager.view().accounts.single().ocrEnabled)
    }
    @Test fun quotaFailurePausesWithoutReplayingOrFallingBack() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enable("fixture-model"); f.quota = true
        runBlocking {
            try { f.manager.classify("s", "{}"); fail() } catch (e: DiagnosticFailure) { assertEquals(429, e.http) }
            try { f.manager.classify("s", "{}"); fail() } catch (e: AccountFailure) { assertEquals("CLASSIFICATION_PAUSED", e.code) }
        }
        assertEquals(1, f.inferences); assertFalse(f.manager.view().accounts.single().enabled)
    }
    @Test fun cancellingCallerDoesNotRevokeCategoryOrOcrConsent() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enable("fixture-model"); f.manager.enableOcrText("fixture-model")
        f.waitResponse = true
        runBlocking {
            val first = async(start = CoroutineStart.UNDISPATCHED) { f.manager.classify("s", "synthetic-cancelled") }
            assertTrue(f.entered.await(10, TimeUnit.SECONDS))
            first.cancel()
            f.release.countDown()
            first.join()
            f.waitResponse = false
            // Executor ordering ensures the cancelled transport's catch path ran first.
            f.manager.recognizeOcrText("s", "synthetic-next-request")
        }
        assertEquals(2, f.inferences)
        assertTrue(f.manager.view().accounts.single().enabled)
        assertTrue(f.manager.view().accounts.single().ocrEnabled)
        val saved = f.store.load().accounts.single()
        assertTrue(saved.consent && saved.ocrTextConsent)
    }
    @Test fun nearExpiryRefreshIsSerializedAndRotationIsPersisted() = fixture { f ->
        f.ttl = 10; f.login(); f.manager.models(); f.manager.models()
        assertEquals(1, f.refreshes)
        assertEquals("rotated-synthetic-refresh", f.store.load().accounts.single().refresh)
        assertEquals("rotated-synthetic-access", f.store.load().accounts.single().access)
    }
    @Test fun revokedRefreshClearsCredentialsAndStopsFurtherRequests() = fixture { f ->
        f.ttl = 10; f.login(); f.refreshFailure = true
        try { f.manager.models(); fail() } catch (e: DiagnosticFailure) { assertEquals(KnownOAuthError.INVALID_GRANT, e.oauth) }
        val record = f.store.load().accounts.single()
        assertTrue(record.access.isEmpty() && record.refresh.isEmpty() && record.idToken.isEmpty())
        try { f.manager.models(); fail() } catch (e: AccountFailure) { assertEquals("SIGN_IN_REQUIRED", e.code) }
        assertEquals(1, f.refreshes)
    }
    @Test fun reauthorizationCannotOverwriteAnotherIdentity() = fixture { f ->
        f.login(); val original = f.store.load().accounts.single().subjectHash
        f.subject = "different-synthetic-account"
        try { f.login("oaiapp_fixture"); fail() } catch (e: DiagnosticFailure) { assertEquals(DiagnosticCode.ACCOUNT_CHANGED, e.code) }
        assertEquals(original, f.store.load().accounts.single().subjectHash)
        assertFalse(f.manager.view().accounts.single().enabled)
    }
    @Test fun pauseDuringInferenceDiscardsLateResponse() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enable("fixture-model"); f.waitResponse = true
        val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
        try {
            val result = executor.submit<Boolean> { runBlocking { try { f.manager.classify("s", "{}"); true } catch (_: Exception) { false } } }
            assertTrue(f.entered.await(10, TimeUnit.SECONDS))
            f.manager.pause(); f.release.countDown()
            assertFalse(result.get(10, TimeUnit.SECONDS)); assertFalse(f.manager.view().accounts.single().enabled)
        } finally { f.release.countDown(); executor.shutdownNow() }
    }
    @Test fun oneTimeTextConsentIsPayloadBoundAndDoesNotEnableBackgroundSending() = fixture { f ->
        f.login(); f.manager.models(); f.manager.selectModel("fixture-model")
        val approval = f.manager.approveTextOnce("synthetic-system", "synthetic-single-record")
        assertFalse(f.manager.view().accounts.single().enabled)
        assertFalse(f.manager.view().accounts.single().ocrEnabled)
        assertTrue(f.manager.isTextApprovalFor(approval, "synthetic-system", "synthetic-single-record"))
        assertFalse(f.manager.isTextApprovalFor(approval, "synthetic-system", "different-record"))
        runBlocking { f.manager.recognizeApprovedText(approval) }
        assertEquals(1, f.inferences)
        assertTrue(f.inferenceBody.contains("synthetic-single-record"))
        assertFalse(f.inferenceBody.contains("input_image"))
        try { runBlocking { f.manager.recognizeApprovedText(approval) }; fail() }
        catch (e: AccountFailure) { assertEquals("APPROVAL_ALREADY_USED", e.code) }
        assertEquals(1, f.inferences)
        assertFalse(f.store.load().accounts.single().consent)
        assertFalse(f.store.load().accounts.single().ocrTextConsent)
    }
    @Test fun pauseInvalidatesOutstandingOneTimeTextApprovalWithoutSending() = fixture { f ->
        f.login(); f.manager.models(); f.manager.selectModel("fixture-model")
        val approval = f.manager.approveTextOnce("synthetic", "synthetic-record")
        f.manager.pause()
        assertFalse(f.manager.isTextApprovalCurrent(approval))
        try { runBlocking { f.manager.recognizeApprovedText(approval) }; fail() }
        catch (e: AccountFailure) { assertEquals("CANCELLED", e.code) }
        assertEquals(0, f.inferences)
    }
    @Test fun selectingModelAloneNeverAuthorizesAutomaticInference() = fixture { f ->
        f.login(); f.manager.models(); f.manager.selectModel("fixture-model")
        assertEquals("fixture-model", f.manager.view().accounts.single().model)
        assertFalse(f.manager.view().accounts.single().enabled)
        assertNull(f.manager.ocrTextTicket())
        try { runBlocking { f.manager.classify("synthetic", "{}"); fail() } }
        catch (e: AccountFailure) { assertEquals("CLASSIFICATION_PAUSED", e.code) }
        assertEquals(0, f.inferences)
    }
    @Test fun revocationReturnsOnlyAfterAuthorizedLocalCommitAndBlocksLaterCommits() = fixture { f ->
        f.login(); f.manager.models(); f.manager.enableOcrText("fixture-model")
        val ticket = f.manager.ocrTextTicket()!!
        val pool = java.util.concurrent.Executors.newFixedThreadPool(2)
        val commitEntered = CountDownLatch(1); val releaseCommit = CountDownLatch(1); val pauseStarted = CountDownLatch(1)
        val order = java.util.concurrent.atomic.AtomicInteger()
        try {
            val commit = pool.submit<Int> { f.manager.commitOcrText(ticket) {
                commitEntered.countDown(); assertTrue(releaseCommit.await(10, TimeUnit.SECONDS)); order.incrementAndGet()
            } }
            assertTrue(commitEntered.await(10, TimeUnit.SECONDS))
            val pause = pool.submit<Int> { pauseStarted.countDown(); f.manager.disableOcrText(); order.incrementAndGet() }
            assertTrue(pauseStarted.await(10, TimeUnit.SECONDS)); releaseCommit.countDown()
            assertTrue(commit.get(10, TimeUnit.SECONDS) < pause.get(10, TimeUnit.SECONDS))
            try { f.manager.commitOcrText(ticket) { fail("late commit") }; fail() }
            catch (e: AccountFailure) { assertEquals("CANCELLED", e.code) }
            assertEquals(0, f.inferences)
        } finally { releaseCommit.countDown(); pool.shutdownNow() }
    }
    private fun fixture(block: (Fixture) -> Unit) {
        val f = Fixture()
        try { block(f) } finally { f.release.countDown(); f.manager.cancel(); f.store.clear() }
    }
    private inner class Fixture {
        val name = "fixture-${UUID.randomUUID()}"
        val store = CredentialStore(context, name)
        var nonce = ""
        var subject = "synthetic-subject"
        var inferences = 0
        var inferenceBody = ""
        var quota = false
        var ttl = 3600
        var refreshes = 0
        var refreshFailure = false
        var waitResponse = false
        val entered = CountDownLatch(1); val release = CountDownLatch(1)
        val key = RSAKeyGenerator(2048).keyID("fixture-key").generate()
        val manager = ChatGptAccounts(context, { ProbeClient(OkHttpClient.Builder().addInterceptor { chain ->
            val path = chain.request().url.encodedPath
            val body = when (path) {
                "/.well-known/openid-configuration" -> """{"issuer":"${OAuthProtocol.ISSUER}","authorization_endpoint":"${OAuthProtocol.AUTH}","token_endpoint":"${OAuthProtocol.TOKEN}","jwks_uri":"${OAuthProtocol.JWKS}","revocation_endpoint":"https://auth.openai.com/api/accounts/oauth/revoke"}"""
                "/.well-known/jwks.json" -> JWKSet(key.toPublicJWK()).toString()
                "/api/accounts/oauth/token" -> {
                    val form = chain.request().body as FormBody
                    val isRefresh = (0 until form.size).any { form.name(it) == "grant_type" && form.value(it) == "refresh_token" }
                    if (isRefresh) {
                        refreshes++
                        if (refreshFailure) return@addInterceptor Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(400).message("synthetic")
                            .header("Content-Type", "application/json").body("{\"error\":\"invalid_grant\"}".toResponseBody("application/json".toMediaType())).build()
                        return@addInterceptor Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("synthetic")
                            .header("Content-Type", "application/json").body("{\"access_token\":\"rotated-synthetic-access\",\"refresh_token\":\"rotated-synthetic-refresh\",\"expires_in\":3600,\"token_type\":\"Bearer\"}".toResponseBody("application/json".toMediaType())).build()
                    }
                    val claims = JWTClaimsSet.Builder().issuer(OAuthProtocol.ISSUER).audience("oaiapp_fixture").subject(subject).claim("nonce", nonce)
                        .issueTime(Date()).expirationTime(Date(System.currentTimeMillis() + 3600000)).build()
                    val jwt = SignedJWT(JWSHeader.Builder(JWSAlgorithm.RS256).keyID(key.keyID).build(), claims).apply { sign(RSASSASigner(key)) }.serialize()
                    """{"access_token":"synthetic-access","refresh_token":"synthetic-refresh","id_token":"$jwt","scope":"openid resource.invoke ${OAuthProtocol.PLAN_SCOPE}","expires_in":$ttl,"token_type":"Bearer"}"""
                }
                "/v1/models" -> """{"models":[{"slug":"fixture-model","display_name":"Synthetic","visibility":"list"}]}"""
                "/api/accounts/oauth/revoke" -> ""
                "/v1/responses" -> {
                    val buffer = okio.Buffer(); chain.request().body!!.writeTo(buffer); inferenceBody = buffer.readUtf8()
                    inferences++; entered.countDown(); if (waitResponse) assertTrue(release.await(10, TimeUnit.SECONDS))
                    if (quota) """{"error":{"code":"subscription_sharing_usage_limit_exceeded"}}""" else
                        "data: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\",\"output\":[{\"type\":\"message\",\"role\":\"assistant\",\"content\":[{\"type\":\"output_text\",\"text\":\"{\\\"existing\\\":\\\"餐饮\\\",\\\"proposed\\\":\\\"\\\"}\"}]}]}}\n\n"
                }
                else -> throw AssertionError("Unexpected synthetic route")
            }
            val type = if (path == "/v1/responses" && !quota) "text/event-stream" else "application/json"
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(if (path == "/v1/responses" && quota) 429 else 200).message("synthetic")
                .header("Content-Type", type).body(body.toResponseBody(type.toMediaType())).build()
        }.build()) }, name)
        fun login(account: String? = null) {
            manager.signIn(account) { url ->
                val auth = url.toHttpUrl(); nonce = auth.queryParameter("nonce")!!
                val callback = URI(auth.queryParameter("redirect_uri")!!)
                Socket("127.0.0.1", callback.port).use { socket ->
                    val target = "${callback.path}?state=${auth.queryParameter("state")}&code=synthetic&client_id=oaiapp_fixture"
                    socket.getOutputStream().write(("GET $target HTTP/1.1\r\nHost: 127.0.0.1:${callback.port}\r\n\r\n").toByteArray())
                }
            }
        }
    }
}
