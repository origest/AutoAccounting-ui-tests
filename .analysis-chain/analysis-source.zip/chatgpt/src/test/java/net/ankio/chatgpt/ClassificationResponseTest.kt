package net.ankio.chatgpt

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import com.google.gson.JsonParser
import okio.Buffer
import org.junit.Assert.*
import org.junit.Test

class ClassificationResponseTest {
    private fun session() = ProbeSession("oaiapp_fixture", "subject", "synthetic-access", setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE, "old-refresh", "validated-id")
    @Test fun classificationUsesResponsesAndOnlyReturnsCompletedOutput() {
        val answer = """{"existing":"餐饮","proposed":""}"""
        val encoded = com.google.gson.Gson().toJson(answer)
        val client = ProbeClient(OkHttpClient.Builder().addInterceptor { chain ->
            assertEquals("https://api.openai.com/v1/responses", chain.request().url.toString())
            val buffer = Buffer(); chain.request().body!!.writeTo(buffer)
            val json = JsonParser.parseString(buffer.readUtf8()).asJsonObject
            assertTrue(json["stream"].asBoolean); assertFalse(json["store"].asBoolean)
            assertEquals("developer", json.getAsJsonArray("input")[0].asJsonObject["role"].asString)
            response(chain, """data: {"type":"response.output_text.delta","delta":"not-returned"}

data: {"type":"response.completed","response":{"status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":$encoded}]}]}}

""", "text/event-stream")
        }.build())
        try { assertEquals(answer, client.classify(session(), ProbeModel("fixture", "Fixture"), "synthetic-system", "synthetic-input")) }
        finally { client.close() }
    }
    @Test fun failedOrRefusedOrIncompleteOutputNeverReturnsPartialText() {
        listOf(
            """{"type":"response.failed"}""",
            """{"type":"response.completed","response":{"status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"refusal"}]}]}}""",
            """{"type":"response.completed","response":{"status":"completed","output":[]}}"""
        ).forEach { event ->
            val client = ProbeClient(OkHttpClient.Builder().addInterceptor { response(it, "data: $event\n\n", "text/event-stream") }.build())
            try {
                try { client.classify(session(), ProbeModel("fixture", "Fixture"), "s", "u"); fail() }
                catch (_: DiagnosticFailure) {}
            } finally { client.close() }
        }
    }
    @Test fun refreshUsesBoundClientAndResourceAndReplacesRotatingToken() {
        val client = ProbeClient(OkHttpClient.Builder().addInterceptor { chain ->
            assertEquals(OAuthProtocol.TOKEN, chain.request().url.toString())
            val form = chain.request().body as FormBody
            val fields = (0 until form.size).associate { form.name(it) to form.value(it) }
            assertEquals(mapOf("grant_type" to "refresh_token", "client_id" to "oaiapp_fixture", "refresh_token" to "old-refresh", "resource" to OAuthProtocol.RESOURCE), fields)
            response(chain, """{"access_token":"new-access","refresh_token":"new-refresh","expires_in":3600,"token_type":"Bearer"}""", "application/json")
        }.build())
        try {
            val renewed = client.refresh(session())
            assertEquals("new-refresh", renewed.refreshToken); assertEquals("new-access", renewed.accessToken)
            assertEquals("validated-id", renewed.idToken); assertEquals("subject", renewed.subjectHash)
            assertEquals(session().scopes, renewed.scopes)
        } finally { client.close() }
    }
    @Test fun revokedGrantDoesNotRetryRefresh() {
        var calls = 0
        val client = ProbeClient(OkHttpClient.Builder().addInterceptor { chain ->
            calls++
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(400).message("Bad")
                .body("""{"error":"invalid_grant","error_description":"PRIVATE"}""".toResponseBody("application/json".toMediaType())).build()
        }.build())
        try {
            try { client.refresh(session()); fail() } catch (e: DiagnosticFailure) {
                assertEquals(KnownOAuthError.INVALID_GRANT, e.oauth)
                assertFalse(Diagnostics.render(client.stage, e).contains("PRIVATE"))
            }
            assertEquals(1, calls)
        } finally { client.close() }
    }
    private fun response(chain: Interceptor.Chain, body: String, type: String) = Response.Builder()
        .request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK").header("Content-Type", type)
        .body(body.toResponseBody(type.toMediaType())).build()
}
