package net.ankio.chatgpt

import org.junit.Assert.*
import org.junit.Test
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException
import java.net.SocketTimeoutException
import java.net.ConnectException
import java.io.IOException
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import com.nimbusds.jose.*
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jose.jwk.JWKSet
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator
import com.nimbusds.jwt.*
import java.util.Date

class DiagnosticsTest {
    private val secret = "SECRET_code_token_person@example.invalid"
    @Test fun exceptionMessagesAndCausesNeverEnterReport() {
        listOf(UnknownHostException(secret), SSLHandshakeException(secret), SocketTimeoutException(secret),
            ConnectException(secret), IOException(secret), IllegalArgumentException(secret)).forEach {
            val report = Diagnostics.render(ProbeStage.TOKEN_EXCHANGE, it)
            assertFalse(report.contains(secret)); assertTrue(report.contains("TOKEN_EXCHANGE"))
        }
        assertEquals(DiagnosticCode.DNS, Diagnostics.normalize(UnknownHostException(secret)).code)
        assertEquals(DiagnosticCode.TLS_HANDSHAKE, Diagnostics.normalize(SSLHandshakeException(secret)).code)
        assertEquals(DiagnosticCode.TIMEOUT, Diagnostics.normalize(SocketTimeoutException(secret)).code)
    }
    @Test fun httpErrorIsAllowlistedAndRawBodyDiscarded() {
        val known = Diagnostics.httpFailure(400, """{"error":"invalid_grant","error_description":"$secret"}""")
        assertEquals(KnownOAuthError.INVALID_GRANT, known.oauth)
        assertEquals(ErrorShape.OAUTH_STRING, known.shape)
        val unknown = Diagnostics.httpFailure(403, """{"error":{"code":"$secret","message":"$secret"}}""")
        assertEquals(KnownOAuthError.UNKNOWN, unknown.oauth)
        assertEquals(ErrorShape.API_ERROR_OBJECT, unknown.shape)
        for (error in listOf(known, unknown, Diagnostics.httpFailure(502, secret), Diagnostics.httpFailure(403, """{"detail":"$secret"}"""))) {
            assertFalse(Diagnostics.render(ProbeStage.TOKEN_EXCHANGE, error).contains(secret))
        }
    }
    @Test fun oauthServerErrorIsNotMisreportedAsUserDecline() {
        val a = OAuthProtocol.Attempt("http://127.0.0.1:1/auth/callback", "host")
        try { OAuthProtocol.callback("/auth/callback?state=${a.state}&error=server_error&error_description=$secret", a); fail() }
        catch (e: OAuthProtocol.Denied) {
            assertEquals(KnownOAuthError.SERVER_ERROR, e.oauth)
            val safe = Diagnostics.render(ProbeStage.CALLBACK, e)
            assertFalse(safe.contains(secret)); assertFalse(safe.contains("授权已拒绝"))
        }
    }
    @Test fun stateIsCheckedBeforeOAuthError() {
        val a = OAuthProtocol.Attempt("http://127.0.0.1:1/auth/callback", "host")
        try { OAuthProtocol.callback("/auth/callback?state=wrong&error=access_denied", a); fail() }
        catch (e: DiagnosticFailure) { assertEquals(DiagnosticCode.CALLBACK_STATE, e.code) }
    }
    @Test fun discoveryMismatchHasSpecificStageAndDoesNotExchange() {
        var requests = 0
        val http = OkHttpClient.Builder().addInterceptor { chain ->
            requests++
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                .body("""{"issuer":"https://example.invalid"}""".toResponseBody("application/json".toMediaType())).build()
        }.build()
        val client = ProbeClient(http)
        try { client.signIn(OAuthProtocol.Attempt("http://127.0.0.1:1/auth/callback", "host"), OAuthProtocol.Callback(secret, "oaiapp_fixture"), ""); fail() }
        catch (e: DiagnosticFailure) {
            assertEquals(ProbeStage.DISCOVERY, client.stage)
            assertEquals(DiagnosticCode.DISCOVERY_MISMATCH, e.code)
            assertEquals(1, requests)
            assertFalse(Diagnostics.render(client.stage, e).contains(secret))
        } finally { client.close() }
    }
    @Test fun modelShapeFailureRetainsIdentityStageEvidence() {
        val client = ProbeClient(OkHttpClient.Builder().addInterceptor { chain ->
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                .body("""{"data":[]}""".toResponseBody("application/json".toMediaType())).build()
        }.build())
        try { client.models(ProbeSession("oaiapp_fixture", "fixture", secret, setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE)); fail() }
        catch (e: DiagnosticFailure) {
            assertEquals(ProbeStage.MODELS, client.stage); assertEquals(DiagnosticCode.MODEL_SCHEMA, e.code)
            assertTrue(Diagnostics.render(client.stage, e).contains("身份已校验"))
            assertFalse(Diagnostics.render(client.stage, e).contains(secret))
        } finally { client.close() }
    }
    @Test fun syntheticCompleteExchangeChecksStagesAndSpecificNonceFailure() {
        val key = RSAKeyGenerator(2048).keyID("synthetic-key").generate()
        val attempt = OAuthProtocol.Attempt("http://127.0.0.1:1/auth/callback", "host")
        val claims = JWTClaimsSet.Builder().issuer(OAuthProtocol.ISSUER).audience("oaiapp_fixture").subject(secret)
            .claim("nonce", "wrong-nonce").issueTime(Date()).expirationTime(Date(System.currentTimeMillis() + 60000)).build()
        val token = SignedJWT(JWSHeader.Builder(JWSAlgorithm.RS256).keyID(key.keyID).build(), claims).apply { sign(RSASSASigner(key)) }.serialize()
        val discovery = """{"issuer":"${OAuthProtocol.ISSUER}","authorization_endpoint":"${OAuthProtocol.AUTH}","token_endpoint":"${OAuthProtocol.TOKEN}","jwks_uri":"${OAuthProtocol.JWKS}"}"""
        val visited = mutableListOf<ProbeStage>()
        val http = OkHttpClient.Builder().addInterceptor { chain ->
            val body = when (chain.request().url.toString()) {
                "${OAuthProtocol.ISSUER}/.well-known/openid-configuration" -> discovery
                OAuthProtocol.TOKEN -> """{"id_token":"$token"}"""
                OAuthProtocol.JWKS -> JWKSet(key.toPublicJWK()).toString()
                else -> error("Unexpected request")
            }
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                .body(body.toResponseBody("application/json".toMediaType())).build()
        }.build()
        val client = ProbeClient(http).apply { progress = { visited.add(it) } }
        try { client.signIn(attempt, OAuthProtocol.Callback("synthetic", "oaiapp_fixture"), ""); fail() }
        catch (e: DiagnosticFailure) {
            assertEquals(listOf(ProbeStage.DISCOVERY, ProbeStage.TOKEN_EXCHANGE, ProbeStage.JWKS, ProbeStage.ID_TOKEN), visited)
            assertEquals(DiagnosticCode.JWT_NONCE, e.code)
            val report = Diagnostics.render(client.stage, e)
            assertFalse(report.contains(secret)); assertFalse(report.contains(token))
        } finally { client.close() }
    }
    @Test fun preflightNeverRequestsTokensOrUsesAuthorizationHeaders() {
        val key = RSAKeyGenerator(2048).keyID("preflight-key").generate()
        val paths = mutableListOf<String>()
        val http = OkHttpClient.Builder().addInterceptor { chain ->
            val r = chain.request()
            assertEquals("GET", r.method); assertNull(r.header("Authorization")); assertNull(r.body)
            paths.add(r.url.encodedPath)
            val body = if (r.url.encodedPath.endsWith("openid-configuration")) {
                """{"issuer":"${OAuthProtocol.ISSUER}","authorization_endpoint":"${OAuthProtocol.AUTH}","token_endpoint":"${OAuthProtocol.TOKEN}","jwks_uri":"${OAuthProtocol.JWKS}"}"""
            } else JWKSet(key.toPublicJWK()).toString()
            Response.Builder().request(r).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                .body(body.toResponseBody("application/json".toMediaType())).build()
        }.build()
        val client = ProbeClient(http)
        try {
            client.preflight()
            assertEquals(listOf("/.well-known/openid-configuration", "/.well-known/jwks.json"), paths)
        } finally { client.close() }
    }
}
