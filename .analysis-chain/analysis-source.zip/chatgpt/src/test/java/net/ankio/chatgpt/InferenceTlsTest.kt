package net.ankio.chatgpt

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.Source
import okio.Timeout
import okio.buffer
import org.junit.Assert.*
import org.junit.Test
import javax.net.ssl.SSLException
import javax.net.ssl.SSLHandshakeException

/** Synthetic transport only. No account, server connection, or trust override. */
class InferenceTlsTest {
    @Test fun modelsCanSucceedBeforeAnInferenceHandshakeFailure() = checkFailure(false)
    @Test fun tlsCanFailAfterResponseHeadersAndMustNotBeAutomaticallyRetried() = checkFailure(true)

    private fun checkFailure(afterHeaders: Boolean) {
        var requests = 0
        val secret = "synthetic-private-detail"
        val http = OkHttpClient.Builder().addInterceptor { chain ->
            requests++
            val request = chain.request()
            assertEquals("https", request.url.scheme)
            assertEquals("api.openai.com", request.url.host)
            val body = if (request.url.encodedPath == "/v1/models") {
                """{"models":[{"slug":"fixture","display_name":"Fixture","visibility":"list"}]}"""
                    .toResponseBody("application/json".toMediaType())
            } else {
                assertEquals("/v1/responses", request.url.encodedPath)
                assertEquals("POST", request.method)
                if (!afterHeaders) throw SSLHandshakeException(secret)
                object : ResponseBody() {
                    override fun contentType() = "text/event-stream".toMediaType()
                    override fun contentLength() = -1L
                    override fun source(): BufferedSource = object : Source {
                        override fun read(sink: Buffer, byteCount: Long): Long = throw SSLException(secret)
                        override fun timeout() = Timeout.NONE
                        override fun close() {}
                    }.buffer()
                }
            }
            Response.Builder().request(request).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                .header("Content-Type", if (afterHeaders) "text/event-stream" else "application/json")
                .body(body).build()
        }.build()
        val client = ProbeClient(http)
        val session = ProbeSession("oaiapp_fixture", "fixture", "synthetic-token",
            setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE)
        try {
            val models = client.models(session)
            assertEquals(1, models.size)
            try { client.test(session, models.single()); fail("Expected synthetic TLS failure") }
            catch (e: DiagnosticFailure) {
                assertEquals(ProbeStage.INFERENCE, client.stage)
                assertEquals(if (afterHeaders) DiagnosticCode.TLS_IO else DiagnosticCode.TLS_HANDSHAKE, e.code)
                assertFalse(Diagnostics.render(client.stage, e).contains(secret))
            }
            assertTrue(session.tested)
            assertEquals(2, requests)
            try { client.test(session, models.single()); fail("Must not replay inference") }
            catch (e: DiagnosticFailure) { assertEquals(DiagnosticCode.ALREADY_TESTED, e.code) }
            assertEquals(2, requests)
        } finally { client.close() }
    }
}
