package net.ankio.chatgpt

import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class LoopbackListenerTest {
    @Test fun actualLoopbackRejectsBadStateThenAcceptsOneValidCallback() {
        val worker = Executors.newSingleThreadExecutor()
        try {
            LoopbackListener().use { listener ->
                val attempt = OAuthProtocol.Attempt(listener.redirect, "fixture-host")
                val future = worker.submit<OAuthProtocol.Callback> { listener.await(attempt, 5000) }
                val http = OkHttpClient.Builder().callTimeout(3, TimeUnit.SECONDS).build()
                http.newCall(Request.Builder().url("${listener.redirect}?state=wrong&code=synthetic&client_id=oaiapp_fixture").build()).execute().use {
                    assertEquals(400, it.code)
                }
                http.newCall(Request.Builder().url("${listener.redirect}?state=${attempt.state}&code=synthetic&client_id=oaiapp_fixture").build()).execute().use {
                    assertEquals(200, it.code)
                    assertFalse(it.body!!.string().contains("synthetic"))
                    assertEquals("no-store", it.header("Cache-Control"))
                }
                val callback = future.get(3, TimeUnit.SECONDS)
                assertEquals("oaiapp_fixture", callback.client)
            }
        } finally { worker.shutdownNow() }
    }
    @Test fun callbackWaitExpires() {
        LoopbackListener().use { listener ->
            try { listener.await(OAuthProtocol.Attempt(listener.redirect, "fixture-host"), 1); fail() }
            catch (_: java.net.SocketTimeoutException) { }
        }
    }
}
