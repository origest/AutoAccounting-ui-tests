package net.ankio.chatgpt

import okhttp3.*
import org.junit.Assert.*
import org.junit.Test
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Proxy
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MissingTypeTest {
    private val completed = "event: response.completed\ndata: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\"}}\n\n"
    @Test fun lowercaseHeaderIsReadByOkHttpAndStreamsSuccessfully() = fixture("content-type: text/event-stream\r\n", completed, null, ResponseType.SSE)
    @Test fun mixedCaseHeaderIsReadByOkHttpAndStreamsSuccessfully() = fixture("CoNtEnT-TyPe: Text/Event-Stream; charset=utf-8\r\n", completed, null, ResponseType.SSE)
    @Test fun missingHeaderWithValidSseCompletesWithoutAnotherRequest() = fixture("", completed, null, ResponseType.MISSING)
    @Test fun missingHeaderWithChunkedSseCompletes() = fixture("", completed, null, ResponseType.MISSING, chunked = true)
    @Test fun missingHeaderWithEmptyBodyFails() = fixture("", "", DiagnosticCode.STREAM_EMPTY, ResponseType.MISSING)
    @Test fun missingHeaderWithHtmlFailsWithoutLeakingBody() = fixture("", "<html>PRIVATE_BODY</html>\n", DiagnosticCode.STREAM_FORMAT, ResponseType.MISSING)
    @Test fun missingHeaderWithJsonDoesNotBecomeSuccess() = fixture("", "{\"object\":\"response\",\"status\":\"completed\"}\n", DiagnosticCode.STREAM_FORMAT, ResponseType.MISSING)
    @Test fun missingHeaderWithIncompleteSseDoesNotBecomeSuccess() = fixture("", "data: [DONE]\n\n", DiagnosticCode.STREAM_ENDED, ResponseType.MISSING)
    @Test fun explicitHtmlTypeIsStillRejectedEvenForSseBody() = fixture("Content-Type: text/html\r\n", completed, DiagnosticCode.STREAM_CONTENT_TYPE, ResponseType.HTML)
    private fun fixture(headers: String, body: String, error: DiagnosticCode?, type: ResponseType, chunked: Boolean = false) {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val worker = Executors.newSingleThreadExecutor()
        var requests = 0
        val served = worker.submit {
            server.accept().use { socket ->
                socket.soTimeout = 5000
                val reader = socket.getInputStream().bufferedReader()
                assertTrue(reader.readLine().startsWith("POST /fixture "))
                var length = 0
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    if (line.startsWith("Content-Length:", true)) length = line.substringAfter(':').trim().toInt()
                }
                repeat(length) { reader.read() }
                val bytes = body.toByteArray()
                val output = socket.getOutputStream()
                if (chunked) {
                    output.write(("HTTP/1.1 200 OK\r\n${headers}Transfer-Encoding: chunked\r\n\r\n").toByteArray())
                    body.chunked(7).forEach { part ->
                        output.write((part.toByteArray().size.toString(16) + "\r\n" + part + "\r\n").toByteArray())
                        output.flush()
                    }
                    output.write("0\r\n\r\n".toByteArray())
                } else {
                    output.write(("HTTP/1.1 200 OK\r\n${headers}Content-Length: ${bytes.size}\r\n\r\n").toByteArray())
                    output.write(bytes)
                }
            }
        }
        val client = ProbeClient(OkHttpClient.Builder().proxy(Proxy.NO_PROXY).callTimeout(5, TimeUnit.SECONDS).addInterceptor { chain ->
            requests++
            // This test rewrites only synthetic requests to a real local HTTP fixture.
            val response = chain.proceed(chain.request().newBuilder().url("http://127.0.0.1:${server.localPort}/fixture").build())
            assertEquals(type, Diagnostics.responseType(response.headers.values("Content-Type")))
            response
        }.build())
        val session = ProbeSession("fixture", "fixture", "synthetic", setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE)
        try {
            try { client.test(session, ProbeModel("fixture", "Fixture")); assertNull(error) }
            catch (e: DiagnosticFailure) {
                assertEquals(error, e.code); assertEquals(200, e.http); assertEquals(type, e.responseType)
                assertFalse(Diagnostics.render(client.stage, e).contains("PRIVATE_BODY"))
            }
            assertEquals(1, requests)
            try { client.test(session, ProbeModel("fixture", "Fixture")); fail() }
            catch (e: DiagnosticFailure) { assertEquals(DiagnosticCode.ALREADY_TESTED, e.code) }
            assertEquals(1, requests)
            served.get(5, TimeUnit.SECONDS)
        } finally { client.close(); server.close(); worker.shutdownNow() }
    }
}
