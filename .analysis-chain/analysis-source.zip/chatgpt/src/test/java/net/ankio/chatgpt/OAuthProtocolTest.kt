package net.ankio.chatgpt

import com.nimbusds.jose.*
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jose.jwk.JWKSet
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator
import com.nimbusds.jwt.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.junit.Assert.*
import org.junit.Test
import java.util.Date

class OAuthProtocolTest {
    private val now = 1_700_000_000L
    private val key by lazy { RSAKeyGenerator(2048).keyID("fixture-key").generate() }
    private fun token(change: (JWTClaimsSet.Builder) -> Unit = {}): String {
        val claims = JWTClaimsSet.Builder().issuer(OAuthProtocol.ISSUER).audience("oaiapp_fixture")
            .subject("synthetic-person").claim("nonce", "fixture-nonce")
            .issueTime(Date((now - 10) * 1000)).expirationTime(Date((now + 600) * 1000))
        change(claims)
        return SignedJWT(JWSHeader.Builder(JWSAlgorithm.RS256).keyID(key.keyID).build(), claims.build())
            .apply { sign(RSASSASigner(key)) }.serialize()
    }
    private fun verify(token: String, nonce: String = "fixture-nonce") = OAuthProtocol.validateIdToken(
        token, JWKSet(key.toPublicJWK()).toString(), "oaiapp_fixture", nonce, now)
    private fun rejected(block: () -> Unit) { try { block(); fail("Expected rejection") } catch (_: Exception) { } }

    @Test fun pkceMatchesRfc7636Vector() {
        assertEquals("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM", OAuthProtocol.digest("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"))
    }
    @Test fun authorizationUsesDynamicRegistrationAndExactLoopback() {
        val a = OAuthProtocol.Attempt("http://127.0.0.1:12345/auth/callback", "urn:uuid:fixture")
        val url = a.authorizationUrl().toHttpUrl()
        assertEquals(OAuthProtocol.DYNAMIC, url.queryParameter("client_id"))
        assertEquals(a.redirect, url.queryParameter("redirect_uri"))
        assertEquals("S256", url.queryParameter("code_challenge_method"))
        assertEquals(OAuthProtocol.digest(a.verifier), url.queryParameter("code_challenge"))
        assertFalse(url.toString().contains(a.verifier))
        assertTrue(url.queryParameter("scope")!!.contains(OAuthProtocol.PLAN_SCOPE))
        assertNotEquals(a.state, OAuthProtocol.Attempt(a.redirect, a.host).state)
    }
    @Test fun issuedClientIsReusedAndCannotBeSwapped() {
        val a = OAuthProtocol.Attempt("http://127.0.0.1:1/auth/callback", "host", "oaiapp_fixture")
        val url = a.authorizationUrl().toHttpUrl()
        assertNull(url.queryParameter("agent_name_hint"))
        assertEquals("oaiapp_fixture", OAuthProtocol.callback("/auth/callback?state=${a.state}&code=synthetic", a).client)
        rejected { OAuthProtocol.callback("/auth/callback?state=${a.state}&code=synthetic&client_id=oaiapp_other", a) }
    }
    @Test fun invalidCallbacksNeverReachExchange() {
        val a = OAuthProtocol.Attempt("http://127.0.0.1:1/auth/callback", "host")
        for (target in listOf("/auth/callback?code=synthetic&client_id=oaiapp_fixture", "/auth/callback?state=wrong&error=access_denied",
            "/auth/callback?state=${a.state}&code=synthetic", "/callback?state=${a.state}&code=synthetic&client_id=oaiapp_fixture",
            "/auth/callback?state=${a.state}&state=duplicate&code=synthetic&client_id=oaiapp_fixture",
            "/auth/callback?state=${a.state}&code=synthetic&client_id=dynamic_agent_client")) {
            rejected { OAuthProtocol.callback(target, a) }
        }
        try { OAuthProtocol.callback("/auth/callback?state=${a.state}&error=access_denied", a); fail() }
        catch (_: OAuthProtocol.Denied) { }
    }
    @Test fun verifiesRealRsaSignatureAndSubject() { assertEquals("synthetic-person", verify(token())) }
    @Test fun rejectsWrongNonceAudienceIssuerExpiryAndMissingIssuedAt() {
        rejected { verify(token(), "wrong-nonce") }
        rejected { verify(token { it.audience("oaiapp_other") }) }
        rejected { verify(token { it.issuer("https://example.invalid") }) }
        rejected { verify(token { it.expirationTime(Date((now - 1) * 1000)) }) }
        rejected { verify(token { it.issueTime(null) }) }
        rejected { verify(token { it.audience(listOf("oaiapp_fixture", "other")) }) }
    }
    @Test fun rejectsWrongSignatureKeyAndUnsignedJwt() {
        val other = RSAKeyGenerator(2048).keyID("fixture-key").generate()
        rejected { OAuthProtocol.validateIdToken(token(), JWKSet(other.toPublicJWK()).toString(), "oaiapp_fixture", "fixture-nonce", now) }
        rejected { verify("eyJhbGciOiJub25lIn0.e30.") }
    }
    @Test fun identityScopesCannotEnableInference() {
        assertFalse(OAuthProtocol.canInfer(setOf("openid", "profile", "email")))
        assertFalse(OAuthProtocol.canInfer(setOf(OAuthProtocol.PLAN_SCOPE)))
        assertTrue(OAuthProtocol.canInfer(setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE)))
    }
    @Test fun testPayloadContainsOnlyFixedTextAndSupportedFields() {
        val input = OAuthProtocol.testInput("fixture-model")
        assertEquals(setOf("model", "input", "store", "stream"), input.keySet())
        assertFalse(input["store"].asBoolean); assertTrue(input["stream"].asBoolean)
        assertTrue(input["input"].isJsonArray)
        assertEquals("Reply with only the word Hello.", input["input"].asJsonArray[0].asJsonObject["content"].asString)
    }
    @Test fun streamRequiresTerminalSuccessAndRejectsLateFailure() {
        val stream = SseCompletion()
        assertFalse(stream.line("data: {\"type\":\"response.output_text.delta\",\"delta\":\"Hello\"}"))
        assertFalse(stream.line(""))
        stream.line("data: {\"type\":\"response.failed\"}")
        rejected { stream.line("") }
        val ok = SseCompletion()
        ok.line("data: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\"}}")
        assertTrue(ok.line(""))
        val incomplete = SseCompletion()
        incomplete.line("data: [DONE]"); assertFalse(incomplete.line(""))
    }
}
