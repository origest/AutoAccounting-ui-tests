package net.ankio.chatgpt

import com.google.gson.Gson
import org.junit.Assert.*
import org.junit.Test

class OcrTextConsentTest {
    @Test fun newAccountsRequireSeparateOcrConsent() {
        val account = AccountRecord()
        assertFalse(account.consent)
        assertFalse(account.ocrTextConsent)
        account.consent = true
        assertFalse(account.ocrTextConsent)
    }

    @Test fun existingCategoryConsentDoesNotMigrateIntoOcrConsent() {
        val state = Gson().fromJson(
            """{"active":"synthetic","accounts":[{"client":"synthetic","consent":true,"model":"fixture-model"}]}""",
            AccountState::class.java
        )
        assertTrue(state.accounts.single().consent)
        assertFalse(state.accounts.single().ocrTextConsent)
    }

    @Test fun bothConsentFlagsRoundTripIndependently() {
        for (category in listOf(false, true)) for (ocr in listOf(false, true)) {
            val account = AccountRecord().apply { consent = category; ocrTextConsent = ocr }
            val restored = Gson().fromJson(Gson().toJson(account), AccountRecord::class.java)
            assertEquals(category, restored.consent)
            assertEquals(ocr, restored.ocrTextConsent)
        }
    }

    @Test fun oldAccountViewCallersDoNotAssumeOcrConsent() {
        val view = ChatGptAccounts.AccountView("synthetic", "Synthetic", true, true, "fixture-model")
        assertFalse(view.ocrEnabled)
    }
}
