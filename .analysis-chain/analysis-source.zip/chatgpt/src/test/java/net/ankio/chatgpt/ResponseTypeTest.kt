package net.ankio.chatgpt

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class ResponseTypeTest {
    private val secret = "PRIVATE_BODY_ACCOUNT_TOKEN"
    @Test fun contentTypesAreFixedEnumsOnly() {
        assertEquals(ResponseType.SSE, Diagnostics.responseType(listOf("Text/Event-Stream; charset=utf-8")))
        assertEquals(ResponseType.JSON, Diagnostics.responseType(listOf("application/problem+json")))
        assertEquals(ResponseType.HTML, Diagnostics.responseType(listOf("text/html")))
        assertEquals(ResponseType.MISSING, Diagnostics.responseType(emptyList()))
        assertEquals(ResponseType.CONFLICTING, Diagnostics.responseType(listOf("application/json", "text/event-stream")))
        assertEquals(ResponseType.OTHER, Diagnostics.responseType(listOf(secret)))
    }
    @Test fun successfulStatusJsonErrorIsNotAcceptedAsInference() {
        check(200, "application/json", """{"error":{"code":"subscription_sharing_usage_limit_exceeded","message":"$secret"}}""",
            DiagnosticCode.STREAM_CONTENT_TYPE, ResponseType.JSON, ErrorShape.API_ERROR_OBJECT, KnownOAuthError.LIMIT_EXCEEDED)
    }
    @Test fun htmlAndMissingHeadersAreSafelyDistinguished() {
        check(200, "text/html", "<html>$secret</html>", DiagnosticCode.STREAM_CONTENT_TYPE, ResponseType.HTML, ErrorShape.OTHER, KnownOAuthError.UNKNOWN)
        check(204, null, "", DiagnosticCode.STREAM_CONTENT_TYPE, ResponseType.MISSING, ErrorShape.OTHER, KnownOAuthError.UNKNOWN)
    }
    @Test fun nonStreamingResponseObjectIsNotAcceptedAsSuccess() {
        check(200, "application/json", """{"object":"response","status":"completed","output":["$secret"]}""",
            DiagnosticCode.STREAM_CONTENT_TYPE, ResponseType.JSON, ErrorShape.RESPONSE_OBJECT, KnownOAuthError.UNKNOWN)
    }
    @Test fun failureStatusRetainsPriorityAndUnknownCodesAreRedacted() {
        check(403, "application/json", """{"error":{"code":"$secret","message":"$secret"}}""",
            DiagnosticCode.HTTP_ERROR, ResponseType.JSON, ErrorShape.API_ERROR_OBJECT, KnownOAuthError.UNKNOWN)
        check(302, "text/html", secret, DiagnosticCode.HTTP_ERROR, ResponseType.HTML, ErrorShape.OTHER, KnownOAuthError.UNKNOWN)
    }
    @Test fun realLoopbackResponseCleanupCannotOverwriteFailureStage() {
        val server = java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
        val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
        val served = worker.submit {
            server.accept().use { socket ->
                socket.soTimeout = 5000
                val reader = socket.getInputStream().bufferedReader()
                var length = 0
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    if (line.startsWith("Content-Length:", true)) length = line.substringAfter(':').trim().toInt()
                }
                repeat(length) { reader.read() }
                val body = "<html>synthetic</html>"
                socket.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: ${body.length}\r\n\r\n$body").toByteArray())
            }
        }
        val client = ProbeClient(OkHttpClient.Builder().proxy(java.net.Proxy.NO_PROXY)
            .callTimeout(5, java.util.concurrent.TimeUnit.SECONDS).addInterceptor { chain ->
                // Route synthetic test traffic to a local fixture, never to OpenAI.
                chain.proceed(chain.request().newBuilder().url("http://127.0.0.1:${server.localPort}/fixture").build())
            }.build())
        try {
            try { client.test(ProbeSession("fixture", "fixture", "synthetic", setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE), ProbeModel("fixture", "Fixture")); fail() }
            catch (e: DiagnosticFailure) {
                assertEquals(DiagnosticCode.STREAM_CONTENT_TYPE, e.code)
                assertEquals(200, e.http); assertEquals(ResponseType.HTML, e.responseType)
                assertEquals(TransportPhase.RESPONSE_HEADERS, e.transport)
            }
            served.get(5, java.util.concurrent.TimeUnit.SECONDS)
        } finally { client.close(); server.close(); worker.shutdownNow() }
    }
    private fun check(status: Int, type: String?, body: String, code: DiagnosticCode, responseType: ResponseType, shape: ErrorShape, oauth: KnownOAuthError) {
        var requests = 0
        val client = ProbeClient(OkHttpClient.Builder().followRedirects(false).addInterceptor { chain ->
            requests++
            val request = chain.request()
            assertEquals("https://api.openai.com/v1/responses", request.url.toString())
            assertEquals("POST", request.method)
            assertEquals("text/event-stream", request.header("Accept"))
            assertEquals("Bearer synthetic-token", request.header("Authorization"))
            assertTrue(request.body!!.contentType().toString().startsWith("application/json"))
            val buffer = Buffer(); request.body!!.writeTo(buffer)
            val payload = JsonParser.parseString(buffer.readUtf8()).asJsonObject
            assertTrue(payload["stream"].asBoolean); assertFalse(payload["store"].asBoolean)
            assertEquals("fixture-slug", payload["model"].asString)
            assertEquals(setOf("model", "store", "stream", "input"), payload.keySet())
            Response.Builder().request(request).code(status).message("synthetic").protocol(Protocol.HTTP_1_1)
                .apply { if (type != null) header("Content-Type", type) }
                .body(body.toResponseBody(type?.toMediaType())).build()
        }.build())
        val session = ProbeSession("fixture", "fixture", "synthetic-token", setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE)
        try {
            try { client.test(session, ProbeModel("fixture-slug", "Synthetic")); fail() }
            catch (e: DiagnosticFailure) {
                assertEquals(code, e.code); assertEquals(status, e.http)
                assertEquals(responseType, e.responseType); assertEquals(shape, e.shape); assertEquals(oauth, e.oauth)
                assertEquals(TransportPhase.RESPONSE_HEADERS, e.transport)
                assertFalse(Diagnostics.render(client.stage, e).contains(secret))
            }
            assertEquals(1, requests)
        } finally { client.close() }
    }
}
