package net.ankio.chatgpt

import org.junit.Assert.*
import org.junit.Test
import javax.net.ssl.*
import java.security.cert.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody

class StreamDiagnosticsTest {
    private val secret = "PRIVATE_token_account_body"
    private fun eventFails(payload: String, code: DiagnosticCode) {
        val parser = SseCompletion()
        try { parser.line("data: $payload"); parser.line(""); fail("Expected fixed diagnostic") }
        catch (e: DiagnosticFailure) {
            assertEquals(code, e.code)
            val report = Diagnostics.render(ProbeStage.INFERENCE, e)
            assertFalse(report.contains(secret)); assertNull(e.cause); assertNull(e.message)
        }
    }
    @Test fun malformedAndNonObjectJsonAreClassified() {
        eventFails("{\"$secret", DiagnosticCode.STREAM_JSON)
        eventFails("[\"$secret\"]", DiagnosticCode.STREAM_JSON)
        eventFails("null", DiagnosticCode.STREAM_JSON)
    }
    @Test fun missingAndInvalidTypesAreClassified() {
        eventFails("{}", DiagnosticCode.STREAM_SCHEMA)
        eventFails("{\"type\":{\"$secret\":1}}", DiagnosticCode.STREAM_SCHEMA)
        eventFails("{\"type\":\"response.completed\"}", DiagnosticCode.STREAM_SCHEMA)
    }
    @Test fun invalidCompletionCannotBecomeSuccess() {
        eventFails("""{"type":"response.completed","response":{"status":"$secret"}}""", DiagnosticCode.STREAM_COMPLETION)
        eventFails("""{"type":"response.completed","response":{"status":null}}""", DiagnosticCode.STREAM_COMPLETION)
    }
    @Test fun oversizedEventHasFixedCode() {
        eventFails(secret.repeat(4000), DiagnosticCode.STREAM_EVENT_LIMIT)
    }
    @Test fun validAndUnknownEventsRemainCompatible() {
        val p = SseCompletion()
        assertFalse(p.line(": heartbeat"))
        assertFalse(p.line("data: {\"type\":\"future.event\"}")); assertFalse(p.line(""))
        assertFalse(p.line("data: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\"}}"))
        assertTrue(p.line(""))
    }
    @Test fun tlsSubtypesAndNestedCausesAreSafe() {
        val cases = listOf(
            SSLHandshakeException(secret) to DiagnosticCode.TLS_HANDSHAKE,
            SSLHandshakeException(secret).apply { initCause(CertificateExpiredException(secret)) } to DiagnosticCode.TLS_CERT_TIME,
            SSLHandshakeException(secret).apply { initCause(CertificateException(secret)) } to DiagnosticCode.TLS_CERT_CHAIN,
            SSLHandshakeException(secret).apply { initCause(CertPathValidatorException(secret)) } to DiagnosticCode.TLS_CERT_CHAIN,
            SSLPeerUnverifiedException(secret) to DiagnosticCode.TLS_PEER,
            SSLProtocolException(secret) to DiagnosticCode.TLS_PROTOCOL,
            SSLException(secret) to DiagnosticCode.TLS_IO)
        cases.forEach { (error, code) ->
            assertEquals(code, Diagnostics.normalize(error).code)
            assertFalse(Diagnostics.render(ProbeStage.INFERENCE, error).contains(secret))
        }
    }
    @Test fun nonSseResponseIsClassifiedBeforeReadingBody() {
        checkResponse("application/json", "{\"private\":\"$secret\"}", DiagnosticCode.STREAM_CONTENT_TYPE, TransportPhase.RESPONSE_HEADERS)
    }
    @Test fun truncatedLineAndMissingTerminalEventAreClassified() {
        checkResponse("text/event-stream", "data: {\"type\":\"$secret\"}", DiagnosticCode.STREAM_LINE, TransportPhase.READING_BODY)
        checkResponse("text/event-stream", "data: [DONE]\n\n", DiagnosticCode.STREAM_ENDED, TransportPhase.READING_BODY)
    }
    private fun checkResponse(type: String, body: String, code: DiagnosticCode, phase: TransportPhase) {
        var requests = 0
        val client = ProbeClient(OkHttpClient.Builder().addInterceptor { chain ->
            requests++
            Response.Builder().request(chain.request()).code(200).message("OK").protocol(Protocol.HTTP_1_1)
                .header("Content-Type", type).body(body.toResponseBody(type.toMediaType())).build()
        }.build())
        val session = ProbeSession("fixture", "fixture", "synthetic", setOf("resource.invoke", OAuthProtocol.PLAN_SCOPE), Long.MAX_VALUE)
        try {
            try { client.test(session, ProbeModel("fixture", "Fixture")); fail() }
            catch (e: DiagnosticFailure) {
                assertEquals(code, e.code); assertEquals(phase, e.transport)
                assertFalse(Diagnostics.render(client.stage, e).contains(secret))
            }
            assertTrue(session.tested); assertEquals(1, requests)
        } finally { client.close() }
    }
}
