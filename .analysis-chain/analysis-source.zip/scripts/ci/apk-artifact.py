#!/usr/bin/env python3
"""Allowlisted, source-bound APK transfer. Never exports signing private keys."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

LAYOUT = {
    'application.apk': ('app/build/outputs/apk/debug', 'net.ankio.auto'),
    'application-tests.apk': ('app/build/outputs/apk/androidTest/debug', 'net.ankio.auto.test'),
    'server-tests.apk': ('server/build/outputs/apk/androidTest/debug', 'org.ezbook.server.test'),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity():
    result = {key: os.environ[key] for key in ('GITHUB_SHA', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT', 'GITHUB_REPOSITORY')}
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == result['GITHUB_SHA']
    result['source_tree'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip()
    return result


def package_details(badging, package):
    details = re.search(r"^package: name='([^']+)' versionCode='([^']*)' versionName='([^']*)'", badging, re.M)
    assert details and details[1] == package, badging
    if package == 'net.ankio.auto':
        assert details[2].isdigit() and details[3], 'Main APK must have a version'
    return details


def pack():
    bundle = Path('apk-transfer'); bundle.mkdir(exist_ok=False)
    sdk = Path(os.environ['ANDROID_HOME']) / 'build-tools/35.0.0'
    manifest = {'schema': 1, 'identity': identity(), 'apks': {}}
    for name, (directory, package) in LAYOUT.items():
        matches = list(Path(directory).glob('*.apk')); assert len(matches) == 1, matches
        source = matches[0]; assert source.is_file() and not source.is_symlink()
        badging = subprocess.check_output([str(sdk / 'aapt'), 'dump', 'badging', str(source)], text=True)
        details = package_details(badging, package)
        abi = re.search(r'^native-code: (.*)$', badging, re.M)
        signature = subprocess.check_output([str(sdk / 'apksigner'), 'verify', '--print-certs', str(source)], text=True)
        certs = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]{64})$', signature, re.M)
        assert certs, 'Missing signer certificate SHA256'
        destination = bundle / name; shutil.copyfile(source, destination)
        manifest['apks'][name] = {'sha256': digest(destination), 'size': destination.stat().st_size,
            'package': package, 'version_code': details[2], 'version_name': details[3],
            'abis': re.findall(r"'([^']+)'", abi[1]) if abi else [],
            'signer_certificate_sha256': sorted({cert.lower() for cert in certs})}
    assert manifest['apks']['application.apk']['signer_certificate_sha256'] == manifest['apks']['application-tests.apk']['signer_certificate_sha256'], 'Application/test signer mismatch'
    path = bundle / 'manifest.json'; path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    with open(os.environ['GITHUB_OUTPUT'], 'a') as output:
        output.write('manifest-sha256=' + digest(path) + '\n')


def verify(bundle, anchor, expected):
    assert re.fullmatch(r'[0-9a-f]{64}', anchor), 'Invalid trusted manifest anchor'
    assert bundle.is_dir() and not bundle.is_symlink()
    assert {path.name for path in bundle.iterdir()} == {*LAYOUT, 'manifest.json'}, 'Unexpected transfer content'
    for path in bundle.iterdir():
        assert path.is_file() and not path.is_symlink(), 'Nonregular artifact file'
    path = bundle / 'manifest.json'
    assert digest(path) == anchor, 'Manifest integrity mismatch'
    manifest = json.loads(path.read_text())
    assert manifest['schema'] == 1 and manifest['identity'] == expected, 'Source/run identity mismatch'
    assert set(manifest['apks']) == set(LAYOUT)
    for name, (_, package) in LAYOUT.items():
        entry = manifest['apks'][name]; apk = bundle / name
        assert entry['package'] == package
        assert entry['size'] == apk.stat().st_size and entry['size'] > 0, 'APK size mismatch'
        assert entry['sha256'] == digest(apk), 'APK integrity mismatch'
        assert entry['signer_certificate_sha256'] and all(re.fullmatch(r'[0-9a-f]{64}', value) for value in entry['signer_certificate_sha256'])
    assert manifest['apks']['application.apk']['signer_certificate_sha256'] == manifest['apks']['application-tests.apk']['signer_certificate_sha256'], 'Application/test signer mismatch'
    return manifest


def restore():
    bundle = Path('apk-transfer')
    manifest = verify(bundle, os.environ['MANIFEST_SHA256'], identity())
    for name, (directory, _) in LAYOUT.items():
        target = Path(directory); target.mkdir(parents=True, exist_ok=True)
        assert not list(target.glob('*.apk')), 'Refusing to replace existing APKs'
        shutil.copyfile(bundle / name, target / name)
    Path('device-evidence').mkdir(exist_ok=True)
    shutil.copyfile(bundle / 'manifest.json', 'device-evidence/APK-MANIFEST.json')
    Path('device-evidence/MANIFEST-SHA256.txt').write_text(os.environ['MANIFEST_SHA256'] + '\n')
    Path('device-evidence/APK-SHA256SUMS.txt').write_text(''.join(f"{entry['sha256']}  {name}\n" for name, entry in manifest['apks'].items()))


def candidate():
    manifest = verify(Path('apk-transfer'), os.environ['MANIFEST_SHA256'], identity())
    # Verify the actual installed inputs have not changed since transfer validation.
    for name, (directory, _) in LAYOUT.items():
        assert digest(Path(directory) / name) == manifest['apks'][name]['sha256']
    summary = json.loads(Path('device-evidence/device-summary.json').read_text())
    assert summary['totals'] == {'tests': 56, 'failures': 0, 'errors': 0, 'skipped': 0}
    assert len(summary['screenshots']) >= 6
    out = Path('tested-candidate'); out.mkdir(exist_ok=False)
    shutil.copyfile('app/build/outputs/apk/debug/application.apk', out / 'application.apk')
    for name in ('APK-MANIFEST.json', 'MANIFEST-SHA256.txt', 'APK-SHA256SUMS.txt', 'SOURCE-COMMIT.txt', 'SOURCE-TREE.txt', 'device-summary.json'):
        shutil.copyfile(Path('device-evidence') / name, out / name)
    reports = out / 'reports'; reports.mkdir()
    for path in Path('device-evidence').glob('TEST-*.xml'):
        shutil.copyfile(path, reports / path.name)
    screenshots = out / 'screenshots'; screenshots.mkdir()
    for path in Path('device-evidence/screenshots').glob('*.png'):
        shutil.copyfile(path, screenshots / path.name)


if __name__ == '__main__':
    {'pack': pack, 'restore': restore, 'candidate': candidate}[sys.argv[1]]()
