#!/usr/bin/env bash
set -euo pipefail

# Read-only diagnostics. This helper never changes device permissions, groups,
# security settings, or process identity, and never starts an emulator.
stage="${1:-check}"
if [[ ! "$stage" =~ ^[a-z0-9-]{1,40}$ ]]; then
    echo 'Invalid KVM diagnostic stage' >&2
    exit 2
fi
mkdir -p device-evidence
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
report="device-evidence/kvm-access-${stage}-${timestamp}-$$.txt"

character_device=0
readable=0
writable=0
if test -c /dev/kvm; then character_device=1; fi
if test -r /dev/kvm; then readable=1; fi
if test -w /dev/kvm; then writable=1; fi

# Numeric IDs, fixed device metadata and ACLs only. Do not dump environment,
# process arguments, credentials, account data, or unrelated files.
{
    printf 'stage=%s\nutc=%s\n' "$stage" "$timestamp"
    printf 'uid='; id -u || echo unavailable
    printf 'real_uid='; id -ru || echo unavailable
    printf 'gid='; id -g || echo unavailable
    printf 'real_gid='; id -rg || echo unavailable
    printf 'groups='; id -G || echo unavailable
    for namespace in mnt user; do
        printf 'namespace_%s=' "$namespace"
        readlink "/proc/$$/ns/$namespace" || echo unavailable
    done
    stat --format='kind=%F mode=%a uid=%u gid=%g device=%t:%T filesystem=%d inode=%i ctime=%Z mtime=%Y' /dev/kvm || echo 'stat=unavailable'
    if command -v getfacl >/dev/null 2>&1; then
        getfacl --numeric --absolute-names /dev/kvm || echo 'acl=unavailable'
    else
        echo 'acl=unavailable (getfacl not installed)'
    fi
    printf 'character_device=%s\nreadable=%s\nwritable=%s\n' "$character_device" "$readable" "$writable"
} > "$report" 2>&1
printf 'KVM read-only diagnostics: %s\n' "$report"

# Explicit branches are intentional: `test -r ... && test -w ...` does not
# stop an errexit shell when the first command fails.
if [[ "$character_device" != 1 ]]; then
    echo 'KVM unavailable: /dev/kvm is not a character device' >&2
    exit 1
fi
if [[ "$readable" != 1 ]]; then
    echo 'KVM access denied: /dev/kvm is not readable; no permission change attempted' >&2
    exit 1
fi
if [[ "$writable" != 1 ]]; then
    echo 'KVM access denied: /dev/kvm is not writable; no permission change attempted' >&2
    exit 1
fi
