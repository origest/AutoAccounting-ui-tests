#!/usr/bin/env python3
"""Bounded diagnostics and shutdown of this job's synthetic emulator only."""
import os
from pathlib import Path
import subprocess

out = Path('device-evidence')
out.mkdir(exist_ok=True)
adb = str(Path(os.environ['ANDROID_HOME']) / 'platform-tools/adb')
commands = [
    ('adb-devices.txt', [adb, 'devices', '-l']),
    ('emulator-properties.txt', [adb, '-s', 'emulator-5554', 'shell', 'getprop']),
    ('emulator-final-logcat.txt', [adb, '-s', 'emulator-5554', 'logcat', '-d', '-t', '1500']),
    ('emulator-shutdown.txt', [adb, '-s', 'emulator-5554', 'emu', 'kill']),
]
# If startup never launched our AVD, do not query or stop a preexisting device.
if not (out / 'emulator.pid').exists():
    commands = commands[:1]
for name, command in commands:
    with (out / name).open('w') as output:
        try:
            subprocess.run(command, stdout=output, stderr=subprocess.STDOUT,
                           timeout=20, check=False, text=True)
        except (OSError, subprocess.TimeoutExpired) as error:
            output.write('\nDiagnostic unavailable: ' + str(error) + '\n')
