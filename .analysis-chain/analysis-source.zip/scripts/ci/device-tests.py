#!/usr/bin/env python3
"""Run only synthetic emulator fixtures and reject skipped/zero-test success."""
import glob, os, pathlib, re, subprocess, tarfile, xml.etree.ElementTree as ET
out = pathlib.Path('device-evidence'); out.mkdir(exist_ok=True)
def run(args, **kw): return subprocess.run(args, check=True, **kw)
def apk(pattern):
    paths = glob.glob(pattern); assert len(paths) == 1, paths
    return paths[0]
assert subprocess.check_output(['adb','shell','getprop','ro.kernel.qemu'], text=True).strip() == '1'
assert subprocess.check_output(['adb','shell','getprop','ro.build.version.sdk'], text=True).strip() == '34'
for path in [apk('app/build/outputs/apk/debug/*.apk'), apk('app/build/outputs/apk/androidTest/debug/*.apk'), apk('server/build/outputs/apk/androidTest/debug/*.apk')]:
    run(['adb','install','--no-streaming','-r',path], timeout=180)
suites = [
 ('net.ankio.auto.ChatGptSettingsDeviceTest', 1, 'net.ankio.auto.test'),
 ('net.ankio.auto.MaterialSettingsDeviceTest', 1, 'net.ankio.auto.test'),
 ('net.ankio.auto.classification.OwnerQueueStoreDeviceTest', 4, 'net.ankio.auto.test'),
 ('net.ankio.auto.classification.OwnerQueuePermissionDeviceTest', 10, 'net.ankio.auto.test'),
 ('net.ankio.auto.classification.OwnerQueueAuthorizationDeviceTest', 16, 'net.ankio.auto.test'),
 ('net.ankio.auto.classification.OwnerQueueProviderStopDeviceTest', 2, 'net.ankio.auto.test'),
 ('net.ankio.auto.capture.PaymentCaptureDeviceTest', 2, 'net.ankio.auto.test'),
 ('net.ankio.auto.capture.PaymentCaptureConcurrencyDeviceTest', 3, 'net.ankio.auto.test'),
 ('net.ankio.auto.capture.PaymentCaptureWindowTest', 1, 'net.ankio.auto.test'),
 ('org.ezbook.server.CategoryConfirmationDeviceTest', 3, 'org.ezbook.server.test'),
 ('org.ezbook.server.OwnerQueueDeviceTest', 2, 'org.ezbook.server.test'),
 ('org.ezbook.server.OwnerQueueAuthorizationDeviceTest', 8, 'org.ezbook.server.test'),
 ('org.ezbook.server.OwnerQueueAuthorizationHttpDeviceTest', 3, 'org.ezbook.server.test'),
]
try:
    for name, expected, package in suites:
        result = run(['adb','shell','am','instrument','-w','-r','-e','class',name,package+'/androidx.test.runner.AndroidJUnitRunner'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=300)
        (out/(name+'.log')).write_text(result.stdout)
        codes = [int(x) for x in re.findall(r'^INSTRUMENTATION_STATUS_CODE: (-?\d+)\s*$', result.stdout, re.M)]
        print(name, 'expected', expected, 'status codes', codes, flush=True)
        assert codes.count(0) == expected and codes.count(1) == expected, result.stdout
        assert all(code in (0,1) for code in codes), result.stdout
        assert re.search(r'OK \('+str(expected)+r' tests?\)', result.stdout), result.stdout
        assert 'FAILURES' not in result.stdout and 'Process crashed' not in result.stdout, result.stdout
        suite = ET.Element('testsuite', name=name, tests=str(expected), failures='0', errors='0', skipped='0')
        for test in re.findall(r'^INSTRUMENTATION_STATUS: test=(.+)$', result.stdout, re.M)[::2]:
            ET.SubElement(suite, 'testcase', classname=name, name=test)
        ET.ElementTree(suite).write(out/('TEST-'+name+'.xml'), encoding='utf-8', xml_declaration=True)
finally:
    # Own empty-account fixture views only; never disable production FLAG_SECURE for UI evidence.
    with (out/'screenshots.tar').open('wb') as f:
        collected = subprocess.run(['adb','exec-out','run-as','net.ankio.auto','tar','-C','no_backup/ui-test-evidence','-cf','-','.'], stdout=f, stderr=subprocess.PIPE, timeout=30)
    if collected.returncode == 0:
        with tarfile.open(out/'screenshots.tar') as archive:
            archive.extractall(out/'screenshots', filter='data')
    subprocess.run(['adb','logcat','-d','-t','1500'], stdout=(out/'emulator-logcat.txt').open('w'), timeout=30)
assert len(list((out/'screenshots').glob('*.png'))) >= 6, 'Missing UI evidence'
(out/'SOURCE-COMMIT.txt').write_text(os.environ['GITHUB_SHA']+'\n')
print(f'All {sum(expected for _, expected, _ in suites)} device tests passed, no skipped tests.')
