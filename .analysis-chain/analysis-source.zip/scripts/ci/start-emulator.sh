#!/usr/bin/env bash
set -euo pipefail
mkdir -p device-evidence
test -c /dev/kvm
# Documented GitHub-hosted runner setup; applies only to this disposable VM.
printf '%s\n' 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules
sudo udevadm control --reload-rules
sudo udevadm trigger --name-match=kvm
test -r /dev/kvm && test -w /dev/kvm
"$ANDROID_HOME/emulator/emulator" -accel-check | tee device-evidence/acceleration.txt
printf 'no\n' | avdmanager create avd --force --name synthetic34 --package 'system-images;android-34;default;x86_64'
"$ANDROID_HOME/emulator/emulator" -avd synthetic34 -accel on -no-window -no-audio -no-boot-anim -no-snapshot -gpu swiftshader -memory 2048 -cores 2 -skin 720x1280 > device-evidence/emulator-start.log 2>&1 &
printf '%s\n' "$!" > device-evidence/emulator.pid
timeout 300 bash -c 'until adb shell getprop sys.boot_completed 2>/dev/null | tr -d "\r" | grep -qx 1; do sleep 3; done'
adb shell wm density 320
adb shell settings put global window_animation_scale 0
adb shell settings put global transition_animation_scale 0
adb shell settings put global animator_duration_scale 0
adb shell input keyevent 82
