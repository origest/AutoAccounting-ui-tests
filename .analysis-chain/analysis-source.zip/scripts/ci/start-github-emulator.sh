#!/usr/bin/env bash
set -euo pipefail
mkdir -p device-evidence
# Recent command-line tools and emulator releases can choose different defaults.
# Give both tools the same explicit home and verify discovery before launching.
export ANDROID_USER_HOME="$HOME/.android"
export ANDROID_EMULATOR_HOME="$ANDROID_USER_HOME"
export ANDROID_AVD_HOME="$ANDROID_USER_HOME/avd"
mkdir -p "$ANDROID_AVD_HOME"
# Any required one-time user-approved access was configured in the workflow.
# Launch as the ordinary runner user; never retry via a privileged identity.
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
trap 'bash "$script_dir/check-kvm-access.sh" launch-failure || true' ERR
if [[ "${ANDROID_EMULATOR_KVM_DEVICE:-/dev/kvm}" != /dev/kvm ]]; then
    echo 'Unexpected emulator KVM device override; stop without changing it' >&2
    exit 1
fi
bash "$script_dir/check-kvm-access.sh" before-launch
emulator=("$ANDROID_HOME/emulator/emulator")
"${emulator[@]}" -accel-check | tee device-evidence/acceleration.txt
printf 'no\n' | avdmanager create avd --force --name synthetic34 --path "$ANDROID_AVD_HOME/synthetic34.avd" --package 'system-images;android-34;default;x86_64'
test -s "$ANDROID_AVD_HOME/synthetic34.ini"
"${emulator[@]}" -list-avds | tee device-evidence/available-avds.txt | grep -qx synthetic34
if [[ "${1:-}" == "--prepare-only" ]]; then
    exit 0
fi
"${emulator[@]}" -avd synthetic34 -accel on -wipe-data -no-window -no-audio -no-boot-anim -no-snapshot -gpu swiftshader -memory 2048 -cores 2 -skin 720x1280 > device-evidence/emulator-start.log 2>&1 &
emulator_pid=$!
printf '%s\n' "$emulator_pid" > device-evidence/emulator.pid
booted=false
deadline=$((SECONDS + 300))
while ((SECONDS < deadline)); do
    if ! kill -0 "$emulator_pid" 2>/dev/null; then
        cat device-evidence/emulator-start.log
        echo 'Emulator exited before Android finished booting' >&2
        exit 1
    fi
    if timeout 5 adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' | grep -qx 1; then
        if ! kill -0 "$emulator_pid" 2>/dev/null; then
            cat device-evidence/emulator-start.log
            echo 'Emulator exited while boot status was being checked' >&2
            exit 1
        fi
        booted=true
        break
    fi
    sleep 3
done
if [[ "$booted" != true ]]; then
    cat device-evidence/emulator-start.log
    echo 'Android boot did not complete within the bounded startup checks' >&2
    exit 1
fi
bash "$script_dir/check-kvm-access.sh" after-boot
test "$(adb shell getprop ro.kernel.qemu | tr -d '\r')" = 1
test "$(adb shell getprop ro.build.version.sdk | tr -d '\r')" = 34
# Fixtures use only local storage and loopback. Do not enable network accounts.
adb shell svc wifi disable
adb shell svc data disable
adb shell wm density 320
adb shell settings put global window_animation_scale 0
adb shell settings put global transition_animation_scale 0
adb shell settings put global animator_duration_scale 0
adb shell input keyevent 82
