#!/usr/bin/env python3
"""One bounded Intel-macOS Android 34 boot using existing HVF access only."""
import json
from datetime import datetime, timezone
import os
from pathlib import Path
import platform
import signal
import shutil
import subprocess
import time

OUT = Path('device-evidence')
SERIAL = 'emulator-5554'
BOOT_BUDGET_SECONDS = 600
OBSERVATION_LIMIT = 16384
DEVICE_SNAPSHOT_INTERVAL_SECONDS = 15


def run(args, deadline, *, timeout=30, capture=True, input=None,
        merge_stderr=True, check=True):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError(f'The {BOOT_BUDGET_SECONDS}-second startup budget expired')
    return subprocess.run(args, check=check, text=True, input=input,
                          stdout=subprocess.PIPE if capture else None,
                          stderr=(subprocess.STDOUT if merge_stderr else subprocess.PIPE) if capture else None,
                          timeout=min(timeout, remaining))


def bounded_text(value):
    if isinstance(value, bytes):
        value = value.decode('utf-8', errors='replace')
    return (value or '')[:OBSERVATION_LIMIT]


class StartupObservations:
    """Read-only evidence, capped by the same deadline as startup itself."""
    def __init__(self, started, deadline):
        self.started = started
        self.deadline = deadline
        self.latest_boot = None
        self.latest_devices = None

    def record(self, event):
        event = dict(event, timestamp_utc=datetime.now(timezone.utc).isoformat(),
                     elapsed_seconds=round(time.monotonic() - self.started, 3))
        with (OUT / 'mac-startup-observations.jsonl').open('a') as output:
            output.write(json.dumps(event) + '\n')
        return event

    def observe(self, args, phase, *, timeout=5):
        event = {'phase': phase, 'command': args, 'returncode': None,
                 'stdout': '', 'stderr': ''}
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            return self.record(dict(event, status='budget_expired'))
        event['timeout_seconds'] = min(timeout, remaining)
        try:
            result = run(args, self.deadline, timeout=timeout, merge_stderr=False, check=False)
            event.update(status='ok' if result.returncode == 0 else 'nonzero',
                         returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
        except subprocess.CalledProcessError as error:
            event.update(status='nonzero', returncode=error.returncode,
                         stdout=error.stdout, stderr=error.stderr)
        except subprocess.TimeoutExpired as error:
            event.update(status='timeout', stdout=error.stdout, stderr=error.stderr)
        except TimeoutError:
            event.update(status='budget_expired')
        except OSError as error:
            event.update(status='os_error', stderr=str(error))
        for stream in ('stdout', 'stderr'):
            value = event[stream] or ''
            event[stream + '_truncated'] = len(value) > OBSERVATION_LIMIT
            event[stream] = bounded_text(value)
        return self.record(event)

    def before_stop(self, adb, process):
        # At deadline, retain the last live observations without extending it.
        # Any fresh commands are read-only, bounded, and target only our serial.
        state = {'phase': 'before_owned_process_cleanup', 'pid': process.pid,
                 'process_returncode': process.poll(), 'latest_boot': self.latest_boot,
                 'latest_devices': self.latest_devices, 'fresh_observations': [],
                 'fresh_collection_status': 'completed_within_startup_budget',
                 'cached_observation_ages_seconds': {}}
        elapsed = time.monotonic() - self.started
        for name, event in [('latest_boot', self.latest_boot), ('latest_devices', self.latest_devices)]:
            state['cached_observation_ages_seconds'][name] = (
                round(max(0, elapsed - event['elapsed_seconds']), 3) if event is not None else None)
        state['cached_observations_are_current_snapshot'] = False
        if state['process_returncode'] is None:
            commands = [
                ([adb, 'devices', '-l'], 'pre_cleanup_devices', 1),
                ([adb, '-s', SERIAL, 'shell', 'getprop', 'sys.boot_completed'], 'pre_cleanup_boot', 1),
                ([adb, '-s', SERIAL, 'logcat', '-d', '-t', '150'], 'pre_cleanup_logcat', 2),
            ]
            for args, phase, timeout in commands:
                if time.monotonic() >= self.deadline:
                    state['fresh_collection_status'] = 'budget_expired_use_last_live_observations'
                    break
                state['fresh_observations'].append(self.observe(args, phase, timeout=timeout))
        else:
            state['fresh_collection_status'] = 'owned_process_already_exited'
        state = self.record(state)
        (OUT / 'mac-pre-cleanup.json').write_text(json.dumps(state, indent=2))


def record_fixture_metadata(sdk, avd_home, observations):
    # Do not dump the environment or arbitrary host files. These allowlists
    # contain only SDK image metadata and our freshly created synthetic AVD.
    allowed = {
        'system-image': (sdk / 'system-images/android-34/default/x86_64/source.properties',
                         {'Pkg.Revision', 'AndroidVersion.ApiLevel', 'SystemImage.Abi', 'SystemImage.TagId'}),
        'avd': (avd_home / 'synthetic34mac.avd/config.ini',
                {'hw.cpu.arch', 'hw.cpu.ncore', 'hw.ramSize', 'hw.gpu.enabled', 'hw.gpu.mode',
                 'hw.lcd.width', 'hw.lcd.height', 'hw.lcd.density', 'tag.id', 'abi.type'}),
    }
    result = {}
    for name, (path, keys) in allowed.items():
        try:
            result[name] = {key.strip(): value.strip()
                            for line in path.read_text().splitlines() if '=' in line
                            for key, value in [line.split('=', 1)] if key.strip() in keys}
        except OSError as error:
            result[name] = {'unavailable': type(error).__name__}
    result['host_resources'] = observations.observe(
        ['sysctl', '-n', 'hw.logicalcpu', 'hw.memsize'], 'host_resources')
    (OUT / 'mac-fixture-metadata.json').write_text(json.dumps(result, indent=2))


def stop_owned_process(process):
    # The emulator is our own isolated process group, never a privileged process.
    if process is not None and process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                return
            process.wait(timeout=5)


def emulator_command(emulator):
    # Kernel diagnostics already use QEMU's stdio serial backend. Give guest
    # logcat its own file, otherwise the two diagnostic streams conflict.
    return [emulator, '-avd', 'synthetic34mac', '-port', '5554', '-accel', 'on',
            '-wipe-data', '-no-window', '-no-audio', '-no-boot-anim', '-no-snapshot',
            '-show-kernel', '-logcat', '*:i',
            '-logcat-output', str((OUT / 'emulator-start-logcat.txt').resolve()),
            '-gpu', 'swiftshader', '-memory', '2048', '-cores', '2', '-skin', '720x1280']


def wait_for_phone_service(adb, process, observations):
    # Boot completion can precede the phone Binder service registration. Only
    # its exact absence is retryable; command errors and denials fail closed.
    while time.monotonic() < observations.deadline:
        if process.poll() is not None:
            raise RuntimeError('The emulator exited while waiting for the phone service')
        event = observations.observe(
            [adb, '-s', SERIAL, 'shell', 'service', 'check', 'phone'],
            'phone_service_readiness')
        if (event['status'] != 'ok' or event['stdout_truncated']
                or event['stderr_truncated'] or event['stderr'].strip()):
            raise RuntimeError('Phone service readiness check failed; see startup observations')
        state = event['stdout'].strip()
        if state == 'Service phone: found':
            return
        if state != 'Service phone: not found':
            raise RuntimeError('Unexpected phone service readiness output; stop without fallback')
        time.sleep(min(3, max(0, observations.deadline - time.monotonic())))
    raise TimeoutError(f'The phone service was not ready within the {BOOT_BUDGET_SECONDS}-second startup budget')


def start():
    OUT.mkdir(exist_ok=True)
    started = time.monotonic()
    deadline = started + BOOT_BUDGET_SECONDS
    observations = StartupObservations(started, deadline)
    process = None
    ready = False
    log = None
    try:
        identity = {'system': platform.system(), 'machine': platform.machine(),
                    'release': platform.release(), 'uid': os.getuid(),
                    'euid': os.geteuid(), 'gid': os.getgid(), 'groups': os.getgroups()}
        (OUT / 'mac-host-identity.json').write_text(json.dumps(identity, indent=2))
        if identity['system'] != 'Darwin' or identity['machine'] != 'x86_64':
            raise RuntimeError('This one-time trial requires Intel macOS')
        if identity['uid'] == 0 or identity['uid'] != identity['euid']:
            raise RuntimeError('This trial requires the ordinary unprivileged runner identity')
        sdk = Path(os.environ['ANDROID_HOME'])
        emulator = str(sdk / 'emulator/emulator')
        adb = str(sdk / 'platform-tools/adb')
        avdmanager = shutil.which('avdmanager')
        if avdmanager is None or not Path(avdmanager).resolve().is_relative_to(sdk.resolve()):
            raise RuntimeError('The installed avdmanager must resolve inside ANDROID_HOME')
        if os.environ.get('ANDROID_EMULATOR_KVM_DEVICE'):
            raise RuntimeError('Unexpected KVM override on an HVF-only trial')
        hvf = run(['sysctl', '-n', 'kern.hv_support'], deadline).stdout.strip()
        (OUT / 'mac-hvf-support.txt').write_text(hvf + '\n')
        if hvf != '1':
            raise RuntimeError('HVF is unavailable; stop without security changes or fallback')
        (OUT / 'emulator-version.txt').write_text(run([emulator, '-version'], deadline).stdout)
        acceleration = run([emulator, '-accel-check'], deadline)
        (OUT / 'acceleration.txt').write_text(acceleration.stdout)
        if 'Hypervisor.Framework' not in acceleration.stdout:
            raise RuntimeError('The acceleration probe did not identify Hypervisor.Framework')
        (OUT / 'adb-server-start.log').write_text(run([adb, 'start-server'], deadline).stdout)
        devices = run([adb, 'devices'], deadline).stdout
        (OUT / 'adb-devices-before-start.txt').write_text(devices)
        if any(line.strip() for line in devices.splitlines()[1:]):
            raise RuntimeError('An Android device already exists; do not touch it')
        user_home = Path(os.environ['HOME']) / '.android'
        avd_home = user_home / 'avd'
        os.environ.update(ANDROID_USER_HOME=str(user_home),
                          ANDROID_EMULATOR_HOME=str(user_home),
                          ANDROID_AVD_HOME=str(avd_home), ANDROID_SERIAL=SERIAL)
        avd_home.mkdir(parents=True, exist_ok=True)
        created = run([avdmanager, 'create', 'avd', '--name', 'synthetic34mac',
                       '--path', str(avd_home / 'synthetic34mac.avd'),
                       '--package', 'system-images;android-34;default;x86_64'],
                      deadline, timeout=60, input='no\n')
        (OUT / 'avd-create.log').write_text(created.stdout)
        if not (avd_home / 'synthetic34mac.ini').is_file():
            raise RuntimeError('The expected new AVD definition is missing')
        available = run([emulator, '-list-avds'], deadline).stdout
        (OUT / 'available-avds.txt').write_text(available)
        if 'synthetic34mac' not in available.splitlines():
            raise RuntimeError('The emulator cannot discover the new AVD')
        record_fixture_metadata(sdk, avd_home, observations)
        if time.monotonic() >= deadline:
            raise TimeoutError('The startup budget expired before launch; no emulator started')
        log = (OUT / 'emulator-start.log').open('w')
        process = subprocess.Popen(
            emulator_command(emulator),
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (OUT / 'emulator.pid').write_text(str(process.pid) + '\n')
        next_device_snapshot = 0
        while time.monotonic() < deadline:
            process_status = process.poll()
            observations.record({'phase': 'process_poll', 'pid': process.pid,
                                 'process_returncode': process_status})
            if process_status is not None:
                raise RuntimeError('The only emulator process exited before boot')
            if time.monotonic() >= next_device_snapshot:
                devices = observations.observe(
                    [adb, 'devices', '-l'], 'devices_during_startup', timeout=2)
                if devices['status'] != 'budget_expired':
                    observations.latest_devices = devices
                next_device_snapshot = time.monotonic() + DEVICE_SNAPSHOT_INTERVAL_SECONDS
            boot = observations.observe(
                [adb, '-s', SERIAL, 'shell', 'getprop', 'sys.boot_completed'], 'boot_poll')
            if boot['status'] != 'budget_expired':
                observations.latest_boot = boot
            if boot['status'] == 'ok' and not boot['stdout_truncated'] and boot['stdout'].strip() == '1':
                if process.poll() is not None:
                    raise RuntimeError('The emulator exited while checking boot')
                break
            time.sleep(min(3, max(0, deadline - time.monotonic())))
        else:
            raise TimeoutError(f'Android did not boot within the {BOOT_BUDGET_SECONDS}-second startup budget')
        for prop, expected in [('ro.kernel.qemu', '1'), ('ro.build.version.sdk', '34')]:
            identity = observations.observe([adb, '-s', SERIAL, 'shell', 'getprop', prop],
                                            'fixture_identity', timeout=30)
            if (identity['status'] != 'ok' or identity['stdout_truncated']
                    or identity['stdout'].strip() != expected):
                raise RuntimeError('Unexpected Android fixture identity: ' + prop)
        run([adb, '-s', SERIAL, 'shell', 'svc', 'wifi', 'disable'], deadline)
        wait_for_phone_service(adb, process, observations)
        for command in [['svc', 'data', 'disable'],
                        ['wm', 'density', '320'],
                        ['settings', 'put', 'global', 'window_animation_scale', '0'],
                        ['settings', 'put', 'global', 'transition_animation_scale', '0'],
                        ['settings', 'put', 'global', 'animator_duration_scale', '0'],
                        ['input', 'keyevent', '82']]:
            run([adb, '-s', SERIAL, 'shell', *command], deadline)
        ready = True
        (OUT / 'mac-boot-summary.json').write_text(json.dumps({
            'boot_seconds': round(time.monotonic() - started, 2),
            'budget_seconds': BOOT_BUDGET_SECONDS, 'serial': SERIAL,
            'android_api': 34, 'hypervisor': 'HVF', 'launches': 1}, indent=2))
        print('The single Android 34 HVF emulator is ready for synthetic tests.', flush=True)
    except Exception as error:
        (OUT / 'mac-startup-error.txt').write_text(str(error) + '\n')
        if isinstance(error, subprocess.CalledProcessError) and error.stdout:
            (OUT / 'mac-startup-command-output.txt').write_text(error.stdout)
        raise
    finally:
        try:
            if not ready and process is not None:
                try:
                    observations.before_stop(adb, process)
                except Exception as diagnostic_error:
                    # Do not replace the primary error or prevent cleanup if a
                    # read-only observation or evidence write itself fails.
                    print('Pre-cleanup diagnostics unavailable: ' + str(diagnostic_error), flush=True)
                finally:
                    stop_owned_process(process)
        finally:
            if log is not None:
                log.close()


if __name__ == '__main__':
    start()
