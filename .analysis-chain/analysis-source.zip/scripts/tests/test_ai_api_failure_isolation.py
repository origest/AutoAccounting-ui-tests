"""Source regression guard for API-test / ChatGPT state isolation.

Runs with Python's standard library, without Gradle or the Android SDK. This
checks the failure branch's source, not Android UI behavior or compilation.
Run: python3 -m unittest discover -s scripts/tests -v
"""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[2]
COMPONENT = ROOT / "app/src/main/java/net/ankio/auto/ui/fragment/settings/AiComponent.kt"


class ApiTestFailureIsolationTest(unittest.TestCase):
    def test_failure_only_reports_error_without_changing_active_settings(self):
        source = COMPONENT.read_text(encoding="utf-8")
        # Match this existing, consistently indented branch. Fail if its shape
        # changes, so a refactor cannot silently turn the guard into a no-op.
        branch = re.search(
            r"^                if \(result\.isSuccess\) \{.*?"
            r"^                \} else \{\n(?P<failure>.*?)"
            r"^                \}",
            source,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(branch, "Review the guard after refactoring the API-test result branches")
        failure = branch.group("failure")
        self.assertNotRegex(
            failure,
            r"\b(?:PrefManager|OwnerCategoryQueue|ChatGptAccounts)\b",
            "A failed API probe must not disable AI, cancel the queue, or revoke ChatGPT consent",
        )
        self.assertRegex(failure, r"showTestResult\(\s*false\s*,")


if __name__ == "__main__":
    unittest.main()
