"""Synthetic SQLite query/scale checks, not Android UI performance evidence."""
import pathlib
import re
import sqlite3
import time
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]
PKG = ROOT / "app/src/main/java/net/ankio/auto/ai/review"
STORE = (PKG / "AiReviewStore.kt").read_text()
PAGING = (PKG / "AiReviewPaging.kt").read_text()
CONST = dict(re.findall(r'const val (\w+) = "([^"]+)"', PAGING))
PREDICATES = {k: CONST[k.upper() + "_WHERE"] for k in ("queue", "pending", "history")}


def database():
    db = sqlite3.connect(":memory:")
    for schema in re.findall(r'"""(CREATE TABLE .*?)"""', STORE, re.S):
        db.execute(schema)
    db.execute("CREATE INDEX event_task ON event(task_id,sequence)")
    for sql in re.findall(r'"(CREATE INDEX IF NOT EXISTS [^"]+)"', PAGING):
        for key, value in CONST.items():
            sql = sql.replace("$" + key, value)
        db.execute(sql)
    return db


def query(tab, cursor=None):
    where = PREDICATES[tab]
    params = []
    if cursor is not None:
        where += " AND " + CONST["AFTER_WHERE"]
        params = [cursor[0], cursor[0], cursor[1]]
    return f"SELECT * FROM task INDEXED BY task_{tab}_page WHERE {where} ORDER BY {CONST['ORDER']} LIMIT ?", params + [101]


def seed(db, size):
    rows = [(f"{i:08d}", "ocr-local", i + 1, 0, "a" * 32, "CATEGORY",
             (("REVIEW", "WAITING", "RUNNING", "FAILED", "APPLYING", "APPLIED", "MANUAL", "STALE")[i % 8]),
             "[]", "", 1, i // 3, i // 3, "synthetic", "") for i in range(size)]
    db.executemany("INSERT INTO task VALUES(" + ",".join(["?"] * 14) + ")", rows)
    return rows


class ReviewPagingTest(unittest.TestCase):
    def scale(self, size):
        with database() as db:
            rows = seed(db, size)
            started = time.perf_counter()
            for tab in PREDICATES:
                states = {"queue": {"WAITING", "RUNNING", "FAILED", "APPLYING"}, "pending": {"REVIEW"}, "history": {"APPLIED", "MANUAL", "STALE"}}[tab]
                expected = {row[0] for row in rows if row[6] in states}
                seen, cursor = [], None
                while True:
                    sql, params = query(tab, cursor)
                    fetched = db.execute(sql, params).fetchall()
                    self.assertLessEqual(len(fetched), 101)
                    page = fetched[:100]
                    seen.extend(row[0] for row in page)
                    count = db.execute(f"SELECT count(*) FROM task WHERE {PREDICATES[tab]}").fetchone()[0]
                    self.assertEqual(len(expected), count)
                    plan = " ".join(row[3] for row in db.execute("EXPLAIN QUERY PLAN " + sql, params))
                    self.assertIn(f"task_{tab}_page", plan)
                    self.assertNotIn("TEMP B-TREE", plan)
                    if len(fetched) <= 100:
                        break
                    cursor = (page[-1][10], page[-1][0])
                self.assertEqual(expected, set(seen))
                self.assertEqual(len(seen), len(set(seen)))
            print(f"Synthetic SQLite {size} tasks: all tabs paged completely, max 101 SQL rows, {(time.perf_counter()-started)*1000:.1f} ms aggregate (not Android timing)")

    def test_100_tasks(self): self.scale(100)
    def test_1000_tasks(self): self.scale(1000)
    def test_10000_tasks(self): self.scale(10000)

    def test_cursor_survives_new_rows_and_departed_anchor(self):
        with database() as db:
            seed(db, 1000)
            sql, params = query("pending")
            first = db.execute(sql, params).fetchall()[:100]
            cursor = (first[-1][10], first[-1][0])
            before = db.execute(*query("pending", cursor)).fetchall()
            db.execute("UPDATE task SET state='APPLIED' WHERE id=?", [cursor[1]])
            db.execute("INSERT INTO task VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ["newer", "ocr-local", 1001, 0, "b"*32, "CATEGORY", "REVIEW", "[]", "", 1, 10000, 10000, "synthetic", ""])
            self.assertEqual(before, db.execute(*query("pending", cursor)).fetchall())
            self.assertEqual("newer", db.execute(*query("pending")).fetchone()[0])

    def test_old_manual_evidence_and_event_pages_remain_available(self):
        with database() as db:
            seed(db, 1)
            db.executemany("INSERT INTO event(id,task_id,state,action,changes,error,timestamp) VALUES(?,?,?,?,?,?,?)", [
                (str(i), "00000000", "REVIEW", "MANUAL_CHANGED" if i == 0 else "DEFERRED", "[]", "", i) for i in range(10000)])
            latest = db.execute("SELECT * FROM event WHERE task_id=? AND action=? ORDER BY sequence DESC LIMIT 1", ["00000000", "MANUAL_CHANGED"]).fetchall()
            self.assertEqual(1, len(latest))
            seen, cursor = set(), None
            while True:
                suffix = "" if cursor is None else " AND sequence<?"
                args = ["00000000"] if cursor is None else ["00000000", cursor]
                rows = db.execute("SELECT * FROM event WHERE task_id=?" + suffix + " ORDER BY sequence DESC LIMIT 101", args).fetchall()
                self.assertLessEqual(len(rows), 101)
                for row in rows[:100]: self.assertNotIn(row[0], seen); seen.add(row[0])
                if len(rows) <= 100: break
                cursor = rows[99][0]
            self.assertEqual(10000, len(seen))

    def test_first_hundred_prompted_candidates_do_not_hide_next_pending_record(self):
        with database() as db:
            seed(db, 101)
            db.execute("UPDATE task SET state='REVIEW'")
            first = db.execute(*query("pending")).fetchall()
            shown = {row[0] for row in first[:100]}
            self.assertEqual(100, len(shown))
            cursor = (first[99][10], first[99][0])
            later = db.execute(*query("pending", cursor)).fetchall()
            self.assertEqual(1, len(later))
            self.assertNotIn(later[0][0], shown)

    def test_prompt_cursor_and_scroll_are_not_committed_before_presentation_checks(self):
        activity = (PKG / "AiReviewActivity.kt").read_text()
        prompts = (ROOT / "app/src/main/java/net/ankio/auto/classification/OwnerCategoryPrompts.kt").read_text()
        self.assertIn("next.records == currentPage.records && next.next == currentPage.next", activity)
        self.assertIn("summaryView?.text = pageSummary()", activity)
        self.assertIn("page.restoreScrollPosition(scroll)", activity)
        self.assertIn("render(preserveScroll = false)", activity)
        self.assertIn("scanJob?.cancel()", prompts)
        self.assertIn("queryLock.withLock", prompts)
        focus = prompts.index("!host.window.decorView.hasWindowFocus()")
        commit = prompts.index("pendingAfter = selection.second", focus)
        shown = prompts.index("promptedThisVisit = true", focus)
        self.assertLess(focus, commit)
        self.assertLess(commit, shown)

    def test_ui_has_no_whole_table_materialization_and_no_background_refresh_scope(self):
        activity = (PKG / "AiReviewActivity.kt").read_text()
        self.assertNotIn("it.list()", activity)
        self.assertIn("it.page(selected, anchor)", activity)
        self.assertIn("repeatOnLifecycle(Lifecycle.State.STARTED)", activity)
        self.assertIn("refreshController.runWhileVisible()", activity)
        self.assertIn("refreshController.launchVisible", activity)
        self.assertNotIn("shown.take", activity)
        self.assertIn("anchors.add(next)", activity)
        self.assertIn("historyPage(record.id, pages.last())", activity)
        self.assertIn("null, 2)", STORE)
        self.assertIn("oldVersion == 1 && newVersion == 2", STORE)
        self.assertNotIn("DROP TABLE", STORE)
