"""Synthetic bytes only: no APK build, emulator, network or private keys."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('apk_artifact', ROOT / 'scripts/ci/apk-artifact.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)


class ArtifactIdentityTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.bundle = Path(self.temp.name)
        self.expected = {'GITHUB_SHA': 'a'*40, 'GITHUB_RUN_ID': '123', 'GITHUB_RUN_ATTEMPT': '1', 'GITHUB_REPOSITORY': 'origest/AutoAccounting', 'source_tree': 'b'*40}
        self.manifest = {'schema': 1, 'identity': self.expected.copy(), 'apks': {}}
        for name, (_, package) in module.LAYOUT.items():
            path = self.bundle / name; path.write_bytes(b'synthetic-' + name.encode())
            self.manifest['apks'][name] = {'package': package, 'sha256': module.digest(path), 'size': path.stat().st_size, 'signer_certificate_sha256': ['c'*64]}
        self.save()

    def save(self):
        path = self.bundle / 'manifest.json'; path.write_text(json.dumps(self.manifest))
        self.anchor = module.digest(path)

    def verify(self):
        return module.verify(self.bundle, self.anchor, self.expected)

    def test_real_badging_allows_versionless_instrumentation_only(self):
        for package in ('net.ankio.auto.test', 'org.ezbook.server.test'):
            details = module.package_details(f"package: name='{package}' versionCode='' versionName='' platformBuildVersionCode='36'", package)
            self.assertEqual(('', ''), (details[2], details[3]))
        with self.assertRaisesRegex(AssertionError, 'Main APK'):
            module.package_details("package: name='net.ankio.auto' versionCode='' versionName=''", 'net.ankio.auto')

    def test_exact_bundle_passes(self):
        self.assertEqual(self.manifest, self.verify())

    def test_changed_apk_same_size_rejected(self):
        path = self.bundle / 'application.apk'; path.write_bytes(b'x' * path.stat().st_size)
        with self.assertRaisesRegex(AssertionError, 'integrity'): self.verify()

    def test_changed_manifest_rejected_against_external_anchor(self):
        (self.bundle / 'manifest.json').write_text('{}')
        with self.assertRaisesRegex(AssertionError, 'Manifest integrity'): self.verify()

    def test_other_source_run_or_attempt_rejected(self):
        for key in self.expected:
            with self.subTest(key=key):
                self.manifest['identity'] = self.expected.copy(); self.manifest['identity'][key] = 'wrong'
                self.save()
                with self.assertRaisesRegex(AssertionError, 'identity'): self.verify()

    def test_extra_file_or_missing_apk_rejected(self):
        extra = self.bundle / 'debug.keystore'; extra.write_bytes(b'not-a-key')
        with self.assertRaisesRegex(AssertionError, 'Unexpected'): self.verify()
        extra.unlink(); (self.bundle / 'server-tests.apk').unlink()
        with self.assertRaisesRegex(AssertionError, 'Unexpected'): self.verify()

    def test_symlink_rejected(self):
        path = self.bundle / 'application.apk'; path.unlink(); path.symlink_to(self.bundle / 'server-tests.apk')
        with self.assertRaisesRegex(AssertionError, 'Nonregular'): self.verify()

    def test_package_or_signer_mismatch_rejected(self):
        self.manifest['apks']['application.apk']['package'] = 'unrelated'; self.save()
        with self.assertRaises(AssertionError): self.verify()
        self.manifest['apks']['application.apk']['package'] = 'net.ankio.auto'
        self.manifest['apks']['application.apk']['signer_certificate_sha256'] = ['d'*64]; self.save()
        with self.assertRaisesRegex(AssertionError, 'signer mismatch'): self.verify()
        self.manifest['apks']['application.apk']['signer_certificate_sha256'] = []; self.save()
        with self.assertRaises(AssertionError): self.verify()

    def test_split_workflow_keeps_source_and_retention_boundaries(self):
        source = (ROOT / '.github/workflows/synthetic-device-validation-macos.yml').read_text()
        linux, mac = source.split('  synthetic-mac-device-tests:')
        self.assertIn('runs-on: ubuntu-24.04', linux)
        self.assertIn('retention-days: 1', linux)
        self.assertIn('artifact-ids: ${{ needs.build-linux.outputs.artifact-id }}', mac)
        self.assertIn('MANIFEST_SHA256: ${{ needs.build-linux.outputs.manifest-sha256 }}', mac)
        self.assertNotIn('gradlew', mac); self.assertNotIn('android-36', mac)
        self.assertNotIn('workflow_dispatch', source); self.assertNotIn('matrix:', source)
        self.assertEqual(2, source.count('github.run_number == 7 && github.run_attempt == 1'))
        self.assertLess(mac.index('apk-artifact.py restore'), mac.index('start-macos-emulator.py'))
        self.assertLess(mac.index('Verify exact device count'), mac.index('apk-artifact.py candidate'))
        self.assertLess(mac.index('apk-artifact.py candidate'), mac.index('private-tested-candidate-'))


if __name__ == '__main__': unittest.main()
