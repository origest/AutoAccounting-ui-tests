"""Static registry checks only; these do not execute or compile Android tests."""
import ast
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[2]


def suites():
    tree = ast.parse((ROOT / 'scripts/ci/device-tests.py').read_text())
    assignments = [node for node in tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'suites'
                           for target in node.targets)]
    assert len(assignments) == 1
    return ast.literal_eval(assignments[0].value)


class DeviceSuiteRegistryTest(unittest.TestCase):
    def test_exact_nonzero_registry_and_package_scope(self):
        entries = suites()
        self.assertEqual(13, len(entries))
        self.assertEqual(13, len({name for name, _, _ in entries}))
        self.assertEqual(56, sum(count for _, count, _ in entries))
        for name, count, package in entries:
            self.assertGreater(count, 0)
            self.assertIn(package, ('net.ankio.auto.test', 'org.ezbook.server.test'))
            self.assertTrue(name.startswith('net.ankio.auto.') if package == 'net.ankio.auto.test'
                            else name.startswith('org.ezbook.server.'))

    def test_registry_counts_match_declared_real_android_test_methods(self):
        for name, count, package in suites():
            module = 'app' if package == 'net.ankio.auto.test' else 'server'
            path = ROOT / module / 'src/androidTest/java' / (name.replace('.', '/') + '.kt')
            source = path.read_text()
            methods = re.findall(r'@Test\b(?:\([^)]*\))?\s+fun\s+(\w+)\s*\(', source)
            self.assertEqual(count, len(methods), name)
            self.assertEqual(count, len(set(methods)), name)
            self.assertNotIn('@Ignore', source, name)

    def test_mac_guards_remain_strict_and_cannot_start_another_run(self):
        source = (ROOT / '.github/workflows/synthetic-device-validation-macos.yml').read_text()
        self.assertIn('len(reports) == 13 and len(cases) == len(set(cases)) == 56', source)
        self.assertIn("'tests': 56, 'failures': 0, 'errors': 0, 'skipped': 0", source)
        self.assertIn('python3 -m unittest discover -s server/src/test/python -v', source)
        self.assertIn('github.run_number == 7 && github.run_attempt == 1', source)
        self.assertIn('timeout-minutes: 25', source)


if __name__ == '__main__':
    unittest.main()
