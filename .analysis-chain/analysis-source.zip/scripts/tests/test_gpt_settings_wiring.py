"""Dependency-free source guards, not Kotlin compilation or Android UI execution."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "app/src/main/java/net/ankio/auto"


class GptSettingsWiringTest(unittest.TestCase):
    def setUp(self):
        self.account = (APP / "ui/activity/ChatGptCategoryActivity.kt").read_text()
        self.queue = (APP / "classification/OwnerCategoryActivity.kt").read_text()
        self.page = (APP / "ui/utils/SettingsPage.kt").read_text()

    def test_account_return_requests_a_refresh_and_busy_completion_drains_it(self):
        resume = self.account.split("override fun onResume()", 1)[1].split("override fun onDestroy()", 1)[0]
        self.assertIn("modelRefreshRequests.request()", resume)
        self.assertIn("refreshModelsIfNeeded()", resume)
        task = self.account.split("private fun runTask(", 1)[1].split("private fun updateSwitches", 1)[0]
        self.assertLess(task.index("busy = false"), task.index("refreshModelsIfNeeded()"))

    def test_refresh_requires_signed_in_account_and_never_grants_permission(self):
        refresh = self.account.split("private fun refreshModels(", 1)[1].split("private fun runTask(", 1)[0]
        self.assertIn("it.key == view.active && it.signedIn", refresh)
        self.assertIn("modelRefreshRequests.takeIfReady(busy, signedIn)", refresh)
        self.assertIn("modelRefreshRequests.complete()", refresh)
        self.assertIn("accounts!!.models()", refresh)
        self.assertNotIn(".enable(", refresh)
        self.assertNotIn(".classify(", refresh)

    def test_login_failure_does_not_turn_pending_resume_into_an_automatic_retry(self):
        login = self.account.split("private fun confirmLogin(", 1)[1].split("private fun stopQueue", 1)[0]
        self.assertIn("finally { loginPending = false; modelRefreshRequests.complete() }", login)
        self.assertIn("models = emptyList()", login)

    def test_material_toggle_requests_instead_of_optimistically_committing(self):
        toggle = self.page.split("fun toggle(", 1)[1].split("fun spinner(", 1)[0]
        self.assertIn("MaterialSwitch(activity)", toggle)
        self.assertLess(toggle.index("isChecked = !requested"), toggle.index("action(requested)"))
        self.assertIn("setOnClickListener", toggle)
        self.assertNotIn("setOnCheckedChangeListener", toggle)

    def test_sending_switch_uses_current_account_and_every_permission_gate(self):
        update = self.account.split("private fun updateSwitches()", 1)[1].split("private fun render(", 1)[0]
        for gate in ("active?.signedIn == true", "active.enabled", "PrefManager.aiCategoryChatGpt",
                     "PrefManager.featureAiAvailable", "PrefManager.aiCategoryRecognition", "PrefManager.aiCategoryHistory"):
            self.assertIn(gate, update)
        self.assertIn("sendingToggle.isChecked = enabled", update)
        self.assertIn("sendingToggle.isEnabled = enabled ||", update)
        self.assertIn("OwnerCategoryQueue.warning()", update)

    def test_queued_render_reads_state_after_dispatch_not_before(self):
        render = self.account.split("private fun render(", 1)[1].split("override fun onResume()", 1)[0]
        self.assertLess(render.index("runOnUiThread"), render.index("val view = accounts?.view()"))

    def test_automatic_switch_is_separate_from_one_time_historical_batches(self):
        update = self.queue.split("private fun updateAutomaticState()", 1)[1].split("private fun consentStamp", 1)[0]
        self.assertIn('OwnerCategoryQueue.enabled(this) && prefs.getBoolean("automatic", false)', update)
        self.assertIn("automaticToggle.isChecked = enabled", update)
        self.assertIn("automaticToggle.isEnabled = enabled ||", update)
        self.assertIn("OwnerCategoryQueue.warning()", update)
        self.assertIn('page.toggle("自动分类新账单")', self.queue)
        self.assertIn('setPositiveButton("确认发送这些账单")', self.queue)

    def test_switch_activation_preserves_explicit_consent_and_stop_boundaries(self):
        self.assertIn('setPositiveButton("同意发送分类数据")', self.account)
        self.assertIn("check(accountKey == accounts!!.view().active)", self.account)
        self.assertIn("if (enabled) confirmSending() else pauseClassification()", self.account)
        self.assertIn("if (enabled) confirmAutomatic() else pauseQueue()", self.queue)
        self.assertIn("if (stopped.localComplete)", self.queue)
        self.assertIn("else showError(OwnerQueuePermissions.FAILURE_MESSAGE)", self.queue)

    def test_ocr_permission_is_separate_and_never_granted_by_login_or_classification(self):
        consent = self.account.split("private fun confirmOcrSending()", 1)[1].split("private fun selectedModelForConsent", 1)[0]
        self.assertIn('setPositiveButton("同意发送 OCR 文字")', consent)
        self.assertIn("check(accountKey == accounts!!.view().active)", consent)
        self.assertIn("ChatGptOcrTextPipeline.enable(applicationContext, model.slug)", consent)
        self.assertEqual(1, self.account.count("ChatGptOcrTextPipeline.enable("))
        self.assertIn("规则无法生成账单时", consent)
        self.assertIn("不会上传截图", consent)
        self.assertIn("账号、订单及其他个人信息", consent)

    def test_ocr_failed_revocation_survives_ui_recreation_and_has_a_retry(self):
        update = self.account.split("private fun updateSwitches()", 1)[1].split("private fun render(", 1)[0]
        self.assertIn("ChatGptOcrTextPipeline.isEnabled(this)", update)
        self.assertIn("ChatGptOcrTextPipeline.warning() ?: ocrWarning", update)
        self.assertIn("ocrProblem == null", update)
        self.assertIn("ocrRetry.visibility", update)
        self.assertIn("if (enabled) confirmOcrSending() else pauseOcrSending()", self.account)

    def test_shared_model_cannot_change_under_an_existing_consent(self):
        selected = self.account.split("private fun selectedModelForConsent", 1)[1].split("private fun pauseOcrSending", 1)[0]
        self.assertIn("active?.enabled == true || active?.ocrEnabled == true", selected)
        self.assertIn("active?.model != model.slug", selected)
        self.assertIn("!enabled && !ocrEnabled", self.account)

    def test_review_policy_render_only_reads_and_new_creation_needs_explicit_confirmation(self):
        update = self.account.split("private fun updatePolicySwitches()", 1)[1].split("private fun confirmSending", 1)[0]
        self.assertIn("toggle.isChecked = reviewPolicy.get(key)", update)
        self.assertNotIn("reviewPolicy.set", update)
        change = self.account.split("private fun changeReviewPolicy(", 1)[1].split("private fun updatePolicySwitches", 1)[0]
        self.assertIn("AiReviewPolicy.Key.PROMPT_NEW_CATEGORY && !enabled", change)
        self.assertIn("AiReviewPolicy.Key.PROMPT_NEW_ASSET && !enabled", change)
        self.assertIn("是否允许自动创建", change)
        self.assertIn('setNegativeButton("取消", null)', change)
        self.assertIn('setPositiveButton("确认启用")', change)

    def test_review_tabs_do_not_grant_sending_permission(self):
        navigate = self.account.split("private fun openReview(", 1)[1].split("private fun changeReviewPolicy", 1)[0]
        self.assertIn("AiReviewActivity::class.java", navigate)
        self.assertIn('putExtra("tab", tab)', navigate)
        self.assertNotIn(".enable(", navigate)
        self.assertIn('openReview("pending")', self.account)
        self.assertIn('openReview("history")', self.account)

    def test_oauth_revocation_result_is_not_hidden_by_queue_revocation_warning(self):
        self.assertIn("val revoked = accounts!!.signOut()", self.account)
        self.assertIn("ChatGPT 远程撤销未确认", self.account)
        self.assertIn("queueWarning != null && detail.isNotBlank() && detail != queueWarning", self.account)


if __name__ == "__main__":
    unittest.main()
