"""Synthetic shell checks only: never inspect a real KVM device or start an emulator."""

from pathlib import Path
import os
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]
CHECK = ROOT / "scripts/ci/check-kvm-access.sh"
START = ROOT / "scripts/ci/start-github-emulator.sh"


class KvmAccessCheckTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="synthetic-kvm-check-")
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)
        self.bin = self.work / "bin"
        self.bin.mkdir()
        self.home = self.work / "home"
        self.home.mkdir()
        self.sdk = self.work / "sdk"
        (self.sdk / "emulator").mkdir(parents=True)
        self.write_script(self.bin / "id", "case \"$1\" in -u|-g|-ru|-rg) echo 1001;; -G) echo '1001 4';; *) exit 9;; esac\n")
        self.write_script(self.bin / "stat", "echo 'kind=character special file mode=660 uid=0 gid=993 device=a:e8 inode=42 ctime=100 mtime=100'\n")
        self.write_script(self.bin / "getfacl", "if [[ \"${FAKE_ACL_FAILURE:-0}\" == 1 ]]; then exit 3; fi\nprintf '%s\\n' '# file: /dev/kvm' 'user::rw-' 'user:1001:rw-' 'group::rw-' 'mask::rw-' 'other::---'\n")
        self.write_script(self.sdk / "emulator/emulator", "touch emulator-was-called\nexit 0\n")
        self.env = os.environ | {
            "PATH": str(self.bin) + ":" + os.environ["PATH"],
            "HOME": str(self.home),
            "ANDROID_HOME": str(self.sdk),
            "FAKE_CHARACTER": "1", "FAKE_READABLE": "1", "FAKE_WRITABLE": "1",
            "FAKE_ACL_FAILURE": "0",
        }
        # An exported test-only Bash function intercepts every access check for
        # the fixed device path. Production code has no configurable KVM path.
        self.wrapper = r'''
function test() {
    if [[ "${2:-}" == /dev/kvm ]]; then
        case "${1:-}" in
            -c) [[ "$FAKE_CHARACTER" == 1 ]]; return;;
            -r) [[ "$FAKE_READABLE" == 1 ]]; return;;
            -w) [[ "$FAKE_WRITABLE" == 1 ]]; return;;
            *) echo 'Unexpected synthetic device check' >&2; return 9;;
        esac
    fi
    builtin test "$@"
}
export -f test
bash "$@"
'''

    @staticmethod
    def write_script(path, body):
        path.write_text("#!/bin/bash\nset -eu\n" + body)
        path.chmod(0o755)

    def run_script(self, script=CHECK, *args, **flags):
        return subprocess.run(
            ["bash", "-c", self.wrapper, "synthetic", str(script), *args],
            cwd=self.work, env=self.env | flags, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=5,
        )

    def reports(self):
        return sorted((self.work / "device-evidence").glob("kvm-access-*.txt"))

    def test_readable_writable_character_device_passes_with_numeric_diagnostics(self):
        result = self.run_script(CHECK, "unit-check")
        self.assertEqual(0, result.returncode, result.stdout)
        report = self.reports()[0].read_text()
        for text in ("uid=1001", "gid=1001", "groups=1001 4", "inode=42",
                     "user:1001:rw-", "character_device=1", "readable=1", "writable=1"):
            self.assertIn(text, report)

    def test_unreadable_but_writable_is_a_failure(self):
        result = self.run_script(FAKE_READABLE="0")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertIn("not readable", result.stdout)
        self.assertIn("readable=0\nwritable=1", self.reports()[0].read_text())

    def test_readable_but_unwritable_is_a_failure(self):
        result = self.run_script(FAKE_WRITABLE="0")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertIn("not writable", result.stdout)

    def test_neither_permission_is_a_failure(self):
        result = self.run_script(FAKE_READABLE="0", FAKE_WRITABLE="0")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertIn("readable=0\nwritable=0", self.reports()[0].read_text())

    def test_non_character_device_is_a_failure(self):
        result = self.run_script(FAKE_CHARACTER="0")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertIn("not a character device", result.stdout)

    def test_acl_diagnostic_failure_does_not_hide_access_denial(self):
        result = self.run_script(FAKE_READABLE="0", FAKE_ACL_FAILURE="1")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertIn("not readable", result.stdout)
        self.assertIn("acl=unavailable", self.reports()[0].read_text())

    def test_start_stops_before_emulator_when_read_access_is_denied(self):
        result = self.run_script(START, "--prepare-only", FAKE_READABLE="0")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertFalse((self.work / "emulator-was-called").exists())
        self.assertEqual(2, len(self.reports()))

    def test_start_stops_before_emulator_when_write_access_is_denied(self):
        result = self.run_script(START, "--prepare-only", FAKE_WRITABLE="0")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertFalse((self.work / "emulator-was-called").exists())

    def test_repeated_checks_preserve_separate_reports(self):
        for _ in range(2):
            result = self.run_script(CHECK, "before-launch")
            self.assertEqual(0, result.returncode, result.stdout)
        self.assertEqual(2, len(self.reports()))

    def test_single_launch_is_after_build_and_grant_is_one_attempt_only(self):
        workflow = (ROOT / ".github/workflows/synthetic-device-validation.yml").read_text()
        self.assertEqual(1, workflow.count("bash scripts/ci/start-github-emulator.sh"))
        self.assertNotIn("Verify emulator boots before building", workflow)
        self.assertLess(workflow.index("Build APKs and run lint"), workflow.index("sudo -n setfacl"))
        self.assertLess(workflow.index("sudo -n setfacl"), workflow.index("bash scripts/ci/start-github-emulator.sh"))
        self.assertIn("github.run_number == 5 && github.run_attempt == 1", workflow)
        self.assertEqual(1, workflow.count("sudo -n setfacl --no-mask"))
        self.assertIn("final-before-shutdown", workflow)
        self.assertIn("final-after-shutdown", workflow)

    def test_acl_guard_refuses_mask_expansion_with_synthetic_inputs(self):
        workflow = (ROOT / ".github/workflows/synthetic-device-validation.yml").read_text()
        guard = workflow.split("python3 - <<'PYACL'\n", 1)[1].split("          PYACL", 1)[0]
        import textwrap
        guard = textwrap.dedent(guard)
        evidence = self.work / "device-evidence"
        evidence.mkdir()
        fixtures = [
            ("user::rw-\ngroup::rw-\nother::---\n", True),
            ("user::rw-\nuser:2000:rwx\ngroup::rwx\nmask::rw-\nother::---\n", True),
            ("user::rw-\ngroup::rw-\nmask::r--\nother::---\n", False),
            ("user::rw-\ngroup::r--\nother::---\n", False),
            ("user::rw-\ngroup::rw-\nmask::rwx\nother::---\n", False),
            ("user::rw-\nother::---\n", False),
        ]
        for acl, allowed in fixtures:
            with self.subTest(acl=acl):
                (evidence / "kvm-acl-before-grant.txt").write_text(acl)
                result = subprocess.run(["python3", "-c", guard], cwd=self.work,
                                        text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                self.assertEqual(allowed, result.returncode == 0, result.stdout)

    def test_unexpected_kvm_override_stops_before_emulator(self):
        result = self.run_script(START, "--prepare-only", ANDROID_EMULATOR_KVM_DEVICE="/synthetic/unexpected")
        self.assertEqual(1, result.returncode, result.stdout)
        self.assertIn("Unexpected emulator KVM device override", result.stdout)
        self.assertFalse((self.work / "emulator-was-called").exists())

    def test_workflow_and_starter_use_the_same_read_only_check(self):
        workflow = (ROOT / ".github/workflows/synthetic-device-validation.yml").read_text()
        self.assertIn("bash scripts/ci/check-kvm-access.sh after-grant", workflow)
        self.assertIn('bash "$script_dir/check-kvm-access.sh" before-launch', START.read_text())
        self.assertNotIn("sudo ", CHECK.read_text())
        self.assertNotIn("setfacl ", CHECK.read_text())


if __name__ == "__main__":
    unittest.main()
