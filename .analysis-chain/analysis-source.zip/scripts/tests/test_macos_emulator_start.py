"""No real emulator: mocks plus one harmless Python argv-transport subprocess."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('mac_start', ROOT / 'scripts/ci/start-macos-emulator.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class MacStartTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='synthetic-mac-start-')
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)
        self.old_cwd = Path.cwd()
        os.chdir(self.work)
        self.addCleanup(os.chdir, self.old_cwd)
        self.env = patch.dict(os.environ, {'ANDROID_HOME': str(self.work / 'sdk'),
                                         'HOME': str(self.work / 'home'),
                                         'ANDROID_EMULATOR_KVM_DEVICE': ''})
        self.env.start(); self.addCleanup(self.env.stop)
        self.process = MagicMock(pid=424242)
        self.process.poll.return_value = None
        self.popen = self.mock('subprocess.Popen', return_value=self.process)
        self.killpg = self.mock('os.killpg')
        self.mock('shutil.which', return_value=str(self.work / 'sdk/cmdline-tools/16.0/bin/avdmanager'))
        self.mock('platform.system', return_value='Darwin')
        self.mock('platform.machine', return_value='x86_64')
        self.mock('platform.release', return_value='synthetic')
        self.mock('os.getuid', return_value=1001)
        self.mock('os.geteuid', return_value=1001)
        self.mock('os.getgid', return_value=1001)
        self.mock('os.getgroups', return_value=[1001])
        self.now = 0
        self.mock('time.monotonic', side_effect=lambda: self.now)
        self.mock('time.sleep', side_effect=lambda seconds: setattr(self, 'now', self.now + seconds))
        self.commands = []
        self.fake_run = self.mock('run', side_effect=self.command)

    def mock(self, target, **kwargs):
        # The dynamic module is not in sys.modules; patch objects directly.
        if '.' in target:
            owner, attr = target.split('.', 1)
            context = patch.object(getattr(module, owner), attr, **kwargs)
        else:
            context = patch.object(module, target, **kwargs)
        result = context.start(); self.addCleanup(context.stop)
        return result

    def command(self, args, deadline, **kwargs):
        self.commands.append(args)
        output = ''
        if args[:2] == ['sysctl', '-n']:
            output = '1\n'
        elif args[-1:] == ['-version']:
            output = 'Synthetic emulator\n'
        elif args[-1:] == ['-accel-check']:
            output = 'accel:\n0\nHypervisor.Framework OS X Version synthetic\naccel\n'
        elif args[-1:] == ['devices']:
            output = 'List of devices attached\n\n'
        elif 'create' in args:
            avd = Path(os.environ['ANDROID_AVD_HOME'])
            (avd / 'synthetic34mac.ini').write_text('path=synthetic\n')
        elif args[-1:] == ['-list-avds']:
            output = 'synthetic34mac\n'
        elif 'getprop' in args:
            output = '34\n' if args[-1] == 'ro.build.version.sdk' else '1\n'
        elif args[-3:] == ['service', 'check', 'phone']:
            output = 'Service phone: found\n'
        return subprocess.CompletedProcess(args, 0, stdout=output, stderr='')

    def observations(self):
        return [json.loads(line) for line in
                (self.work / 'device-evidence/mac-startup-observations.jsonl').read_text().splitlines()]

    def test_success_launches_exactly_once_with_accel_on_and_api34(self):
        module.start()
        self.popen.assert_called_once()
        argv = self.popen.call_args.args[0]
        self.assertEqual('on', argv[argv.index('-accel') + 1])
        self.assertIn('-no-snapshot', argv)
        self.assertIn('-show-kernel', argv)
        self.assertEqual('*:i', argv[argv.index('-logcat') + 1])
        self.assertEqual(1, argv.count('-logcat-output'))
        self.assertEqual(str((self.work / 'device-evidence/emulator-start-logcat.txt').resolve()),
                         argv[argv.index('-logcat-output') + 1])
        self.assertTrue(self.popen.call_args.kwargs['start_new_session'])
        self.killpg.assert_not_called()
        summary = json.loads((self.work / 'device-evidence/mac-boot-summary.json').read_text())
        self.assertEqual((34, 1, 600), (summary['android_api'], summary['launches'], summary['budget_seconds']))

    def test_boot_after_old_five_minute_limit_succeeds_with_one_launch(self):
        def slow_boot(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['sys.boot_completed']:
                if self.now < 450:
                    self.now = 450
                    result.stdout = '\n'
            return result
        self.fake_run.side_effect = slow_boot
        module.start()
        summary = json.loads((self.work / 'device-evidence/mac-boot-summary.json').read_text())
        self.assertEqual(600, summary['budget_seconds'])
        self.assertEqual(453, summary['boot_seconds'])
        self.popen.assert_called_once()
        self.killpg.assert_not_called()

    def test_avdmanager_outside_sdk_is_rejected_before_launch(self):
        module.shutil.which.return_value = '/synthetic/unrelated/avdmanager'
        with self.assertRaisesRegex(RuntimeError, 'inside ANDROID_HOME'):
            module.start()
        self.popen.assert_not_called()

    def test_wrong_platform_never_launches(self):
        module.platform.system.return_value = 'Linux'
        with self.assertRaisesRegex(RuntimeError, 'Intel macOS'):
            module.start()
        self.popen.assert_not_called()

    def test_root_identity_never_launches(self):
        module.os.getuid.return_value = 0
        with self.assertRaisesRegex(RuntimeError, 'unprivileged'):
            module.start()
        self.popen.assert_not_called()

    def test_missing_hvf_never_launches_or_changes_permissions(self):
        self.fake_run.return_value = subprocess.CompletedProcess([], 0, stdout='0\n')
        self.fake_run.side_effect = None
        with self.assertRaisesRegex(RuntimeError, 'HVF is unavailable'):
            module.start()
        self.popen.assert_not_called(); self.killpg.assert_not_called()

    def test_acceleration_denial_is_recorded_and_not_retried(self):
        def fail(args, deadline, **kwargs):
            if args[-1:] == ['-accel-check']:
                raise subprocess.CalledProcessError(11, args, output='Synthetic HVF denial')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = fail
        with self.assertRaises(subprocess.CalledProcessError):
            module.start()
        self.popen.assert_not_called()
        self.assertEqual('Synthetic HVF denial', (self.work / 'device-evidence/mac-startup-command-output.txt').read_text())
        self.assertEqual(1, sum(c.args[0][-1:] == ['-accel-check'] for c in self.fake_run.call_args_list))

    def test_existing_device_is_never_modified(self):
        def existing(args, deadline, **kwargs):
            if args[-1:] == ['devices']:
                return subprocess.CompletedProcess(args, 0, stdout='List of devices attached\nsynthetic-other\tdevice\n')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = existing
        with self.assertRaisesRegex(RuntimeError, 'already exists'):
            module.start()
        self.popen.assert_not_called(); self.killpg.assert_not_called()

    def test_dead_emulator_is_not_relaunched(self):
        self.process.poll.return_value = 1
        with self.assertRaisesRegex(RuntimeError, 'only emulator process exited'):
            module.start()
        self.popen.assert_called_once()

    def test_outer_emulator_exit_zero_is_not_a_successful_boot(self):
        self.process.poll.return_value = 0
        with self.assertRaisesRegex(RuntimeError, 'only emulator process exited'):
            module.start()
        self.popen.assert_called_once()
        self.assertFalse((self.work / 'device-evidence/mac-boot-summary.json').exists())
        snapshot = json.loads((self.work / 'device-evidence/mac-pre-cleanup.json').read_text())
        self.assertEqual(0, snapshot['process_returncode'])
        self.assertEqual('owned_process_already_exited', snapshot['fresh_collection_status'])

    def test_expired_budget_before_launch_never_starts_emulator(self):
        def expired(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['-list-avds']:
                self.now = 601
            return result
        self.fake_run.side_effect = expired
        with self.assertRaisesRegex(TimeoutError, 'before launch'):
            module.start()
        self.popen.assert_not_called()
        self.killpg.assert_not_called()

    def test_wifi_is_disabled_before_phone_wait_and_other_settings_follow_it(self):
        module.start()
        check = next(i for i, args in enumerate(self.commands)
                     if args[-3:] == ['service', 'check', 'phone'])
        wifi = next(i for i, args in enumerate(self.commands)
                    if args[-3:] == ['svc', 'wifi', 'disable'])
        self.assertLess(wifi, check)
        changes = [i for i, args in enumerate(self.commands)
                   if args[-3:] == ['svc', 'data', 'disable'] or 'settings' in args or 'wm' in args]
        self.assertTrue(changes)
        self.assertTrue(all(check < i for i in changes))
        self.assertEqual(1, sum(args[-3:] == ['service', 'check', 'phone']
                                for args in self.commands))

    def test_phone_service_registration_lag_waits_without_relaunch(self):
        checks = 0
        def delayed(args, deadline, **kwargs):
            nonlocal checks
            result = self.command(args, deadline, **kwargs)
            if args[-3:] == ['service', 'check', 'phone']:
                checks += 1
                if checks < 3:
                    result.stdout = 'Service phone: not found\n'
            return result
        self.fake_run.side_effect = delayed
        module.start()
        self.assertEqual(3, checks)
        self.assertEqual(6, self.now)
        self.assertEqual(['Service phone: not found\n'] * 2 + ['Service phone: found\n'],
                         [e['stdout'] for e in self.observations()
                          if e['phase'] == 'phone_service_readiness'])
        self.assertEqual(1, sum(args[-3:] == ['svc', 'data', 'disable'] for args in self.commands))
        self.popen.assert_called_once()
        self.killpg.assert_not_called()

    def test_missing_phone_service_expires_at_shared_startup_deadline(self):
        checks = 0
        def missing(args, deadline, **kwargs):
            nonlocal checks
            self.assertLess(self.now, deadline)
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['ro.build.version.sdk']:
                self.now = 598
            if args[-3:] == ['service', 'check', 'phone']:
                checks += 1
                result.stdout = 'Service phone: not found\n'
            return result
        self.fake_run.side_effect = missing
        with self.assertRaisesRegex(TimeoutError, 'phone service was not ready within the 600-second'):
            module.start()
        self.assertEqual((1, 600), (checks, self.now))
        event = next(e for e in self.observations() if e['phase'] == 'phone_service_readiness')
        self.assertEqual(2, event['timeout_seconds'])
        self.assertEqual([['svc', 'wifi', 'disable']],
                         [args[-3:] for args in self.commands if 'svc' in args])
        self.assertFalse(any('settings' in args or 'wm' in args for args in self.commands))
        self.assertFalse((module.OUT / 'mac-boot-summary.json').exists())
        self.popen.assert_called_once()
        self.killpg.assert_called_once()

    def check_phone_readiness_rejected(self, stdout, stderr='', returncode=0):
        def response(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-3:] == ['service', 'check', 'phone']:
                result.stdout, result.stderr, result.returncode = stdout, stderr, returncode
            return result
        self.fake_run.side_effect = response
        with self.assertRaisesRegex(RuntimeError, '[Pp]hone service readiness'):
            module.start()
        self.assertEqual(1, sum(args[-3:] == ['service', 'check', 'phone']
                                for args in self.commands))
        self.assertEqual([['svc', 'wifi', 'disable']],
                         [args[-3:] for args in self.commands if 'svc' in args])
        self.assertFalse(any('settings' in args or 'wm' in args for args in self.commands))
        self.assertFalse((module.OUT / 'mac-boot-summary.json').exists())
        self.popen.assert_called_once()
        self.killpg.assert_called_once()

    def test_phone_service_nonzero_missing_is_not_retried(self):
        self.check_phone_readiness_rejected('Service phone: not found\n', returncode=1)

    def test_phone_service_permission_denial_is_not_retried(self):
        self.check_phone_readiness_rejected('', 'Permission Denial: synthetic', 1)

    def test_phone_service_found_with_stderr_denial_is_rejected(self):
        self.check_phone_readiness_rejected('Service phone: found\n', 'Permission Denial: synthetic')

    def test_phone_service_empty_output_is_not_assumed_ready(self):
        self.check_phone_readiness_rejected('')

    def test_phone_service_unknown_output_is_not_retried(self):
        self.check_phone_readiness_rejected('unexpected synthetic service response')

    def test_phone_service_truncated_output_is_not_assumed_ready(self):
        self.check_phone_readiness_rejected('Service phone: found\n' + ' ' * 20000)

    def test_phone_service_command_timeout_is_not_retried(self):
        def timeout(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-3:] == ['service', 'check', 'phone']:
                raise subprocess.TimeoutExpired(args, 5, output=b'synthetic timeout')
            return result
        self.fake_run.side_effect = timeout
        with self.assertRaisesRegex(RuntimeError, 'Phone service readiness check failed'):
            module.start()
        self.assertEqual(1, sum(args[-3:] == ['service', 'check', 'phone']
                                for args in self.commands))
        self.assertEqual([['svc', 'wifi', 'disable']],
                         [args[-3:] for args in self.commands if 'svc' in args])
        self.killpg.assert_called_once()

    def test_phone_service_wait_stops_if_owned_emulator_exits(self):
        def dies(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-3:] == ['service', 'check', 'phone']:
                result.stdout = 'Service phone: not found\n'
                self.process.poll.return_value = 1
            return result
        self.fake_run.side_effect = dies
        with self.assertRaisesRegex(RuntimeError, 'exited while waiting for the phone service'):
            module.start()
        self.assertEqual(1, sum(args[-3:] == ['service', 'check', 'phone']
                                for args in self.commands))
        self.assertEqual([['svc', 'wifi', 'disable']],
                         [args[-3:] for args in self.commands if 'svc' in args])
        self.popen.assert_called_once()

    def test_expired_phone_readiness_budget_does_not_start_probe(self):
        module.OUT.mkdir()
        self.now = 600
        self.fake_run.reset_mock()
        with self.assertRaises(TimeoutError):
            module.wait_for_phone_service('/synthetic/adb', self.process,
                                          module.StartupObservations(0, 600))
        self.fake_run.assert_not_called()

    def test_data_disable_failure_after_phone_ready_still_stops_without_retry(self):
        def denied(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-3:] == ['svc', 'data', 'disable']:
                raise subprocess.CalledProcessError(1, args, output='Permission Denial: synthetic')
            return result
        self.fake_run.side_effect = denied
        with self.assertRaises(subprocess.CalledProcessError):
            module.start()
        self.assertEqual(1, sum(args[-3:] == ['svc', 'data', 'disable'] for args in self.commands))
        self.assertFalse((module.OUT / 'mac-boot-summary.json').exists())
        self.popen.assert_called_once()
        self.killpg.assert_called_once()

    def test_expired_boot_budget_stops_only_owned_process(self):
        self.popen.side_effect = lambda *args, **kwargs: (setattr(self, 'now', 601) or self.process)
        with self.assertRaises(TimeoutError):
            module.start()
        self.popen.assert_called_once()
        self.killpg.assert_called_once_with(424242, module.signal.SIGTERM)

    def test_wrong_api_fails_without_second_launch(self):
        def wrong_api(args, deadline, **kwargs):
            if args[-1:] == ['ro.build.version.sdk']:
                return subprocess.CompletedProcess(args, 0, stdout='33\n')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = wrong_api
        with self.assertRaisesRegex(RuntimeError, 'fixture identity'):
            module.start()
        self.popen.assert_called_once()
        self.killpg.assert_called_once()
        self.assertFalse(any('svc' in args or 'settings' in args or 'wm' in args for args in self.commands))

    def test_stderr_warning_does_not_hide_valid_stdout_or_identity(self):
        def warning(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if 'getprop' in args:
                result.stdout = result.stdout.rstrip() + '\r\n'
                result.stderr = 'synthetic adb warning\n'
            return result
        self.fake_run.side_effect = warning
        module.start()
        reads = [event for event in self.observations() if event['phase'] in ('boot_poll', 'fixture_identity')]
        self.assertEqual(3, len(reads))
        self.assertTrue(all(event['stderr'] == 'synthetic adb warning\n' for event in reads))
        self.killpg.assert_not_called()

    def test_stderr_one_is_not_boot_completion(self):
        def only_stderr(args, deadline, **kwargs):
            if args[-1:] == ['sys.boot_completed']:
                self.now = 600
                return subprocess.CompletedProcess(args, 0, stdout='', stderr='1\r\n')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = only_stderr
        with self.assertRaisesRegex(TimeoutError, 'Android did not boot'):
            module.start()
        self.assertFalse((self.work / 'device-evidence/mac-boot-summary.json').exists())
        self.popen.assert_called_once()
        self.killpg.assert_called_once()

    def test_nonzero_stdout_one_is_not_boot_completion(self):
        def nonzero(args, deadline, **kwargs):
            if args[-1:] == ['sys.boot_completed']:
                self.now = 600
                return subprocess.CompletedProcess(args, 1, stdout='1\n', stderr='synthetic failure')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = nonzero
        with self.assertRaises(TimeoutError):
            module.start()
        boot = next(event for event in self.observations() if event['phase'] == 'boot_poll')
        self.assertEqual(('nonzero', 1), (boot['status'], boot['returncode']))

    def test_truncated_stdout_cannot_falsely_confirm_boot(self):
        def oversized(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['sys.boot_completed']:
                self.now = 600
                result.stdout = '1\n' + ' ' * 20000 + 'unexpected'
            return result
        self.fake_run.side_effect = oversized
        with self.assertRaises(TimeoutError):
            module.start()
        boot = next(event for event in self.observations() if event['phase'] == 'boot_poll')
        self.assertTrue(boot['stdout_truncated'])
        self.assertFalse((self.work / 'device-evidence/mac-boot-summary.json').exists())
        self.killpg.assert_called_once()

    def test_truncated_stdout_cannot_falsely_confirm_api_identity(self):
        def oversized(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['ro.build.version.sdk']:
                result.stdout = '34\n' + ' ' * 20000 + 'unexpected'
            return result
        self.fake_run.side_effect = oversized
        with self.assertRaisesRegex(RuntimeError, 'ro.build.version.sdk'):
            module.start()
        self.assertFalse(any('svc' in args or 'settings' in args or 'wm' in args for args in self.commands))
        self.killpg.assert_called_once()

    def test_timeout_partial_byte_outputs_are_preserved(self):
        def timeout(args, deadline, **kwargs):
            if args[-1:] == ['sys.boot_completed']:
                self.now = 600
                raise subprocess.TimeoutExpired(args, 5, output=b'synthetic partial\xff', stderr=b'synthetic offline')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = timeout
        with self.assertRaises(TimeoutError):
            module.start()
        event = next(event for event in self.observations() if event['phase'] == 'boot_poll')
        self.assertEqual('timeout', event['status'])
        self.assertEqual('synthetic partial\ufffd', event['stdout'])
        self.assertEqual('synthetic offline', event['stderr'])
        self.assertIsNone(event['returncode'])
        self.assertIn('+00:00', event['timestamp_utc'])
        self.assertEqual(600, event['elapsed_seconds'])

    def test_offline_polls_and_periodic_devices_are_preserved_then_succeed(self):
        attempts = 0
        def offline(args, deadline, **kwargs):
            nonlocal attempts
            if args[-1:] == ['sys.boot_completed']:
                attempts += 1
                if attempts < 7:
                    raise subprocess.CalledProcessError(1, args, output='', stderr='synthetic device offline')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = offline
        module.start()
        events = self.observations()
        polls = [event for event in events if event['phase'] == 'boot_poll']
        devices = [event for event in events if event['phase'] == 'devices_during_startup']
        self.assertEqual(7, len(polls))
        self.assertTrue(all(event['status'] == 'nonzero' for event in polls[:-1]))
        self.assertEqual('ok', polls[-1]['status'])
        self.assertEqual([0, 15], [event['elapsed_seconds'] for event in devices])
        self.assertTrue(all(event['timeout_seconds'] == 2 for event in devices))
        self.popen.assert_called_once()

    def test_deadline_snapshot_precedes_stop_without_new_adb_commands(self):
        def timeout(args, deadline, **kwargs):
            self.assertLess(self.now, deadline, 'No subprocess may start after deadline')
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['sys.boot_completed']:
                result.stdout = '0\n'
                self.now = 600
            return result
        self.fake_run.side_effect = timeout
        def check_snapshot(*args):
            snapshot = json.loads((self.work / 'device-evidence/mac-pre-cleanup.json').read_text())
            self.assertEqual(424242, snapshot['pid'])
            self.assertEqual('0\n', snapshot['latest_boot']['stdout'])
            self.assertEqual([], snapshot['fresh_observations'])
            self.assertFalse(snapshot['cached_observations_are_current_snapshot'])
            self.assertEqual(600, snapshot['cached_observation_ages_seconds']['latest_devices'])
            self.assertEqual('budget_expired_use_last_live_observations', snapshot['fresh_collection_status'])
        self.killpg.side_effect = check_snapshot
        with self.assertRaises(TimeoutError):
            module.start()
        self.killpg.assert_called_once()

    def test_skipped_poll_preserves_previous_live_boot_observation(self):
        device_reads = 0
        boot_reads = 0
        def consume_budget(args, deadline, **kwargs):
            nonlocal device_reads, boot_reads
            result = self.command(args, deadline, **kwargs)
            if args[-2:] == ['devices', '-l']:
                device_reads += 1
                if device_reads == 2:
                    self.assertEqual(598, self.now)
                    self.now = 600
                    raise subprocess.TimeoutExpired(args, 2, output=b'synthetic partial devices')
            if args[-1:] == ['sys.boot_completed']:
                boot_reads += 1
                self.now = 595
                result.stdout = '0\n'
            return result
        self.fake_run.side_effect = consume_budget
        with self.assertRaises(TimeoutError):
            module.start()
        snapshot = json.loads((self.work / 'device-evidence/mac-pre-cleanup.json').read_text())
        self.assertEqual(1, boot_reads)
        self.assertEqual(('0\n', 595), (snapshot['latest_boot']['stdout'], snapshot['latest_boot']['elapsed_seconds']))
        self.assertEqual(5, snapshot['cached_observation_ages_seconds']['latest_boot'])
        self.assertEqual('timeout', snapshot['latest_devices']['status'])
        events = [event for event in self.observations() if event['phase'] == 'boot_poll']
        self.assertEqual(['ok', 'budget_expired'], [event['status'] for event in events])
        self.killpg.assert_called_once()

    def test_identity_keeps_original_timeout_capped_by_remaining_budget(self):
        def near_deadline(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['sys.boot_completed']:
                self.now = 595
            if args[-1:] in (['ro.kernel.qemu'], ['ro.build.version.sdk']):
                self.assertEqual(30, kwargs['timeout'])
            return result
        self.fake_run.side_effect = near_deadline
        module.start()
        identity = [event for event in self.observations() if event['phase'] == 'fixture_identity']
        self.assertEqual(2, len(identity))
        self.assertTrue(all(event['timeout_seconds'] == 5 for event in identity))
        self.killpg.assert_not_called()

    def test_early_failure_collects_fresh_read_only_state_before_stop(self):
        def wrong_api(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['ro.build.version.sdk']:
                result.stdout = '33\n'
            return result
        self.fake_run.side_effect = wrong_api
        def check_snapshot(*args):
            snapshot = json.loads((self.work / 'device-evidence/mac-pre-cleanup.json').read_text())
            self.assertEqual(['pre_cleanup_devices', 'pre_cleanup_boot', 'pre_cleanup_logcat'],
                             [event['phase'] for event in snapshot['fresh_observations']])
            self.assertTrue(all(event['timeout_seconds'] <= 2 for event in snapshot['fresh_observations']))
            self.assertEqual('completed_within_startup_budget', snapshot['fresh_collection_status'])
        self.killpg.side_effect = check_snapshot
        with self.assertRaisesRegex(RuntimeError, 'fixture identity'):
            module.start()
        self.killpg.assert_called_once()
        self.popen.assert_called_once()

    def test_snapshot_failure_does_not_hide_startup_failure_or_cleanup(self):
        def wrong_api(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['ro.build.version.sdk']:
                result.stdout = '33\n'
            return result
        self.fake_run.side_effect = wrong_api
        with patch.object(module.StartupObservations, 'before_stop', side_effect=OSError('synthetic disk failure')):
            with self.assertRaisesRegex(RuntimeError, 'fixture identity'):
                module.start()
        self.popen.assert_called_once()
        self.killpg.assert_called_once_with(424242, module.signal.SIGTERM)
        self.assertTrue(self.popen.call_args.kwargs['stdout'].closed)

    def test_early_failure_snapshot_stops_at_original_deadline(self):
        in_cleanup = False
        def near_deadline(args, deadline, **kwargs):
            nonlocal in_cleanup
            self.assertLess(self.now, deadline)
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['ro.build.version.sdk']:
                result.stdout = '33\n'
                self.now = 599.5
                in_cleanup = True
            elif in_cleanup:
                self.assertEqual(['devices', '-l'], args[-2:])
                self.now = 600
                raise subprocess.TimeoutExpired(args, .5, output=b'synthetic incomplete devices')
            return result
        self.fake_run.side_effect = near_deadline
        with self.assertRaisesRegex(RuntimeError, 'fixture identity'):
            module.start()
        snapshot = json.loads((self.work / 'device-evidence/mac-pre-cleanup.json').read_text())
        self.assertEqual(1, len(snapshot['fresh_observations']))
        event = snapshot['fresh_observations'][0]
        self.assertEqual(('timeout', .5), (event['status'], event['timeout_seconds']))
        self.assertEqual('budget_expired_use_last_live_observations', snapshot['fresh_collection_status'])
        self.killpg.assert_called_once()

    def test_failed_identity_cannot_be_satisfied_by_stderr(self):
        def misleading(args, deadline, **kwargs):
            result = self.command(args, deadline, **kwargs)
            if args[-1:] == ['ro.kernel.qemu']:
                result.stdout, result.stderr = '', '1\n'
            return result
        self.fake_run.side_effect = misleading
        with self.assertRaisesRegex(RuntimeError, 'ro.kernel.qemu'):
            module.start()
        self.assertFalse(any('svc' in args or 'settings' in args or 'wm' in args for args in self.commands))
        self.killpg.assert_called_once()

    def test_os_error_is_recorded_without_new_launch(self):
        def missing_adb(args, deadline, **kwargs):
            if args[-1:] == ['sys.boot_completed']:
                self.now = 600
                raise OSError('synthetic adb executable unavailable')
            return self.command(args, deadline, **kwargs)
        self.fake_run.side_effect = missing_adb
        with self.assertRaises(TimeoutError):
            module.start()
        event = next(event for event in self.observations() if event['phase'] == 'boot_poll')
        self.assertEqual('os_error', event['status'])
        self.assertIn('synthetic adb executable unavailable', event['stderr'])
        self.popen.assert_called_once()

    def test_output_size_and_metadata_are_allowlisted(self):
        module.OUT.mkdir()
        observer = module.StartupObservations(0, 600)
        self.fake_run.side_effect = None
        self.fake_run.return_value = subprocess.CompletedProcess([], 0, stdout='x' * 20000, stderr='')
        event = observer.observe(['synthetic-read-only'], 'test')
        self.assertEqual(module.OBSERVATION_LIMIT, len(event['stdout']))
        self.assertTrue(event['stdout_truncated'])
        sdk = self.work / 'sdk'
        source = sdk / 'system-images/android-34/default/x86_64/source.properties'
        source.parent.mkdir(parents=True)
        source.write_text('Pkg.Revision=7\nAndroidVersion.ApiLevel=34\nsecret=DO_NOT_COPY\n')
        avd = self.work / 'avd'
        config = avd / 'synthetic34mac.avd/config.ini'
        config.parent.mkdir(parents=True)
        config.write_text('hw.cpu.ncore=2\nhw.ramSize=2048\nsecret=DO_NOT_COPY\n')
        module.record_fixture_metadata(sdk, avd, observer)
        content = (module.OUT / 'mac-fixture-metadata.json').read_text()
        self.assertNotIn('DO_NOT_COPY', content)
        metadata = json.loads(content)
        self.assertEqual({'Pkg.Revision': '7', 'AndroidVersion.ApiLevel': '34'}, metadata['system-image'])
        self.assertEqual({'hw.cpu.ncore': '2', 'hw.ramSize': '2048'}, metadata['avd'])

    def test_observation_at_expired_deadline_never_executes_command(self):
        module.OUT.mkdir()
        self.now = 600
        self.fake_run.reset_mock()
        event = module.StartupObservations(0, 600).observe(['synthetic-read-only'], 'expired')
        self.assertEqual('budget_expired', event['status'])
        self.fake_run.assert_not_called()

    def test_command_timeout_is_capped_by_remaining_startup_budget(self):
        # Exercise the real subprocess wrapper with a mocked subprocess call.
        source_spec = importlib.util.spec_from_file_location('mac_run_wrapper', ROOT / 'scripts/ci/start-macos-emulator.py')
        wrapper = importlib.util.module_from_spec(source_spec); source_spec.loader.exec_module(wrapper)
        with patch.object(wrapper.time, 'monotonic', return_value=20), patch.object(wrapper.subprocess, 'run') as command:
            wrapper.run(['synthetic-command'], 22, timeout=30)
            self.assertEqual(2, command.call_args.kwargs['timeout'])
            wrapper.run(['synthetic-read-only'], 22, timeout=5, merge_stderr=False, check=False)
            self.assertEqual(subprocess.PIPE, command.call_args.kwargs['stderr'])
            self.assertFalse(command.call_args.kwargs['check'])
            self.assertEqual(2, command.call_args.kwargs['timeout'])
            with self.assertRaises(TimeoutError):
                wrapper.run(['synthetic-command'], 19)
            self.assertEqual(2, command.call_count)

    def test_workflow_is_one_bounded_mac_trial_with_no_privilege_changes(self):
        text = (ROOT / '.github/workflows/synthetic-device-validation-macos.yml').read_text()
        self.assertIn('runs-on: macos-15-intel', text)
        self.assertIn('timeout-minutes: 25', text)
        self.assertIn('timeout-minutes: 11', text)
        self.assertEqual(600, module.BOOT_BUDGET_SECONDS)
        self.assertIn('github.run_number == 7 && github.run_attempt == 1', text)
        self.assertEqual(1, text.count('python3 scripts/ci/start-macos-emulator.py'))
        self.assertLess(text.index('Build APKs and run lint'), text.index('Start the only bounded'))
        self.assertIn('timeout-minutes: 20', text)
        self.assertIn('needs: build-linux', text)
        for forbidden in ('sudo ', 'setfacl ', 'chmod ', 'udevadm ', 'HAXM', '-accel off'):
            self.assertNotIn(forbidden, text)
        self.assertIn("'tests': 56, 'failures': 0, 'errors': 0, 'skipped': 0", text)
        self.assertIn('len(reports) == 13', text)
        self.assertIn('len(screenshots) >= 6', text)


class MacDiagnosticCommandTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='synthetic mac args with spaces ')
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)
        old_cwd = Path.cwd()
        os.chdir(self.work)
        self.addCleanup(os.chdir, old_cwd)

    @staticmethod
    def documented_stdio_consumers(argv):
        # Source-derived configuration model, NOT an emulator execution.
        # Android QEMU2 VirtconsoleLogcat maps show-kernel to serial stdio;
        # startup logcat chooses a file only when logcat-output is supplied.
        # https://android.googlesource.com/platform/external/qemu/+/refs/heads/emu-32-release/android-qemu2-glue/main.cpp
        return int('-show-kernel' in argv) + int('-logcat' in argv and '-logcat-output' not in argv)

    def test_diagnostics_have_only_one_documented_stdio_consumer(self):
        argv = module.emulator_command('synthetic-emulator')
        self.assertEqual(1, argv.count('-show-kernel'))
        self.assertEqual(1, argv.count('-logcat'))
        self.assertEqual(1, argv.count('-logcat-output'))
        self.assertEqual(1, self.documented_stdio_consumers(argv))

    def test_old_missing_logcat_destination_reproduces_configuration_collision(self):
        argv = module.emulator_command('synthetic-emulator')
        index = argv.index('-logcat-output')
        del argv[index:index + 2]
        self.assertEqual(2, self.documented_stdio_consumers(argv))

    def test_logcat_destination_is_absolute_separate_and_inside_evidence(self):
        argv = module.emulator_command('synthetic-emulator')
        destination = Path(argv[argv.index('-logcat-output') + 1])
        self.assertTrue(destination.is_absolute())
        self.assertEqual((self.work / 'device-evidence').resolve(), destination.parent)
        self.assertNotEqual((self.work / 'device-evidence/emulator-start.log').resolve(), destination)
        self.assertEqual('emulator-start-logcat.txt', destination.name)
        self.assertIn(' ', str(destination))
        self.assertFalse(destination.exists(), 'Constructing the command must not start or write anything')

    def test_real_python_child_receives_output_path_with_spaces_as_one_argument(self):
        # This executes Python solely to inspect OS argv transport. It does
        # not validate Android emulator flag parsing or launch an emulator.
        argv = module.emulator_command('synthetic-emulator')
        result = subprocess.run(
            [sys.executable, '-c', 'import json,sys; print(json.dumps(sys.argv[1:]))', *argv],
            check=True, capture_output=True, text=True, timeout=5)
        received = json.loads(result.stdout)
        self.assertEqual(argv, received)
        self.assertEqual(str((self.work / 'device-evidence/emulator-start-logcat.txt').resolve()),
                         received[received.index('-logcat-output') + 1])


if __name__ == '__main__':
    unittest.main()
