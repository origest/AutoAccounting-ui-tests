"""Source-only guards, not a substitute for Kotlin compilation or device execution."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
APP = "app/src/main/java/net/ankio/auto/"
SERVER = "server/src/main/java/org/ezbook/server/"

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

class OcrTextWiringTest(unittest.TestCase):
    def test_automatic_ocr_is_selected_separately_and_captured_ticket_is_bound(self):
        s = read(APP + "service/OcrService.kt")
        self.assertIn("val useVision = !useChatGptText && PrefManager.aiVisionRecognition", s)
        self.assertLess(s.index("val captureTicket"), s.index("performOcrCapture(useVision)"))
        self.assertIn("captureTicket = captureTicket", s)

    def test_rules_precede_any_raw_text_dispatch(self):
        s = read(APP + "service/ocr/ChatGptOcrTextPipeline.kt")
        self.assertLess(s.index("analyzeOcrRulesOnly"), s.index("recognizeOcrText("))
        self.assertIn('getBoolean("selected", false)', s)
        self.assertIn("accounts.commitOcrText(ticket)", s)
        self.assertIn('SettingUtils.baseCurrency() == "CNY"', s)

    def test_manual_action_has_an_independent_visible_consent(self):
        s = read(APP + "ui/fragment/DataFragment.kt")
        self.assertIn("onAiClick = ::handleAiClick", s)
        self.assertIn('setPositiveButton("同意并分析一次")', s)
        self.assertLess(s.index('setPositiveButton("同意并分析一次")'), s.index("ChatGptRawRecordAnalysis.approve"))
        self.assertIn("OpenAI", s)
        ET.parse(ROOT / "app/src/main/res/layout/adapter_data.xml")
        self.assertIn("@+id/aiAnalyze", read("app/src/main/res/layout/adapter_data.xml"))

    def test_manual_payload_bound_before_dispatch_and_no_image_field(self):
        s = read(APP + "service/ocr/ChatGptRawRecordAnalysis.kt")
        self.assertIn("isTextApprovalFor(approval, OcrTextBillContract.PROMPT, plan.payload)", s)
        self.assertLess(s.index("isTextApprovalFor"), s.index("recognizeApprovedText"))
        self.assertIn("commitApprovedText(approval)", s)
        self.assertNotIn("raw.image", s)
        self.assertNotIn("plan.image", s)

    def test_dispatch_is_durable_and_no_text_in_attempt_schema(self):
        s = read(APP + "service/ocr/OcrTextAttemptStore.kt")
        schema = next(line for line in s.splitlines() if "CREATE TABLE attempt" in line)
        self.assertNotIn("payload", schema)
        self.assertNotIn("response", schema)
        self.assertIn("fingerprint TEXT PRIMARY KEY", schema)
        self.assertIn('put("state", "DISPATCHED")', s)

    def test_local_commit_is_guarded_by_same_account_monitor_as_revoke(self):
        s = read("chatgpt/src/main/java/net/ankio/chatgpt/ChatGptAccounts.kt")
        self.assertIn("@Synchronized fun <T> commitOcrText", s)
        self.assertIn("@Synchronized fun <T> commitApprovedText", s)
        self.assertIn("@Synchronized fun disableOcrText", s)
        self.assertIn("cancelled.set(true); client.close(); future.cancel(true)", s)

    def test_editor_completes_only_after_confirmed_write_and_syncs_revision(self):
        s = read(APP + "ui/dialog/BillEditorDialog.kt")
        self.assertIn("BillTool.saveBillWithResult(billInfo, saveTarget)", s)
        self.assertIn("if (persisted)", s)
        self.assertIn("bill.categoryRevision = updated.categoryRevision", s)
        self.assertIn("check(BillAPI.putConfirmed(bill, target))", read(APP + "utils/BillTool.kt"))

    def test_history_keeps_local_ids_not_ocr_text(self):
        s = read(APP + "service/ocr/OcrReviewBridge.kt")
        self.assertIn('AiReviewChange("OCR_BILL", "", billId.toString())', s)
        self.assertIn("it.defer(reviewId)", s)
        self.assertNotIn("recognizeOcrText", s)
        self.assertNotIn("recognizeApprovedText", s)

    def test_failures_preserve_codes_without_provider_body(self):
        s = read(SERVER + "tools/BillService.kt")
        self.assertIn("aiError?.code ?: 404", s)
        self.assertIn("AiFailureHint.from(e)", s)
        provider = read(SERVER + "ai/providers/BaseOpenAIProvider.kt")
        self.assertIn("throw AiRequestFailure(response.code)", provider)
        self.assertNotIn("error(message)", provider)

    def test_text_contract_checks_credentials_currency_and_never_auto_saves(self):
        s = read(SERVER + "ai/tools/OcrTextBillContract.kt")
        self.assertIn("!isSafeText(text)", s)
        self.assertIn("!supportsCurrency(text)", s)
        self.assertIn('values.getValue("currency") != "CNY"', s)
        self.assertIn("auto = false", s)
        self.assertIn("state = BillState.Wait2Edit", s)

if __name__ == "__main__":
    unittest.main()
