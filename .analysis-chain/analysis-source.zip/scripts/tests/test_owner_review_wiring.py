"""Source/SQLite boundary guards only. Kotlin compilation and device execution are separate."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "app/src/main/java/net/ankio/auto/classification"
SERVER = ROOT / "server/src/main/java/org/ezbook/server/server/OwnerQueueRoutes.kt"


class OwnerReviewWiringTest(unittest.TestCase):
    def setUp(self):
        self.worker = (APP / "OwnerCategoryQueue.kt").read_text()
        self.review = (APP / "OwnerCategoryReview.kt").read_text()
        self.store = (APP / "OwnerQueueStore.kt").read_text()
        self.server = SERVER.read_text()

    def test_worker_no_longer_sends_results_directly_to_apply(self):
        worker = self.worker.split("class OwnerCategoryWorker", 1)[1]
        self.assertNotIn('"ownerQueue/apply"', worker)
        self.assertIn('"RESULT", "REVIEW", response', worker)
        self.assertLess(worker.index("OwnerCategoryReview.claim(context, task)"), worker.index("accounts.classify("))
        self.assertIn("OwnerCategoryReview.apply(context, review, manual = false)", worker)

    def test_automatic_application_rechecks_policy_and_original_authority(self):
        apply = self.review.split("suspend fun apply(", 1)[1]
        self.assertGreaterEqual(apply.count("!manual && !policy.canAutoApply(current)"), 2)
        self.assertIn('task.state != "REVIEW"', apply)
        self.assertIn("target(task.input) != record.target", apply)
        self.assertIn("OwnerCategoryQueue.epoch(context) == task.epoch", self.review)
        self.assertIn("OwnerCategoryQueue.generation(task.input.source) == task.generation", self.review)
        self.assertIn("reviews.beginApply(record.id, current.changes)", apply)
        self.assertIn("AiReviewState.FAILED", apply)
        self.assertIn("if (dispatched)", apply)

    def test_saved_response_recovery_never_reissues_the_provider_call(self):
        recover = self.review.split("internal fun review(", 1)[1].split("fun register()", 1)[0]
        self.assertIn('task.state == "RESULT" && record.errorCode == "REQUEST_INTERRUPTED"', recover)
        self.assertIn("store.recoverReview(record.id, changes)", recover)
        self.assertNotIn("classify(", self.review)
        self.assertNotIn("recognizeOcrText(", self.review)

    def test_pending_results_remain_bounded_and_are_scrubbed_when_paused(self):
        self.assertIn("'READY','DISPATCHED','RESULT','REVIEW'", self.store)
        self.assertIn('setOf("READY", "DISPATCHED", "RESULT", "REVIEW")', self.store)
        self.assertIn("payload='', response='' WHERE state IN ('READY','DISPATCHED','RESULT','REVIEW')", self.store)
        self.assertIn("OwnerCategoryReview.cancelPending(context)", self.worker)
        self.assertIn("OwnerCategoryReview.invalidate(context, task.input)", self.worker)

    def test_server_retains_transactional_revoke_fence_and_requires_creation_permission(self):
        apply = self.server.split("suspend fun applyOwnerQueue", 1)[1].split("fun Route.ownerQueueRoutes", 1)[0]
        self.assertIn("db.withTransaction", apply)
        self.assertLess(apply.index("request.authorizationGeneration != authorization.revision"), apply.index("db.categoryDao().insert"))
        self.assertIn("loadByBookAndType(book.remoteId, type.name)", apply)
        self.assertIn("selected != request.confirmedCategory", apply)
        self.assertIn("result.proposed != null && !request.allowCreate", apply)
        self.assertIn('bill.cateName.trim() !in setOf("其他", "其它")', apply)

    def test_ocr_no_longer_bypasses_rule_priority(self):
        policy = (APP / "ClassificationPolicy.kt").read_text()
        eligible = policy.split("fun eligible(", 1)[1].split("fun reserve(", 1)[0]
        self.assertNotIn("mode == Mode.OCR", eligible)
        hold = self.worker.split("fun shouldHoldForAi(", 1)[1].split("fun eligible(", 1)[0]
        self.assertNotIn("WorkMode.isOcr()", hold)
        self.assertIn('bill.category.trim() in setOf("其他", "其它")', eligible)

    def test_prompts_never_start_an_activity_from_background(self):
        prompt = (APP / "OwnerCategoryPrompts.kt").read_text()
        self.assertNotIn("startActivity", prompt)
        self.assertIn("onActivityResumed", prompt)
        self.assertIn("resumed.get() !== host", prompt)
        self.assertIn("host.window.decorView.hasWindowFocus()", prompt)
        self.assertIn("promptedThisVisit = true", prompt)
        self.assertIn("host is AiReviewActivity", prompt)
        self.assertIn("FLAG_SECURE", self.review)


if __name__ == "__main__":
    unittest.main()
