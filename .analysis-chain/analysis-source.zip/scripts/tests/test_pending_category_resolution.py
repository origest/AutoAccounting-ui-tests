"""Source guards only; device tests cover the actual Room compare-and-set."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]

class PendingCategoryResolutionTest(unittest.TestCase):
    def test_cancel_has_no_resolution_and_manual_uses_existing_selector(self):
        s = (ROOT / "app/src/main/java/net/ankio/auto/ui/dialog/BillEditorDialog.kt").read_text()
        self.assertIn('.setNegativeButton("取消，保留待确认") { _, _ -> }', s)
        self.assertIn("basicInfoComponent.chooseCategory()", s)
        self.assertIn("AiReviewPolicy(ctx).canAutoApply(record)", s)
        self.assertNotIn('setNegativeButton("不创建")', s)

    def test_manual_choice_is_not_cleared_until_server_cas(self):
        s = (ROOT / "app/src/main/java/net/ankio/auto/ui/dialog/components/BasicInfoComponent.kt").read_text()
        self.assertIn("onPendingCategoryChoice?.invoke(snapshot, path)", s)
        self.assertNotIn('pendingCategory = ""', s)
        server = (ROOT / "server/src/main/java/org/ezbook/server/server/CategorySuggestionService.kt").read_text()
        self.assertIn("request.revision != bill.categoryRevision", server)
        self.assertIn("if (!request.accept && request.existingPath.isNullOrBlank()) return@withTransaction null", server)
        self.assertIn("path !in CategoryTool.categoryPaths(categories)", server)

    def test_automatic_creation_has_source_revision_policy_fence_and_history(self):
        s = (ROOT / "app/src/main/java/net/ankio/auto/service/ocr/OcrPendingCategoryReview.kt").read_text()
        self.assertIn("policy.withAutomaticApply(record, commit)", s)
        self.assertIn("target(current) != record.target", s)
        self.assertIn("beginApply(record.id, record.changes)", s)
        self.assertIn("AiReviewState.MANUAL, changes", s)
        self.assertIn("AiReviewKind.OCR_CATEGORY", s)
        self.assertNotIn("recognizeOcrText", s)
        self.assertNotIn("recognizeApprovedText", s)
        self.assertNotIn("LocalNetwork", s)

if __name__ == "__main__":
    unittest.main()
