"""Source inspection only; does not compile Kotlin or prove runtime/device correctness."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / 'app/src/main/java/net/ankio/auto/classification'

class QueueAuthorizationWiringTest(unittest.TestCase):
    def test_apply_and_rows_carry_generation(self):
        queue = (APP / 'OwnerCategoryQueue.kt').read_text()
        review = (APP / 'OwnerCategoryReview.kt').read_text()
        store = (APP / 'OwnerQueueStore.kt').read_text()
        self.assertIn('task.generation != serverGeneration', queue)
        self.assertIn('task.response, task.legacy, task.generation', review)
        self.assertIn('OwnerCategoryQueue.generation(task.input.source) == task.generation', review)
        self.assertIn('store.enqueue(input, false, epoch, serverGeneration)', queue)
        self.assertIn('ALTER TABLE task ADD COLUMN generation INTEGER', store)
        self.assertNotIn('DELETE FROM attempt', store)
    def test_pending_and_corruption_gate_new_work(self):
        queue = (APP / 'OwnerCategoryQueue.kt').read_text()
        controller = (APP / 'OwnerQueueAuthorization.kt').read_text()
        self.assertIn('authorization.snapshot().pending == null', queue)
        self.assertIn('authorization.corrupted ->', queue)
        self.assertIn('permissions.completeGrantIfCurrent(expectedStamp)', queue)
        self.assertIn('if (corrupted || !valid(next))', controller)
        self.assertIn('if (record.pending != prepared)', controller)
        self.assertIn('remote.source != pending.source', controller)
    def test_stop_does_not_wait_for_control_or_busy_ui(self):
        queue = (APP / 'OwnerCategoryQueue.kt').read_text()
        activity = (APP / 'OwnerCategoryActivity.kt').read_text()
        stop = queue.split('fun stop(context:', 1)[1].split('fun activate(', 1)[0]
        self.assertLess(stop.index('authorization.stop'), stop.index('permissions.stop'))
        self.assertNotIn('reconcile()', stop)
        self.assertIn('reconcileLater()', stop)
        self.assertIn('page.button("暂停并取消剩余任务")', activity)
    def test_grants_wait_for_server_and_keep_separate_ui_revision(self):
        activity = (APP / 'OwnerCategoryActivity.kt').read_text()
        controller = (APP / 'OwnerQueueAuthorization.kt').read_text()
        self.assertEqual(2, activity.count('OwnerCategoryQueue.authorizeServer('))
        self.assertIn('if (generation(source, scope) != null) return true', controller)
        self.assertIn('OwnerCategoryQueue.stamp()', activity)
    def test_android_tests_call_production_controller(self):
        tests = (ROOT / 'app/src/androidTest/java/net/ankio/auto/classification/OwnerQueueAuthorizationDeviceTest.kt').read_text()
        self.assertIn('OwnerQueueAuthorization(disk, wire)', tests)
        self.assertIn('controller.reconcile()', tests)
        self.assertIn('controller.stop()', tests)
        self.assertNotIn('class FakeController', tests)
