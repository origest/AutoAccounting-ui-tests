"""Exercise the production SQL WHERE predicate with synthetic in-memory SQLite.

This validates the epoch/state predicate and its call-site wiring, not the Android
SQLiteOpenHelper wrapper, complete worker behavior, or Kotlin compilation.
"""

from pathlib import Path
import re
import sqlite3
import unittest


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "app/src/main/java/net/ankio/auto/classification/OwnerQueueStore.kt"


class QueueMutationGuardTest(unittest.TestCase):
    def setUp(self):
        self.source = SOURCE.read_text()
        match = re.search(r'const val MUTATION_WHERE = "([^"]+)"', self.source)
        self.assertIsNotNone(match)
        self.guard = match.group(1)
        self.db = sqlite3.connect(":memory:")
        self.db.execute("CREATE TABLE task (key TEXT PRIMARY KEY, epoch INTEGER, state TEXT, payload TEXT, response TEXT)")

    def tearDown(self):
        self.db.close()

    def seed(self, epoch, state, payload="synthetic", response=""):
        self.db.execute("INSERT INTO task VALUES (?, ?, ?, ?, ?)", ("fixture:1", epoch, state, payload, response))

    def transition(self, epoch, expected, state, payload="synthetic", response=""):
        return self.db.execute(
            "UPDATE task SET state=?,payload=?,response=? WHERE " + self.guard,
            (state, payload, response, "fixture:1", str(epoch), expected),
        ).rowcount

    def row(self):
        return self.db.execute("SELECT epoch,state,payload,response FROM task").fetchone()

    def test_valid_transition_applies_only_once(self):
        self.seed(2, "DISPATCHED")
        self.assertEqual(1, self.transition(2, "DISPATCHED", "RESULT", response="synthetic result"))
        self.assertEqual(0, self.transition(2, "DISPATCHED", "UNKNOWN", payload=""))
        self.assertEqual((2, "RESULT", "synthetic", "synthetic result"), self.row())

    def test_late_completion_cannot_restore_a_scrubbed_row(self):
        self.seed(1, "UNKNOWN", payload="")
        self.assertEqual(0, self.transition(1, "DISPATCHED", "RESULT", payload="", response="late"))
        self.assertEqual((1, "UNKNOWN", "", ""), self.row())

    def test_reused_key_is_protected_from_an_old_epoch(self):
        self.seed(2, "READY")
        self.assertEqual(0, self.transition(1, "READY", "CANCELLED", payload=""))
        self.assertEqual(0, self.transition(1, "READY", "DISPATCHED"))
        self.assertEqual((2, "READY", "synthetic", ""), self.row())
        self.assertEqual(1, self.transition(2, "READY", "DISPATCHED"))

    def test_legacy_key_only_update_reproduces_resurrection(self):
        self.seed(1, "UNKNOWN", payload="")
        self.db.execute("UPDATE task SET state='RESULT',response='late' WHERE key=?", ("fixture:1",))
        self.assertEqual((1, "RESULT", "", "late"), self.row())

    def test_status_and_dispatch_wire_epoch_and_expected_state_into_the_guard(self):
        self.assertIn("MUTATION_WHERE, arrayOf(key, epoch.toString(), expectedState)", self.source)
        self.assertIn('MUTATION_WHERE, arrayOf(key, epoch.toString(), "READY")', self.source)
        worker = (SOURCE.parent / "OwnerCategoryQueue.kt").read_text()
        self.assertIn('if (!store.status(task.key, task.epoch, "DISPATCHED", "RESULT", response)) return@repeat', worker)


if __name__ == "__main__":
    unittest.main()
