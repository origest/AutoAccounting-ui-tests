"""Source guards only. Android regression tests exercise the real permission class separately.

These checks do not execute Kotlin, prove disk durability or close the server commit gap.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
JAVA = ROOT / "app/src/main/java/net/ankio/auto"


class QueuePermissionWiringTest(unittest.TestCase):
    def setUp(self):
        self.queue = (JAVA / "classification/OwnerCategoryQueue.kt").read_text()
        self.boundary = (JAVA / "classification/OwnerQueuePermissions.kt").read_text()
        self.activity = (JAVA / "classification/OwnerCategoryActivity.kt").read_text()

    def test_every_automatic_grant_is_atomic_and_versioned(self):
        activate = self.boundary.split("@Synchronized fun activate", 1)[1].split("@Synchronized fun saveCursor", 1)[0]
        self.assertIn('putBoolean("enabled", true)', activate)
        self.assertIn('putBoolean("automatic", true)', activate)
        self.assertIn('Math.addExact(stamp().automaticGrant, 1)', activate)
        self.assertEqual(1, activate.count("commit(editor)"))
        self.assertNotIn(".commit()", self.activity)
        self.assertIn("OwnerCategoryQueue.stamp()", self.activity)

    def test_stop_attempts_all_boundaries_and_never_uses_worker_mutex(self):
        stop = self.boundary.split("@Synchronized fun stop", 1)[1]
        self.assertLess(stop.index("blocked = true"), stop.index("val settings"))
        for call in ("cancelTasks()", "pauseProvider()", "cancelWork()"):
            self.assertIn("attempt { " + call, stop)
        self.assertNotIn("mutex", stop)
        self.assertIn("cancelled?.let { throw it }", stop)
        self.assertIn("if (!result.localComplete || !durableIntent) reportFailure(context)", self.queue)

    def test_failed_persistence_is_runtime_blocked_and_reported(self):
        self.assertIn("!permissions.blocked", self.queue)
        self.assertIn("if (!it) failed()", self.boundary)
        self.assertIn('Result.failure(workDataOf("queueError" to "PERMISSION_STORAGE_FAILURE"))', self.queue)
        self.assertIn("else showError(OwnerQueuePermissions.FAILURE_MESSAGE)", self.activity)
        self.assertIn("OwnerCategoryQueue.warning()?.let", self.activity)
        self.assertIn("重启后暂停状态无法保证", self.boundary)

    def test_worker_ticket_and_late_scope_mutations_are_fenced(self):
        worker = self.queue.split("class OwnerCategoryWorker", 1)[1]
        self.assertIn("val ticket = synchronized(OwnerCategoryQueue)", worker)
        self.assertIn("Triple(OwnerCategoryQueue.stamp(), PrefManager.workMode.name, account)", worker)
        self.assertGreaterEqual(worker.count("OwnerCategoryQueue.stamp() != grant"), 3)
        self.assertNotIn('prefs.edit().putLong("cursor"', worker)
        self.assertIn("OwnerCategoryQueue.saveCursor(context, grant, bill.id)", worker)
        self.assertIn("OwnerCategoryQueue.saveCursor(context, grant, list.upper)", worker)
        self.assertIn("if (blocked || stamp() != expected) return false", self.boundary)

    def test_account_ui_never_reports_success_after_an_incomplete_stop(self):
        account = (JAVA / "ui/activity/ChatGptCategoryActivity.kt").read_text()
        self.assertEqual(1, account.count("OwnerCategoryQueue.stop(this)"))
        self.assertIn("check(net.ankio.auto.classification.OwnerCategoryQueue.stop(this).localComplete)", account)
        self.assertIn("OwnerCategoryQueue.warning() ?: message", account)
        self.assertIn("finally { if (error is kotlinx.coroutines.CancellationException) throw error }", self.queue)


if __name__ == "__main__":
    unittest.main()
