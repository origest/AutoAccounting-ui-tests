"""Finite, synthetic target design; NOT an Android implementation or proof.

A single persistent task key and its attempt ledger are modeled. Re-enqueue may
reuse that key only when it was never attempted. A successful durable stop and
cleanup fence preserve revocation across restart. Lost/uncertain writes are
explicit counterexamples, not promises that production handles those failures.

Database cleanup and clearing the durable cleanup marker are separate events.
The marker, immutable executor tickets, and grant fence are model assumptions.
This model is not wired to the separate production authorization controller,
its pending-revocation record, or its server transaction fence. SQLite outcomes
below are abstract, not tests of Android storage or failure behavior.

By default, crash includes successful startup DISPATCHED-to-UNKNOWN recovery.
A non-ok crash outcome targets that recovery write, which can be retried with
recover. The send transition assumes atomic permission validation/admission;
it is not proof that production HTTP cancellation closes the send race.
"""

from dataclasses import dataclass, replace
import unittest


@dataclass(frozen=True)
class State:
    generation: int = 0
    allowed: bool = True
    durable_generation: int = 0
    durable_allowed: bool = True
    pending: tuple = ()
    durable_pending: tuple = ()
    cleaned_generation: int = -1
    dialog: object = None
    queued: object = None  # Immutable input ticket captured before executor admission.
    admitted: object = None  # Acknowledged durable dispatch, not yet sent.
    in_flight: object = None
    row_generation: int = 0
    row_state: str = "READY"
    attempt: bool = False  # Persistent, per-key no-replay ledger.
    sends: int = 0  # External observation; process death cannot erase a send.
    last_decision: str = "GRANT"  # External user intent, survives a crash.
    stop_acknowledged: bool = False
    write_error: object = None


EVENTS = ("open_dialog", "grant", "stop", "cleanup", "finish_cleanup",
          "enqueue", "submit", "drop_queued", "dispatch", "send", "result", "crash", "recover")
OUTCOMES = ("ok", "lost", "persisted_unacknowledged")


def step(state, event, durable_stop=True, outcome="ok"):
    """'lost' rolls back disk; 'persisted_unacknowledged' cannot authorize a send.

    These are conservative possibilities, not a claim that a particular Android
    API produces each result. Failed operations retain a runtime block where
    possible; a crash can still expose old durable authorization after a lost
    stop write. A returned error is never equivalent to a successful stop.
    """
    assert outcome in OUTCOMES
    written, acknowledged = outcome != "lost", outcome == "ok"
    if event == "open_dialog":
        return replace(state, dialog=state.generation)
    if event == "grant":
        if (state.dialog != state.generation or state.pending or state.durable_pending
                or state.generation != state.durable_generation):
            return None
        return replace(state, allowed=acknowledged,
                       durable_allowed=True if written else state.durable_allowed,
                       dialog=None, last_decision="GRANT", stop_acknowledged=False,
                       write_error=None if acknowledged else "grant")
    if event == "stop":
        if state.generation >= 2:  # Finite bound, not an unbounded proof.
            return None
        generation = state.generation + 1
        pending = state.pending + (generation,)
        stopped = replace(state, generation=generation, allowed=False,
                          pending=pending, last_decision="STOP",
                          stop_acknowledged=durable_stop and acknowledged,
                          write_error=None if acknowledged else "stop")
        if durable_stop and written:
            stopped = replace(stopped, durable_generation=generation,
                              durable_allowed=False, durable_pending=pending)
        return stopped
    if event == "cleanup":
        if not state.pending:
            return None
        ticket = state.pending[0]
        row_state = state.row_state
        if state.row_generation < ticket:
            if row_state == "DISPATCHED":
                row_state = "UNKNOWN"
            elif row_state in ("READY", "RESULT"):
                row_state = "CANCELLED"
        return replace(state, row_state=row_state if written else state.row_state,
                       cleaned_generation=ticket if acknowledged else state.cleaned_generation,
                       write_error=None if acknowledged else "cleanup")
    if event == "finish_cleanup":
        if not state.pending or state.cleaned_generation != state.pending[0]:
            return None
        # Never clear a marker using an unacknowledged/reverted stop generation.
        if state.generation != state.durable_generation:
            return None
        remaining = state.pending[1:]
        return replace(state, pending=remaining if acknowledged else state.pending,
                       durable_pending=remaining if written else state.durable_pending,
                       write_error=None if acknowledged else "finish_cleanup")
    if event == "enqueue":
        if (not state.allowed or state.pending or state.attempt
                or state.row_state not in ("CANCELLED", "STALE")):
            return None
        return replace(state,
                       row_generation=state.generation if written else state.row_generation,
                       row_state="READY" if written else state.row_state,
                       write_error=None if acknowledged else "enqueue")
    if event == "submit":
        if (not state.allowed or state.queued is not None
                or state.row_state != "READY" or state.row_generation != state.generation):
            return None
        return replace(state, queued=state.generation)
    if event == "drop_queued":
        if state.queued is None:
            return None
        return replace(state, queued=None)
    if event == "dispatch":
        if (not state.allowed or state.queued != state.generation or state.pending
                or state.row_generation != state.generation
                or state.row_state != "READY" or state.attempt):
            return None
        return replace(state, queued=None,
                       row_state="DISPATCHED" if written else state.row_state,
                       attempt=written, admitted=state.generation if acknowledged else None,
                       write_error=None if acknowledged else "dispatch")
    if event == "send":
        if (not state.allowed or state.admitted != state.generation
                or state.row_state != "DISPATCHED" or not state.attempt):
            return None
        return replace(state, admitted=None, in_flight=state.generation, sends=state.sends + 1)
    if event == "result":
        if (not state.allowed or state.in_flight != state.generation
                or state.row_generation != state.generation or state.row_state != "DISPATCHED"):
            return None
        return replace(state, row_state="RESULT" if written else state.row_state,
                       in_flight=None if acknowledged else state.in_flight,
                       write_error=None if acknowledged else "result")
    if event == "crash":
        needs_recovery = state.row_state == "DISPATCHED"
        return replace(state, generation=state.durable_generation,
                       allowed=state.durable_allowed, dialog=None, queued=None,
                       admitted=None, in_flight=None, pending=state.durable_pending,
                       cleaned_generation=-1,
                       write_error="recover" if needs_recovery and not acknowledged else None,
                       row_state="UNKNOWN" if needs_recovery and written else state.row_state)
    if event == "recover":
        if state.row_state != "DISPATCHED" or state.admitted is not None or state.in_flight is not None:
            return None
        return replace(state, row_state="UNKNOWN" if written else state.row_state,
                       write_error=None if acknowledged else "recover")
    raise AssertionError(event)


def trace(*events, state=None):
    state = State() if state is None else state
    for event in events:
        changed = step(state, event)
        if changed is None:
            raise AssertionError((event, state))
        state = changed
    return state


class QueueStopDesignModelTest(unittest.TestCase):
    def test_async_only_pause_has_a_process_death_counterexample(self):
        stopped = step(State(), "stop", durable_stop=False)
        self.assertFalse(stopped.allowed)
        self.assertFalse(stopped.stop_acknowledged)
        restarted = step(stopped, "crash")
        self.assertEqual("STOP", restarted.last_decision)
        self.assertTrue(restarted.allowed, "Unsafe counterexample, not desired behavior")

    def test_successful_write_model_explores_new_generation_dispatch_and_restart(self):
        frontier = {State()}
        visited = set(frontier)
        saw_new_dispatch = saw_new_send = saw_restart_unknown = False
        for _ in range(12):
            following = set()
            for state in frontier:
                for event in EVENTS:
                    changed = step(state, event)
                    if changed is None:
                        continue
                    if changed.last_decision == "STOP":
                        self.assertFalse(changed.allowed, (state, event, changed))
                    if changed.allowed:
                        self.assertFalse(changed.pending, (state, event, changed))
                        self.assertFalse(changed.durable_pending, (state, event, changed))
                    if changed.row_state in ("DISPATCHED", "RESULT", "UNKNOWN"):
                        self.assertTrue(changed.attempt)
                    self.assertLessEqual(changed.sends, 1, (state, event, changed))
                    if event == "dispatch" and changed.generation > 0:
                        saw_new_dispatch = True
                    if event == "send" and changed.generation > 0:
                        saw_new_send = True
                    if event == "crash" and changed.generation > 0 and changed.row_state == "UNKNOWN":
                        saw_restart_unknown = True
                    if changed not in visited:
                        following.add(changed)
            visited.update(following)
            frontier = following
        self.assertTrue(saw_new_dispatch, "Exploration must reach re-enqueued new-generation dispatch")
        self.assertTrue(saw_new_send, "Exploration must reach a newly authorized send")
        self.assertTrue(saw_restart_unknown, "Exploration must cover its crash recovery")
        print(f"Synthetic stop model: {len(visited)} states, depth <= 12, at most two stops; successful writes only")

    def test_stop_cleanup_grant_reenqueue_dispatch_send(self):
        state = trace("stop", "cleanup", "finish_cleanup", "open_dialog", "grant", "enqueue", "submit", "dispatch", "send")
        self.assertEqual((1, 1, "DISPATCHED", True, 1),
                         (state.generation, state.row_generation, state.row_state, state.attempt, state.sends))
        self.assertEqual("RESULT", step(state, "result").row_state)

    def test_both_cleanup_stages_fence_grant(self):
        state = trace("stop", "open_dialog")
        self.assertIsNone(step(state, "grant"))
        state = step(state, "cleanup")
        self.assertIsNone(step(state, "grant"))
        self.assertTrue(step(step(state, "finish_cleanup"), "grant").allowed)

    def test_old_dialog_cannot_restore_permission(self):
        state = trace("open_dialog", "stop", "cleanup", "finish_cleanup")
        self.assertIsNone(step(state, "grant"))

    def test_old_input_cannot_inherit_reenqueued_row_and_fresh_input_can_send(self):
        state = trace("submit", "stop", "cleanup", "finish_cleanup", "open_dialog", "grant", "enqueue")
        self.assertEqual((0, 1, 1), (state.queued, state.generation, state.row_generation))
        self.assertIsNone(step(state, "dispatch"))
        state = trace("drop_queued", "submit", "dispatch", "send", state=state)
        self.assertEqual(1, state.sends)

    def test_attempted_same_key_is_not_reenqueued_under_new_grant(self):
        state = trace("submit", "dispatch", "send", "stop", "cleanup", "finish_cleanup", "open_dialog", "grant")
        self.assertEqual("UNKNOWN", state.row_state)
        self.assertTrue(state.attempt)
        self.assertIsNone(step(state, "enqueue"))
        self.assertIsNone(step(state, "result"))

    def test_repeated_stops_must_finish_before_a_new_grant(self):
        state = trace("stop", "stop", "cleanup", "finish_cleanup", "open_dialog")
        self.assertIsNone(step(state, "grant"))
        state = trace("cleanup", "finish_cleanup", "grant", state=state)
        self.assertTrue(state.allowed)
        self.assertIsNone(step(state, "cleanup"))

    def test_crash_after_cleanup_before_marker_clear_repeats_cleanup_safely(self):
        state = trace("stop", "cleanup", "crash", "open_dialog")
        self.assertEqual("CANCELLED", state.row_state)
        self.assertIsNone(step(state, "grant"))
        state = trace("cleanup", "finish_cleanup", "grant", "enqueue", "submit", "dispatch", state=state)
        self.assertEqual(1, state.row_generation)

    def test_crash_before_cleanup_preserves_stop_and_after_cleanup_requires_new_grant(self):
        stopped = trace("stop", "crash", "open_dialog")
        self.assertFalse(stopped.allowed)
        self.assertIsNone(step(stopped, "grant"))
        cleaned = trace("cleanup", "finish_cleanup", "crash", state=stopped)
        self.assertFalse(cleaned.allowed)
        self.assertFalse(cleaned.pending)
        self.assertTrue(trace("open_dialog", "grant", state=cleaned).allowed)

    def test_restart_before_and_after_new_generation_dispatch(self):
        ready = trace("stop", "cleanup", "finish_cleanup", "open_dialog", "grant", "enqueue", "crash")
        self.assertTrue(ready.allowed, "An acknowledged grant preserves authorized restart behavior")
        dispatched = trace("submit", "dispatch", state=ready)
        for state in (dispatched, step(dispatched, "send")):
            restarted = step(state, "crash")
            self.assertEqual("UNKNOWN", restarted.row_state)
            self.assertTrue(restarted.attempt)
            self.assertIsNone(step(restarted, "enqueue"))
            self.assertIsNone(step(restarted, "dispatch"))
            self.assertIsNone(step(restarted, "send"))

    def test_lost_stop_write_is_an_explicit_revocation_counterexample(self):
        stopped = step(State(), "stop", outcome="lost")
        self.assertFalse(stopped.allowed)
        self.assertFalse(stopped.stop_acknowledged)
        self.assertEqual("stop", stopped.write_error)
        restarted = step(stopped, "crash")
        self.assertEqual("STOP", restarted.last_decision)
        self.assertTrue(restarted.allowed, "Lost durable write makes restart safety impossible to claim")

    def test_unacknowledged_stop_may_have_persisted_but_cannot_be_claimed_successful(self):
        stopped = step(State(), "stop", outcome="persisted_unacknowledged")
        self.assertFalse(stopped.stop_acknowledged)
        restarted = step(stopped, "crash")
        self.assertFalse(restarted.allowed)
        self.assertEqual((1,), restarted.pending)

    def test_failed_database_cleanup_keeps_grant_blocked_and_retries(self):
        stopped = trace("stop", "open_dialog")
        for outcome in OUTCOMES[1:]:
            failed = step(stopped, "cleanup", outcome=outcome)
            self.assertIsNone(step(failed, "finish_cleanup"))
            self.assertIsNone(step(failed, "grant"))
            recovered = trace("crash", "cleanup", "finish_cleanup", "open_dialog", "grant", state=failed)
            self.assertTrue(recovered.allowed)

    def test_marker_clear_failure_is_safe_to_retry_after_durable_row_cleanup(self):
        cleaned = trace("stop", "cleanup", "open_dialog")
        for outcome in OUTCOMES[1:]:
            failed = step(cleaned, "finish_cleanup", outcome=outcome)
            self.assertIsNone(step(failed, "grant"))
            restarted = step(failed, "crash")
            self.assertFalse(restarted.allowed)
            self.assertEqual("CANCELLED", restarted.row_state)
            if restarted.pending:
                restarted = trace("cleanup", "finish_cleanup", state=restarted)
            self.assertTrue(trace("open_dialog", "grant", state=restarted).allowed)

    def test_failed_new_grant_is_not_runtime_permission_but_restart_outcome_is_uncertain(self):
        stopped = trace("stop", "cleanup", "finish_cleanup", "open_dialog")
        for outcome in OUTCOMES[1:]:
            failed = step(stopped, "grant", outcome=outcome)
            self.assertFalse(failed.allowed)
            self.assertIsNone(step(failed, "enqueue"))
            self.assertEqual(outcome == "persisted_unacknowledged", step(failed, "crash").allowed)

    def test_enqueue_failure_does_not_reuse_old_epoch_row_for_dispatch(self):
        granted = trace("stop", "cleanup", "finish_cleanup", "open_dialog", "grant")
        failed = step(granted, "enqueue", outcome="lost")
        self.assertEqual((0, "CANCELLED"), (failed.row_generation, failed.row_state))
        self.assertIsNone(step(failed, "submit"))
        self.assertEqual(1, trace("enqueue", "submit", "dispatch", "send", state=failed).sends)
        uncertain = step(granted, "enqueue", outcome="persisted_unacknowledged")
        self.assertEqual((1, "READY"), (uncertain.row_generation, uncertain.row_state))
        self.assertFalse(uncertain.attempt)
        self.assertEqual(1, trace("crash", "submit", "dispatch", "send", state=uncertain).sends)

    def test_dispatch_write_failure_never_authorizes_a_provider_send(self):
        ready = trace("stop", "cleanup", "finish_cleanup", "open_dialog", "grant", "enqueue", "submit")
        for outcome in OUTCOMES[1:]:
            failed = step(ready, "dispatch", outcome=outcome)
            self.assertIsNone(step(failed, "send"))
            self.assertEqual(0, failed.sends)
            restarted = step(failed, "crash")
            if outcome == "lost":
                self.assertFalse(restarted.attempt)
                self.assertEqual(1, trace("submit", "dispatch", "send", state=restarted).sends)
            else:
                self.assertTrue(restarted.attempt)
                self.assertEqual("UNKNOWN", restarted.row_state)
                self.assertIsNone(step(restarted, "dispatch"))

    def test_result_write_failure_does_not_replay_an_attempted_request(self):
        sent = trace("stop", "cleanup", "finish_cleanup", "open_dialog", "grant", "enqueue", "submit", "dispatch", "send")
        for outcome in OUTCOMES[1:]:
            failed = step(sent, "result", outcome=outcome)
            restarted = step(failed, "crash")
            self.assertEqual("UNKNOWN" if outcome == "lost" else "RESULT", restarted.row_state)
            self.assertTrue(restarted.attempt)
            self.assertEqual(1, restarted.sends)
            self.assertIsNone(step(restarted, "enqueue"))
            self.assertIsNone(step(restarted, "dispatch"))
            self.assertIsNone(step(restarted, "send"))

    def test_startup_recovery_write_failure_keeps_attempt_and_cannot_authorize_replay(self):
        sent = trace("submit", "dispatch", "send")
        for outcome in OUTCOMES[1:]:
            restarted = step(sent, "crash", outcome=outcome)
            self.assertEqual("recover", restarted.write_error)
            self.assertEqual("DISPATCHED" if outcome == "lost" else "UNKNOWN", restarted.row_state)
            self.assertTrue(restarted.attempt)
            self.assertIsNone(step(restarted, "dispatch"))
            self.assertIsNone(step(restarted, "send"))
            self.assertIsNone(step(restarted, "enqueue"))
            if outcome == "lost":
                retry_failed = step(restarted, "recover", outcome="lost")
                self.assertEqual("DISPATCHED", retry_failed.row_state)
                restarted = step(retry_failed, "recover")
            self.assertEqual("UNKNOWN", restarted.row_state)
            self.assertEqual(1, restarted.sends)


if __name__ == "__main__":
    unittest.main()
