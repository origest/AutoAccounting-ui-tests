"""Synthetic worker interleavings and one production source-wiring guard.

The threaded model uses only Python memory and locks. It does not run Kotlin,
SharedPreferences, HTTP, Room, or Android instrumentation. Legacy counterexamples
remain to document why the old design failed; they do not execute the new fence.
"""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from itertools import permutations
from pathlib import Path
import re
from threading import Event, RLock
import unittest


ROOT = Path(__file__).resolve().parents[2]
QUEUE = ROOT / "app/src/main/java/net/ankio/auto/classification/OwnerCategoryQueue.kt"


def automatic_sequence(events, fenced):
    epoch, automatic, worker_epoch = 0, True, 0
    for event in events:
        if event == "stop":
            epoch += 1
            automatic = False
        elif event == "grant":
            automatic = True
        elif event == "error" and (not fenced or epoch == worker_epoch):
            automatic = False
    return epoch, automatic


@dataclass(frozen=True)
class AutomaticSettings:
    epoch: int = 0
    automatic: bool = True
    durable_automatic: bool = True


def error_write(settings, expected_epoch, outcome):
    """Abstract memory-first write; no real SharedPreferences API is executed.

    A failure may leave disk unchanged or may have written without a success
    acknowledgment. Both are modeled to avoid claiming durability from a false
    return. This is not an assertion of Android's exact failure semantics.
    """
    assert outcome in ("ok", "lost", "persisted_unacknowledged")
    if settings.epoch != expected_epoch:
        return settings, False
    return replace(settings, automatic=False,
                   durable_automatic=settings.durable_automatic if outcome == "lost" else False), outcome == "ok"


class QueueWorkerInterleavingTest(unittest.TestCase):
    def test_legacy_late_error_closes_new_generation(self):
        self.assertEqual((1, False), automatic_sequence(("stop", "grant", "error"), fenced=False))

    def test_atomic_epoch_fence_preserves_each_new_grant_ordering(self):
        sequences = [s for s in permutations(("stop", "grant", "error")) if s.index("stop") < s.index("grant")]
        self.assertEqual(3, len(sequences))
        for sequence in sequences:
            self.assertEqual((1, True), automatic_sequence(sequence, fenced=True), sequence)

    def test_current_generation_error_still_disables_automatic(self):
        self.assertEqual((0, False), automatic_sequence(("error",), fenced=True))

    def test_legacy_same_epoch_reconfirmation_is_not_protected_from_an_older_error(self):
        self.assertEqual((0, False), automatic_sequence(("grant", "error"), fenced=True))
        self.assertEqual((0, True), automatic_sequence(("error", "grant"), fenced=True))
        # These observations do not decide the intended product semantics. The
        # legacy epoch-only helper cannot identify a later same-epoch grant.

    def test_error_write_failure_cannot_claim_durable_automatic_disable(self):
        failed, accepted = error_write(AutomaticSettings(), 0, "lost")
        self.assertFalse(accepted)
        self.assertFalse(failed.automatic)
        self.assertTrue(failed.durable_automatic, "Restart may restore automatic after an unpersisted write")

    def test_false_write_result_does_not_identify_the_persistent_outcome(self):
        lost, lost_result = error_write(AutomaticSettings(), 0, "lost")
        persisted, persisted_result = error_write(AutomaticSettings(), 0, "persisted_unacknowledged")
        self.assertFalse(lost_result)
        self.assertFalse(persisted_result)
        self.assertNotEqual(lost.durable_automatic, persisted.durable_automatic)

    def test_stale_epoch_error_does_not_even_attempt_a_write(self):
        settings = AutomaticSettings(epoch=1)
        for outcome in ("ok", "lost", "persisted_unacknowledged"):
            after, accepted = error_write(settings, 0, outcome)
            self.assertEqual(settings, after)
            self.assertFalse(accepted)

    def test_split_compare_then_write_is_not_a_fence(self):
        epoch, automatic, worker_epoch = 0, True, 0
        matched = epoch == worker_epoch
        epoch += 1  # stop
        automatic = True  # later explicit grant
        if matched:
            automatic = False  # stale comparison applied too late
        self.assertFalse(automatic)

    def test_shared_monitor_orders_check_write_and_new_grant(self):
        monitor = RLock()
        checked, release, grant_started, grant_done = (Event() for _ in range(4))
        state = {"epoch": 0, "automatic": True}

        def old_error():
            with monitor:
                if state["epoch"] == 0:
                    checked.set()
                    if not release.wait(3):
                        raise AssertionError("Synthetic persistence was not released")
                    state["automatic"] = False

        def new_grant():
            grant_started.set()
            with monitor:
                state["epoch"] += 1
                state["automatic"] = True
            grant_done.set()

        with ThreadPoolExecutor(max_workers=2) as executor:
            first = executor.submit(old_error)
            try:
                self.assertTrue(checked.wait(3))
                second = executor.submit(new_grant)
                self.assertTrue(grant_started.wait(3))
                self.assertFalse(grant_done.is_set())
            finally:
                release.set()
            first.result(timeout=3)
            second.result(timeout=3)
        self.assertEqual({"epoch": 1, "automatic": True}, state)

    def test_legacy_repeating_client_permission_checks_does_not_guard_server_commit(self):
        owner_epoch, owner_enabled = 0, True
        bill_revision, request_revision = 7, 7
        for _ in range(2):
            self.assertTrue(owner_enabled and owner_epoch == 0)
        owner_epoch, owner_enabled = 1, False  # pause before the server commits
        applied = bill_revision == request_revision  # legacy server checks only snapshot state
        self.assertTrue(applied)
        self.assertFalse(owner_enabled)

    def test_transaction_bound_server_epoch_would_reject_a_cancelled_apply(self):
        request_epoch, server_epoch = 0, 1
        bill_revision, request_revision = 7, 7
        applied = request_epoch == server_epoch and bill_revision == request_revision
        self.assertFalse(applied)

    def test_worker_uses_a_monitor_bound_epoch_check_before_writing_settings(self):
        source = QUEUE.read_text()
        boundary = (QUEUE.parent / "OwnerQueuePermissions.kt").read_text()
        self.assertRegex(
            boundary,
            r"@Synchronized\s+fun disableAutomaticIfCurrent\(expected: Stamp\): DisableResult \{\s*"
            r"if \(stamp\(\) != expected\) return DisableResult.STALE",
        )
        self.assertIn('commit(prefs.edit().putBoolean("automatic", false))', boundary)
        self.assertIn('data class Stamp(val epoch: Long, val automaticGrant: Long)', boundary)
        worker = source.split("class OwnerCategoryWorker", 1)[1]
        self.assertIn("OwnerCategoryQueue.disableAutomaticIfCurrent(context, grant)", worker)
        self.assertNotIn('prefs.edit().putBoolean("automatic", false)', worker)



if __name__ == "__main__":
    unittest.main()
