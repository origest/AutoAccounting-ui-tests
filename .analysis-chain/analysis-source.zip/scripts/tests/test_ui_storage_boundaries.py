"""Dependency-free source guards, not Android compilation or runtime tests."""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[2]
JAVA = ROOT / "app/src/main/java/net/ankio/auto"


class UiStorageBoundaryTest(unittest.TestCase):
    def test_encoding_precedes_the_locked_permission_and_capacity_recheck(self):
        source = (JAVA / "capture/PaymentCaptureStore.kt").read_text()
        save = source.split("fun save(", 1)[1].split("@Synchronized fun delete", 1)[0]
        lock = save.rindex("synchronized(PaymentCaptureStore::class.java)")
        self.assertLess(save.index("check(encode(bitmap, it))"), lock)
        commit = save[lock:]
        self.assertLess(commit.index("check(permitted())"), commit.index("temp.renameTo(target)"))
        self.assertIn("existing.size < 100", commit)
        self.assertIn("temp.length() + existing.sumOf { it.length() } <= 128L * 1024 * 1024", commit)
        self.assertIn("finally { temp.delete() }", save)

    def test_temporary_file_creation_is_gated_by_the_same_lock_as_clear(self):
        source = (JAVA / "capture/PaymentCaptureStore.kt").read_text()
        save = source.split("fun save(", 1)[1].split("@Synchronized fun delete", 1)[0]
        self.assertRegex(
            save,
            r"val output = synchronized\(PaymentCaptureStore::class.java\) \{\s*"
            r"check\(permitted\(\)\) \{ \"CANCELLED\" \}\s*temp\.outputStream\(\)\s*\}",
        )
        self.assertIn("output.use { check(encode(bitmap, it)) }", save)

    def test_controller_does_not_wrap_encoding_in_the_permission_lock(self):
        source = (JAVA / "capture/PaymentCaptureController.kt").read_text()
        write = source.split("io.execute {", 1)[1]
        self.assertLess(write.index("store.save(bitmap)"), write.index("synchronized(PaymentCaptureStore::class.java)"))
        self.assertRegex(write, r"store\.save\(bitmap\) \{\s*alive && ticket == serial && prefs\.getBoolean\(\"enabled\", false\) && prefs\.getLong\(\"epoch\", 0\) == epoch")


if __name__ == "__main__":
    unittest.main()
