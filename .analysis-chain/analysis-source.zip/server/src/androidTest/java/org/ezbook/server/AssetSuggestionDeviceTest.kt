package org.ezbook.server

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.ezbook.server.constant.AssetsType
import org.ezbook.server.constant.BillType
import org.ezbook.server.constant.Currency
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.AssetsModel
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookNameModel
import org.ezbook.server.server.*
import org.junit.Assert.*
import org.junit.Test

class AssetSuggestionDeviceTest {
    // RoomDatabase has close(), but does not implement Closeable on this Room version.
    private inline fun <T> AppDatabase.use(block: (AppDatabase) -> T): T =
        try { block(this) } finally { close() }
    private fun db() = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getInstrumentation().targetContext, AppDatabase::class.java).build()
    private suspend fun fixture(db: AppDatabase): BillInfoModel {
        db.bookNameDao().insertOrReplace(BookNameModel().apply { name = "Synthetic"; remoteId = "synthetic" })
        return BillInfoModel(type = BillType.Expend, bookName = "Synthetic").apply { id = db.billInfoDao().insert(this) }
    }
    private fun request(bill: BillInfoModel) = AssetSuggestionPreviewRequest(bill.id, bill.hash(), "WECHAT_BALANCE", "CNY")

    @Test fun previewAndDeclineDoNotCreateAndConfirmationIsOneUse() = runBlocking {
        db().use { db ->
            val service = AssetSuggestionService(); val bill = fixture(db)
            val preview = service.preview(db, request(bill))!!
            assertEquals(0, db.assetsDao().count())
            assertNull(service.confirm(db, AssetSuggestionConfirmation(preview.token, false, null)))
            assertNull(service.confirm(db, AssetSuggestionConfirmation(preview.token, true, null)))
            val next = service.preview(db, request(bill))!!
            val result = service.confirm(db, AssetSuggestionConfirmation(next.token, true, null))!!
            assertEquals("微信零钱", result.bill.accountNameFrom)
            assertFalse(result.bill.auto)
            assertEquals(1, db.assetsDao().count())
            val asset = db.assetsDao().load().single()
            assertEquals("", asset.extras); assertEquals("", asset.icon); assertEquals(Currency.CNY, asset.currency)
            assertNull(service.confirm(db, AssetSuggestionConfirmation(next.token, true, null)))
            assertEquals(1, db.assetsDao().count())
        }
    }
    @Test fun existingAliasRequiresExplicitIdAndDoesNotCreateDuplicate() = runBlocking {
        db().use { db ->
            val service = AssetSuggestionService(); val bill = fixture(db)
            val asset = AssetsModel().apply { name = "微信余额"; extras = "synthetic-do-not-send" }
            asset.id = db.assetsDao().insert(asset)
            val preview = service.preview(db, request(bill))!!
            assertEquals(asset.id, preview.existingId)
            assertNull(service.confirm(db, AssetSuggestionConfirmation(preview.token, true, null)))
            val next = service.preview(db, request(bill))!!
            assertEquals("微信余额", service.confirm(db, AssetSuggestionConfirmation(next.token, true, asset.id))!!.bill.accountNameFrom)
            assertEquals(1, db.assetsDao().count())
            assertEquals("synthetic-do-not-send", db.assetsDao().load().single().extras)
        }
    }
    @Test fun duplicateCreatedAfterReviewRequiresFreshReview() = runBlocking {
        db().use { db ->
            val service = AssetSuggestionService(); val bill = fixture(db)
            val a = service.preview(db, request(bill))!!; val b = service.preview(db, request(bill))!!
            assertNotNull(service.confirm(db, AssetSuggestionConfirmation(a.token, true, null)))
            assertNull(service.confirm(db, AssetSuggestionConfirmation(b.token, true, null)))
            assertEquals(1, db.assetsDao().count())
        }
    }
    @Test fun changedBookOrAccountAndExpiredPreviewCannotWrite() = runBlocking {
        db().use { db ->
            var time = 0L; val service = AssetSuggestionService { time }; val bill = fixture(db)
            val expired = service.preview(db, request(bill))!!
            time = 300_000
            assertNull(service.confirm(db, AssetSuggestionConfirmation(expired.token, true, null)))
            val edited = service.preview(db, request(bill))!!
            bill.accountNameFrom = "Manual asset"; db.billInfoDao().update(bill)
            assertNull(service.confirm(db, AssetSuggestionConfirmation(edited.token, true, null)))
            val moved = service.preview(db, request(bill))!!
            bill.bookName = "Another"; db.billInfoDao().update(bill)
            assertNull(service.confirm(db, AssetSuggestionConfirmation(moved.token, true, null)))
            assertEquals(0, db.assetsDao().count())
        }
    }
    @Test fun invalidKindCurrencyAndAmbiguousDuplicatesFailClosed() = runBlocking {
        db().use { db ->
            val service = AssetSuggestionService(); val bill = fixture(db)
            assertNull(service.preview(db, request(bill).copy(kind = "BORROWER")))
            assertNull(service.preview(db, request(bill).copy(currency = "INVALID")))
            db.assetsDao().insert(AssetsModel().apply { name = "微信零钱"; type = AssetsType.CREDIT })
            assertNull(service.preview(db, request(bill)))
            db.assetsDao().clear()
            db.assetsDao().insert(AssetsModel().apply { name = "微信零钱"; currency = Currency.USD })
            assertNull(service.preview(db, request(bill)))
            db.assetsDao().clear()
            repeat(2) { db.assetsDao().insert(AssetsModel().apply { name = "微信零钱" }) }
            assertNull(service.preview(db, request(bill)))
            assertEquals(2, db.assetsDao().count())
        }
    }
    @Test fun anotherDatabaseCannotConsumeAProposalToWrite() = runBlocking {
        db().use { first -> db().use { second ->
            val service = AssetSuggestionService(); val a = fixture(first); fixture(second)
            val preview = service.preview(first, request(a))!!
            assertNull(service.confirm(second, AssetSuggestionConfirmation(preview.token, true, null)))
            assertEquals(0, first.assetsDao().count()); assertEquals(0, second.assetsDao().count())
        } }
    }
    @Test fun manualExistingSelectionUsesStableIdAndDoesNotCreate() = runBlocking {
        db().use { db ->
            val service = AssetSuggestionService(); val bill = fixture(db)
            val asset = AssetsModel().apply { name = "Synthetic asset"; type = AssetsType.CREDIT; currency = Currency.USD }
            asset.id = db.assetsDao().insert(asset)
            val preview = service.preview(db, AssetSuggestionPreviewRequest(bill.id, bill.hash(), "", "", 0, asset.id))!!
            assertEquals(asset.id, preview.existingId)
            val applied = service.confirm(db, AssetSuggestionConfirmation(preview.token, true, asset.id))!!
            assertEquals(asset.id, applied.assetId)
            assertEquals(asset.name, applied.bill.accountNameFrom)
            assertEquals(1, db.assetsDao().count())
        }
    }
    @Test fun revisionChangeInvalidatesTicketAndResponseIdentifiesCreatedAsset() = runBlocking {
        db().use { db ->
            val service = AssetSuggestionService(); val bill = fixture(db)
            val old = service.preview(db, request(bill))!!
            bill.categoryRevision++; db.billInfoDao().update(bill)
            assertNull(service.confirm(db, AssetSuggestionConfirmation(old.token, true, null)))
            assertEquals(0, db.assetsDao().count())
            val next = service.preview(db, request(bill).copy(revision = bill.categoryRevision))!!
            val applied = service.confirm(db, AssetSuggestionConfirmation(next.token, true, null))!!
            assertEquals(db.assetsDao().load().single().id, applied.assetId)
        }
    }

}
