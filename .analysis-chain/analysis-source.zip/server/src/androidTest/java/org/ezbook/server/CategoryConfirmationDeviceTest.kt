package org.ezbook.server

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookNameModel
import org.ezbook.server.server.CategorySuggestionConfirmation
import org.ezbook.server.server.confirmCategorySuggestion
import org.junit.Assert.*
import org.junit.Test

class CategoryConfirmationDeviceTest {
    @Test fun pendingSuggestionRequiresConsentAndCannotBeConfirmedTwice() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
        try {
            db.bookNameDao().insertOrReplace(BookNameModel().apply { name = "Synthetic"; remoteId = "fixture-book" })
            val bill = BillInfoModel(type = org.ezbook.server.constant.BillType.Expend, bookName = "Synthetic", pendingCategory = "宠物")
            bill.id = db.billInfoDao().insert(bill)
            assertEquals(0, db.categoryDao().loadByBookAndType("fixture-book", "Expend").size)
            val request = CategorySuggestionConfirmation(bill.id, "Synthetic", bill.type.name, "宠物", true, bill.categoryRevision)
            assertNull(confirmCategorySuggestion(db, request.copy(book = "Wrong")))
            assertEquals("宠物", db.billInfoDao().queryId(bill.id)!!.pendingCategory)
            assertNotNull(confirmCategorySuggestion(db, request))
            assertEquals("", db.billInfoDao().queryId(bill.id)!!.pendingCategory)
            assertNull(confirmCategorySuggestion(db, request))
            assertEquals(1, db.categoryDao().loadByBookAndType("fixture-book", "Expend").size)
        } finally { db.close() }
    }
    @Test fun migration21To22PreservesRowsAndAddsPendingDefaultAndIndexes() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "synthetic-migration-${java.util.UUID.randomUUID()}.db"
        fun helper(version: Int) = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
            androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context).name(name)
                .callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(version) {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        db.execSQL("CREATE TABLE BillInfoModel (id INTEGER PRIMARY KEY, bookName TEXT NOT NULL, type TEXT NOT NULL, shopName TEXT NOT NULL, shopItem TEXT NOT NULL, time INTEGER NOT NULL)")
                        db.execSQL("INSERT INTO BillInfoModel VALUES (1, 'Synthetic', 'Expend', 'Synthetic shop', 'Synthetic item', 0)")
                    }
                    override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                        org.ezbook.server.db.MIGRATION_21_22.migrate(db)
                    }
                }).build())
        try {
            helper(21).use { it.writableDatabase }
            helper(22).use { h ->
                val db = h.writableDatabase
                db.query("SELECT bookName, pendingCategory FROM BillInfoModel WHERE id=1").use { c ->
                    assertTrue(c.moveToFirst()); assertEquals("Synthetic", c.getString(0)); assertEquals("", c.getString(1))
                }
                db.query("SELECT count(*) FROM sqlite_master WHERE type='index' AND name LIKE 'index_BillInfoModel_bookName_type_%'").use { c ->
                    assertTrue(c.moveToFirst()); assertEquals(2, c.getInt(0))
                }
            }
        } finally { context.deleteDatabase(name) }
    }
    @Test fun cancellationPreservesPendingAndDoesNotCreateCategory() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
        try {
            val bill = BillInfoModel(type = org.ezbook.server.constant.BillType.Expend, bookName = "Synthetic", pendingCategory = "宠物")
            bill.id = db.billInfoDao().insert(bill)
            assertNull(confirmCategorySuggestion(db, CategorySuggestionConfirmation(bill.id, "Synthetic", bill.type.name, "宠物", false, bill.categoryRevision)))
            assertEquals("宠物", db.billInfoDao().queryId(bill.id)!!.pendingCategory)
            assertTrue(db.categoryDao().loadByBookAndType("fixture-book", "Expend").isEmpty())
        } finally { db.close() }
    }
}
