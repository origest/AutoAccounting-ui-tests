package org.ezbook.server

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookNameModel
import org.ezbook.server.server.CategorySuggestionConfirmation
import org.ezbook.server.server.confirmCategorySuggestion
import org.junit.Assert.*
import org.junit.Test

class CategoryExistingChoiceDeviceTest {
    @Test fun explicitExistingChoiceClearsPendingOnlyAtMatchingRevisionAndNeverCreates() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
        try {
            db.bookNameDao().insertOrReplace(BookNameModel().apply { name = "Synthetic"; remoteId = "fixture-book" })
            db.categoryDao().insert(org.ezbook.server.db.model.CategoryModel().apply {
                name = "餐饮"; remoteId = "fixture-food"; remoteParentId = "-1"; remoteBookId = "fixture-book"
                type = org.ezbook.server.constant.BillType.Expend
            })
            val bill = BillInfoModel(type = org.ezbook.server.constant.BillType.Expend, bookName = "Synthetic", pendingCategory = "宠物")
            bill.id = db.billInfoDao().insert(bill)
            val request = CategorySuggestionConfirmation(bill.id, "Synthetic", bill.type.name, "宠物", false, bill.categoryRevision, "餐饮")
            assertNull(confirmCategorySuggestion(db, request.copy(revision = bill.categoryRevision + 1)))
            assertNull(confirmCategorySuggestion(db, request.copy(existingPath = "不存在")))
            assertNull(confirmCategorySuggestion(db, request.copy(book = "Wrong")))
            assertEquals("宠物", db.billInfoDao().queryId(bill.id)!!.pendingCategory)
            val changed = requireNotNull(confirmCategorySuggestion(db, request))
            assertEquals("餐饮", changed.cateName)
            assertEquals("", changed.pendingCategory)
            assertEquals(bill.categoryRevision + 1, changed.categoryRevision)
            assertNull(confirmCategorySuggestion(db, request))
            assertEquals(1, db.categoryDao().loadByBookAndType("fixture-book", "Expend").size)
        } finally { db.close() }
    }
}
