package org.ezbook.server

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.ezbook.server.constant.BillState
import org.ezbook.server.constant.BillType
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookNameModel
import org.ezbook.server.db.model.CategoryModel
import org.ezbook.server.server.*
import org.junit.Assert.*
import org.junit.Test

class ManualCategoryDeviceTest {
    private suspend fun fixture(block: suspend (AppDatabase, BillInfoModel) -> Unit) {
        val db = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getInstrumentation().targetContext, AppDatabase::class.java).build()
        try {
            db.bookNameDao().insertOrReplace(BookNameModel().apply { name = "Synthetic"; remoteId = "synthetic" })
            db.categoryDao().insert(CategoryModel().apply { name = "餐饮"; remoteId = "food"; remoteParentId = "-1"; remoteBookId = "synthetic"; type = BillType.Expend })
            val bill = BillInfoModel(type = BillType.Expend, bookName = "Synthetic", cateName = "手选", categoryOrigin = "MANUAL", auto = true)
            bill.id = db.billInfoDao().insert(bill)
            block(db, bill)
        } finally { db.close() }
    }
    private suspend fun request(db: AppDatabase, bill: BillInfoModel, proposed: Boolean = false): ManualCategoryApply {
        val input = ownerQueueInput(bill.id, db)!!
        return ManualCategoryApply(input.source, bill.id, bill.categoryRevision, bill.hash(),
            if (proposed) """{"existing":"","proposed":"宠物"}""" else """{"existing":"餐饮","proposed":""}""",
            if (proposed) "宠物" else "餐饮", proposed)
    }
    @Test fun explicitConfirmationAppliesOncePreservingOtherFields() = runBlocking { fixture { db, bill ->
        val request = request(db, bill)
        assertTrue(applyManualCategory(request, db))
        assertFalse(applyManualCategory(request, db))
        val saved = db.billInfoDao().queryId(bill.id)!!
        assertEquals("餐饮", saved.cateName)
        assertEquals("MANUAL", saved.categoryOrigin)
        assertFalse(saved.auto)
        assertEquals(bill.copy(cateName = "餐饮", auto = false, categoryRevision = 1), saved)
    } }
    @Test fun staleManualEditAndWrongSourceCannotCreateNewCategory() = runBlocking { fixture { db, bill ->
        val request = request(db, bill, true)
        assertFalse(applyManualCategory(request.copy(source = "wrong"), db))
        bill.cateName = "更新后的手选"
        db.billInfoDao().update(bill)
        assertFalse(applyManualCategory(request, db))
        assertEquals(1, db.categoryDao().loadByBookAndType("synthetic", "Expend").size)
        assertEquals("更新后的手选", db.billInfoDao().queryId(bill.id)!!.cateName)
    } }
    @Test fun confirmedNewCategoryCreatedOnlyOnceAndReused() = runBlocking { fixture { db, bill ->
        val firstRequest = request(db, bill, true)
        assertTrue(applyManualCategory(firstRequest, db))
        assertFalse(applyManualCategory(firstRequest, db))
        val second = BillInfoModel(type = BillType.Expend, bookName = "Synthetic", cateName = "其他")
        second.id = db.billInfoDao().insert(second)
        assertTrue(applyManualCategory(request(db, second, true), db))
        assertEquals(2, db.categoryDao().loadByBookAndType("synthetic", "Expend").size)
    } }
    @Test fun proposedNameBeyondInferenceLimitReusesExistingCategory() = runBlocking { fixture { db, bill ->
        repeat(500) { index ->
            db.categoryDao().insert(CategoryModel().apply {
                name = "Fixture $index"; remoteId = "fixture-$index"; remoteParentId = "-1"
                remoteBookId = "synthetic"; type = BillType.Expend
            })
        }
        db.categoryDao().insert(CategoryModel().apply {
            name = "宠物"; remoteId = "existing-pet"; remoteParentId = "-1"
            remoteBookId = "synthetic"; type = BillType.Expend
        })
        assertEquals(500, ownerQueueInput(bill.id, db)!!.categories.size)
        assertTrue(applyManualCategory(request(db, bill, true), db))
        assertEquals(502, db.categoryDao().loadByBookAndType("synthetic", "Expend").size)
        assertEquals("宠物", db.billInfoDao().queryId(bill.id)!!.cateName)
    } }
    @Test fun changedCanonicalPathCannotReplaceConfirmedTopLevelSuggestion() = runBlocking { fixture { db, bill ->
        val request = request(db, bill, true)
        db.categoryDao().insert(CategoryModel().apply {
            name = "生活"; remoteId = "life"; remoteParentId = "-1"
            remoteBookId = "synthetic"; type = BillType.Expend
        })
        db.categoryDao().insert(CategoryModel().apply {
            name = "宠物"; remoteId = "pet"; remoteParentId = "life"
            remoteBookId = "synthetic"; type = BillType.Expend
        })
        assertFalse(applyManualCategory(request, db))
        assertEquals("手选", db.billInfoDao().queryId(bill.id)!!.cateName)
    } }
    @Test fun existingSelectionNeverCreatesWithoutCreationConsent() = runBlocking { fixture { db, bill ->
        val request = request(db, bill, true).copy(allowCreate = false)
        assertFalse(applyManualCategory(request, db))
        assertEquals(1, db.categoryDao().loadByBookAndType("synthetic", "Expend").size)
    } }
    @Test fun syncedGroupedPendingDeletedAndMalformedRequestsCannotWrite() = runBlocking { fixture { db, bill ->
        for (changed in listOf(bill.copy(state = BillState.Synced), bill.copy(groupId = 100), bill.copy(pendingCategory = "宠物"))) {
            val latest = db.billInfoDao().queryId(bill.id)!!
            val next = changed.copy(categoryRevision = latest.categoryRevision)
            db.billInfoDao().update(next)
            assertFalse(applyManualCategory(request(db, next), db))
        }
        val latest = db.billInfoDao().queryId(bill.id)!!
        val ordinary = latest.copy(pendingCategory = "", groupId = -1, state = BillState.Wait2Edit)
        db.billInfoDao().update(ordinary)
        val request = request(db, ordinary)
        assertFalse(applyManualCategory(request.copy(response = """{"existing":"unknown","proposed":""}"""), db))
        db.billInfoDao().deleteId(bill.id)
        assertFalse(applyManualCategory(request, db))
    } }
    private suspend fun editRequest(db: AppDatabase, bill: BillInfoModel): ManualBillEdit {
        val input = ownerQueueInput(bill.id, db)!!
        return ManualBillEdit(ManualBillEditTarget(input.source, bill.id, bill.categoryRevision, bill.hash()),
            bill.copy(cateName = "餐饮", state = BillState.Edited))
    }
    @Test fun ordinaryEditorSaveIsOriginBoundAndOneUse() = runBlocking { fixture { db, bill ->
        val request = editRequest(db, bill)
        assertFalse(applyManualBillEdit(request.copy(target = request.target.copy(source = "other-source")), db))
        assertTrue(applyManualBillEdit(request, db))
        assertFalse(applyManualBillEdit(request, db))
        assertFalse(db.billInfoDao().queryId(bill.id)!!.auto)
    } }
    @Test fun ordinaryEditorNeverReinsertsDeletedBill() = runBlocking { fixture { db, bill ->
        val request = editRequest(db, bill)
        db.billInfoDao().deleteId(bill.id)
        assertFalse(applyManualBillEdit(request, db))
        assertNull(db.billInfoDao().queryId(bill.id))
    } }
    @Test fun ordinaryEditorRejectsChangedSnapshotAndRetargeting() = runBlocking { fixture { db, bill ->
        val request = editRequest(db, bill)
        assertFalse(applyManualBillEdit(request.copy(target = request.target.copy(original = "different")), db))
        assertFalse(applyManualBillEdit(request.copy(bill = request.bill.copy(id = bill.id + 1)), db))
        bill.money += 1
        db.billInfoDao().update(bill)
        assertFalse(applyManualBillEdit(request, db))
    } }
    @Test fun ordinaryEditorCannotSaveSyncedOrPendingBill() = runBlocking { fixture { db, bill ->
        bill.state = BillState.Synced
        db.billInfoDao().update(bill)
        var fresh = db.billInfoDao().queryId(bill.id)!!
        assertFalse(applyManualBillEdit(editRequest(db, fresh), db))
        fresh.state = BillState.Wait2Edit; fresh.pendingCategory = "宠物"
        db.billInfoDao().update(fresh)
        fresh = db.billInfoDao().queryId(bill.id)!!
        assertFalse(applyManualBillEdit(editRequest(db, fresh), db))
    } }

}
