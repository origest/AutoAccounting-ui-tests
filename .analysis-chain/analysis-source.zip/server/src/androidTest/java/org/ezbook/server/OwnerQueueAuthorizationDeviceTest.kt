package org.ezbook.server

import androidx.room.Room
import androidx.room.withTransaction
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.*
import org.ezbook.server.constant.BillType
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookNameModel
import org.ezbook.server.server.*
import org.junit.Assert.*
import org.junit.Test

/** Synthetic rows only. These tests execute the actual Room transaction, not a state model. */
class OwnerQueueAuthorizationDeviceTest {
    private fun database() = Room.inMemoryDatabaseBuilder(
        InstrumentationRegistry.getInstrumentation().targetContext, AppDatabase::class.java).build()

    private suspend fun request(db: AppDatabase): OwnerQueueApply {
        db.bookNameDao().insertOrReplace(BookNameModel().apply { name = "Fence fixture"; remoteId = "fence" })
        val bill = BillInfoModel(type = BillType.Expend, bookName = "Fence fixture", cateName = "其他", categoryOrigin = "RULE")
        bill.id = db.billInfoDao().insert(bill)
        val input = ownerQueueInput(bill.id, db)!!
        return OwnerQueueApply(input.source, bill.id, bill.categoryRevision, bill.hash(),
            """{"existing":"","proposed":"宠物"}""", false)
    }

    @Test fun absentAndWrongGenerationDenyEvenLegacyApply() = runBlocking {
        val db = database()
        try {
            val request = request(db)
            assertFalse(ownerQueueAuthorization(db).enabled)
            assertFalse(applyOwnerQueue(request.copy(allowLegacy = true), db))
            val grant = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(request.source, 0, true, "grant"), db)
            assertTrue(grant.accepted)
            assertFalse(applyOwnerQueue(request.copy(allowLegacy = true), db))
            assertFalse(applyOwnerQueue(request.copy(authorizationGeneration = 0), db))
            assertTrue(applyOwnerQueue(request.copy(authorizationGeneration = grant.state.revision), db))
        } finally { db.close() }
    }

    @Test fun acknowledgedRevokeRejectsStaleApplyWithoutMutatingBill() = runBlocking {
        val db = database()
        try {
            val request = request(db)
            val grant = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(request.source, 0, true, "grant"), db)
            val revoke = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(request.source, grant.state.revision, false, "revoke"), db)
            assertTrue(revoke.accepted)
            assertFalse(applyOwnerQueue(request.copy(authorizationGeneration = grant.state.revision), db))
            assertEquals("RULE", db.billInfoDao().queryId(request.id)!!.categoryOrigin)
            assertEquals("", db.billInfoDao().queryId(request.id)!!.pendingCategory)
        } finally { db.close() }
    }

    @Test fun applyTransactionMustFinishBeforeRevokeAcknowledgement() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "fence-serialization-${java.util.UUID.randomUUID()}.db"
        val db = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        // A separate Room instance/executor proves this is a SQLite commit fence,
        // not merely a shared coroutine mutex or one Room transaction executor.
        val revokerDb = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        val release = CompletableDeferred<Unit>()
        try {
            val request = request(db)
            val grant = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(request.source, 0, true, "grant"), db)
            assertEquals(grant.state, ownerQueueAuthorization(revokerDb))
            val inside = CompletableDeferred<Unit>()
            val apply = async(Dispatchers.IO) {
                db.withTransaction {
                    assertTrue(applyOwnerQueue(request.copy(authorizationGeneration = grant.state.revision), db))
                    inside.complete(Unit)
                    release.await() // The outer real transaction has not committed yet.
                }
            }
            withTimeout(5000) { inside.await() }
            val attempted = CompletableDeferred<Unit>()
            val revoke = async(Dispatchers.IO) {
                attempted.complete(Unit)
                changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(request.source, grant.state.revision, false, "revoke"), revokerDb)
            }
            attempted.await()
            assertNull(withTimeoutOrNull(200) { revoke.await() })
            release.complete(Unit)
            withTimeout(5000) { apply.await(); assertTrue(revoke.await().accepted) }
            assertEquals("AI", db.billInfoDao().queryId(request.id)!!.categoryOrigin)
            assertFalse(applyOwnerQueue(request.copy(authorizationGeneration = grant.state.revision), db))
        } finally { release.complete(Unit); revokerDb.close(); db.close(); context.deleteDatabase(name) }
    }

    @Test fun reorderedGrantCannotResurrectDisabledState() = runBlocking {
        val db = database()
        try {
            val source = ownerQueueAuthorization(db).source
            val delayed = OwnerQueueAuthorizationChange(source, 0, true, "delayed-grant")
            val revoke = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(source, 0, false, "revoke-first"), db)
            assertTrue(revoke.accepted)
            assertEquals(1L, revoke.state.revision)
            assertFalse(changeOwnerQueueAuthorization(delayed, db).accepted)
            assertFalse(ownerQueueAuthorization(db).enabled)
        } finally { db.close() }
    }

    @Test fun lostResponseReconciliationAndExactRetryDoNotAdvanceGeneration() = runBlocking {
        val db = database()
        try {
            val source = ownerQueueAuthorization(db).source
            val grant = OwnerQueueAuthorizationChange(source, 0, true, "same-operation")
            changeOwnerQueueAuthorization(grant, db) // Deliberately discard acknowledgement.
            val recovered = ownerQueueAuthorization(db)
            assertEquals(grant.operationId, recovered.operationId)
            assertTrue(recovered.enabled)
            assertEquals(1L, recovered.revision)
            assertEquals(recovered, changeOwnerQueueAuthorization(grant, db).state)
            assertTrue(changeOwnerQueueAuthorization(grant, db).accepted)
            assertFalse(changeOwnerQueueAuthorization(grant.copy(enabled = false), db).accepted)
            assertFalse(changeOwnerQueueAuthorization(grant.copy(expectedRevision = 1), db).accepted)
            val revoke = OwnerQueueAuthorizationChange(source, 1, false, "revoke")
            assertTrue(changeOwnerQueueAuthorization(revoke, db).accepted)
            assertTrue(changeOwnerQueueAuthorization(revoke, db).accepted)
            assertFalse(changeOwnerQueueAuthorization(grant, db).accepted)
            assertEquals(2L, ownerQueueAuthorization(db).revision)
        } finally { db.close() }
    }

    @Test fun failedTransactionNeverReturnsSuccessOrPersistsAuthorization() = runBlocking {
        val db = database()
        try {
            val state = ownerQueueAuthorization(db)
            db.openHelper.writableDatabase.execSQL("CREATE TRIGGER fail_fence BEFORE INSERT ON SettingModel WHEN NEW.`key` LIKE 'owner_queue_authorization:%' BEGIN SELECT RAISE(ABORT, 'synthetic failure'); END")
            var acknowledged = false
            try {
                acknowledged = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(state.source, 0, true, "fail"), db).accepted
                fail("Transaction must throw")
            } catch (_: android.database.sqlite.SQLiteException) { }
            assertFalse(acknowledged)
            assertEquals(state, ownerQueueAuthorization(db))

            // Once the row exists, revoke uses SettingDao.update rather than insert.
            db.openHelper.writableDatabase.execSQL("DROP TRIGGER fail_fence")
            val grant = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(state.source, 0, true, "grant-before-failure"), db)
            assertTrue(grant.accepted)
            assertTrue(grant.state.enabled)
            db.openHelper.writableDatabase.execSQL("CREATE TRIGGER fail_revoke BEFORE UPDATE ON SettingModel WHEN NEW.`key` LIKE 'owner_queue_authorization:%' BEGIN SELECT RAISE(ABORT, 'synthetic revoke failure'); END")
            val revoke = OwnerQueueAuthorizationChange(state.source, grant.state.revision, false, "retry-revoke")
            acknowledged = false
            try {
                acknowledged = changeOwnerQueueAuthorization(revoke, db).accepted
                fail("Failed revoke transaction must throw")
            } catch (_: android.database.sqlite.SQLiteException) { }
            assertFalse(acknowledged)
            assertEquals(grant.state, ownerQueueAuthorization(db))
            db.openHelper.writableDatabase.execSQL("DROP TRIGGER fail_revoke")
            val retried = changeOwnerQueueAuthorization(revoke, db)
            assertTrue(retried.accepted)
            assertFalse(retried.state.enabled)
            assertEquals(grant.state.revision + 1, retried.state.revision)
            assertEquals(revoke.operationId, retried.state.operationId)
            assertEquals(retried.state, ownerQueueAuthorization(db))
        } finally { db.close() }
    }

    @Test fun revokeSurvivesDatabaseCloseAndReopen() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "fence-${java.util.UUID.randomUUID()}.db"
        fun open() = Room.databaseBuilder(context, AppDatabase::class.java, name).build()
        var db = open()
        try {
            val state = ownerQueueAuthorization(db)
            val grant = OwnerQueueAuthorizationChange(state.source, 0, true, "grant")
            assertTrue(changeOwnerQueueAuthorization(grant, db).accepted)
            val revoke = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(state.source, 1, false, "revoke"), db)
            assertTrue(revoke.accepted)
            db.close()
            db = open()
            assertEquals(revoke.state, ownerQueueAuthorization(db))
            assertFalse(changeOwnerQueueAuthorization(grant, db).accepted)
        } finally { db.close(); context.deleteDatabase(name) }
    }

    @Test fun corruptedStateAndOverflowCannotResetFence() = runBlocking {
        val db = database()
        try {
            val state = ownerQueueAuthorization(db)
            val key = "owner_queue_authorization:${state.source}"
            db.settingDao().set(key, "corrupt")
            try { ownerQueueAuthorization(db); fail("Corrupt state must fail closed") }
            catch (_: IllegalStateException) { }
            db.settingDao().set(key, "${Long.MAX_VALUE}\t0\tlast")
            assertFalse(changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(state.source, Long.MAX_VALUE, true, "overflow"), db).accepted)
            assertFalse(ownerQueueAuthorization(db).enabled)
            assertEquals(Long.MAX_VALUE, ownerQueueAuthorization(db).revision)
        } finally { db.close() }
    }
}
