package org.ezbook.server

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.ktor.application.install
import io.ktor.features.ContentNegotiation
import io.ktor.gson.gson
import io.ktor.routing.routing
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import kotlinx.coroutines.runBlocking
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.server.*
import org.junit.Assert.*
import org.junit.Test
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/** Real loopback HTTP and real Room. All data is synthetic; no provider is contacted. */
class OwnerQueueAuthorizationHttpDeviceTest {
    private val gson = Gson()

    // Raw sockets deliberately avoid dependence on the app's cleartext HTTP client policy.
    private fun http(port: Int, method: String, body: String? = null, timeout: Int = 5000): String =
        Socket("127.0.0.1", port).use { socket ->
            socket.soTimeout = timeout
            val bytes = body.orEmpty().toByteArray(Charsets.UTF_8)
            val headers = "$method /ownerQueue/authorization HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\nContent-Type: application/json\r\nContent-Length: ${bytes.size}\r\n\r\n"
            socket.getOutputStream().apply { write(headers.toByteArray(Charsets.US_ASCII)); write(bytes); flush() }
            socket.getInputStream().readBytes().toString(Charsets.UTF_8)
        }

    private fun data(response: String): JsonObject {
        assertTrue(response.substringBefore("\r\n"), response.startsWith("HTTP/1.1 200"))
        val split = response.indexOf("\r\n\r\n")
        check(split >= 0)
        var body = response.substring(split + 4)
        // Ktor may choose chunked transport rather than Content-Length.
        if (response.substring(0, split).contains("transfer-encoding: chunked", ignoreCase = true)) {
            val decoded = StringBuilder()
            while (true) {
                val end = body.indexOf("\r\n")
                val size = body.substring(0, end).substringBefore(';').toInt(16)
                if (size == 0) break
                // These authorization fixtures contain ASCII only.
                decoded.append(body.substring(end + 2, end + 2 + size))
                body = body.substring(end + 2 + size + 2)
            }
            body = decoded.toString()
        }
        return JsonParser.parseString(body).asJsonObject.getAsJsonObject("data")
    }

    private fun fixture(test: (Int, AppDatabase) -> Unit) {
        val db = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getInstrumentation().targetContext, AppDatabase::class.java).build()
        val port = ServerSocket(0).use { it.localPort }
        val server = embeddedServer(Netty, host = "127.0.0.1", port = port) {
            install(ContentNegotiation) { gson() }
            routing { ownerQueueRoutes(database = { db }, notifyCommitted = {}) }
        }
        try { server.start(wait = false); test(port, db) }
        finally { server.stop(0, 5000); db.close() }
    }

    @Test fun httpDefaultDenyReorderedGrantAndIdempotentRevoke() = fixture { port, _ ->
        val initial = data(http(port, "GET"))
        assertFalse(initial["enabled"].asBoolean)
        assertEquals(0L, initial["revision"].asLong)
        val source = initial["source"].asString
        val revoke = OwnerQueueAuthorizationChange(source, 0, false, "revoke-first")
        val acknowledgement = data(http(port, "POST", gson.toJson(revoke)))
        assertTrue(acknowledgement["accepted"].asBoolean)
        val retry = data(http(port, "POST", gson.toJson(revoke)))
        assertTrue(retry["accepted"].asBoolean)
        assertEquals(1L, retry.getAsJsonObject("state")["revision"].asLong)
        val stale = data(http(port, "POST", gson.toJson(OwnerQueueAuthorizationChange(source, 0, true, "delayed"))))
        assertFalse(stale["accepted"].asBoolean)
        assertFalse(stale.getAsJsonObject("state")["enabled"].asBoolean)
        val wrongSource = data(http(port, "POST", gson.toJson(revoke.copy(source = "old-source"))))
        assertFalse(wrongSource["accepted"].asBoolean)
        assertEquals(source, wrongSource.getAsJsonObject("state")["source"].asString)
    }

    @Test fun committedRevokeWithTimedOutResponseIsReconciledWithoutReplay() = fixture { port, _ ->
        val initial = data(http(port, "GET"))
        val source = initial["source"].asString
        val grant = OwnerQueueAuthorizationChange(source, 0, true, "grant")
        assertTrue(data(http(port, "POST", gson.toJson(grant)))["accepted"].asBoolean)
        val revoke = OwnerQueueAuthorizationChange(source, 1, false, "revoke-lost-response")
        val committed = CountDownLatch(1)
        val release = CountDownLatch(1)
        val failure = AtomicReference<Throwable?>()
        ServerSocket(0).use { proxy ->
            proxy.soTimeout = 5000
            // The proxy consumes the real server response after its transaction commits, then
            // withholds it so the caller actually times out with an uncertain result.
            val worker = thread(name = "synthetic-response-loss") {
                try {
                    proxy.accept().use { client ->
                        client.soTimeout = 5000
                        val input = client.getInputStream().bufferedReader(Charsets.UTF_8)
                        var length = 0
                        while (true) {
                            val line = input.readLine() ?: error("Missing HTTP headers")
                            if (line.isEmpty()) break
                            if (line.startsWith("Content-Length:", true)) length = line.substringAfter(':').trim().toInt()
                        }
                        val body = CharArray(length)
                        var read = 0
                        while (read < length) {
                            val n = input.read(body, read, length - read)
                            check(n > 0)
                            read += n
                        }
                        val response = http(port, "POST", String(body))
                        assertTrue(data(response)["accepted"].asBoolean)
                        committed.countDown()
                        check(release.await(30, TimeUnit.SECONDS))
                        // Deliberately close without delivering the acknowledgement.
                    }
                } catch (t: Throwable) { failure.set(t); committed.countDown() }
            }
            try {
                try { http(proxy.localPort, "POST", gson.toJson(revoke), timeout = 300); fail("Expected timeout") }
                catch (_: SocketTimeoutException) { }
                assertTrue(committed.await(5, TimeUnit.SECONDS))
                failure.get()?.let { throw AssertionError("Proxy failed", it) }
                val recovered = data(http(port, "GET"))
                assertEquals(revoke.operationId, recovered["operationId"].asString)
                assertFalse(recovered["enabled"].asBoolean)
                assertEquals(2L, recovered["revision"].asLong)
                val retry = data(http(port, "POST", gson.toJson(revoke)))
                assertTrue(retry["accepted"].asBoolean)
                assertEquals(2L, retry.getAsJsonObject("state")["revision"].asLong)
                assertFalse(data(http(port, "POST", gson.toJson(grant)))["accepted"].asBoolean)
            } finally { release.countDown(); worker.join(31000) }
            assertFalse("Proxy worker must terminate", worker.isAlive)
            failure.get()?.let { throw AssertionError("Proxy failed", it) }
        }
    }

    @Test fun failedHttpTransactionDoesNotClaimSuccess() = fixture { port, db ->
        val initial = data(http(port, "GET"))
        db.openHelper.writableDatabase.execSQL("CREATE TRIGGER fail_http_fence BEFORE INSERT ON SettingModel WHEN NEW.`key` LIKE 'owner_queue_authorization:%' BEGIN SELECT RAISE(ABORT, 'synthetic failure'); END")
        val request = OwnerQueueAuthorizationChange(initial["source"].asString, 0, true, "fail")
        val response = http(port, "POST", gson.toJson(request))
        assertFalse(response.startsWith("HTTP/1.1 200"))
        assertEquals(0L, data(http(port, "GET"))["revision"].asLong)
        runBlocking { assertFalse(ownerQueueAuthorization(db).enabled) }

        db.openHelper.writableDatabase.execSQL("DROP TRIGGER fail_http_fence")
        val granted = data(http(port, "POST", gson.toJson(request)))
        assertTrue(granted["accepted"].asBoolean)
        val grantState = granted.getAsJsonObject("state")
        assertTrue(grantState["enabled"].asBoolean)
        db.openHelper.writableDatabase.execSQL("CREATE TRIGGER fail_http_revoke BEFORE UPDATE ON SettingModel WHEN NEW.`key` LIKE 'owner_queue_authorization:%' BEGIN SELECT RAISE(ABORT, 'synthetic revoke failure'); END")
        val revoke = OwnerQueueAuthorizationChange(request.source, grantState["revision"].asLong, false, "retry-revoke")
        val failedRevoke = http(port, "POST", gson.toJson(revoke))
        assertFalse(failedRevoke.startsWith("HTTP/1.1 200"))
        assertEquals(grantState, data(http(port, "GET")))
        runBlocking {
            val unchanged = ownerQueueAuthorization(db)
            assertTrue(unchanged.enabled)
            assertEquals(grantState["revision"].asLong, unchanged.revision)
            assertEquals(request.operationId, unchanged.operationId)
        }
        db.openHelper.writableDatabase.execSQL("DROP TRIGGER fail_http_revoke")
        val retried = data(http(port, "POST", gson.toJson(revoke)))
        assertTrue(retried["accepted"].asBoolean)
        val revoked = retried.getAsJsonObject("state")
        assertFalse(revoked["enabled"].asBoolean)
        assertEquals(grantState["revision"].asLong + 1, revoked["revision"].asLong)
        assertEquals(revoke.operationId, revoked["operationId"].asString)
        assertEquals(revoked, data(http(port, "GET")))
    }
}
