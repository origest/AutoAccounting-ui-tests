package org.ezbook.server

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.*
import org.ezbook.server.constant.BillType
import org.ezbook.server.server.*
import org.junit.Assert.*
import org.junit.Test

class OwnerQueueDeviceTest {
    @Test fun staleManualEditsAndReplayAreRejectedWithoutCreatingCategories() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getInstrumentation().targetContext, AppDatabase::class.java).build()
        try {
            db.bookNameDao().insertOrReplace(BookNameModel().apply { name = "Synthetic"; remoteId = "synthetic" })
            val bill = BillInfoModel(type = BillType.Expend, bookName = "Synthetic", cateName = "其他", categoryOrigin = "RULE")
            bill.id = db.billInfoDao().insert(bill)
            val snapshot = ownerQueueInput(bill.id, db)!!
            val grant = changeOwnerQueueAuthorization(OwnerQueueAuthorizationChange(snapshot.source, 0, true, "fixture-grant"), db)
            assertTrue(grant.accepted)
            val request = OwnerQueueApply(snapshot.source, bill.id, 0, bill.hash(), """{"existing":"","proposed":"宠物"}""", false, grant.state.revision)
            assertFalse(applyOwnerQueue(request.copy(source = "spoof"), db))
            assertTrue(applyOwnerQueue(request, db))
            assertFalse(applyOwnerQueue(request, db))
            assertTrue(db.categoryDao().loadByBookAndType("synthetic", "Expend").isEmpty())
            val current = db.billInfoDao().queryId(bill.id)!!
            assertEquals("宠物", current.pendingCategory)
            current.pendingCategory = ""; current.categoryOrigin = "MANUAL"; current.cateName = "手选"
            db.billInfoDao().update(current)
            assertFalse(applyOwnerQueue(request.copy(revision = current.categoryRevision, original = current.hash()), db))
            assertEquals("手选", db.billInfoDao().queryId(bill.id)!!.cateName)
            try { db.billInfoDao().update(bill); fail("Stale writer must fail") } catch (_: IllegalStateException) { }

            // New-item automation requires a distinct explicit creation decision, not inference alone.
            val createBill = BillInfoModel(type = BillType.Expend, bookName = "Synthetic", cateName = "其他", categoryOrigin = "RULE")
            createBill.id = db.billInfoDao().insert(createBill)
            val create = OwnerQueueApply(snapshot.source, createBill.id, createBill.categoryRevision, createBill.hash(),
                """{"existing":"","proposed":"宠物"}""", false, grant.state.revision, confirmedCategory = "宠物")
            assertFalse(applyOwnerQueue(create, db))
            assertTrue(applyOwnerQueue(create.copy(allowCreate = true), db))
            assertFalse(applyOwnerQueue(create.copy(allowCreate = true), db))
            assertEquals(1, db.categoryDao().loadByBookAndType("synthetic", "Expend").size)
            val created = db.billInfoDao().queryId(createBill.id)!!
            assertEquals("宠物", created.cateName)
            assertEquals("", created.pendingCategory)
            assertFalse(created.auto)

            // Default/legacy requests cannot silently apply an existing category either.
            val existingBill = BillInfoModel(type = BillType.Expend, bookName = "Synthetic", cateName = "其他", categoryOrigin = "RULE")
            existingBill.id = db.billInfoDao().insert(existingBill)
            val existing = OwnerQueueApply(snapshot.source, existingBill.id, existingBill.categoryRevision, existingBill.hash(),
                """{"existing":"宠物","proposed":""}""", false, grant.state.revision)
            assertFalse(applyOwnerQueue(existing, db))
            assertTrue(applyOwnerQueue(existing.copy(confirmedCategory = "宠物", manual = true), db))
            assertEquals("MANUAL", db.billInfoDao().queryId(existingBill.id)!!.categoryOrigin)
            assertEquals(1, db.categoryDao().loadByBookAndType("synthetic", "Expend").size)
        } finally { db.close() }
    }
    @Test fun migration22To23PreservesLegacyCategoryAndIds() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "queue-migration-${java.util.UUID.randomUUID()}.db"
        fun helper(version: Int) = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
            androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context).name(name).callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(version) {
                override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE BillInfoModel(id INTEGER PRIMARY KEY, cateName TEXT NOT NULL, groupId INTEGER NOT NULL)")
                    db.execSQL("INSERT INTO BillInfoModel VALUES(42, '其他', -1)")
                }
                override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) { org.ezbook.server.db.MIGRATION_22_23.migrate(db) }
            }).build())
        try {
            helper(22).use { it.writableDatabase }
            helper(23).use { h -> h.writableDatabase.query("SELECT id,cateName,categoryOrigin,categoryRevision FROM BillInfoModel").use {
                assertTrue(it.moveToFirst()); assertEquals(42L, it.getLong(0)); assertEquals("其他", it.getString(1)); assertEquals("LEGACY_UNKNOWN", it.getString(2)); assertEquals(0L, it.getLong(3))
            } }
        } finally { context.deleteDatabase(name) }
    }
}
