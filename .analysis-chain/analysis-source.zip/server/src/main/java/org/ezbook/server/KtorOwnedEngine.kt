package org.ezbook.server

import io.ktor.application.ApplicationStopped
import io.ktor.server.netty.NettyApplicationEngine

/** Adapter shared by production and JVM lifecycle integration tests. */
internal class KtorOwnedEngine(private val engine: NettyApplicationEngine) : OwnedEngineSlot.Engine {
    override fun start(onStopped: () -> Unit) {
        engine.environment.monitor.subscribe(ApplicationStopped) { onStopped() }
        engine.start()
    }
    override fun stop() { engine.stop(0, 1_000) }
}
