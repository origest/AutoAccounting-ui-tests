package org.ezbook.server

import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Owns only engines created by this slot. No HTTP health guesses or foreign-resource cleanup. */
internal class OwnedEngineSlot(private val factory: () -> Engine) {
    interface Engine { fun start(onStopped: () -> Unit); fun stop() }
    private val lock = ReentrantLock()
    @Volatile private var owned: Engine? = null
    private val running = AtomicReference<Engine?>()
    private val ready = AtomicReference<Engine?>()
    @Volatile var cleanupUnknown: Boolean = false
        private set
    val isRunning: Boolean get() = ready.get()?.let { it === owned && it === running.get() } == true

    fun start(): Boolean = lock.withLock {
        check(!cleanupUnknown) { "owned_cleanup_unknown" }
        if (isRunning) return true
        stopLocked()
        val candidate = factory()
        owned = candidate
        running.set(candidate)
        try {
            candidate.start { running.compareAndSet(candidate, null) }
            if (running.get() === candidate) ready.set(candidate)
            return isRunning
        } catch (error: Throwable) {
            running.compareAndSet(candidate, null)
            try { stopLocked() } catch (_: Throwable) { /* retained blocked state */ }
            throw error
        }
    }

    fun stop() = lock.withLock { stopLocked() }

    /** Upgrade will terminate the process. Never wait for an in-flight startup on its main thread. */
    fun tryStop(): Boolean {
        if (!lock.tryLock()) return false
        try { stopLocked(); return true } finally { lock.unlock() }
    }

    private fun stopLocked() {
        val old = owned ?: return
        running.compareAndSet(old, null)
        ready.compareAndSet(old, null)
        try {
            old.stop()
            owned = null
        } catch (error: Throwable) {
            cleanupUnknown = true
            throw error
        }
    }
}
