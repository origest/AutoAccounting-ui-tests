package net.ankio.auto.testing

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.http.LocalNetwork
import net.ankio.auto.http.api.BillAPI
import net.ankio.auto.service.OwnerHostForegroundService
import net.ankio.auto.service.host.OwnerHttpRuntime
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.Server
import org.ezbook.server.db.Db
import org.ezbook.server.db.model.BillInfoModel
import org.junit.Assert.*
import org.junit.Test

/** Only a newly provisioned blank emulator with our minimal synthetic baseline fixture.
 * This is NOT a real legacy APK compatibility, notification or Xposed hook test. */
class ParallelIsolationDeviceTest {
    private val i = InstrumentationRegistry.getInstrumentation()
    private val app get() = i.targetContext.applicationContext
    private data class Baseline(val ready:Int,val requests:Int,val epoch:String,val uid:Int,val pid:Int,val rows:Int,val sentinel:String)
    private fun stage(value:String) = i.sendStatus(1,Bundle().apply { putString("parallelStage",value) })
    private fun baseline():Baseline {
        val p=app.packageManager.getPackageInfo("net.ankio.auto",PackageManager.GET_META_DATA)
        check(p.versionName=="SYNTHETIC_BASELINE_ONLY_1") { "NOT_SYNTHETIC_FIXTURE" }
        check(p.applicationInfo!!.metaData.getInt("synthetic.baseline.version")==1)
        return app.contentResolver.query(Uri.parse("content://net.ankio.auto.syntheticproof/state"),null,null,null,null)!!.use {
            check(it.moveToFirst())
            val b=Baseline(it.getInt(0),it.getInt(1),it.getString(2),it.getInt(3),it.getInt(4),it.getInt(5),it.getString(6))
            check(!it.moveToNext()); b
        }
    }
    private fun waitFor(condition:()->Boolean) {
        val until=SystemClock.elapsedRealtime()+20_000
        while(!condition() && SystemClock.elapsedRealtime()<until) SystemClock.sleep(50)
        check(condition()) { "SAFE_WAIT_TIMEOUT" }
    }
    @Test fun syntheticDualPackageIsolationOnly() {
        check(InstrumentationRegistry.getArguments().getString("parallelBlankDevice")=="true")
        check(android.os.Build.HARDWARE in setOf("ranchu","goldfish"))
        check(app.packageName=="net.ankio.auto.paralleltest")
        check(Server.PORT==52145 && LocalNetwork.baseUrl=="http://127.0.0.1:52145")
        check(!app.getDatabasePath("autoAccount.db").exists())
        // Baseline must already have been launched by CI before instrumentation/app initialization.
        val old=baseline()
        check(old.ready==1 && old.requests==0 && old.rows==1 && old.sentinel=="baseline-fixed-synthetic-v1")
        check(old.uid!=app.applicationInfo.uid && old.pid!=android.os.Process.myPid())
        val oldInfo=app.packageManager.getApplicationInfo("net.ankio.auto",0)
        check(oldInfo.dataDir!=app.applicationInfo.dataDir)
        fun unchanged() { assertEquals(old,baseline()) }
        stage("TWO_DISTINCT_SYNTHETIC_UIDS")
        var activity:Activity?=null
        try {
            PrefManager.workMode=WorkMode.Xposed // Host lease mode only; APK contains no hook entrypoint.
            activity=i.startActivitySync(Intent().setClassName(app.packageName,OwnerHostFixtureActivity::class.java.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            i.runOnMainSync { OwnerHostForegroundService.reconcile(activity!!) }
            waitFor { OwnerHttpRuntime.status.value=="RUNNING" }
            unchanged(); stage("NEW_PORT_READY_OLD_PORT_ZERO")
            val id=runBlocking {
                check(Db.get().billInfoDao().highestId()==0L)
                Db.get().billInfoDao().insert(BillInfoModel(shopName="parallel-synthetic-sentinel-v1",money=1.25,time=1_700_000_000_000L))
            }
            val first=runBlocking { requireNotNull(BillAPI.get(id)) }
            assertEquals("parallel-synthetic-sentinel-v1",first.shopName)
            assertEquals(1.25,first.money,0.0)
            unchanged(); stage("NEW_SENTINEL_READ_BASELINE_UNCHANGED")
            runBlocking {
                val row=requireNotNull(Db.get().billInfoDao().queryId(id))
                row.shopName="parallel-synthetic-sentinel-v2"
                Db.get().billInfoDao().update(row)
            }
            repeat(3) {
                val row=runBlocking { requireNotNull(BillAPI.get(id)) }
                assertEquals("parallel-synthetic-sentinel-v2",row.shopName)
                assertEquals(1.25,row.money,0.0)
                unchanged()
            }
            stage("NEW_MUTATION_ISOLATED_BASELINE_UNCHANGED")
            SystemClock.sleep(2_000)
            unchanged(); stage("OLD_PORT_ZERO_FINAL")
        } finally {
            app.stopService(Intent(app,OwnerHostForegroundService::class.java))
            activity?.let { a -> i.runOnMainSync { a.finish() } }
            waitFor { OwnerHttpRuntime.status.value=="STOPPED" && !Server.isPortOccupied() }
            unchanged(); stage("NEW_HOST_STOPPED_BASELINE_UNCHANGED")
        }
    }
}
