package net.ankio.auto.classification

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.ezbook.server.models.ResultModel
import java.io.ByteArrayOutputStream
import java.net.Proxy
import java.util.concurrent.TimeUnit

/** Bounded legacy-local transport. This is NOT caller/server authentication. */
internal object OwnerQueueHttp {
    private val client = OkHttpClient.Builder().proxy(Proxy.NO_PROXY).callTimeout(10, TimeUnit.SECONDS)
        .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false).build()
    suspend fun request(path: String, body: String?): String = withContext(Dispatchers.IO) {
        require(path.startsWith("ownerQueue/"))
        val request = Request.Builder().url("http://127.0.0.1:52145/$path")
        if (body != null) request.post(body.toRequestBody("application/json".toMediaType()))
        client.newCall(request.build()).execute().use { response ->
            check(response.isSuccessful)
            val data = requireNotNull(response.body)
            require(data.contentLength() <= 512_000)
            data.byteStream().use { input ->
                val out = ByteArrayOutputStream()
                val chunk = ByteArray(4096)
                while (true) {
                    val n = input.read(chunk)
                    if (n < 0) break
                    require(out.size() + n <= 512_000)
                    out.write(chunk, 0, n)
                }
                out.toString("UTF-8")
            }
        }
    }
    suspend inline fun <reified T> get(path: String): ResultModel<T> = Gson().fromJson(request(path, null), object : TypeToken<ResultModel<T>>() {}.type)
    suspend inline fun <reified T> post(path: String, body: String): ResultModel<T> = Gson().fromJson(request(path, body), object : TypeToken<ResultModel<T>>() {}.type)
}
