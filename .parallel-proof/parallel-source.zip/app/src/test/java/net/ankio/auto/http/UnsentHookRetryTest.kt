package net.ankio.auto.http

import java.net.ServerSocket
import java.net.Socket
import java.io.Closeable
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.net.InetSocketAddress
import kotlin.concurrent.thread
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class UnsentHookRetryTest {
    private val url = "http://127.0.0.1:52145/js/analysis?type=DATA&app=test.synthetic"
    private class Receiver(private val count: AtomicInteger, private val response: String?) : Closeable {
        private val listener = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress("127.0.0.1", 52145)) }
        private val failure = AtomicReference<Throwable?>()
        private val worker = thread(isDaemon = true) {
            try {
            while (!listener.isClosed) {
                val socket = try { listener.accept() } catch (_: IOException) { break }
                socket.use { client ->
                    client.soTimeout = 5000
                    val input = client.getInputStream(); val header = StringBuilder()
                    while (!header.endsWith("\r\n\r\n") && header.length < 8192) {
                        val value = input.read(); if (value < 0) break; header.append(value.toChar())
                    }
                    // A canceled follow-up may establish TCP but send zero HTTP bytes.
                    // Count actual HTTP traffic, not accepted sockets, as POST attempts.
                    if (header.isEmpty()) return@use
                    count.incrementAndGet()
                    val length = Regex("(?i)Content-Length: (\\d+)").find(header)?.groupValues?.get(1)?.toInt() ?: 0
                    repeat(length) { check(input.read() >= 0) }
                    if (response != null) { client.getOutputStream().write(response.toByteArray()); client.getOutputStream().flush() }
                }
            }
            } catch (error: Throwable) { failure.set(error) }
        }
        override fun close() {
            listener.close(); worker.join(6000); check(!worker.isAlive)
            failure.get()?.let { throw AssertionError("synthetic_receiver_failed", it) }
        }
    }
    private fun server(count: AtomicInteger, status: Int? = 200): Receiver = Receiver(count,
        status?.let { "HTTP/1.1 $it Synthetic\r\nContent-Length: 2\r\nConnection: close\r\nRetry-After: 0\r\n\r\n{}" })

    @Test fun typedUnsentFailureHasThreeAttemptBound() = runBlocking {
        var count = 0; val waits = mutableListOf<Long>()
        try {
            retryUnsentHookRequest(pause = { waits += it }) { count++; throw UnsentHookRequest(IOException()) }
        } catch (_: UnsentHookRequest) { }
        assertEquals(3, count); assertEquals(listOf(1000L, 2000L), waits)
    }

    @Test fun ambiguousIoFailureDoesNotRetry() = runBlocking {
        var count = 0
        try { retryUnsentHookRequest { count++; throw IOException() } } catch (_: IOException) { }
        assertEquals(1, count)
    }

    @Test fun cancellationDuringBackoffStopsFurtherAttempts() = runBlocking {
        var count = 0
        val job = launch { retryUnsentHookRequest(pause = { delay(10000) }) { count++; throw UnsentHookRequest(IOException()) } }
        yield(); job.cancelAndJoin(); assertEquals(1, count)
    }

    @Test fun serverRecoversAfterRefusedConnectionReceivesExactlyOnePost() = runBlocking {
        val count = AtomicInteger(); var receiver: Receiver? = null
        val starter = launch { delay(250); receiver = server(count) }
        try { assertEquals("{}", RequestsUtils(true).jsonStr(url, "synthetic").getOrThrow()) }
        finally { starter.join(); receiver?.close() }
        assertEquals(1, count.get())
    }

    @Test fun lostResponseAfterPostMustNotReplay() = runBlocking {
        val count = AtomicInteger(); val receiver = server(count, null)
        try { assertTrue(RequestsUtils(true).jsonStr(url, "synthetic").isFailure); delay(50) }
        finally { receiver.close() }
        assertEquals(1, count.get())
    }

    @Test fun retryAfterZeroMustNotTriggerHiddenPostReplay() = runBlocking {
        val count = AtomicInteger(); val receiver = server(count, 503)
        try { assertTrue(RequestsUtils(true).jsonStr(url, "synthetic").isFailure); delay(50) }
        finally { receiver.close() }
        assertEquals(1, count.get())
    }
}
