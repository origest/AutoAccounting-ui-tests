package net.ankio.auto

import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.platform.app.InstrumentationRegistry
import com.google.android.material.materialswitch.MaterialSwitch
import net.ankio.auto.ui.activity.ChatGptCategoryActivity
import net.ankio.auto.ui.utils.SettingsPage
import org.junit.Assert.*
import org.junit.Test

class ChatGptSettingsDeviceTest {
    @Test fun dedicatedAccountScreenDoesNotOpenBrowserOrEnableClassificationOnLaunch() {
        val i = InstrumentationRegistry.getInstrumentation()
        val filter = android.content.IntentFilter(Intent.ACTION_VIEW).apply { addCategory(Intent.CATEGORY_BROWSABLE); addDataScheme("https") }
        val monitor = i.addMonitor(filter, android.app.Instrumentation.ActivityResult(android.app.Activity.RESULT_CANCELED, null), true)
        val before = net.ankio.auto.utils.PrefManager.aiCategoryChatGpt
        val a = i.startActivitySync(Intent(i.targetContext, ChatGptCategoryActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        try {
            i.runOnMainSync {
                val text = mutableListOf<String>()
                fun visit(v: View) {
                    if (v is TextView) text.add(v.text.toString())
                    if (v is ViewGroup) for (n in 0 until v.childCount) visit(v.getChildAt(n))
                }
                visit(a.window.decorView)
                assertTrue(text.any { it == "Continue with ChatGPT" })
                assertTrue(text.any { it == "允许发送账单分类数据" })
                assertTrue(text.any { it.contains("登录完成返回后自动刷新模型") })
                assertEquals(before, net.ankio.auto.utils.PrefManager.aiCategoryChatGpt)
                assertEquals(0, monitor.hits)
                assertConsentSwitchRequestsDoNotOptimisticallyChangeItsSavedState(a as ChatGptCategoryActivity)
            }
        } finally { i.runOnMainSync { a.finish() }; i.removeMonitor(monitor) }
    }

    private fun assertConsentSwitchRequestsDoNotOptimisticallyChangeItsSavedState(a: ChatGptCategoryActivity) {
        val requests = mutableListOf<Boolean>()
        val toggle: MaterialSwitch = SettingsPage(a, "Synthetic switch test").toggle("Synthetic permission") { requests.add(it) }
        assertFalse(toggle.isChecked)
        toggle.performClick()
        assertEquals(listOf(true), requests)
        assertFalse("Pending or cancelled confirmation must remain off", toggle.isChecked)
        toggle.performClick()
        assertFalse("Repeated requests must not grant permission", toggle.isChecked)

        toggle.isChecked = true // The caller has confirmed persisted authorization.
        assertEquals("Rendering must never invoke consent callbacks", 2, requests.size)
        toggle.performClick()
        assertEquals(false, requests.last())
        assertTrue("A failed revoke must not be shown as a confirmed off state", toggle.isChecked)
        toggle.isChecked = false
        assertEquals(3, requests.size)
    }
}
