package net.ankio.auto

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.test.platform.app.InstrumentationRegistry
import com.google.android.material.textfield.TextInputLayout
import net.ankio.auto.ui.activity.ChatGptCategoryActivity
import net.ankio.auto.classification.OwnerCategoryActivity
import net.ankio.auto.capture.PaymentCaptureActivity
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

/** Only synthetic empty-account emulator UI. Drawing own views never clears FLAG_SECURE. */
class MaterialSettingsDeviceTest {
    @Test fun materialPagesRenderAndScrollWithoutGrantingConsent() {
        val i = InstrumentationRegistry.getInstrumentation()
        assumeTrue(android.os.Build.HARDWARE in setOf("ranchu", "goldfish"))
        assumeTrue(net.ankio.chatgpt.ChatGptAccounts.get(i.targetContext).view().accounts.isEmpty())
        val before = net.ankio.auto.utils.PrefManager.aiCategoryChatGpt
        val filter = android.content.IntentFilter(Intent.ACTION_VIEW).apply { addDataScheme("https") }
        val monitor = i.addMonitor(filter, android.app.Instrumentation.ActivityResult(Activity.RESULT_CANCELED, null), true)
        try {
            for (type in listOf(ChatGptCategoryActivity::class.java, OwnerCategoryActivity::class.java, PaymentCaptureActivity::class.java)) {
                val a = i.startActivitySync(Intent(i.targetContext, type).setAction(Intent.ACTION_MAIN).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                try {
                    i.waitForIdleSync()
                    // Cancel real consent dialogs; neither path may request external permission.
                    if (type == ChatGptCategoryActivity::class.java || type == PaymentCaptureActivity::class.java) {
                        val title = if (type == ChatGptCategoryActivity::class.java) "Continue with ChatGPT" else "启用支付截图"
                        val deadline = android.os.SystemClock.uptimeMillis() + 15_000
                        var ready = false
                        while (!ready && android.os.SystemClock.uptimeMillis() < deadline) {
                            i.runOnMainSync { ready = descendants(a.window.decorView).filterIsInstance<android.widget.Button>().first { it.text == title }.isEnabled }
                            if (!ready) android.os.SystemClock.sleep(100)
                        }
                        assertTrue("Account loading did not finish", ready)
                        i.runOnMainSync { descendants(a.window.decorView).filterIsInstance<android.widget.Button>().first { it.text == title }.performClick() }
                        i.waitForIdleSync()
                        i.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK)
                        i.waitForIdleSync()
                        assertFalse(a.isFinishing)
                        assertFalse(i.targetContext.getSharedPreferences("payment-capture", android.content.Context.MODE_PRIVATE).getBoolean("enabled", false))
                    }
                    i.runOnMainSync {
                        assertTrue(a.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
                        val root = a.window.decorView
                        assertTrue(root.width > 0 && root.height > 0)
                        if (a is OwnerCategoryActivity) assertOwnerCategoryNumberFields(a)
                        val scroll = descendants(root).filterIsInstance<NestedScrollView>().single()
                        snapshot(a, "top")
                        scroll.scrollTo(0, 0)
                    }
                    // Capture overlapping viewports so model, consent and queue controls are reviewable.
                    for (step in 1..20) {
                        var more = false
                        i.runOnMainSync {
                            val scroll = descendants(a.window.decorView).filterIsInstance<NestedScrollView>().single()
                            more = scroll.canScrollVertically(1)
                            if (more) scroll.scrollBy(0, (scroll.height * .8f).toInt())
                        }
                        if (!more) break
                        i.waitForIdleSync()
                        i.runOnMainSync { snapshot(a, "page-$step") }
                    }
                    i.waitForIdleSync()
                    i.runOnMainSync {
                        snapshot(a, "bottom")
                        assertEquals(before, net.ankio.auto.utils.PrefManager.aiCategoryChatGpt)
                        assertFalse(net.ankio.auto.classification.OwnerCategoryQueue.enabled(a))
                        assertEquals(0, monitor.hits)
                        assertTrue(descendants(a.window.decorView).filterIsInstance<TextView>().any { it.text.isNotEmpty() })
                    }
                } finally { i.runOnMainSync { a.finish() } }
            }
        } finally { i.removeMonitor(monitor) }
    }
    private fun assertOwnerCategoryNumberFields(a: OwnerCategoryActivity) {
        val expected = mapOf(
            "每小时上限" to net.ankio.auto.classification.OwnerCategoryQueue.prefs(a).getInt("limit", 10).toString(),
            "天数" to "30",
            "每批笔数" to "100",
        )
        val fields = descendants(a.window.decorView).filterIsInstance<TextInputLayout>()
        assertEquals("All numeric settings must render", expected.size, fields.size)
        for ((label, value) in expected) {
            val field = fields.single { it.hint?.toString() == label }
            val edit = requireNotNull(field.editText)
            assertEquals(value, edit.text.toString())
            assertEquals(InputType.TYPE_CLASS_NUMBER, edit.inputType and InputType.TYPE_MASK_CLASS)
            assertEquals(1, edit.maxLines)
            assertEquals(TextInputLayout.BOX_BACKGROUND_OUTLINE, field.boxBackgroundMode)
            // Material reparents the editor and uses the supplied params on its input frame.
            // Generic ViewGroup.LayoutParams crash while that frame's margins are updated.
            val inputFrame = edit.parent as View
            assertSame(field, inputFrame.parent)
            assertTrue("$label input frame needs LinearLayout.LayoutParams", inputFrame.layoutParams is LinearLayout.LayoutParams)
            assertEquals(ViewGroup.LayoutParams.MATCH_PARENT, inputFrame.layoutParams.width)
            assertEquals(ViewGroup.LayoutParams.WRAP_CONTENT, inputFrame.layoutParams.height)
            assertTrue("$label field must be laid out", field.width > 0 && field.height > 0)
            assertTrue("$label editor must be laid out", edit.width > 0 && edit.height > 0)
        }
    }
    private fun descendants(v: View): List<View> = listOf(v) +
        if (v is ViewGroup) (0 until v.childCount).flatMap { descendants(v.getChildAt(it)) } else emptyList()
    private fun snapshot(a: Activity, position: String) {
        val v = a.window.decorView
        val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        try {
            v.draw(Canvas(b))
            val dir = File(a.noBackupFilesDir, "ui-test-evidence").apply { mkdirs() }
            File(dir, "${a.javaClass.simpleName}-$position.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } finally { b.recycle() }
    }
}
