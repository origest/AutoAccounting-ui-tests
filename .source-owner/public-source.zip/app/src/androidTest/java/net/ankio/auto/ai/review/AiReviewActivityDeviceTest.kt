package net.ankio.auto.ai.review

import android.app.Dialog
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.google.gson.Gson
import net.ankio.auto.classification.OwnerCategoryPrompts
import net.ankio.auto.ui.activity.ChatGptCategoryActivity
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** Actual Activity/dialog interactions, owned synthetic views only. No login, model request or bill save. */
class AiReviewActivityDeviceTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private data class Fixture(val name: String, val reads: AtomicInteger, val dialogs: AtomicInteger, val dialog: AtomicReference<Dialog?>)
    private fun fixture(size: Int, body: (Fixture) -> Unit) {
        assertTrue("Run only on an isolated emulator", android.os.Build.HARDWARE in setOf("ranchu", "goldfish"))
        assertTrue("No real account may be present", net.ankio.chatgpt.ChatGptAccounts.get(context).view().accounts.isEmpty())
        val fixture = Fixture("review-ui-${UUID.randomUUID()}.db", AtomicInteger(), AtomicInteger(), AtomicReference(null))
        try {
            AiReviewUiFixture.install(fixture.name, { fixture.reads.incrementAndGet() }, { fixture.dialog.set(it); fixture.dialogs.incrementAndGet() })
            assertEquals(AiReviewPolicy.Settings(), AiReviewPolicy(context).settings())
            AiReviewStore(context).use { it.page(AiReviewTab.QUEUE) }
            seed(fixture.name, size)
            body(fixture)
        } finally {
            instrumentation.runOnMainSync { fixture.dialog.getAndSet(null)?.dismiss() }
            AiReviewUiFixture.clear()
            context.deleteSharedPreferences(fixture.name.removeSuffix(".db") + "-policy")
            listOf("", "-journal", "-wal", "-shm").forEach { File(context.noBackupFilesDir, fixture.name + it).delete() }
        }
    }
    private fun seed(name: String, size: Int) {
        SQLiteDatabase.openDatabase(File(context.noBackupFilesDir, name).path, null, SQLiteDatabase.OPEN_READWRITE).use { db ->
            db.beginTransaction()
            try {
                repeat(size) { i ->
                    val id = i.toString().padStart(8, '0')
                    val state = listOf("REVIEW", "WAITING", "RUNNING", "FAILED", "APPLYING", "APPLIED", "MANUAL", "STALE")[i % 8]
                    val changes = "[{\"field\":\"CATEGORY\",\"before\":\"其他\",\"after\":\"合成类别\",\"createsNew\":false,\"kind\":\"\",\"currency\":\"\"}]"
                    db.execSQL("INSERT INTO task VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", arrayOf<Any>(id, "ocr-local", i+1, 0, "a".repeat(32), "CATEGORY", state, changes, "", 0, i/3, i/3, "synthetic-ui", ""))
                    db.execSQL("INSERT INTO event(id,task_id,state,action,changes,error,timestamp) VALUES(?,?,?,?,?,?,?)", arrayOf<Any>("event-$id", id, state, "CREATED", changes, "", i))
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }
    private fun start(tab: String = "queue") = ActivityScenario.launch<AiReviewActivity>(Intent(context, AiReviewActivity::class.java).putExtra("tab", tab))
    private fun all(view: View): List<View> = listOf(view) + if (view is ViewGroup) (0 until view.childCount).flatMap { all(view.getChildAt(it)) } else emptyList()
    private fun texts(view: View) = all(view).filterIsInstance<TextView>().map { it.text.toString() }
    private fun click(scenario: ActivityScenario<AiReviewActivity>, label: String) = scenario.onActivity { activity ->
        val button = all(activity.window.decorView).filterIsInstance<Button>().first { it.text.toString() == label }
        button.requestRectangleOnScreen(android.graphics.Rect(0, 0, button.width, button.height), true)
        assertTrue(button.performClick())
    }
    private fun waitUntil(timeout: Long = 5_000, condition: () -> Boolean): Long {
        val start = SystemClock.elapsedRealtime()
        while (!condition() && SystemClock.elapsedRealtime() - start < timeout) SystemClock.sleep(25)
        assertTrue("UI condition did not become true within ${timeout}ms", condition())
        return SystemClock.elapsedRealtime() - start
    }
    private fun waitText(scenario: ActivityScenario<AiReviewActivity>, text: String, timeout: Long = 5_000): Long = waitUntil(timeout) {
        var found = false
        scenario.onActivity { found = texts(it.window.decorView).any { value -> value.contains(text) } }
        found
    }
    private fun screenshot(view: View, name: String) {
        assertTrue(view.width > 0 && view.height > 0)
        val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        try {
            view.draw(Canvas(bitmap))
            File(context.noBackupFilesDir, "ui-test-evidence").apply { mkdirs() }.resolve(name).outputStream().use {
                assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        } finally { bitmap.recycle() }
    }
    private fun snapshot(scenario: ActivityScenario<AiReviewActivity>, name: String) {
        waitUntil {
            var laidOut = false
            scenario.onActivity { activity -> laidOut = all(activity.window.decorView).filterIsInstance<NestedScrollView>()
                .any { it.height > 0 && it.getChildAt(0).height > 0 } }
            laidOut
        }
        scenario.onActivity {
            assertTrue(it.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
            val values = texts(it.window.decorView)
            val count = values.count { value -> value.contains(" · 账单 #") }
            assertTrue("Only one bounded page may be rendered", count <= 100)
            val reported = values.firstOrNull { value -> value.startsWith("此状态共 ") }
                ?.let { value -> Regex("显示 ([0-9]+) 条").find(value)?.groupValues?.get(1)?.toInt() }
            assertEquals("Rendered cards match the real page summary", reported, count)
            screenshot(it.window.decorView, name)
        }
    }
    private fun waitDialog(fixture: Fixture) = waitUntil {
        var ready = false
        instrumentation.runOnMainSync { ready = fixture.dialog.get()?.let {
            it.isShowing && (it.window?.decorView?.width ?: 0) > 0 && (it.window?.decorView?.height ?: 0) > 0
        } == true }
        ready
    }
    private fun metrics(name: String, scenario: String, size: Int, times: Map<String, Long>, limits: Map<String, Long>, checks: Map<String, Any>) {
        times.forEach { (key, elapsed) -> assertTrue("$key exceeded fixed UI smoke limit", elapsed <= requireNotNull(limits[key])) }
        File(context.noBackupFilesDir, "ui-test-evidence").apply { mkdirs() }.resolve(name).writeText(Gson().toJson(mapOf(
            "schema_version" to 1, "scenario" to scenario, "synthetic_records" to size, "max_rendered_rows" to 100,
            "timings_ms" to times, "limits_ms" to limits, "checks" to checks)))
    }
    @Test fun threeTabsAndHistoryRenderFromTenThousandSyntheticTasks() = fixture(10_000) { fixture ->
        val started = SystemClock.elapsedRealtime(); val scenario = start()
        val times = linkedMapOf<String, Long>()
        try {
            waitText(scenario, "此状态共 5000 条", 10_000); times["queue_load"] = SystemClock.elapsedRealtime() - started
            scenario.onActivity { activity ->
                val values = texts(activity.window.decorView)
                assertTrue(values.any { it.startsWith("等待处理 ·") }); assertTrue(values.any { it.startsWith("识别中 ·") })
                assertTrue(values.any { it.startsWith("失败 / 需核对 ·") }); assertTrue(values.any { it.startsWith("正在保存 ·") })
                assertEquals(100, values.count { it.startsWith("单笔分类 · 账单 #") })
            }
            snapshot(scenario, "AiReviewActivity-queue.png")
            var at = SystemClock.elapsedRealtime(); click(scenario, "待确认 · 已完成识别"); waitText(scenario, "此状态共 1250 条"); times["pending_tab"] = SystemClock.elapsedRealtime() - at
            snapshot(scenario, "AiReviewActivity-pending.png")
            at = SystemClock.elapsedRealtime(); click(scenario, "应用与手动修改历史"); waitText(scenario, "此状态共 3750 条"); times["history_tab"] = SystemClock.elapsedRealtime() - at
            snapshot(scenario, "AiReviewActivity-history.png")
            at = SystemClock.elapsedRealtime(); click(scenario, "分页查看此任务历史")
            waitDialog(fixture)
            instrumentation.waitForIdleSync()
            instrumentation.runOnMainSync { screenshot(requireNotNull(fixture.dialog.get()?.window).decorView, "AiReviewActivity-history-dialog.png") }
            times["history_dialog"] = SystemClock.elapsedRealtime() - at
            instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
            SQLiteDatabase.openDatabase(File(context.noBackupFilesDir, fixture.name).path, null, SQLiteDatabase.OPEN_READONLY).use { db ->
                db.rawQuery("SELECT sum(attempt) FROM task", null).use { it.moveToFirst(); assertEquals(0L, it.getLong(0)) }
            }
            metrics("AiReviewActivity-tabs-metrics.json", "tabs", 10_000, times,
                mapOf("queue_load" to 10_000L, "pending_tab" to 5_000L, "history_tab" to 5_000L, "history_dialog" to 5_000L),
                mapOf("tabs_correct" to true, "inference_attempt_sum" to 0))
        } finally { scenario.close() }
    }
    @Test fun pendingPaginationKeepsScrollAndRestoresTabAfterRecreation() = fixture(1_000) { fixture ->
        val scenario = start("pending"); val times = linkedMapOf<String, Long>()
        try {
            waitText(scenario, "此状态共 125 条", 10_000)
            val at = SystemClock.elapsedRealtime(); click(scenario, "下一页 · 较早记录"); waitText(scenario, "第 2 页显示 25 条"); times["next_page"] = SystemClock.elapsedRealtime() - at
            snapshot(scenario, "AiReviewActivity-pending-page2.png") // Also waits for the real page layout.
            val scrollRef = AtomicReference<NestedScrollView>(); var offset = 0
            scenario.onActivity { activity ->
                val scroll = all(activity.window.decorView).filterIsInstance<NestedScrollView>().single()
                scroll.scrollTo(0, 700); offset = scroll.scrollY; assertTrue(offset > 0); scrollRef.set(scroll)
            }
            AiReviewStore(context).use { store ->
                val row = store.create(AiReviewTarget("ocr-local", 20_000, 0, "b".repeat(32)), AiReviewKind.CATEGORY)
                assertTrue(store.review(store.claim(row.id)!!, listOf(AiReviewChange("CATEGORY", "其他", "合成类别"))))
            }
            waitText(scenario, "此状态共 126 条", 7_500)
            scenario.onActivity { activity ->
                val scroll = all(activity.window.decorView).filterIsInstance<NestedScrollView>().single()
                assertSame("Count-only refresh must not rebuild the page", scrollRef.get(), scroll)
                assertEquals(offset, scroll.scrollY)
                assertTrue(texts(activity.window.decorView).any { it.contains("第 2 页") })
            }
            val rotateAt = SystemClock.elapsedRealtime(); scenario.recreate(); waitText(scenario, "此状态共 126 条"); times["recreate_pending_tab"] = SystemClock.elapsedRealtime() - rotateAt
            snapshot(scenario, "AiReviewActivity-pending-recreated.png")
            metrics("AiReviewActivity-paging-metrics.json", "paging", 1_000, times,
                mapOf("next_page" to 5_000L, "recreate_pending_tab" to 5_000L), mapOf("older_pending_reachable" to true, "scroll_retained" to true, "tab_restored" to true))
        } finally { scenario.close() }
    }
    @Test fun stoppedActivityDoesNotPollAndResumeRefreshesImmediately() = fixture(100) { fixture ->
        val scenario = start()
        try {
            waitText(scenario, "此状态共 51 条", 10_000)
            scenario.moveToState(Lifecycle.State.CREATED)
            val stopped = fixture.reads.get()
            SQLiteDatabase.openDatabase(File(context.noBackupFilesDir, fixture.name).path, null, SQLiteDatabase.OPEN_READWRITE).use {
                it.execSQL("UPDATE task SET state='APPLIED' WHERE id='00000001'")
            }
            SystemClock.sleep(5_500)
            assertEquals("Stopped Activity must not start a new periodic read", stopped, fixture.reads.get())
            val at = SystemClock.elapsedRealtime(); scenario.moveToState(Lifecycle.State.RESUMED)
            waitUntil { fixture.reads.get() > stopped }; waitText(scenario, "此状态共 50 条")
            val elapsed = SystemClock.elapsedRealtime() - at
            snapshot(scenario, "AiReviewActivity-resumed.png")
            metrics("AiReviewActivity-lifecycle-metrics.json", "lifecycle", 100, mapOf("resume_refresh" to elapsed), mapOf("resume_refresh" to 5_000L),
                mapOf("poll_count_before_stop" to stopped, "poll_count_after_wait" to stopped, "poll_count_after_resume" to fixture.reads.get(), "background_wait_ms" to 5_500, "queue_total_after_resume" to 50))
        } finally { scenario.close() }
    }
    @Test fun realAutomaticPromptWaitsForForegroundAndCancelOrBackKeepsPending() = fixture(0) { fixture ->
        val host = ActivityScenario.launch<ChatGptCategoryActivity>(Intent(context, ChatGptCategoryActivity::class.java))
        var id = ""
        val times = linkedMapOf<String, Long>()
        try {
            host.moveToState(Lifecycle.State.CREATED)
            AiReviewStore(context).use { store ->
                val row = store.create(AiReviewTarget("00000000-0000-0000-0000-000000000042", 42, 0, "c".repeat(32)), AiReviewKind.OWNER_CATEGORY)
                id = row.id
                assertTrue(store.review(store.claim(id)!!, listOf(AiReviewChange("CATEGORY", "其他", "合成类别"))))
            }
            instrumentation.runOnMainSync { OwnerCategoryPrompts.offer(id) }
            instrumentation.waitForIdleSync(); assertEquals(0, fixture.dialogs.get())
            val at = SystemClock.elapsedRealtime()
            host.moveToState(Lifecycle.State.RESUMED)
            waitUntil { var focused = false; host.onActivity { focused = it.window.decorView.hasWindowFocus() }; focused || fixture.dialog.get()?.isShowing == true }
            if (fixture.dialog.get()?.isShowing != true) instrumentation.runOnMainSync { OwnerCategoryPrompts.offer(id) }
            waitDialog(fixture)
            instrumentation.waitForIdleSync()
            instrumentation.runOnMainSync {
                val dialog = fixture.dialog.get() as androidx.appcompat.app.AlertDialog
                assertTrue(requireNotNull(dialog.window).attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
                screenshot(requireNotNull(dialog.window).decorView, "OwnerCategoryReview-auto-prompt.png")
                dialog.getButton(android.content.DialogInterface.BUTTON_NEGATIVE).performClick()
            }
            times["foreground_prompt"] = SystemClock.elapsedRealtime() - at
            waitUntil { AiReviewStore(context).use { it.latestEvent(id, setOf("DEFERRED")) != null } }
            val shown = fixture.dialogs.get(); instrumentation.runOnMainSync { OwnerCategoryPrompts.offer(id) }; instrumentation.waitForIdleSync()
            assertEquals("A dismissed automatic prompt must not repeat in the same visit", shown, fixture.dialogs.get())
        } finally { host.close() }
        val review = start("pending")
        try {
            waitText(review, "此状态共 1 条", 10_000)
            fixture.dialog.set(null); click(review, "查看并处理建议")
            waitDialog(fixture); instrumentation.waitForIdleSync()
            instrumentation.runOnMainSync { screenshot(requireNotNull(fixture.dialog.get()?.window).decorView, "OwnerCategoryReview-pending-dialog.png") }
            val beforeBack = AiReviewStore(context).use { store -> store.historyPage(id).events.count { it.action == "DEFERRED" } }
            instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK); instrumentation.waitForIdleSync()
            waitUntil { AiReviewStore(context).use { store -> store.historyPage(id).events.count { it.action == "DEFERRED" } > beforeBack } }
            assertEquals(AiReviewState.REVIEW, AiReviewStore(context).use { it.get(id)!!.state })
            metrics("OwnerCategoryReview-prompts-metrics.json", "prompts", 1, times, mapOf("foreground_prompt" to 5_000L),
                mapOf("background_dialog_count" to 0, "cancel_kept_pending" to true, "back_kept_pending" to true, "same_visit_no_repeat" to true))
        } finally { review.close() }
    }
}
