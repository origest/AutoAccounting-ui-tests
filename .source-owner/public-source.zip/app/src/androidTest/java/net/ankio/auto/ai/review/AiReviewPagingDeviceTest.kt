package net.ankio.auto.ai.review

import android.database.sqlite.SQLiteDatabase
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.util.UUID
import org.junit.Assert.*
import org.junit.Test

/** Isolated synthetic databases only. Building this class is not a device-run result. */
class AiReviewPagingDeviceTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private fun fixture(block: (String) -> Unit) {
        val name = "review-page-${UUID.randomUUID()}.db"
        try {
            AiReviewStore(context, name, "synthetic").use { it.page(AiReviewTab.PENDING) }
            block(name)
        } finally { listOf("", "-journal", "-wal", "-shm").forEach { File(context.noBackupFilesDir, name + it).delete() } }
    }
    private fun open(name: String) = SQLiteDatabase.openDatabase(File(context.noBackupFilesDir, name).path, null, SQLiteDatabase.OPEN_READWRITE)
    private fun seed(name: String, size: Int) = open(name).use { db ->
        db.beginTransaction()
        try {
            repeat(size) { index ->
                val state = listOf("REVIEW", "WAITING", "RUNNING", "FAILED", "APPLYING", "APPLIED", "MANUAL", "STALE")[index % 8]
                db.execSQL("INSERT INTO task VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", arrayOf<Any>(
                    index.toString().padStart(8, '0'), "ocr-local", index + 1, 0, "a".repeat(32), "CATEGORY", state,
                    "[{\"field\":\"CATEGORY\",\"before\":\"其他\",\"after\":\"餐饮\",\"createsNew\":false,\"kind\":\"\",\"currency\":\"\"}]",
                    "", 1, index / 3, index / 3, "synthetic", ""))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    private fun scale(size: Int) = fixture { name ->
        seed(name, size)
        AiReviewStore(context, name, "synthetic").use { store ->
            for (tab in AiReviewTab.entries) {
                val expected = (0 until size).filter { when (tab) {
                    AiReviewTab.PENDING -> it % 8 == 0
                    AiReviewTab.QUEUE -> it % 8 in 1..4
                    AiReviewTab.HISTORY -> it % 8 >= 5
                } }.map { it.toString().padStart(8, '0') }.toSet()
                val seen = mutableSetOf<String>(); var cursor: AiReviewCursor? = null
                do {
                    val page = store.page(tab, cursor)
                    assertTrue(page.records.size <= 100)
                    assertEquals(expected.size.toLong(), page.total)
                    assertTrue(page.records.all { seen.add(it.id) })
                    cursor = page.next
                } while (cursor != null)
                assertEquals(expected, seen)
                val query = AiReviewPaging.query(tab, AiReviewCursor(size.toLong(), ""), 100)
                open(name).use { db -> db.rawQuery("EXPLAIN QUERY PLAN ${query.sql}", query.args).use { plan ->
                    val details = buildList { while (plan.moveToNext()) add(plan.getString(3)) }.joinToString(" ")
                    assertTrue(details.contains("task_${tab.key}_page"))
                    assertFalse(details.contains("TEMP B-TREE"))
                } }
            }
        }
    }
    @Test fun oneHundredRecordsRemainBoundedAndComplete() = scale(100)
    @Test fun oneThousandRecordsRemainBoundedAndComplete() = scale(1_000)
    @Test fun tenThousandRecordsRemainBoundedAndComplete() = scale(10_000)
    @Test fun olderManualEvidenceSurvivesTenThousandNewerHistoryEvents() = fixture { name ->
        seed(name, 1)
        open(name).use { db ->
            db.beginTransaction()
            try {
                repeat(10_000) { index -> db.execSQL("INSERT INTO event(id,task_id,state,action,changes,error,timestamp) VALUES(?,?,?,?,?,?,?)", arrayOf<Any>(
                    index.toString(), "00000000", "REVIEW", if (index == 0) "MANUAL_CHANGED" else "DEFERRED", "[]", "", index)) }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
        AiReviewStore(context, name, "synthetic").use { store ->
            assertEquals(100, store.historyPage("00000000").events.size)
            assertEquals("MANUAL_CHANGED", store.latestEvent("00000000", setOf("REVIEW_READY", "MANUAL_CHANGED"))!!.action)
            var next: Long? = null; val seen = mutableSetOf<String>()
            do { val page = store.historyPage("00000000", next); assertTrue(page.events.all { seen.add(it.id) }); next = page.next } while (next != null)
            assertEquals(10_000, seen.size)
        }
    }
    @Test fun versionOneMigrationOnlyAddsIndexesAndPreservesPendingRows() = fixture { name ->
        seed(name, 1_000)
        open(name).use { db ->
            AiReviewPaging.indexes().forEach { sql -> db.execSQL("DROP INDEX " + sql.substringAfter("EXISTS ").substringBefore(" ON")) }
            db.version = 1
        }
        AiReviewStore(context, name, "synthetic").use { store ->
            assertEquals(125, store.page(AiReviewTab.PENDING).total.toInt())
            assertEquals(100, store.page(AiReviewTab.PENDING).records.size)
        }
        open(name).use { assertEquals(2, it.version) }
    }
}
