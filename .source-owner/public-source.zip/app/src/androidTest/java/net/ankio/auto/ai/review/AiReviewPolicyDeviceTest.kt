package net.ankio.auto.ai.review

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.test.platform.app.InstrumentationRegistry
import java.lang.reflect.Proxy
import org.junit.Assert.*
import org.junit.Test

class AiReviewPolicyDeviceTest {
    /** Emulates Android's memory cache changing even when durable commit reports failure. */
    private class Preferences {
        val values = mutableMapOf<String, Boolean>()
        var commitResult = true
        private val staged = mutableMapOf<String, Boolean>()
        private lateinit var editor: SharedPreferences.Editor
        val prefs: SharedPreferences
        init {
            editor = Proxy.newProxyInstance(SharedPreferences.Editor::class.java.classLoader,
                arrayOf(SharedPreferences.Editor::class.java)) { _, method, args ->
                when (method.name) {
                    "putBoolean" -> { staged[args!![0] as String] = args[1] as Boolean; editor }
                    "commit" -> { values.putAll(staged); staged.clear(); commitResult }
                    else -> error("Unexpected editor method: ${method.name}")
                }
            } as SharedPreferences.Editor
            prefs = Proxy.newProxyInstance(SharedPreferences::class.java.classLoader,
                arrayOf(SharedPreferences::class.java)) { _, method, args ->
                when (method.name) {
                    "getBoolean" -> values[args!![0] as String] ?: args[1] as Boolean
                    "edit" -> editor
                    else -> error("Unexpected preference method: ${method.name}")
                }
            } as SharedPreferences
        }
    }
    @Test fun failedCommitRemainsFailClosedAcrossPolicyInstances() {
        val fake = Preferences()
        val context = object : ContextWrapper(InstrumentationRegistry.getInstrumentation().targetContext) {
            override fun getApplicationContext(): Context = this
            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences = fake.prefs
        }
        val first = AiReviewPolicy(context)
        // Reset the process-level latch using a successful, conservative explicit save.
        assertTrue(first.update(AiReviewPolicy.Settings()))
        try {
            assertFalse(first.get(AiReviewPolicy.Key.AUTO_APPLY_CATEGORY))
            assertTrue(first.get(AiReviewPolicy.Key.PROMPT_NEW_CATEGORY))
            fake.commitResult = false
            assertFalse(first.set(AiReviewPolicy.Key.AUTO_APPLY_CATEGORY, true))
            assertEquals(true, fake.values["autoApplyCategory"])
            val second = AiReviewPolicy(context)
            assertNotNull(second.warning())
            assertFalse(second.get(AiReviewPolicy.Key.AUTO_APPLY_CATEGORY))
            assertTrue(second.get(AiReviewPolicy.Key.PROMPT_NEW_CATEGORY))
            fake.commitResult = true
            assertTrue(second.set(AiReviewPolicy.Key.AUTO_APPLY_ASSETS, true))
            assertNull(second.warning())
            assertFalse(second.get(AiReviewPolicy.Key.AUTO_APPLY_CATEGORY))
            assertTrue(second.get(AiReviewPolicy.Key.AUTO_APPLY_ASSETS))
        } finally {
            fake.commitResult = true
            first.update(AiReviewPolicy.Settings())
        }
    }
    @Test fun automaticLocalCommitSerializesRevocationAndRechecksBeforeNextCommit() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val policy = AiReviewPolicy(context)
        val record = AiReviewRecord("synthetic", AiReviewTarget("ocr-local", 42, 1, "a".repeat(32)),
            AiReviewKind.OCR_CATEGORY, AiReviewState.REVIEW,
            listOf(AiReviewChange("CATEGORY", "其他", "宠物", true)), "", 1, 0, 0)
        val entered = java.util.concurrent.CountDownLatch(1)
        val release = java.util.concurrent.CountDownLatch(1)
        val revoked = java.util.concurrent.CountDownLatch(1)
        val finished = java.util.concurrent.CountDownLatch(1)
        val pool = java.util.concurrent.Executors.newFixedThreadPool(2)
        try {
            assertTrue(policy.update(AiReviewPolicy.Settings(confirmNewCategory = false)))
            val applying = pool.submit<Boolean?> {
                try { policy.withAutomaticApply(record) {
                    entered.countDown()
                    check(release.await(5, java.util.concurrent.TimeUnit.SECONDS))
                    true
                } } finally { finished.countDown() }
            }
            assertTrue(entered.await(5, java.util.concurrent.TimeUnit.SECONDS))
            val changing = pool.submit<Boolean> {
                policy.set(AiReviewPolicy.Key.PROMPT_NEW_CATEGORY, true).also { revoked.countDown() }
            }
            assertFalse(revoked.await(100, java.util.concurrent.TimeUnit.MILLISECONDS))
            release.countDown()
            assertEquals(true, applying.get(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(changing.get(5, java.util.concurrent.TimeUnit.SECONDS))
            var ran = false
            assertNull(policy.withAutomaticApply(record) { ran = true })
            assertFalse(ran)
        } finally {
            release.countDown()
            finished.await(5, java.util.concurrent.TimeUnit.SECONDS)
            pool.shutdownNow()
            assertTrue(policy.update(AiReviewPolicy.Settings()))
        }
    }

}
