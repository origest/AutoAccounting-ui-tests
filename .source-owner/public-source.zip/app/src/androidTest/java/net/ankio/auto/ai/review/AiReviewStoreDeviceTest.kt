package net.ankio.auto.ai.review

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

/** Synthetic references only. No providers, account connections, or bill-database writes. */
class AiReviewStoreDeviceTest {
    private val context: Context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private val target = AiReviewTarget("ocr-local", 42, 0, "a".repeat(32))
    private val changes = listOf(AiReviewChange("CATEGORY", "其他", "餐饮"))
    private fun fixture(block: (String) -> Unit) {
        val name = "review-test-${UUID.randomUUID()}.db"
        try { block(name) } finally {
            val file = File(context.noBackupFilesDir, name)
            listOf("", "-journal", "-wal", "-shm").forEach { File(file.path + it).delete() }
        }
    }
    @Test fun idempotentCreateClaimsAndApplyTokensCannotReplay() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val record = store.create(target, AiReviewKind.CATEGORY)
            assertEquals(record, store.create(target, AiReviewKind.CATEGORY))
            val claim = store.claim(record.id)!!
            assertNull(store.claim(record.id))
            assertTrue(store.review(claim, changes))
            assertFalse(store.review(claim, changes))
            assertFalse(store.fail(claim, "REQUEST_FAILED"))
            assertTrue(store.defer(record.id))
            assertEquals("DEFERRED", store.history(record.id).last().action)
            val token = store.beginApply(record.id)!!
            assertNull(store.beginApply(record.id))
            assertFalse(store.finishApply(record.id, "wrong", AiReviewState.APPLIED))
            assertTrue(store.finishApply(record.id, token, AiReviewState.APPLIED))
            assertFalse(store.finishApply(record.id, token, AiReviewState.APPLIED))
            assertEquals(AiReviewState.APPLIED, store.get(record.id)!!.state)
        }
    }
    @Test fun failedRequestsNeedExplicitRetryAndOldClaimsRemainInvalid() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.CATEGORY).id
            val first = store.claim(id)!!
            assertTrue(store.fail(first, "sensitive arbitrary provider message"))
            assertEquals("REQUEST_FAILED", store.get(id)!!.errorCode)
            assertNull(store.claim(id))
            val second = store.claim(id, explicitRetry = true)!!
            assertEquals(first.attempt + 1, second.attempt)
            assertNotEquals(first.token, second.token)
            assertFalse(store.review(first, changes))
            assertTrue(store.review(second, changes))
            val token = store.beginApply(id)!!
            assertTrue(store.finishApply(id, token, AiReviewState.FAILED))
            assertEquals("APPLY_UNCONFIRMED", store.get(id)!!.errorCode)
            assertNull(store.claim(id))
            assertNull(store.claim(id, explicitRetry = true))
        }
    }
    @Test fun sameProcessOpenPreservesWorkAndNewProcessRecoversBothInterruptedStates() = fixture { name ->
        val ids = AiReviewStore(context, name, "first-process").use { store ->
            val running = store.create(target, AiReviewKind.CATEGORY).id
            store.claim(running)!!
            val applying = store.create(target.copy(billId = 43), AiReviewKind.CATEGORY).id
            assertTrue(store.review(store.claim(applying)!!, changes))
            store.beginApply(applying)!!
            AiReviewStore(context, name, "first-process").use { other ->
                assertEquals(AiReviewState.RUNNING, other.get(running)!!.state)
                assertEquals(AiReviewState.APPLYING, other.get(applying)!!.state)
            }
            running to applying
        }
        AiReviewStore(context, name, "new-process").use { store ->
            assertEquals("REQUEST_INTERRUPTED", store.get(ids.first)!!.errorCode)
            assertEquals("APPLY_UNCONFIRMED", store.get(ids.second)!!.errorCode)
            assertEquals(AiReviewState.FAILED, store.get(ids.first)!!.state)
            assertNull(store.claim(ids.first))
            assertNull(store.claim(ids.second))
            assertEquals("RECOVERED", store.history(ids.second).last().action)
        }
    }
    @Test fun concurrentHelpersHaveOnlyOneWinningClaim() = fixture { name ->
        AiReviewStore(context, name, "owner").use { first ->
            AiReviewStore(context, name, "owner").use { second ->
                val id = first.create(target, AiReviewKind.CATEGORY).id
                second.get(id) // Open both helpers before starting the race.
                val start = CountDownLatch(1)
                val executor = Executors.newFixedThreadPool(2)
                try {
                    val futures = listOf(first, second).map { store -> executor.submit<AiReviewClaim?> {
                        start.await(); store.claim(id)
                    } }
                    start.countDown()
                    assertEquals(1, futures.map { it.get(10, TimeUnit.SECONDS) }.count { it != null })
                    assertEquals(1, first.history(id).count { it.action == "CLAIMED" })
                } finally { executor.shutdownNow() }
            }
        }
    }
    @Test fun invalidPayloadCannotChangeTaskOrHistory() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.OCR).id
            val claim = store.claim(id)!!
            try { store.review(claim, listOf(AiReviewChange("OCR_BILL", "", "raw receipt text"))); fail("Expected validation failure") }
            catch (_: IllegalArgumentException) { }
            assertEquals(AiReviewState.RUNNING, store.get(id)!!.state)
            assertEquals(2, store.history(id).size)
            assertTrue(store.review(claim, listOf(AiReviewChange("OCR_BILL", "", "7"))))
            assertEquals("7", store.get(id)!!.changes.single().after)
        }
    }
    @Test fun eventWriteFailureRollsBackClaimAndDoesNotAuthorizeRequest() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.CATEGORY).id
            android.database.sqlite.SQLiteDatabase.openDatabase(File(context.noBackupFilesDir, name).path, null,
                android.database.sqlite.SQLiteDatabase.OPEN_READWRITE).use { db ->
                db.execSQL("CREATE TRIGGER reject_claim BEFORE INSERT ON event WHEN NEW.action='CLAIMED' BEGIN SELECT RAISE(ABORT,'synthetic failure'); END")
            }
            try { store.claim(id); fail("Expected durable write failure") }
            catch (_: android.database.sqlite.SQLiteException) { }
            assertEquals(AiReviewState.WAITING, store.get(id)!!.state)
            assertEquals(0, store.get(id)!!.attempt)
            assertEquals(1, store.history(id).size)
        }
    }

    @Test fun unsentApplyCanReturnToReviewWithoutReplayingToken() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.CATEGORY).id
            assertTrue(store.review(store.claim(id)!!, changes))
            val first = store.beginApply(id)!!
            assertFalse(store.returnToReview(id, "wrong", "AUTH_CHANGED"))
            assertEquals(AiReviewState.APPLYING, store.get(id)!!.state)
            assertTrue(store.returnToReview(id, first, "AUTH_CHANGED"))
            assertEquals(AiReviewState.REVIEW, store.get(id)!!.state)
            assertEquals(changes, store.get(id)!!.changes)
            assertEquals("AUTH_CHANGED", store.get(id)!!.errorCode)
            assertEquals("APPLY_DEFERRED", store.history(id).last().action)
            assertFalse(store.returnToReview(id, first))
            assertFalse(store.finishApply(id, first, AiReviewState.APPLIED))
            val second = store.beginApply(id)!!
            assertNotEquals(first, second)
            assertFalse(store.returnToReview(id, first))
            assertTrue(store.returnToReview(id, second))
            assertEquals("", store.get(id)!!.errorCode)
        }
    }

    @Test fun ownerQueueKindHasSeparateIdentityFromManualCategory() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val manual = store.create(target, AiReviewKind.CATEGORY)
            val owner = store.create(target, AiReviewKind.OWNER_CATEGORY)
            assertNotEquals(manual.id, owner.id)
            assertEquals(owner, store.create(target, AiReviewKind.OWNER_CATEGORY))
            assertTrue(store.review(store.claim(owner.id)!!, changes))
            assertEquals(AiReviewKind.OWNER_CATEGORY, store.get(owner.id)!!.kind)
        }
    }
    @Test fun manualAmendmentPreservesOriginalHistoryAndRequiresReviewState() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.ASSET).id
            val original = listOf(AiReviewChange("ASSET_FROM", "1", "2"))
            val changed = listOf(AiReviewChange("ASSET_FROM", "1", "3"))
            assertFalse(store.amendReview(id, changed))
            assertTrue(store.review(store.claim(id)!!, original))
            assertTrue(store.amendReview(id, changed))
            assertEquals(changed, store.get(id)!!.changes)
            assertEquals(original, store.history(id).first { it.action == "REVIEW_READY" }.changes)
            assertEquals("MANUAL_CHANGED", store.history(id).last().action)
            assertEquals(changed, store.history(id).last().changes)
            try { store.amendReview(id, listOf(AiReviewChange("ASSET_FROM", "1", "raw account text"))); fail("Expected safe-field rejection") }
            catch (_: IllegalArgumentException) { }
            assertEquals(changed, store.get(id)!!.changes)
            val token = store.beginApply(id)!!
            assertFalse(store.amendReview(id, original))
            assertTrue(store.finishApply(id, token, AiReviewState.MANUAL))
            assertFalse(store.amendReview(id, original))
        }
    }

    @Test fun cancelPendingIsKindScopedAndNeverChangesApplying() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val waiting = store.create(target, AiReviewKind.OWNER_CATEGORY).id
            val running = store.create(target.copy(billId = 43), AiReviewKind.OWNER_CATEGORY).id
            val oldClaim = store.claim(running)!!
            val review = store.create(target.copy(billId = 44), AiReviewKind.OWNER_CATEGORY).id
            assertTrue(store.review(store.claim(review)!!, changes))
            val applying = store.create(target.copy(billId = 45), AiReviewKind.OWNER_CATEGORY).id
            assertTrue(store.review(store.claim(applying)!!, changes))
            val token = store.beginApply(applying)!!
            val other = store.create(target, AiReviewKind.CATEGORY).id
            assertEquals(3, store.cancelPending(AiReviewKind.OWNER_CATEGORY))
            assertEquals(0, store.cancelPending(AiReviewKind.OWNER_CATEGORY))
            for (id in listOf(waiting, running, review)) {
                assertEquals(AiReviewState.STALE, store.get(id)!!.state)
                assertEquals("CANCELLED", store.get(id)!!.errorCode)
                assertEquals("CANCELLED", store.history(id).last().action)
                assertFalse(store.recoverReview(id, changes))
            }
            assertFalse(store.review(oldClaim, changes))
            assertFalse(store.fail(oldClaim, "REQUEST_FAILED"))
            assertEquals(AiReviewState.WAITING, store.get(other)!!.state)
            assertEquals(AiReviewState.APPLYING, store.get(applying)!!.state)
            assertTrue(store.finishApply(applying, token, AiReviewState.APPLIED))
        }
    }
    @Test fun persistedResultRecoveryIsSingleUseAndDoesNotReplayClaims() = fixture { name ->
        val oldClaim = AiReviewStore(context, name, "old-process").use { store ->
            store.claim(store.create(target, AiReviewKind.OWNER_CATEGORY).id)!!
        }
        AiReviewStore(context, name, "new-process").use { store ->
            assertEquals("REQUEST_INTERRUPTED", store.get(oldClaim.id)!!.errorCode)
            assertTrue(store.recoverReview(oldClaim.id, changes))
            assertEquals(oldClaim.attempt, store.get(oldClaim.id)!!.attempt)
            assertEquals("RESULT_RECOVERED", store.history(oldClaim.id).last().action)
            assertFalse(store.recoverReview(oldClaim.id, changes))
            assertFalse(store.review(oldClaim, changes))
            assertNull(store.claim(oldClaim.id, explicitRetry = true))
            val token = store.beginApply(oldClaim.id)!!
            assertTrue(store.finishApply(oldClaim.id, token, AiReviewState.FAILED))
            assertFalse(store.recoverReview(oldClaim.id, changes))
            val waiting = store.create(target.copy(billId = 43), AiReviewKind.OWNER_CATEGORY).id
            assertFalse(store.recoverReview(waiting, changes))
            val cancelled = store.claim(waiting)!!
            assertTrue(store.fail(cancelled, "CANCELLED"))
            assertFalse(store.recoverReview(waiting, changes))
        }
    }

    @Test fun singleTaskCancellationDoesNotCancelOtherPendingBills() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val first = store.create(target, AiReviewKind.OWNER_CATEGORY).id
            val second = store.create(target.copy(billId = 43), AiReviewKind.OWNER_CATEGORY).id
            assertEquals(1, store.cancelPending(AiReviewKind.OWNER_CATEGORY, first))
            assertEquals(AiReviewState.STALE, store.get(first)!!.state)
            assertEquals(AiReviewState.WAITING, store.get(second)!!.state)
        }
    }
    @Test fun staleReviewSnapshotCannotClaimAChangedSuggestion() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.CATEGORY).id
            assertTrue(store.review(store.claim(id)!!, changes))
            val newer = listOf(AiReviewChange("CATEGORY", "其他", "出行"))
            assertTrue(store.amendReview(id, newer))
            assertNull(store.beginApply(id, changes))
            assertNotNull(store.beginApply(id, newer))
        }
    }
    @Test fun verifiedOcrDraftReconciliationNeverReplaysRequestOrAcceptsOtherKinds() = fixture { name ->
        val id = AiReviewStore(context, name, "old").use { store ->
            val id = store.create(target, AiReviewKind.OCR).id
            store.claim(id)!!
            id
        }
        AiReviewStore(context, name, "new").use { store ->
            assertTrue(store.reconcileOcrDraft(id, 73, false))
            assertEquals(AiReviewState.REVIEW, store.get(id)!!.state)
            assertEquals("73", store.get(id)!!.changes.single().after)
            assertFalse(store.reconcileOcrDraft(id, 73, false))
            val token = store.beginApply(id)!!
            assertTrue(store.finishApply(id, token, AiReviewState.FAILED))
            assertFalse(store.reconcileOcrDraft(id, 74, true))
            assertTrue(store.reconcileOcrDraft(id, 73, true))
            assertEquals(AiReviewState.APPLIED, store.get(id)!!.state)
            assertNull(store.claim(id, true))
            val other = store.create(target, AiReviewKind.CATEGORY).id
            store.fail(store.claim(other)!!, "REQUEST_INTERRUPTED")
            assertFalse(store.reconcileOcrDraft(other, 73, true))
        }
    }
    @Test fun finalChangesAreValidatedAndPreserveOriginalProposalHistory() = fixture { name ->
        AiReviewStore(context, name, "owner").use { store ->
            val id = store.create(target, AiReviewKind.ASSET).id
            val proposal = listOf(AiReviewChange("ASSET_FROM", "", "", true, "CASH", "CNY"))
            assertTrue(store.review(store.claim(id)!!, proposal))
            val token = store.beginApply(id)!!
            val applied = listOf(AiReviewChange("ASSET_FROM", "", "73"))
            try { store.finishApply(id, token, AiReviewState.FAILED, applied); fail("Expected invalid outcome") }
            catch (_: IllegalArgumentException) { }
            try { store.finishApply(id, token, AiReviewState.APPLIED, listOf(AiReviewChange("ASSET_FROM", "", "bank text"))); fail("Expected invalid ID") }
            catch (_: IllegalArgumentException) { }
            assertEquals(AiReviewState.APPLYING, store.get(id)!!.state)
            assertTrue(store.finishApply(id, token, AiReviewState.APPLIED, applied))
            assertEquals(applied, store.get(id)!!.changes)
            assertEquals(proposal, store.history(id).first { it.action == "REVIEW_READY" }.changes)
            assertEquals(applied, store.history(id).last().changes)
            assertFalse(store.finishApply(id, token, AiReviewState.APPLIED, applied))
        }
    }

}
