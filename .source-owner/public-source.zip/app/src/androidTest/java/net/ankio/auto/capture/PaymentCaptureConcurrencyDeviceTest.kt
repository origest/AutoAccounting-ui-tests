package net.ankio.auto.capture

import android.graphics.Bitmap
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** Isolated synthetic directories only. No real screenshots, accounts or accessibility service. */
class PaymentCaptureConcurrencyDeviceTest {
    @Test fun clearAfterTheInitialPermissionReadPreventsLateTemporaryFileCreation() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-payment-capture-${UUID.randomUUID()}"
        val directory = File(context.noBackupFilesDir, name)
        val initialCheck = CountDownLatch(1)
        val resumeSave = CountDownLatch(1)
        val permitted = AtomicBoolean(true)
        val checks = AtomicInteger()
        val encoded = AtomicBoolean(false)
        val temporaryCreatedBeforeRecheck = AtomicBoolean(false)
        val executor = Executors.newSingleThreadExecutor()
        val bitmap = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
        val store = PaymentCaptureStore(context, name) { _, output ->
            encoded.set(true)
            output.write(1)
            true
        }
        try {
            val save = executor.submit<File> {
                store.save(bitmap) {
                    val allowed = permitted.get()
                    if (checks.incrementAndGet() == 1) {
                        initialCheck.countDown()
                        check(resumeSave.await(5, TimeUnit.SECONDS))
                    } else {
                        // The repeated permission check must run before any new temp file exists.
                        temporaryCreatedBeforeRecheck.set(directory.listFiles().orEmpty().any { it.extension == "tmp" })
                    }
                    allowed
                }
            }
            assertTrue(initialCheck.await(3, TimeUnit.SECONDS))
            synchronized(PaymentCaptureStore::class.java) {
                permitted.set(false)
                store.clear()
            }
            resumeSave.countDown()
            try {
                save.get(3, TimeUnit.SECONDS)
                fail("Old capture continued after clear")
            } catch (error: ExecutionException) {
                assertTrue(error.cause is IllegalStateException)
            }
            assertFalse("Encoding started after clear", encoded.get())
            assertFalse("A temporary file was created before permission was rechecked", temporaryCreatedBeforeRecheck.get())
            assertEquals(2, checks.get())
            assertTrue(directory.listFiles().orEmpty().isEmpty())
        } finally {
            resumeSave.countDown()
            executor.shutdownNow()
            executor.awaitTermination(5, TimeUnit.SECONDS)
            bitmap.recycle()
            directory.deleteRecursively()
        }
    }

    @Test fun revocationDoesNotWaitForEncodingAndPreventsPublication() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-payment-capture-${UUID.randomUUID()}"
        val directory = File(context.noBackupFilesDir, name)
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val permitted = AtomicBoolean(true)
        val executor = Executors.newFixedThreadPool(2)
        val bitmap = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
        val store = PaymentCaptureStore(context, name) { _, output ->
            entered.countDown()
            check(release.await(5, TimeUnit.SECONDS))
            output.write(1)
            true
        }
        try {
            val save = executor.submit<File> { store.save(bitmap) { permitted.get() } }
            assertTrue(entered.await(3, TimeUnit.SECONDS))
            // This is the same lock used by the settings page to revoke permission.
            val revoke = executor.submit<Boolean> {
                synchronized(PaymentCaptureStore::class.java) { permitted.set(false) }
                true
            }
            assertTrue("Revocation waited for encoding", revoke.get(1, TimeUnit.SECONDS))
            release.countDown()
            try {
                save.get(3, TimeUnit.SECONDS)
                fail("Revoked capture was published")
            } catch (error: ExecutionException) {
                assertTrue(error.cause is IllegalStateException)
            }
            assertTrue(store.files().isEmpty())
            assertTrue(directory.listFiles().orEmpty().isEmpty())
        } finally {
            release.countDown()
            executor.shutdownNow()
            executor.awaitTermination(5, TimeUnit.SECONDS)
            bitmap.recycle()
            directory.deleteRecursively()
        }
    }

    @Test fun concurrentCommitsRecheckTheFileCountLimit() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-payment-capture-${UUID.randomUUID()}"
        val directory = File(context.noBackupFilesDir, name).apply { mkdirs() }
        repeat(99) { File(directory, "fixture-$it.png").writeBytes(byteArrayOf(1)) }
        val entered = CountDownLatch(2)
        val release = CountDownLatch(1)
        val executor = Executors.newFixedThreadPool(2)
        val bitmap = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
        val store = PaymentCaptureStore(context, name) { _, output ->
            entered.countDown()
            check(release.await(5, TimeUnit.SECONDS))
            output.write(1)
            true
        }
        try {
            val saves = (1..2).map {
                executor.submit<Boolean> {
                    try { store.save(bitmap); true }
                    catch (_: IllegalStateException) { false }
                }
            }
            assertTrue(entered.await(3, TimeUnit.SECONDS))
            release.countDown()
            assertEquals(1, saves.count { it.get(3, TimeUnit.SECONDS) })
            assertEquals(100, store.files().size)
            assertFalse(directory.listFiles().orEmpty().any { it.extension == "tmp" })
        } finally {
            release.countDown()
            executor.shutdownNow()
            executor.awaitTermination(5, TimeUnit.SECONDS)
            bitmap.recycle()
            directory.deleteRecursively()
        }
    }
}
