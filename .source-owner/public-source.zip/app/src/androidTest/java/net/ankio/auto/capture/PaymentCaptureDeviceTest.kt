package net.ankio.auto.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.WindowManager
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

class PaymentCaptureDeviceTest {
    @Test fun privateImageRoundTripDeletionAndStorageCap() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = PaymentCaptureStore(context)
        store.clear()
        val bitmap = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
        try {
            val file = store.save(bitmap)
            assertTrue(file.canonicalPath.startsWith(context.noBackupFilesDir.canonicalPath + "/"))
            assertEquals(1, store.files().size)
            assertTrue(store.delete(file))
            assertFalse(file.exists())
            repeat(100) { store.save(bitmap) }
            try { store.save(bitmap); fail("Expected storage cap") } catch (_: IllegalStateException) { }
            assertEquals(100, store.files().size)
        } finally { bitmap.recycle(); store.clear() }
    }
    @Test fun openingSettingsDoesNotEnableCaptureOrRequestPermissions() {
        val i = InstrumentationRegistry.getInstrumentation()
        val prefs = i.targetContext.getSharedPreferences("payment-capture", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        val monitor = i.addMonitor(android.content.IntentFilter(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS), null, true)
        val activity = i.startActivitySync(Intent(i.targetContext, PaymentCaptureActivity::class.java).setAction(Intent.ACTION_MAIN).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        try {
            i.runOnMainSync {
                assertFalse(prefs.getBoolean("enabled", false))
                assertFalse(prefs.getBoolean("automatic", false))
                assertTrue(activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
                assertEquals(0, monitor.hits)
            }
            val info = i.targetContext.packageManager.getActivityInfo(android.content.ComponentName(i.targetContext, PaymentCaptureActivity::class.java), 0)
            assertFalse(info.exported)
        } finally { i.runOnMainSync { activity.finish() }; i.removeMonitor(monitor) }
    }
}
