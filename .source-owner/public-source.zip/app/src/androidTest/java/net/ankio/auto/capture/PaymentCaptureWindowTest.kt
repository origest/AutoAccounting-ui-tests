package net.ankio.auto.capture

import android.accessibilityservice.AccessibilityService
import android.app.UiAutomation
import android.content.Intent
import android.os.Build
import android.os.ParcelFileDescriptor
import android.view.WindowManager
import androidx.test.platform.app.InstrumentationRegistry
import com.google.android.accessibility.selecttospeak.SelectToSpeakService
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Synthetic settings window only. Run on an emulator with this app's accessibility service enabled. */
class PaymentCaptureWindowTest {
    @Test fun platformRejectsSecureWindowAndCapturesUnprotectedFixture() {
        assumeTrue(Build.VERSION.SDK_INT >= 34)
        val i = InstrumentationRegistry.getInstrumentation()
        assumeTrue(Build.HARDWARE in setOf("ranchu", "goldfish"))
        val automation = i.getUiAutomation(UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES)
        // Rebind after instrumentation starts; its process restart invalidates an earlier binding.
        fun shell(command: String) {
            ParcelFileDescriptor.AutoCloseInputStream(automation.executeShellCommand(command)).use { it.readBytes() }
        }
        shell("settings delete secure enabled_accessibility_services")
        shell("settings put secure enabled_accessibility_services net.ankio.auto/com.google.android.accessibility.selecttospeak.SelectToSpeakService")
        shell("settings put secure accessibility_enabled 1")
        val activity = i.startActivitySync(Intent(i.targetContext, PaymentCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        try {
            val deadline = System.currentTimeMillis() + 120000
            while (SelectToSpeakService.instance == null && System.currentTimeMillis() < deadline) Thread.sleep(100)
            val service = SelectToSpeakService.instance ?: error("Enable accessibility in the synthetic emulator before this test")
            fun screenshot(): Int {
                Thread.sleep(700) // platform screenshot interval and window accessibility propagation
                val latch = CountDownLatch(1)
                val result = AtomicInteger(-1)
                i.runOnMainSync {
                    // Obtain the ID from the known fixture itself, even if a system ANR
                    // dialog covers it. This tests the platform API, not foreground detection.
                    val node = activity.window.decorView.createAccessibilityNodeInfo()
                    val id = try { node.windowId } finally { node.recycle() }
                    assertTrue("Fixture must have a window ID", id >= 0)
                    service.takeScreenshotOfWindow(id, service.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                            screenshot.hardwareBuffer.close(); result.set(0); latch.countDown()
                        }
                        override fun onFailure(errorCode: Int) { result.set(errorCode); latch.countDown() }
                    })
                }
                assertTrue(latch.await(30, TimeUnit.SECONDS))
                return result.get()
            }
            assertEquals(AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW, screenshot())
            i.runOnMainSync { activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
            assertEquals(0, screenshot())
            i.runOnMainSync { activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE) }
            assertEquals(AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW, screenshot())
        } finally {
            i.runOnMainSync { activity.finish() }
            shell("settings delete secure enabled_accessibility_services")
            shell("settings put secure accessibility_enabled 0")
        }
    }
}
