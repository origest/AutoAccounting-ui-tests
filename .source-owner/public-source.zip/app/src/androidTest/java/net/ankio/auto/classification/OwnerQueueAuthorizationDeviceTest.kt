package net.ankio.auto.classification

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

/** Exercises production controller. Synthetic transport/storage only, no real accounts or provider.
 * These tests have not been compiled or run on a device in the local partial checkout.
 */
class OwnerQueueAuthorizationDeviceTest {
    private class Disk : OwnerQueueAuthorization.Persistence {
        var record: OwnerQueueAuthorization.Record? = null
        var fail = false
        override fun read() = record
        override fun write(record: OwnerQueueAuthorization.Record): Boolean {
            if (fail) return false
            this.record = record
            return true
        }
    }
    private class Wire : OwnerQueueAuthorization.Transport {
        var state = OwnerQueueAuthorization.Remote("source", 0, false, null)
        var loseAfterCommit = false
        var unavailable = false
        var beforeChange: (suspend () -> Unit)? = null
        var changes = 0
        override suspend fun read(): OwnerQueueAuthorization.Remote {
            check(!unavailable)
            return state
        }
        override suspend fun change(change: OwnerQueueAuthorization.Change): OwnerQueueAuthorization.Reply {
            beforeChange?.invoke()
            check(!unavailable)
            changes++
            val accepted = change.source == state.source && change.expectedRevision == state.revision
            if (accepted) state = OwnerQueueAuthorization.Remote(change.source, state.revision + 1, change.enabled, change.operationId)
            if (loseAfterCommit) { loseAfterCommit = false; error("lost response") }
            return OwnerQueueAuthorization.Reply(accepted, state)
        }
    }
    private fun fixture(block: suspend (Disk, Wire, OwnerQueueAuthorization) -> Unit) = runBlocking {
        val disk = Disk(); val wire = Wire()
        block(disk, wire, OwnerQueueAuthorization(disk, wire))
    }
    @Test fun defaultDeniesAndGrantRequiresAcknowledgedPersistence() = fixture { _, _, controller ->
        assertNull(controller.generation("source", "scope"))
        assertTrue(controller.beginGrant("source", "scope"))
        assertNull(controller.generation("source", "scope"))
        assertTrue(controller.reconcile())
        assertEquals(1L, controller.generation("source", "scope"))
    }
    @Test fun lostGrantReplyReconcilesExactOperationWithoutNewGeneration() = fixture { _, wire, controller ->
        controller.beginGrant("source", "scope"); wire.loseAfterCommit = true
        assertFalse(controller.reconcile()); assertNull(controller.generation("source", "scope"))
        val id = controller.snapshot().pending!!.operationId
        assertTrue(controller.reconcile()); assertEquals(id, wire.state.operationId)
        assertEquals(1, wire.changes); assertEquals(1L, controller.generation("source", "scope"))
    }
    @Test fun lostRevokeReplyBlocksGrantUntilReadAcknowledges() = fixture { _, wire, controller ->
        controller.beginGrant("source", "scope"); controller.reconcile()
        controller.stop(); wire.loseAfterCommit = true
        assertFalse(controller.reconcile()); assertFalse(controller.beginGrant("source", "scope"))
        assertTrue(controller.reconcile()); assertFalse(wire.state.enabled)
        assertTrue(controller.beginGrant("source", "scope"))
    }
    @Test fun stopDoesNotWaitForBlockedControlAndOldGrantCannotRestore() = fixture { _, wire, controller ->
        val entered = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>()
        wire.beforeChange = { entered.complete(Unit); release.await() }
        controller.beginGrant("source", "scope")
        coroutineScope {
            val inflight = async(Dispatchers.Default) { controller.reconcile() }
            entered.await()
            try {
                withTimeout(1000) { withContext(Dispatchers.Default) { assertTrue(controller.stop()) } }
                assertFalse(controller.beginGrant("source", "scope"))
                assertNull(controller.generation("source", "scope"))
                release.complete(Unit); assertTrue(inflight.await())
                assertFalse(wire.state.enabled); assertEquals(2L, wire.state.revision)
            } finally { release.complete(Unit) }
        }
    }
    @Test fun pendingRevokeSurvivesRestartAndTimeout() = fixture { disk, wire, controller ->
        controller.beginGrant("source", "scope"); controller.reconcile(); controller.stop()
        val id = controller.snapshot().pending!!.operationId
        wire.unavailable = true
        val restarted = OwnerQueueAuthorization(disk, wire)
        assertFalse(restarted.reconcile()); assertEquals(id, restarted.snapshot().pending!!.operationId)
        assertFalse(restarted.beginGrant("source", "scope"))
        wire.unavailable = false; assertTrue(restarted.reconcile()); assertFalse(wire.state.enabled)
    }
    @Test fun interruptedGrantOnRestartBecomesRevokeNotConsent() = fixture { disk, wire, controller ->
        controller.beginGrant("source", "scope"); wire.loseAfterCommit = true; controller.reconcile()
        val restarted = OwnerQueueAuthorization(disk, wire)
        assertFalse(restarted.snapshot().pending!!.enabled)
        assertTrue(restarted.reconcile()); assertFalse(wire.state.enabled)
        assertNull(restarted.generation("source", "scope"))
    }
    @Test fun writeFailureLatchesUntilAcknowledgedDurableRevoke() = fixture { disk, _, controller ->
        disk.fail = true
        assertFalse(controller.beginGrant("source", "scope")); assertTrue(controller.storageFailed)
        assertNull(controller.generation("source", "scope"))
        assertFalse(controller.stop()); assertFalse(controller.reconcile())
        disk.fail = false; assertTrue(controller.stop()); assertTrue(controller.reconcile())
        assertFalse(controller.storageFailed)
    }
    @Test fun sourceReplacementCannotAcknowledgeOldSourceRevoke() = fixture { _, wire, controller ->
        controller.beginGrant("source", "scope"); controller.reconcile(); controller.stop()
        wire.state = wire.state.copy(source = "replacement", enabled = false)
        assertFalse(controller.reconcile()); assertNotNull(controller.snapshot().pending)
        assertFalse(controller.beginGrant("replacement", "scope"))
    }
    @Test fun sameScopeRegrantPreservesCurrentTicketButLaterRevokeInvalidatesIt() = fixture { _, wire, controller ->
        controller.beginGrant("source", "scope"); controller.reconcile()
        val ticket = controller.generation("source", "scope")
        assertTrue(controller.beginGrant("source", "scope")); controller.reconcile()
        assertEquals(ticket, controller.generation("source", "scope")); assertEquals(1, wire.changes)
        controller.stop(); controller.reconcile(); controller.beginGrant("source", "scope"); controller.reconcile()
        assertNotEquals(ticket, controller.generation("source", "scope"))
    }
    @Test fun scopeChangeCannotAdoptExistingGeneration() = fixture { _, _, controller ->
        controller.beginGrant("source", "account/model/mode"); controller.reconcile()
        assertNull(controller.generation("source", "another/model/mode"))
        assertFalse(controller.beginGrant("source", "another/model/mode"))
    }
    @Test fun conflictingOperationCannotBeMistakenForAcknowledgement() = fixture { _, wire, controller ->
        controller.beginGrant("source", "scope")
        wire.beforeChange = { wire.state = wire.state.copy(revision = 4, enabled = true, operationId = "different") }
        assertFalse(controller.reconcile()); assertNull(controller.generation("source", "scope"))
        assertFalse(controller.snapshot().pending!!.enabled)
        wire.beforeChange = null; assertTrue(controller.reconcile()); assertFalse(wire.state.enabled)
    }
    @Test fun repeatedStopKeepsStableRevokeIdAndStillAdvancesDisabledServer() = fixture { _, wire, controller ->
        controller.stop("source"); val id = controller.snapshot().pending!!.operationId
        controller.stop("source"); assertEquals(id, controller.snapshot().pending!!.operationId)
        assertTrue(controller.reconcile()); assertEquals(1L, wire.state.revision)
        controller.stop(); assertTrue(controller.reconcile()); assertEquals(2L, wire.state.revision)
    }
    @Test fun corruptedRecordIsNeverOverwrittenOrClearedByCurrentHost() = fixture { disk, wire, _ ->
        disk.record = OwnerQueueAuthorization.Record("lost-source", -1, "scope", true)
        val original = disk.record
        val controller = OwnerQueueAuthorization(disk, wire)
        assertTrue(controller.corrupted); assertFalse(controller.stop("source"))
        assertFalse(controller.reconcile()); assertEquals(original, disk.record)
        assertFalse(controller.beginGrant("source", "scope")); assertEquals(0, wire.changes)
    }
    @Test fun malformedRemoteNeverBecomesARebasedIntent() = fixture { _, wire, controller ->
        controller.stop("source")
        val pending = controller.snapshot().pending
        wire.state = wire.state.copy(revision = -1)
        assertFalse(controller.reconcile()); assertEquals(pending, controller.snapshot().pending)
        assertEquals(0, wire.changes)
    }
    @Test fun failedAcknowledgmentWriteDoesNotAuthorizeOrSurviveAsGrant() = fixture { disk, wire, controller ->
        controller.beginGrant("source", "scope")
        wire.beforeChange = { disk.fail = true }
        assertFalse(controller.reconcile()); assertNull(controller.generation("source", "scope"))
        disk.fail = false; wire.beforeChange = null
        val restarted = OwnerQueueAuthorization(disk, wire)
        assertFalse(restarted.snapshot().pending!!.enabled)
        assertTrue(restarted.reconcile()); assertFalse(wire.state.enabled)
    }

    @Test fun presentNullOrBlankGsonPreferencesAreCorruptionNotFreshInstall() = runBlocking {
        val context = androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-auth-corruption-${java.util.UUID.randomUUID()}"
        val prefs = context.getSharedPreferences(name, android.content.Context.MODE_PRIVATE)
        try {
            val persistence = OwnerQueueAuthorizationPreferences(prefs)
            val valid = OwnerQueueAuthorization.Record("source", 1, "scope", true)
            assertTrue(persistence.write(valid)); assertEquals(valid, persistence.read())
            val saved = com.google.gson.Gson().fromJson(prefs.getString("serverAuthorization", null), com.google.gson.JsonObject::class.java)
            for (field in listOf("source", "revision", "scope", "enabled", "pending")) {
                val incomplete = saved.deepCopy()
                incomplete["record"].asJsonObject.remove(field)
                assertTrue(prefs.edit().putString("serverAuthorization", incomplete.toString()).commit())
                assertTrue(OwnerQueueAuthorization(persistence, Wire()).corrupted)
            }
            for (json in listOf("null", "", " ", "{}", "{broken", "{\"enabled\":true}",
                "{\"schema\":1,\"record\":{}}",
                "{\"schema\":1,\"record\":{\"source\":\"source\",\"revision\":1,\"scope\":\"scope\",\"enabled\":\"false\",\"pending\":null}}")) {
                assertTrue(prefs.edit().putString("serverAuthorization", json).commit())
                val wire = Wire()
                val controller = OwnerQueueAuthorization(OwnerQueueAuthorizationPreferences(prefs), wire)
                assertTrue(controller.corrupted)
                assertFalse(controller.stop("source")); assertFalse(controller.reconcile())
                assertEquals(json, prefs.getString("serverAuthorization", null)); assertEquals(0, wire.changes)
            }
        } finally { context.deleteSharedPreferences(name) }
    }

}
