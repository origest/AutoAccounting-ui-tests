package net.ankio.auto.classification

import android.content.Context
import android.content.SharedPreferences
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.lang.reflect.Proxy
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Real production permission boundary with isolated Android preferences and injected write failures.
 * No real queue, provider, account or worker schedule is changed.
 */
class OwnerQueuePermissionDeviceTest {
    private class FaultPreferences(val actual: SharedPreferences) : SharedPreferences by actual {
        var fault: String? = null
        var commits = 0
        override fun edit(): SharedPreferences.Editor {
            val editor = actual.edit()
            return Proxy.newProxyInstance(SharedPreferences.Editor::class.java.classLoader,
                arrayOf(SharedPreferences.Editor::class.java)) { proxy, method, args ->
                if (method.name == "commit") {
                    commits++
                    when (fault) {
                        "lost" -> false
                        "unacknowledged" -> { editor.commit(); false }
                        "throw" -> throw IllegalStateException("synthetic storage failure")
                        else -> editor.commit()
                    }
                } else {
                    val result = method.invoke(editor, *(args ?: emptyArray()))
                    if (result is SharedPreferences.Editor) proxy else result
                }
            } as SharedPreferences.Editor
        }
    }
    private fun fixture(block: (FaultPreferences, OwnerQueuePermissions) -> Unit) {
        val target = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-owner-permission-${UUID.randomUUID()}"
        val prefs = FaultPreferences(target.getSharedPreferences(name, Context.MODE_PRIVATE))
        try { block(prefs, OwnerQueuePermissions(prefs)) }
        finally { target.deleteSharedPreferences(name) }
    }
    private fun denied(block: () -> Unit) {
        try { block(); fail("Expected storage/blocked failure") } catch (_: IllegalStateException) { }
    }
    @Test fun oldEpochFailureCannotDisableTheCurrentAutomaticScope() = fixture { prefs, permissions ->
        assertTrue(prefs.edit().putLong("epoch", 2).putBoolean("automatic", true)
            .putBoolean("enabled", true).putString("source", "synthetic").commit())
        assertEquals(OwnerQueuePermissions.DisableResult.STALE,
            permissions.disableAutomaticIfCurrent(OwnerQueuePermissions.Stamp(1, 0)))
        assertTrue(prefs.getBoolean("automatic", false))
        assertEquals(2L, prefs.getLong("epoch", 0))
        assertEquals(OwnerQueuePermissions.DisableResult.DISABLED,
            permissions.disableAutomaticIfCurrent(permissions.stamp()))
        assertFalse(prefs.getBoolean("automatic", true))
        assertTrue(prefs.getBoolean("enabled", false))
        assertEquals("synthetic", prefs.getString("source", ""))
    }
    @Test fun sameEpochRegrantRejectsOldErrorAndPreservesManualActivationSemantics() = fixture { prefs, permissions ->
        permissions.activate(10, "first", 12)
        val old = permissions.stamp()
        permissions.activate(20, "second", 23)
        val current = permissions.stamp()
        assertEquals(old.epoch, current.epoch)
        assertEquals(old.automaticGrant + 1, current.automaticGrant)
        val writes = prefs.commits
        assertEquals(OwnerQueuePermissions.DisableResult.STALE, permissions.disableAutomaticIfCurrent(old))
        assertEquals(writes, prefs.commits)
        assertTrue(prefs.getBoolean("automatic", false))
        assertEquals("second", prefs.getString("source", ""))
        assertEquals(23L, prefs.getLong("cursor", 0))
        permissions.activate(5)
        assertEquals(current, permissions.stamp())
        assertTrue(prefs.getBoolean("automatic", false))
        assertEquals(23L, prefs.getLong("cursor", 0))
    }
    @Test fun failedStopTriesEveryBoundaryAndRequiresSuccessfulRetryBeforeActivation() {
        for (fault in listOf("lost", "unacknowledged", "throw")) fixture { prefs, permissions ->
            permissions.activate(10, "synthetic", 1)
            prefs.fault = fault
            val calls = mutableListOf<String>()
            val result = permissions.stop({ calls.add("tasks") }, { calls.add("provider") }, { calls.add("work") })
            assertFalse(result.settings)
            assertFalse(result.complete)
            assertTrue(result.tasks && result.provider && result.work)
            assertEquals(listOf("tasks", "provider", "work"), calls)
            assertTrue(permissions.blocked)
            assertNotNull(permissions.warning)
            // A failed acknowledgment alone says nothing about disk, including a restart.
            assertEquals(fault != "unacknowledged", prefs.getBoolean("enabled", false))
            denied { permissions.activate(10, "new", 2) }
            prefs.fault = null
            assertTrue(permissions.stop({}, {}, {}).complete)
            assertFalse(permissions.blocked)
            assertNull(permissions.warning)
            assertFalse(prefs.getBoolean("enabled", true))
        }
    }
    @Test fun taskAndProviderFailuresDoNotSkipWorkCancellation() = fixture { _, permissions ->
        var work = false
        val result = permissions.stop({ error("synthetic task failure") }, { error("synthetic provider failure") }, { work = true })
        assertTrue(result.settings)
        assertFalse(result.tasks)
        assertFalse(result.provider)
        assertTrue(result.work && work)
        assertTrue(permissions.blocked)
        assertNotNull(permissions.warning)
    }
    @Test fun failedActivationIsBlockedEvenWhenPreferencesAlreadyChangedInMemory() = fixture { prefs, permissions ->
        prefs.fault = "unacknowledged"
        denied { permissions.activate(10, "synthetic", 3) }
        assertTrue(prefs.getBoolean("enabled", false))
        assertTrue(prefs.getBoolean("automatic", false))
        assertTrue(permissions.blocked)
        assertNotNull(permissions.warning)
    }
    @Test fun failedCurrentErrorIsDistinctFromStaleError() = fixture { prefs, permissions ->
        permissions.activate(10, "synthetic", 0)
        val current = permissions.stamp()
        prefs.fault = "lost"
        assertEquals(OwnerQueuePermissions.DisableResult.STORAGE_FAILURE, permissions.disableAutomaticIfCurrent(current))
        assertTrue(permissions.blocked)
        assertTrue(prefs.getBoolean("automatic", false))
        assertNotNull(permissions.warning)
        val writes = prefs.commits
        assertEquals(OwnerQueuePermissions.DisableResult.STALE,
            permissions.disableAutomaticIfCurrent(current.copy(automaticGrant = current.automaticGrant - 1)))
        assertEquals(writes, prefs.commits)
    }
    @Test fun staleCursorCannotOverwriteNewGrantAndFailedCursorBlocksQueue() = fixture { prefs, permissions ->
        permissions.activate(10, "first", 10)
        val old = permissions.stamp()
        permissions.activate(10, "second", 50)
        assertFalse(permissions.saveCursor(old, 20))
        assertEquals(50L, prefs.getLong("cursor", 0))
        assertTrue(permissions.saveCursor(permissions.stamp(), 51))
        assertEquals(51L, prefs.getLong("cursor", 0))
        prefs.fault = "lost"
        denied { permissions.saveCursor(permissions.stamp(), 52) }
        assertTrue(permissions.blocked)
        assertNotNull(permissions.warning)
    }
    @Test fun cancellationExceptionIsPreservedAfterAllStopBoundariesAreAttempted() = fixture { _, permissions ->
        val original = CancellationException("synthetic cancellation")
        var provider = false
        var work = false
        try {
            permissions.stop({ throw original }, { provider = true }, { work = true })
            fail("Expected cancellation")
        } catch (actual: CancellationException) { assertSame(original, actual) }
        assertTrue(provider && work)
        assertTrue(permissions.blocked)
    }
    @Test fun stopDoesNotWaitForTheWorkerMutex() = fixture { _, permissions ->
        val executor = Executors.newSingleThreadExecutor()
        runBlocking { OwnerCategoryQueue.mutex.lock() }
        try {
            val stopped = executor.submit<Boolean> { permissions.stop({}, {}, {}).complete }
            assertTrue(stopped.get(3, TimeUnit.SECONDS))
            assertTrue(OwnerCategoryQueue.mutex.isLocked)
        } finally { OwnerCategoryQueue.mutex.unlock(); executor.shutdownNow() }
    }
    @Test fun delayedOldAuthorizationCompletionCannotRevokeNewGrant() = fixture { _, permissions ->
        permissions.activate(10, "source", 1)
        val old = permissions.stamp()
        permissions.stop({}, {}, {})
        permissions.activate(10, "source", 2)
        var revoked = false
        assertFalse(permissions.completeGrantIfCurrent(old) { revoked = true; permissions.stop({}, {}, {}) })
        assertFalse(revoked)
        assertTrue(permissions.completeGrantIfCurrent(permissions.stamp()) { revoked = true })
        assertTrue(revoked)
    }

}
