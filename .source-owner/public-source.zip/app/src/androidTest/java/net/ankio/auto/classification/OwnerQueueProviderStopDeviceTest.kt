package net.ankio.auto.classification

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import com.google.gson.Gson
import kotlinx.coroutines.runBlocking
import net.ankio.chatgpt.ChatGptAccounts
import net.ankio.chatgpt.ProbeClient
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Real permission -> accounts.pause -> ProbeClient.close integration, not Queue.stop/UI wiring.
 * Every HTTP request terminates in an application interceptor; it never calls proceed().
 * Only synthetic credentials and a UUID-named encrypted store are used. No singleton is changed.
 * Reflection is confined to test fixture setup/cleanup because chatgpt internals are another module.
 */
class OwnerQueueProviderStopDeviceTest {
    private class Fixture {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-owner-provider-stop-${UUID.randomUUID()}"
        val prefs = context.getSharedPreferences(name, Context.MODE_PRIVATE)
        val permissions = OwnerQueuePermissions(prefs)
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val calls = AtomicInteger()
        val http = OkHttpClient.Builder().addInterceptor { chain ->
            calls.incrementAndGet()
            entered.countDown()
            // Deliberately model a transport that ignores interruption and Call.cancel().
            // Test finally always releases this latch, including after a stop timeout.
            while (true) {
                try { release.await(); break } catch (_: InterruptedException) { }
            }
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1)
                .code(200).message("synthetic success")
                .header("Content-Type", "text/event-stream")
                .body(("data: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\"," +
                    "\"output\":[{\"type\":\"message\",\"role\":\"assistant\",\"content\":[" +
                    "{\"type\":\"output_text\",\"text\":\"synthetic-category\"}]}]}}\n\n")
                    .toResponseBody("text/event-stream".toMediaType()))
                .build()
        }.build()
        private val storeClass = Class.forName("net.ankio.chatgpt.CredentialStore")
        private val stateClass = Class.forName("net.ankio.chatgpt.AccountState")
        private val store = storeClass.getDeclaredConstructor(Context::class.java, String::class.java)
            .apply { isAccessible = true }.newInstance(context, name)
        lateinit var accounts: ChatGptAccounts
            private set
        val classifyExecutor = Executors.newSingleThreadExecutor()
        val stopExecutor = Executors.newSingleThreadExecutor()

        fun initialize() {
            // Seed only this fixture's store before constructing the real production account service.
            val state = Gson().fromJson("""{
                "host":"urn:uuid:synthetic-provider-stop", "active":"oaiapp_synthetic",
                "accounts":[{"label":1,"client":"oaiapp_synthetic","subjectHash":"synthetic",
                "access":"synthetic-not-a-token","refresh":"","idToken":"",
                "scopes":["resource.invoke","chatgpt.tokens.use.direct"],
                "expiresAt":${System.currentTimeMillis() + TimeUnit.HOURS.toMillis(1)},
                "model":"synthetic-model","consent":true,"paused":""}]
            }""", stateClass)
            storeClass.getDeclaredMethod("save", stateClass).apply { isAccessible = true }.invoke(store, state)
            accounts = newAccounts()
            assertTrue(accounts.view().accounts.single().enabled)
            permissions.activate(1, "synthetic-source", 1)
        }

        fun newAccounts(): ChatGptAccounts {
            val factory: () -> ProbeClient = { ProbeClient(http) }
            return ChatGptAccounts::class.java.declaredConstructors.single { it.parameterTypes.size == 3 }
                .apply { isAccessible = true }.newInstance(context, factory, name) as ChatGptAccounts
        }

        fun shutdownAccounts(value: ChatGptAccounts) {
            value.cancel()
            val executor = ChatGptAccounts::class.java.getDeclaredField("requests")
                .apply { isAccessible = true }.get(value) as ExecutorService
            executor.shutdownNow()
            assertTrue("Production request executor did not terminate", executor.awaitTermination(5, TimeUnit.SECONDS))
        }

        fun close() {
            release.countDown()
            try {
                if (::accounts.isInitialized) shutdownAccounts(accounts)
            } finally {
                classifyExecutor.shutdownNow()
                stopExecutor.shutdownNow()
                try {
                    assertTrue(classifyExecutor.awaitTermination(5, TimeUnit.SECONDS))
                    assertTrue(stopExecutor.awaitTermination(5, TimeUnit.SECONDS))
                } finally {
                    http.dispatcher.executorService.shutdownNow()
                    http.connectionPool.evictAll()
                    storeClass.getDeclaredMethod("clear").apply { isAccessible = true }.invoke(store)
                    context.deleteSharedPreferences(name)
                }
            }
        }
    }

    @Test fun syntheticTransportCanCompleteRealClassificationBeforePause() {
        val fixture = Fixture()
        try {
            fixture.initialize()
            fixture.release.countDown()
            val output = fixture.classifyExecutor.submit<String> {
                runBlocking { fixture.accounts.classify("synthetic instruction", "synthetic input") }
            }
            assertEquals("synthetic-category", output.get(5, TimeUnit.SECONDS))
            assertEquals(1, fixture.calls.get())
        } finally { fixture.close() }
    }

    @Test fun permissionStopPausesRealAccountsWhileClassificationTransportRemainsBlocked() {
        val fixture = Fixture()
        try {
            fixture.initialize()
            val outcome = fixture.classifyExecutor.submit<Result<String>> {
                runCatching { runBlocking { fixture.accounts.classify("synthetic instruction", "synthetic input") } }
            }
            assertTrue("Real classify request never reached synthetic transport", fixture.entered.await(5, TimeUnit.SECONDS))
            assertFalse(outcome.isDone)
            val boundaries = mutableListOf<String>()
            val stopped = fixture.stopExecutor.submit<OwnerQueuePermissions.StopResult> {
                fixture.permissions.stop(
                    { boundaries.add("tasks") },
                    { fixture.accounts.pause(); boundaries.add("provider") },
                    { boundaries.add("work") }
                )
            }.get(3, TimeUnit.SECONDS)
            assertTrue(stopped.localComplete)
            assertEquals(listOf("tasks", "provider", "work"), boundaries)
            assertEquals("Stop must not release the blocked transport", 1L, fixture.release.count)
            assertFalse("Classification should remain inside the blocked transport", outcome.isDone)
            assertFalse(fixture.accounts.view().accounts.single().enabled)
            assertFalse(fixture.prefs.getBoolean("enabled", true))
            assertFalse(fixture.prefs.getBoolean("automatic", true))
            // Read back the isolated encrypted store through a new real account service.
            val reloaded = fixture.newAccounts()
            try { assertFalse(reloaded.view().accounts.single().enabled) }
            finally { fixture.shutdownAccounts(reloaded) }
            fixture.release.countDown()
            val late = outcome.get(5, TimeUnit.SECONDS)
            assertTrue("Cancelled provider output must never be accepted", late.isFailure)
            assertFalse(fixture.accounts.view().accounts.single().enabled)
            assertEquals("Pause must not retry the provider", 1, fixture.calls.get())
        } finally { fixture.close() }
    }
}
