package net.ankio.auto.classification

import androidx.test.platform.app.InstrumentationRegistry
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.OwnerQueueInput
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class OwnerQueueStoreDeviceTest {
    private fun fixture(id: Long) = OwnerQueueInput("synthetic-source", BillInfoModel(id = id, categoryOrigin = "RULE"), emptyList(), emptyList())
    @Test fun competingWorkersCanDebitAndDispatchOnlyOnce() {
        val c = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-queue-${UUID.randomUUID()}.db"
        val executor = Executors.newFixedThreadPool(2)
        try {
            OwnerQueueStore(c, name).use { assertTrue(it.enqueue(fixture(1), false, 1)) }
            val start = CountDownLatch(1)
            val futures = (1..2).map { executor.submit<Boolean> { OwnerQueueStore(c, name).use { start.await(); it.dispatch("synthetic-source:1", 1, 1, 10_000_000) } } }
            start.countDown()
            assertEquals(1, futures.count { it.get(20, TimeUnit.SECONDS) })
            OwnerQueueStore(c, name).use { store ->
                store.recover()
                assertTrue(store.summary().contains("UNKNOWN: 1"))
                assertFalse(store.enqueue(fixture(1), false, 2))
                assertTrue(store.enqueue(fixture(2), false, 2))
                assertFalse(store.dispatch("synthetic-source:2", 2, 1, 10_000_001))
                assertTrue(store.dispatch("synthetic-source:2", 2, 1, 13_600_001))
            }
        } finally { executor.shutdownNow(); File(c.noBackupFilesDir, name).delete() }
    }
    @Test fun cancellationBeforeSendCanBeExplicitlyEnqueuedAgainButSentAttemptCannot() {
        val c = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-queue-${UUID.randomUUID()}.db"
        try { OwnerQueueStore(c, name).use { store ->
            store.enqueue(fixture(1), true, 1); store.cancel()
            assertFalse(store.contains(fixture(1)))
            assertTrue(store.enqueue(fixture(1), true, 2))
            assertTrue(store.dispatch("synthetic-source:1", 2, 10, 1000))
            store.cancel()
            assertTrue(store.contains(fixture(1)))
            assertFalse(store.enqueue(fixture(1), true, 3))
        } } finally { File(c.noBackupFilesDir, name).delete() }
    }
    @Test fun staleMutationsCannotRestoreCancelledOrReenqueuedTasks() {
        val c = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-queue-${UUID.randomUUID()}.db"
        try { OwnerQueueStore(c, name).use { store ->
            assertTrue(store.enqueue(fixture(1), true, 1))
            assertTrue(store.dispatch("synthetic-source:1", 1, 10, 1000))
            store.cancel()
            assertFalse(store.status("synthetic-source:1", 1, "DISPATCHED", "RESULT", "synthetic"))
            assertTrue(store.summary().contains("UNKNOWN: 1"))
            assertNull(store.next())

            assertTrue(store.enqueue(fixture(2), true, 1))
            store.cancel()
            assertTrue(store.enqueue(fixture(2), true, 2))
            assertFalse(store.status("synthetic-source:2", 1, "READY", "CANCELLED"))
            assertFalse(store.dispatch("synthetic-source:2", 1, 10, 1001))
            assertEquals(2L, store.next()!!.epoch)
            assertTrue(store.dispatch("synthetic-source:2", 2, 10, 1001))
            assertTrue(store.status("synthetic-source:2", 2, "DISPATCHED", "RESULT", "synthetic"))
            assertEquals(2L, store.next()!!.input.bill.id)
        } } finally { File(c.noBackupFilesDir, name).delete() }
    }
    @Test fun legacyMigrationCancelsPayloadsButRetainsUnknownAndAttemptLedger() {
        val c = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "test-queue-migration-${UUID.randomUUID()}.db"
        val file = File(c.noBackupFilesDir, name)
        try {
            android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(file, null).use { db ->
                db.execSQL("CREATE TABLE task (key TEXT PRIMARY KEY, payload TEXT NOT NULL, legacy INTEGER NOT NULL, epoch INTEGER NOT NULL, state TEXT NOT NULL, response TEXT NOT NULL DEFAULT '', mode TEXT NOT NULL)")
                db.execSQL("CREATE TABLE attempt (key TEXT PRIMARY KEY, sent INTEGER NOT NULL)")
                db.execSQL("INSERT INTO task VALUES ('synthetic-source:1','legacy',1,1,'READY','','OCR')")
                db.execSQL("INSERT INTO task VALUES ('synthetic-source:2','legacy',1,1,'DISPATCHED','','OCR')")
                db.execSQL("INSERT INTO attempt VALUES ('synthetic-source:2',1000)")
                db.version = 1
            }
            OwnerQueueStore(c, name).use { store ->
                assertNull(store.next())
                assertTrue(store.summary().contains("CANCELLED: 1"))
                assertTrue(store.summary().contains("UNKNOWN: 1"))
                assertFalse(store.enqueue(fixture(2), true, 2, 5))
                assertTrue(store.enqueue(fixture(1), true, 2, 5))
                assertEquals(5L, store.next()!!.generation)
                assertEquals(1L, android.database.DatabaseUtils.longForQuery(store.readableDatabase, "SELECT COUNT(*) FROM attempt", null))
            }
        } finally { file.delete() }
    }

}
