package net.ankio.auto.service.ocr

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class OcrTextAttemptStoreDeviceTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    @Test fun concurrentClaimsOnlyDispatchOneAndSurviveReopen() {
        val name = "ocr-test-${UUID.randomUUID()}.db"
        val key = OcrTextAttemptStore.fingerprint("synthetic.app", "synthetic text")
        val pool = Executors.newFixedThreadPool(2)
        try {
            OcrTextAttemptStore(context, name).use { it.writableDatabase }
            val start = CountDownLatch(1)
            val results = (1..2).map { pool.submit<OcrTextAttemptStore.Claim> {
                OcrTextAttemptStore(context, name).use { start.await(); it.claim(key, 1, 10000, 10) }
            } }
            start.countDown()
            assertEquals(1, results.count { it.get(10, TimeUnit.SECONDS) == OcrTextAttemptStore.Claim.ACCEPTED })
            OcrTextAttemptStore(context, name).use {
                assertEquals("DISPATCHED", it.find(key)!!.state)
                assertEquals(OcrTextAttemptStore.Claim.DUPLICATE, it.claim(key, 2, 10001, 10))
                assertTrue(it.finish(key, "UNKNOWN"))
                assertFalse(it.finish(key, "SUCCEEDED", 99))
            }
            OcrTextAttemptStore(context, name).use {
                assertEquals("UNKNOWN", it.find(key)!!.state)
                assertEquals(OcrTextAttemptStore.Claim.DUPLICATE, it.claim(key, 2, 10002, 10))
            }
        } finally { pool.shutdownNow(); File(context.noBackupFilesDir, name).delete() }
    }
    @Test fun budgetAndFingerprintHaveIndependentSources() {
        val name = "ocr-test-${UUID.randomUUID()}.db"
        try { OcrTextAttemptStore(context, name).use {
            val first = OcrTextAttemptStore.fingerprint("synthetic.app", "synthetic")
            val second = OcrTextAttemptStore.fingerprint("synthetic.app", "synthetic", "NOTICE")
            assertNotEquals(first, second)
            assertEquals(OcrTextAttemptStore.Claim.ACCEPTED, it.claim(first, 1, 4_000_000, 1))
            assertEquals(OcrTextAttemptStore.Claim.LIMIT, it.claim(second, 2, 4_000_001, 1))
            assertEquals(OcrTextAttemptStore.Claim.ACCEPTED, it.claim(second, 2, 7_600_001, 1))
            it.readableDatabase.rawQuery("PRAGMA table_info(attempt)", null).use { cursor ->
                val names = buildList { while (cursor.moveToNext()) add(cursor.getString(1)) }
                assertEquals(listOf("fingerprint", "state", "sent", "raw_id", "bill_id"), names)
            }
        } } finally { File(context.noBackupFilesDir, name).delete() }
    }
}
