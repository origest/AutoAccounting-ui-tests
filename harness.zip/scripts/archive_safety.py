"""Strict source ZIP extraction, including duplicate and symlink rejection."""
import hashlib
import os
import shutil
from pathlib import Path, PurePosixPath
import stat
import zipfile

from safe_scratch import MIN_FREE


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def unpack_zip(path, destination, *, max_bytes=4*1024**3, minimum_free=0):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    entries = []
    names = set()
    total = 0
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = info.filename
            clean = name[:-1] if info.is_dir() else name
            p = PurePosixPath(clean)
            mode = info.external_attr >> 16
            if (info.orig_filename != name or '\x00' in info.orig_filename
                    or not clean or '\\' in name or '\x00' in name or p.is_absolute()
                    or '..' in p.parts or '.' in clean.split('/') or '//' in name
                    or str(p) != clean or clean in names
                    or stat.S_ISLNK(mode)
                    or stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError('Unsafe ZIP entry')
            names.add(clean)
            total += info.file_size
            if total > max_bytes:
                raise ValueError('ZIP expansion exceeds bound')
            entries.append(info)
        for info in entries:
            target = destination / info.filename
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as src, target.open('xb') as dst:
                    while chunk := src.read(1024*1024):
                        if minimum_free and shutil.disk_usage(destination).free < minimum_free + len(chunk) + 16*1024**2:
                            raise ValueError('Insufficient reserved extraction space')
                        dst.write(chunk)
                # Keep executable tool bits; strip setuid/setgid and group/world write.
                target.chmod(0o755 if (info.external_attr >> 16) & 0o111 else 0o644)



# One exact official API 33 image exceeds the generic 4 GiB ZIP budget.
# These values are a reviewed identity contract, not configurable upper limits.
AOSP33_ARCHIVE_SIZE = 694005732
AOSP33_ARCHIVE_SHA256 = '297a7384ceb7a3d050d78c98c11e166dd3985ccb72bfa6d13b56b71a4aa5bc22'
AOSP33_EXPANDED_SIZE = 4457578928
AOSP33_MEMBERS = (
    ('x86_64/NOTICE.txt', 3372624, 0o100644), 
    ('x86_64/VerifiedBootParams.textproto', 356, 0o100644), 
    ('x86_64/advancedFeatures.ini', 667, 0o100644), 
    ('x86_64/build.prop', 4454, 0o100644), 
    ('x86_64/encryptionkey.img', 18874368, 0o100644), 
    ('x86_64/kernel-ranchu', 23484160, 0o100644), 
    ('x86_64/ramdisk.img', 3588735, 0o100644), 
    ('x86_64/source.properties', 370, 0o100644), 
    ('x86_64/system.img', 4306501632, 0o100644), 
    ('x86_64/userdata.img', 1048576, 0o100644), 
    ('x86_64/vendor.img', 100663296, 0o100644), 
    ('x86_64/data/local.prop', 46, 0o100644), 
    ('x86_64/data/misc/apns/apns-conf.xml', 6575, 0o100644), 
    ('x86_64/data/misc/emulator/version.txt', 61, 0o100644), 
    ('x86_64/data/misc/emulator/config/radioconfig.xml', 1433, 0o100644), 
    ('x86_64/data/misc/gceconfigs/gpu.config', 94, 0o100644), 
    ('x86_64/data/misc/modem_simulator/iccprofile_for_carrierapitests.xml', 16537, 0o100644), 
    ('x86_64/data/misc/modem_simulator/iccprofile_for_sim0.xml', 14647, 0o100644), 
    ('x86_64/data/misc/modem_simulator/etc/modem_simulator/files/numeric_operator.xml', 297, 0o100644), 
)


def _check_aosp33_members(infos):
    observed = tuple((info.orig_filename, info.file_size, info.external_attr >> 16) for info in infos)
    if (observed != AOSP33_MEMBERS
            or any(info.filename != info.orig_filename or info.is_dir()
                   or not stat.S_ISREG(info.external_attr >> 16) for info in infos)
            or sum(info.file_size for info in infos) != AOSP33_EXPANDED_SIZE):
        raise ValueError('Pinned AOSP image member contract mismatch')


def unpack_pinned_aosp33(path, destination):
    """Use the measured budget only after exact full archive and member checks.

    The same no-follow regular-file handle is hashed, inspected and extracted.
    Source and every other tool retain their existing ZIP limits.
    """
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or before.st_uid != os.getuid() or before.st_size != AOSP33_ARCHIVE_SIZE):
            raise ValueError('Pinned AOSP image archive size or ownership mismatch')
        if hashlib.file_digest(stream, 'sha256').hexdigest() != AOSP33_ARCHIVE_SHA256:
            raise ValueError('Pinned AOSP image archive hash mismatch')
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive:
            _check_aosp33_members(archive.infolist())
        # Archive already occupies disk. Reserve its full expansion plus the
        # unchanged post-extraction 8.2 GiB gate and small filesystem headroom.
        required = AOSP33_EXPANDED_SIZE + MIN_FREE + 16*1024**2
        if shutil.disk_usage(Path(destination).parent).free < required:
            raise ValueError('Insufficient space for pinned AOSP image expansion')
        stream.seek(0)
        unpack_zip(stream, destination, max_bytes=AOSP33_EXPANDED_SIZE, minimum_free=MIN_FREE)
        after = os.fstat(stream.fileno())
        if ((after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                != (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)):
            raise ValueError('Pinned AOSP image archive changed during extraction')
        if shutil.disk_usage(destination).free < MIN_FREE:
            raise ValueError('Insufficient reserved space after image extraction')
