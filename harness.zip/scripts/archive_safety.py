"""Strict source ZIP extraction, including duplicate and symlink rejection."""
import hashlib
from pathlib import Path, PurePosixPath
import stat
import zipfile


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def unpack_zip(path, destination, *, max_bytes=4*1024**3):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    entries = []
    names = set()
    total = 0
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = info.filename
            clean = name[:-1] if info.is_dir() else name
            p = PurePosixPath(clean)
            mode = info.external_attr >> 16
            if (info.orig_filename != name or '\x00' in info.orig_filename
                    or not clean or '\\' in name or '\x00' in name or p.is_absolute()
                    or '..' in p.parts or '.' in clean.split('/') or '//' in name
                    or str(p) != clean or clean in names
                    or stat.S_ISLNK(mode)
                    or stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError('Unsafe ZIP entry')
            names.add(clean)
            total += info.file_size
            if total > max_bytes:
                raise ValueError('ZIP expansion exceeds bound')
            entries.append(info)
        for info in entries:
            target = destination / info.filename
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as src, target.open('xb') as dst:
                    while chunk := src.read(1024*1024):
                        dst.write(chunk)
                # Keep executable tool bits; strip setuid/setgid and group/world write.
                target.chmod(0o755 if (info.external_attr >> 16) & 0o111 else 0o644)

