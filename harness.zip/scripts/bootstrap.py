"""Hash-bound flat-upload harness bootstrap; does not execute extracted code."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tempfile
import zipfile

SCRIPT_NAMES = {
    'archive_safety.py', 'bootstrap.py', 'kvm_access.py', 'manifest_audit.py',
    'public_evidence.py', 'result_parser.py', 'run_ui.py', 'safe_scratch.py',
    'source_contract.py', 'test_archive_safety.py', 'test_bootstrap.py',
    'test_kvm_access.py', 'test_manifest_audit.py', 'test_public_contract.py',
    'test_public_evidence.py', 'test_result_parser.py', 'test_safe_scratch.py',
    'test_source_contract.py',
}
EXPECTED_FILES = {'runtime-lock.json', 'expected-tests.json'} | {'scripts/'+n for n in SCRIPT_NAMES}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError('Duplicate config key')
        result[key] = value
    return result


def bootstrap(workspace, runner_temp, expected_hash, expected_size):
    workspace = Path(workspace)
    runner_temp = Path(runner_temp)
    for directory in (workspace, runner_temp):
        st = directory.lstat()
        if (not stat.S_ISDIR(st.st_mode) or directory.resolve() != directory
                or st.st_uid != os.getuid()): raise ValueError('Unsafe bootstrap directory')
    if not re.fullmatch('[0-9a-f]{64}', expected_hash): raise ValueError('Invalid harness pin')
    bundle = workspace/'harness.zip'
    st = bundle.lstat()
    if (not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_uid != os.getuid()
            or st.st_size != expected_size or not 0 < st.st_size <= 512*1024):
        raise ValueError('Invalid harness archive')
    raw = bundle.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_hash: raise ValueError('Harness hash mismatch')
    for name in ('scripts', 'runtime-lock.json', 'expected-tests.json'):
        if os.path.lexists(workspace/name): raise ValueError('Harness destination already exists')
    stage = Path(tempfile.mkdtemp(prefix='aa-harness-bootstrap-', dir=runner_temp))
    names, total = set(), 0
    # BytesIO keeps the checked bytes bound to extraction, with no path reopening.
    from io import BytesIO
    with zipfile.ZipFile(BytesIO(raw)) as archive:
        entries = archive.infolist()
        for info in entries:
            name = info.filename
            p = PurePosixPath(name)
            mode = info.external_attr >> 16
            if (info.orig_filename != name or '\x00' in info.orig_filename or name not in EXPECTED_FILES
                    or p.is_absolute() or str(p) != name or '\\' in name
                    or '..' in p.parts or '.' in name.split('/') or name in names
                    or info.is_dir() or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                    or info.flag_bits & 1): raise ValueError('Unsafe harness member')
            total += info.file_size
            if info.file_size > 128*1024 or total > 2*1024*1024: raise ValueError('Oversized harness')
            names.add(name)
        if names != EXPECTED_FILES: raise ValueError('Incomplete harness')
        for info in entries:
            target = stage/info.filename
            target.parent.mkdir(mode=0o700, exist_ok=True)
            data = archive.read(info)
            if len(data) != info.file_size: raise ValueError('Harness size mismatch')
            with target.open('xb') as out: out.write(data)
            target.chmod(0o600)
    cfg = json.loads((stage/'runtime-lock.json').read_text(), object_pairs_hook=unique_object)
    if (cfg.get('publication_review') != 'approved'
            or cfg.get('repository') != 'origest/AutoAccounting-ui-tests'
            or cfg['repository'] != os.environ['GITHUB_REPOSITORY']
            or cfg.get('public_scope') != 'source-only-no-apk'
            or cfg.get('temporary_kvm_uid_acl_authorized') is not True):
        raise ValueError('Unapproved harness scope')
    for name in ('scripts', 'runtime-lock.json', 'expected-tests.json'):
        if os.path.lexists(workspace/name): raise ValueError('Harness destination appeared')
        os.rename(stage/name, workspace/name)
    stage.rmdir()
