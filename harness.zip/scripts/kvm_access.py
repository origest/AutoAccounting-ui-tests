"""One authorized temporary current-UID KVM ACL lease; no broad permissions."""
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile


from safe_scratch import validate

DEVICE='/dev/kvm'
LEASE='.kvm-lease.json'
REQUIRED='.kvm-lease-required.json'


class KvmError(Exception): pass


RESTORE_PHASES=frozenset({'scratch_validate','lease_load','device_check','acl_read',
    'acl_compare','restore_command','restore_readback','receipt_commit','complete'})
RESTORE_REASONS=frozenset({'NONE','SCRATCH_INVALID','SCRATCH_IO_FAILED','LEASE_IO_FAILED',
    'DEVICE_IO_FAILED','ACL_IO_FAILED','KVM_ACL_INVALID','KVM_ACL_DUPLICATE',
    'KVM_ACL_INCOMPLETE','KVM_ACL_MISSING_MASK','KVM_MASK_NOT_RW','KVM_DEVICE_INVALID',
    'KVM_ACL_READ_FAILED','KVM_LEASE_INVALID','KVM_LEASE_CHANGED','KVM_LEASE_MISSING',
    'KVM_LEASE_SCOPE','KVM_LEASE_DIFFERENCE','KVM_DEVICE_CHANGED',
    'KVM_ACL_CHANGED_EXTERNALLY','KVM_RESTORE_COMMAND_FAILED','KVM_RESTORE_COMMAND_TIMEOUT',
    'KVM_RESTORE_NOT_VERIFIED','RECEIPT_WRITE_FAILED','INVALID_DATA','IO_FAILED',
    'OPERATION_TIMEOUT','UNEXPECTED_FAILURE'})
ACL_READBACK=frozenset({'not_checked','lease','original','unexpected','unavailable'})
RECEIPT_STATES=frozenset({'not_loaded','not_needed','pending','committed','failed'})
ACL_DIFFERENCE_FIELDS=frozenset({'owner_permissions_changed','owning_group_permissions_changed',
    'other_permissions_changed','mask_changed','current_uid_entry_changed','other_named_entries_changed'})


class KvmRestoreError(KvmError):
    def __init__(self,result):
        super().__init__(result['diagnostic']['reason'])
        self.result=result


def _restore_reason(error,phase):
    # Never publish exception messages, paths, UID, ACL text or raw stderr.
    if isinstance(error,KvmError) and str(error) in RESTORE_REASONS:
        return str(error)
    if phase=='receipt_commit': return 'RECEIPT_WRITE_FAILED'
    if isinstance(error,subprocess.TimeoutExpired):
        return 'KVM_RESTORE_COMMAND_TIMEOUT' if phase=='restore_command' else 'OPERATION_TIMEOUT'
    if isinstance(error,OSError):
        return {'scratch_validate':'SCRATCH_IO_FAILED','lease_load':'LEASE_IO_FAILED',
                'device_check':'DEVICE_IO_FAILED','acl_read':'ACL_IO_FAILED'}.get(phase,'IO_FAILED')
    if isinstance(error,(ValueError,KeyError,TypeError)):
        return 'SCRATCH_INVALID' if phase=='scratch_validate' else 'INVALID_DATA'
    return 'UNEXPECTED_FAILURE'


def parse_acl(text):
    acl={}
    for line in text.splitlines():
        line=line.split('#',1)[0].strip()
        if not line: continue
        match=re.fullmatch(r'(user|group|mask|other):(\d*):([r-][w-][x-])',line)
        if not match or (match[1] in ('mask','other') and match[2]): raise KvmError('KVM_ACL_INVALID')
        key=match[1]+':'+match[2]
        if key in acl: raise KvmError('KVM_ACL_DUPLICATE')
        acl[key]=match[3]
    if not {'user:','group:','other:'}.issubset(acl): raise KvmError('KVM_ACL_INCOMPLETE')
    named=any(k not in ('user:','group:','mask:','other:') for k in acl)
    if named and 'mask:' not in acl: raise KvmError('KVM_ACL_MISSING_MASK')
    return acl


def text_acl(acl): return ''.join(k+':'+acl[k]+'\n' for k in sorted(acl))


def acl_difference(current,before,after,uid):
    """Classify already parsed ACLs without another device read or raw output.

    Owner/group fields describe ACL permissions, not numeric ownership. Both
    references matter: a difference from the lease alone might be the original
    ACL. No category identifies an actor, cause, or time of change.
    """
    current_key='user:'+str(uid)
    fields={'owner_permissions_changed':'user:','owning_group_permissions_changed':'group:',
            'other_permissions_changed':'other:','mask_changed':'mask:',
            'current_uid_entry_changed':current_key}
    excluded=set(fields.values())
    other=lambda acl:{key:value for key,value in acl.items() if key not in excluded}
    def difference(reference):
        result={name:current.get(key)!=reference.get(key) for name,key in fields.items()}
        result['other_named_entries_changed']=other(current)!=other(reference)
        return result
    return {'from_original':difference(before),'from_lease':difference(after)}


def expected_after(before,uid):
    # Validate the persisted original and prove the only permitted difference.
    before=parse_acl(text_acl(before))
    if before.get('mask:',before['group:'])!='rw-': raise KvmError('KVM_MASK_NOT_RW')
    after=before.copy(); after['user:'+str(uid)]='rw-'
    after.setdefault('mask:',before['group:'])
    return after


class System:
    def identity(self):
        st=os.lstat(DEVICE)
        if not stat.S_ISCHR(st.st_mode) or (os.major(st.st_rdev),os.minor(st.st_rdev))!=(10,232):
            raise KvmError('KVM_DEVICE_INVALID')
        return {'device':st.st_dev,'inode':st.st_ino,'rdev':st.st_rdev,'uid':st.st_uid,'gid':st.st_gid}

    def acl(self):
        p=subprocess.run(['/usr/bin/getfacl','--absolute-names','--omit-header','--numeric',DEVICE],
                         capture_output=True,text=True,timeout=10)
        if p.returncode: raise KvmError('KVM_ACL_READ_FAILED')
        return parse_acl(p.stdout)

    def writable(self): return os.access(DEVICE,os.R_OK|os.W_OK)

    def grant(self,uid):
        return subprocess.run(['/usr/bin/sudo','-n','/usr/bin/setfacl','--no-mask','-m',
                               'u:'+str(uid)+':rw-',DEVICE],capture_output=True,timeout=10).returncode

    def restore(self,before,uid):
        key='user:'+str(uid)
        if key in before:
            operation=['-m','u:'+str(uid)+':'+before[key]]
        else:
            # Remove only this UID, and the automatically added mask if originally absent.
            operation=['-x','u:'+str(uid)+('' if 'mask:' in before else ',m')]
        return subprocess.run(['/usr/bin/sudo','-n','/usr/bin/setfacl','--no-mask',*operation,DEVICE],
                              capture_output=True,timeout=10).returncode


def write_lease(path,data,*,new=False):
    # Persist before changing /dev/kvm, so a later always-step can restore it.
    if new:
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'w') as out:
            json.dump(data,out); out.flush(); os.fsync(out.fileno())
        return
    # Keep the last complete receipt if serialization, write or fsync fails.
    # This is not a guarantee against VM loss, SIGKILL or storage failure.
    st=path.lstat()
    if (not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_nlink!=1
            or stat.S_IMODE(st.st_mode)!=0o600): raise KvmError('KVM_LEASE_INVALID')
    fd,temporary=tempfile.mkstemp(prefix='.kvm-lease-update-',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as out:
            json.dump(data,out); out.flush(); os.fsync(out.fileno())
        current=path.lstat()
        if (current.st_dev,current.st_ino)!=(st.st_dev,st.st_ino): raise KvmError('KVM_LEASE_CHANGED')
        os.replace(temporary,path)
    finally:
        if os.path.lexists(temporary): os.unlink(temporary)


def _unique_json(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise KvmError('KVM_LEASE_INVALID')
        result[key]=value
    return result


def _read_private_json(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        before=os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_nlink!=1
                or stat.S_IMODE(before.st_mode)!=0o600 or before.st_size>16384):
            raise KvmError('KVM_LEASE_INVALID')
        raw=os.read(fd,16385)
        after=os.fstat(fd); current=path.lstat()
        fields=lambda st:(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns,st.st_mode,st.st_nlink,st.st_uid)
        if len(raw)>16384 or fields(before)!=fields(after) or fields(after)!=fields(current):
            raise KvmError('KVM_LEASE_CHANGED')
        return json.loads(raw,object_pairs_hook=_unique_json)
    finally: os.close(fd)


def load_lease(root,identity):
    validate(root,identity)
    path=root/LEASE
    if path.is_symlink(): raise KvmError('KVM_LEASE_INVALID')
    if not path.exists():
        if (root/REQUIRED).exists() or (root/REQUIRED).is_symlink(): raise KvmError('KVM_LEASE_MISSING')
        return None
    data=_read_private_json(path)
    fields={'schema','identity','runner_uid','device_path','device','before','after','restored','applied'}
    if (not isinstance(data,dict) or set(data)!=fields or type(data['schema']) is not int
            or data['schema']!=1 or type(data['runner_uid']) is not int
            or type(data['restored']) is not bool or type(data['applied']) is not bool):
        raise KvmError('KVM_LEASE_INVALID')
    if (data['identity']!=identity or data['runner_uid']!=os.getuid()
            or data['runner_uid']==0 or data['device_path']!=DEVICE): raise KvmError('KVM_LEASE_SCOPE')
    device=data['device']
    if (not isinstance(device,dict) or set(device)!={'device','inode','rdev','uid','gid'}
            or any(type(v) is not int or v<0 for v in device.values())):
        raise KvmError('KVM_LEASE_INVALID')
    if not isinstance(data['before'],dict) or not isinstance(data['after'],dict): raise KvmError('KVM_LEASE_INVALID')
    if data['after']!=expected_after(data['before'],data['runner_uid']): raise KvmError('KVM_LEASE_DIFFERENCE')
    required=_read_private_json(root/REQUIRED)
    if (not isinstance(required,dict) or set(required)!={'identity','runner_uid'}
            or type(required['runner_uid']) is not int or required!={'identity':identity,'runner_uid':data['runner_uid']}):
        raise KvmError('KVM_LEASE_SCOPE')
    return data


def ensure_access(root,identity,*,system=None,uid=None):
    system=system or System(); uid=os.getuid() if uid is None else uid
    validate(root,identity)
    if uid==0: raise KvmError('KVM_ROOT_RUNNER_FORBIDDEN')
    device=system.identity()
    if system.writable(): return {'changed_permissions':False,'restore_verified':False,'state':'not_needed'}
    if uid==device['uid']: raise KvmError('KVM_OWNER_PERMISSION_UNEXPECTED')
    before=system.acl(); after=expected_after(before,uid)
    if before==after: raise KvmError('KVM_ACCESS_DENIED_DESPITE_ACL')
    data={'schema':1,'identity':identity,'runner_uid':uid,'device_path':DEVICE,'device':device,
          'before':before,'after':after,'restored':False,'applied':False}
    write_lease(root/REQUIRED,{'identity':identity,'runner_uid':uid},new=True)
    write_lease(root/LEASE,data,new=True)
    if system.identity()!=device or system.acl()!=before: raise KvmError('KVM_CHANGED_BEFORE_GRANT')
    result=system.grant(uid)
    if system.identity()!=device or system.acl()!=after: raise KvmError('KVM_GRANT_NOT_VERIFIED')
    if result or not system.writable(): raise KvmError('KVM_GRANT_FAILED')
    data['applied']=True; write_lease(root/LEASE,data)
    return {'changed_permissions':True,'restore_verified':False,'state':'lease_active'}


def restore_access(root,identity,*,system=None):
    """One conservative restore attempt, with bounded facts even on later I/O failure.

    A verified original ACL is separate from receipt persistence. Unknown state is
    never rewritten. An error carries only schema-safe diagnostics in .result.
    """
    system=system or System()
    diagnostic={'phase':'scratch_validate','reason':'NONE','write_attempted':False,
                'acl_readback':'not_checked','receipt':'not_loaded'}
    result={'changed_permissions':True,'restore_verified':False,'state':'restore_failed',
            'diagnostic':diagnostic}
    try:
        validate(root,identity)
        diagnostic['phase']='lease_load'
        data=load_lease(root,identity)
        if data is None:
            result.update(changed_permissions=False,state='not_needed')
            diagnostic.update(phase='complete',receipt='not_needed')
            return result
        diagnostic['receipt']='pending'
        diagnostic['phase']='device_check'
        if system.identity()!=data['device']: raise KvmError('KVM_DEVICE_CHANGED')
        diagnostic['phase']='acl_read'
        current=system.acl()
        # Bind this ACL read to the same device on both sides of the read.
        if system.identity()!=data['device']: raise KvmError('KVM_DEVICE_CHANGED')
        diagnostic['phase']='acl_compare'
        if current==data['before']:
            diagnostic['acl_readback']='original'
            changed=data['applied']
        else:
            if current!=data['after']:
                diagnostic['acl_readback']='unexpected'
                diagnostic['acl_difference']=acl_difference(current,data['before'],data['after'],data['runner_uid'])
                raise KvmError('KVM_ACL_CHANGED_EXTERNALLY')
            diagnostic['acl_readback']='lease'
            diagnostic['phase']='restore_command'
            diagnostic['write_attempted']=True
            command_status=system.restore(data['before'],data['runner_uid'])
            # A nonzero command is still a failure, but a safe read can tell us
            # whether it changed anything. Never repeat the write or expand it.
            diagnostic['phase']='restore_readback'
            if system.identity()!=data['device']: raise KvmError('KVM_DEVICE_CHANGED')
            current=system.acl()
            if system.identity()!=data['device']: raise KvmError('KVM_DEVICE_CHANGED')
            if current!=data['before']:
                diagnostic['acl_readback']='unexpected'
                raise KvmError('KVM_RESTORE_NOT_VERIFIED')
            diagnostic['acl_readback']='original'
            changed=True
            if command_status:
                result.update(changed_permissions=True,restore_verified=True,state='original_acl_verified')
                diagnostic['phase']='restore_command'
                raise KvmError('KVM_RESTORE_COMMAND_FAILED')
        result.update(changed_permissions=bool(changed),restore_verified=bool(changed),
                      state='original_acl_verified' if changed else 'not_needed')
        diagnostic['phase']='receipt_commit'
        data['restored']=True
        if changed: data['applied']=True
        write_lease(root/LEASE,data)
        diagnostic.update(phase='complete',receipt='committed')
        return result
    except Exception as error:
        diagnostic['reason']=_restore_reason(error,diagnostic['phase'])
        if diagnostic['phase']=='receipt_commit': diagnostic['receipt']='failed'
        if diagnostic['phase'] in ('device_check','acl_read','restore_readback'):
            diagnostic['acl_readback']='unavailable'
            result.update(restore_verified=False,state='restore_failed')
        raise KvmRestoreError(result) from None


def restore_outcome(root,identity,*,system=None):
    try: return restore_access(root,identity,system=system)
    except KvmRestoreError as error: return error.result


def restore_succeeded(result):
    return (result['state'] in ('not_needed','original_acl_verified')
            and result.get('diagnostic',{}).get('reason','NONE')=='NONE')


def always_entrypoint():
    # The independent entry point never leaks a traceback, environment or path.
    try:
        import public_evidence
        identity={key:os.environ[key] for key in ('GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','GITHUB_SHA','GITHUB_REPOSITORY')}
        root=Path(os.environ['RUNNER_TEMP'])/'aa-public-ui-one-job'
        result=restore_outcome(root,identity) if root.exists() else {
            'changed_permissions':False,'restore_verified':False,'state':'not_needed',
            'diagnostic':{'phase':'complete','reason':'NONE','write_attempted':False,
                          'acl_readback':'not_checked','receipt':'not_needed'}}
        ok=public_evidence.record_restore_attempt('always',result)
        print('KVM restore attempt completed; see fixed diagnostic record.')
        return 0 if ok and restore_succeeded(result) else 1
    except Exception:
        print('KVM_RESTORE_ENTRY_DIAGNOSTIC {"source":"always","phase":"entry","reason":"RESTORE_ENTRY_FAILED"}')
        try:
            import public_evidence
            public_evidence.evidence_error('always','kvm')
        except Exception: pass
        return 1


if __name__=='__main__':
    raise SystemExit(always_entrypoint())
