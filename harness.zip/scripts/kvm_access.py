"""One authorized temporary current-UID KVM ACL lease; no broad permissions."""
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile

from safe_scratch import validate

DEVICE='/dev/kvm'
LEASE='.kvm-lease.json'
REQUIRED='.kvm-lease-required.json'


class KvmError(Exception): pass


def parse_acl(text):
    acl={}
    for line in text.splitlines():
        line=line.split('#',1)[0].strip()
        if not line: continue
        match=re.fullmatch(r'(user|group|mask|other):(\d*):([r-][w-][x-])',line)
        if not match or (match[1] in ('mask','other') and match[2]): raise KvmError('KVM_ACL_INVALID')
        key=match[1]+':'+match[2]
        if key in acl: raise KvmError('KVM_ACL_DUPLICATE')
        acl[key]=match[3]
    if not {'user:','group:','other:'}.issubset(acl): raise KvmError('KVM_ACL_INCOMPLETE')
    named=any(k not in ('user:','group:','mask:','other:') for k in acl)
    if named and 'mask:' not in acl: raise KvmError('KVM_ACL_MISSING_MASK')
    return acl


def text_acl(acl): return ''.join(k+':'+acl[k]+'\n' for k in sorted(acl))


def expected_after(before,uid):
    # Validate the persisted original and prove the only permitted difference.
    before=parse_acl(text_acl(before))
    if before.get('mask:',before['group:'])!='rw-': raise KvmError('KVM_MASK_NOT_RW')
    after=before.copy(); after['user:'+str(uid)]='rw-'
    after.setdefault('mask:',before['group:'])
    return after


class System:
    def identity(self):
        st=os.lstat(DEVICE)
        if not stat.S_ISCHR(st.st_mode) or (os.major(st.st_rdev),os.minor(st.st_rdev))!=(10,232):
            raise KvmError('KVM_DEVICE_INVALID')
        return {'device':st.st_dev,'inode':st.st_ino,'rdev':st.st_rdev,'uid':st.st_uid,'gid':st.st_gid}

    def acl(self):
        p=subprocess.run(['/usr/bin/getfacl','--absolute-names','--omit-header','--numeric',DEVICE],
                         capture_output=True,text=True,timeout=10)
        if p.returncode: raise KvmError('KVM_ACL_READ_FAILED')
        return parse_acl(p.stdout)

    def writable(self): return os.access(DEVICE,os.R_OK|os.W_OK)

    def grant(self,uid):
        return subprocess.run(['/usr/bin/sudo','-n','/usr/bin/setfacl','--no-mask','-m',
                               'u:'+str(uid)+':rw-',DEVICE],capture_output=True,timeout=10).returncode

    def restore(self,before,uid):
        key='user:'+str(uid)
        if key in before:
            operation=['-m','u:'+str(uid)+':'+before[key]]
        else:
            # Remove only this UID, and the automatically added mask if originally absent.
            operation=['-x','u:'+str(uid)+('' if 'mask:' in before else ',m')]
        return subprocess.run(['/usr/bin/sudo','-n','/usr/bin/setfacl','--no-mask',*operation,DEVICE],
                              capture_output=True,timeout=10).returncode


def write_lease(path,data,*,new=False):
    # Persist before changing /dev/kvm, so a later always-step can restore it.
    if new:
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'w') as out:
            json.dump(data,out); out.flush(); os.fsync(out.fileno())
        return
    # Keep the last complete receipt if serialization, write or fsync fails.
    # This is not a guarantee against VM loss, SIGKILL or storage failure.
    st=path.lstat()
    if (not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_nlink!=1
            or stat.S_IMODE(st.st_mode)!=0o600): raise KvmError('KVM_LEASE_INVALID')
    fd,temporary=tempfile.mkstemp(prefix='.kvm-lease-update-',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as out:
            json.dump(data,out); out.flush(); os.fsync(out.fileno())
        current=path.lstat()
        if (current.st_dev,current.st_ino)!=(st.st_dev,st.st_ino): raise KvmError('KVM_LEASE_CHANGED')
        os.replace(temporary,path)
    finally:
        if os.path.lexists(temporary): os.unlink(temporary)


def load_lease(root,identity):
    validate(root,identity)
    path=root/LEASE
    if path.is_symlink(): raise KvmError('KVM_LEASE_INVALID')
    if not path.exists():
        if (root/REQUIRED).exists() or (root/REQUIRED).is_symlink(): raise KvmError('KVM_LEASE_MISSING')
        return None
    st=path.lstat()
    if (not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_nlink!=1
            or stat.S_IMODE(st.st_mode)!=0o600 or st.st_size>16384): raise KvmError('KVM_LEASE_INVALID')
    data=json.loads(path.read_text())
    if (data.get('identity')!=identity or data.get('runner_uid')!=os.getuid()
            or data['runner_uid']==0 or data.get('device_path')!=DEVICE): raise KvmError('KVM_LEASE_SCOPE')
    if data['after']!=expected_after(data['before'],data['runner_uid']): raise KvmError('KVM_LEASE_DIFFERENCE')
    return data


def ensure_access(root,identity,*,system=None,uid=None):
    system=system or System(); uid=os.getuid() if uid is None else uid
    validate(root,identity)
    if uid==0: raise KvmError('KVM_ROOT_RUNNER_FORBIDDEN')
    device=system.identity()
    if system.writable(): return {'changed_permissions':False,'restore_verified':False,'state':'not_needed'}
    if uid==device['uid']: raise KvmError('KVM_OWNER_PERMISSION_UNEXPECTED')
    before=system.acl(); after=expected_after(before,uid)
    if before==after: raise KvmError('KVM_ACCESS_DENIED_DESPITE_ACL')
    data={'schema':1,'identity':identity,'runner_uid':uid,'device_path':DEVICE,'device':device,
          'before':before,'after':after,'restored':False,'applied':False}
    write_lease(root/REQUIRED,{'identity':identity,'runner_uid':uid},new=True)
    write_lease(root/LEASE,data,new=True)
    if system.identity()!=device or system.acl()!=before: raise KvmError('KVM_CHANGED_BEFORE_GRANT')
    result=system.grant(uid)
    if system.identity()!=device or system.acl()!=after: raise KvmError('KVM_GRANT_NOT_VERIFIED')
    if result or not system.writable(): raise KvmError('KVM_GRANT_FAILED')
    data['applied']=True; write_lease(root/LEASE,data)
    return {'changed_permissions':True,'restore_verified':False,'state':'lease_active'}


def restore_access(root,identity,*,system=None):
    system=system or System()
    data=load_lease(root,identity)
    if data is None: return {'changed_permissions':False,'restore_verified':False,'state':'not_needed'}
    if system.identity()!=data['device']: raise KvmError('KVM_DEVICE_CHANGED')
    current=system.acl()
    if current==data['before']:
        data['restored']=True; write_lease(root/LEASE,data)
        return ({'changed_permissions':True,'restore_verified':True,'state':'original_acl_verified'} if data['applied']
                else {'changed_permissions':False,'restore_verified':False,'state':'not_needed'})
    if current!=data['after']: raise KvmError('KVM_ACL_CHANGED_EXTERNALLY')
    result=system.restore(data['before'],data['runner_uid'])
    if result or system.identity()!=data['device'] or system.acl()!=data['before']:
        raise KvmError('KVM_RESTORE_NOT_VERIFIED')
    data['restored']=True; data['applied']=True; write_lease(root/LEASE,data)
    return {'changed_permissions':True,'restore_verified':True,'state':'original_acl_verified'}


if __name__=='__main__':
    # Separate always-step, same exact run and owned root. No lease means no action.
    import sys
    identity={k:os.environ[k] for k in ('GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','GITHUB_SHA','GITHUB_REPOSITORY')}
    root=Path(os.environ['RUNNER_TEMP'])/'aa-public-ui-one-job'
    try:
        result=restore_access(root,identity) if root.exists() else {'changed_permissions':False,'restore_verified':False,'state':'not_needed'}
        from public_evidence import record_kvm_restore
        record_kvm_restore(result)
        print('KVM restore status: '+result['state'])
    except Exception:
        from public_evidence import record_kvm_restore
        record_kvm_restore({'changed_permissions':True,'restore_verified':False,'state':'restore_failed'})
        print('KVM restore verification: false. No unknown ACL was overwritten.')
        sys.exit(1)
