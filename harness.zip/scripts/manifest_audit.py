"""Parse pinned aapt2 xmltree output by hierarchy, not substring presence."""
import json
import re

ANDROID='http://schemas.android.com/apk/res/android:'
TARGET='net.ankio.auto.isolatedui'
RUNNER='net.ankio.auto.isolated.IsolatedUiTestRunner'
HOST='net.ankio.auto.isolated.IsolatedUiHostActivity'
APPLICATION='net.ankio.auto.isolated.IsolatedUiApplication'


def parse_tree(text):
    roots=[]; stack=[]
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('N: '):
            continue
        match=re.fullmatch(r'( *)E: ([\w.-]+)(?: \(line=\d+\))?',line)
        if match:
            indent=len(match[1])
            while stack and stack[-1][0]>=indent: stack.pop()
            node={'tag':match[2],'attributes':{},'children':[]}
            if stack: stack[-1][1]['children'].append(node)
            else: roots.append(node)
            stack.append((indent,node)); continue
        match=re.fullmatch(r'( *)A: ([^=]+)=(.*)',line)
        if not match: raise ValueError('Unexpected manifest dump line')
        indent=len(match[1])
        while stack and stack[-1][0]>=indent: stack.pop()
        if not stack: raise ValueError('Manifest attribute without element')
        name=re.sub(r'\(0x[0-9a-fA-F]+\)$','',match[2])
        if name.startswith(ANDROID): name='android:'+name[len(ANDROID):]
        if name in stack[-1][1]['attributes']: raise ValueError('Duplicate manifest attribute')
        value=match[3].split(' (Raw: ',1)[0]
        if value.startswith('"'): value=json.loads(value)
        stack[-1][1]['attributes'][name]=value
    if len(roots)!=1 or roots[0]['tag']!='manifest': raise ValueError('Invalid manifest root')
    return roots[0]


def audit_manifest(text, instrumentation, *, require_test_only=True):
    root=parse_tree(text)
    expected_package=TARGET+'.test' if instrumentation else TARGET
    if root['attributes'].get('package')!=expected_package: raise ValueError('Wrong manifest package')
    def walk(node):
        yield node
        for child in node['children']: yield from walk(child)
    nodes=list(walk(root))
    sdk=[n for n in root['children'] if n['tag']=='uses-sdk']
    if (len(sdk)!=1 or sdk[0]['attributes'].get('android:minSdkVersion')!='29'
            or sdk[0]['attributes'].get('android:targetSdkVersion')!='36'):
        raise ValueError('Unexpected SDK version')
    forbidden={'uses-permission','uses-permission-sdk-23','uses-permission-sdk-m',
               'service','receiver','provider','activity-alias','intent-filter'}
    if any(n['tag'] in forbidden or n['tag'].startswith('uses-permission') for n in nodes):
        raise ValueError('Forbidden permission or component')
    apps=[n for n in root['children'] if n['tag']=='application']
    if len(apps)!=1 or sum(n['tag']=='application' for n in nodes)!=1:
        raise ValueError('Expected one application')
    app=apps[0]; attrs=app['attributes']
    if attrs.get('android:allowBackup')!='false' or attrs.get('android:debuggable')!='true':
        raise ValueError('Unsafe application flags')
    if require_test_only and not instrumentation and attrs.get('android:testOnly')!='true':
        raise ValueError('Expected explicitly test-only package')
    if instrumentation and attrs.get('android:testOnly') not in (None,'true'):
        raise ValueError('Unexpected instrumentation testOnly flag')
    instruments=[n for n in nodes if n['tag']=='instrumentation']
    activities=[n for n in nodes if n['tag']=='activity']
    if instrumentation:
        if activities or len(instruments)!=1 or instruments[0] not in root['children']:
            raise ValueError('Invalid instrumentation components')
        if attrs.get('android:name') not in (None,'android.app.Application'):
            raise ValueError('Unexpected instrumentation application')
        properties=instruments[0]['attributes']
        if properties.get('android:name')!=RUNNER or properties.get('android:targetPackage')!=TARGET:
            raise ValueError('Wrong instrumentation identity')
    else:
        if instruments or attrs.get('android:name')!=APPLICATION:
            raise ValueError('Wrong target application')
        if len(activities)!=1 or activities[0] not in app['children']:
            raise ValueError('Expected only the isolated host activity')
        properties=activities[0]['attributes']
        if properties.get('android:name')!=HOST or properties.get('android:exported')!='false':
            raise ValueError('Wrong or exported host activity')
    return {'package':expected_package,'test_only':attrs.get('android:testOnly')=='true',
            'requested_permissions':0,'production_components':0}
