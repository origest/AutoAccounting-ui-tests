"""Private Linux runtime supervisor; signal only pidfd-bound kernel children.

No PID/name tree scanning or process-group signals. The supervisor is a session
leader and child subreaper. Only its own kernel children file is enumerated.
A child PID is never used for a signal: waitid(P_PIDFD) first proves ownership,
then pidfd_send_signal targets that same process even in the presence of PID reuse.
"""
import ctypes
import errno
import json
import os
from pathlib import Path
import select
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import threading

CLOSE_SECONDS = 20.0
SUPERVISOR_CLEANUP_SECONDS = 18.0
MAX_MESSAGE = 6 * 1024 * 1024
MAX_CAPTURE = 2 * 1024 * 1024
REASONS = frozenset({
    'NONE', 'UNSUPPORTED_PLATFORM', 'CONTROL_LOST', 'PROTOCOL_INVALID',
    'OWNERSHIP_UNVERIFIED', 'CLEANUP_TIMEOUT', 'CHILD_SIGNAL_FAILED',
    'CHILD_WAIT_FAILED', 'CHILD_ENUMERATION_FAILED', 'COMMAND_START_FAILED',
    'COMMAND_TIMEOUT', 'OUTPUT_TOO_LARGE', 'SUPERVISOR_FAILED', 'UNEXPECTED_FAILURE',
})
RUNTIME_REASONS = REASONS
STATES = frozenset({'not_started', 'stopped_verified', 'cleanup_failed'})


class OwnedRuntimeError(RuntimeError):
    def __init__(self, reason):
        self.reason = reason if reason in REASONS else 'SUPERVISOR_FAILED'
        self.code = 'RUNTIME_' + self.reason
        super().__init__(self.code)


RuntimeFailure = OwnedRuntimeError


def result(state, reason='NONE'):
    if state not in STATES or reason not in REASONS:
        raise OwnedRuntimeError('PROTOCOL_INVALID')
    return {'state': state, 'reason': reason}


class ChildKernel:
    """Kernel ownership checks, isolated for deterministic negative testing."""
    def __init__(self):
        self.children_path = Path('/proc/self/task') / str(threading.get_native_id()) / 'children'
        self.probe_started = False

    def prepare(self):
        if not (hasattr(os, 'pidfd_open') and hasattr(os, 'P_PIDFD')
                and hasattr(signal, 'pidfd_send_signal') and hasattr(os, 'WNOWAIT')):
            raise OwnedRuntimeError('UNSUPPORTED_PLATFORM')
        self.children()
        # This affects only this dedicated supervisor process, not system settings.
        libc = ctypes.CDLL(None, use_errno=True)
        if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
            raise OwnedRuntimeError('UNSUPPORTED_PLATFORM')
        value = ctypes.c_int()
        if libc.prctl(37, ctypes.byref(value), 0, 0, 0) != 0 or value.value != 1:
            raise OwnedRuntimeError('UNSUPPORTED_PLATFORM')
        if os.getsid(0) != os.getpid():
            raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
        fd = None
        try:
            fd = os.pidfd_open(os.getpid(), 0)
            try:
                os.waitid(os.P_PIDFD, fd, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            except ChildProcessError:
                pass  # A process must never be its own child.
            else:
                raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
        except OSError:
            raise OwnedRuntimeError('UNSUPPORTED_PLATFORM') from None
        finally:
            if fd is not None:
                os.close(fd)
        # Validate the real child/pidfd/waitid path using only a tiny Python probe.
        # Closing its input is sufficient to end it; no arbitrary PID signal is used.
        proc = None
        child_fd = None
        try:
            proc = subprocess.Popen(
                [sys.executable, '-B', '-c', 'import os; os.read(0, 1)'],
                stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'})
            self.probe_started = True
            if proc.pid not in self.children():
                raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
            child_fd = self.bind(proc.pid)
            if child_fd is None:
                raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
            self.signal_child(child_fd, 0)  # Capability/ownership check, not a delivered signal.
        finally:
            if child_fd is not None:
                self.release(child_fd)
            if proc is not None:
                proc.stdin.close()
                try:
                    proc.wait(timeout=2)
                except (subprocess.TimeoutExpired, OSError):
                    raise OwnedRuntimeError('CHILD_WAIT_FAILED') from None

    def children(self):
        try:
            with self.children_path.open('r', encoding='ascii') as source:
                raw = source.read(65537)
            if len(raw) > 65536:
                raise ValueError()
            values = raw.split()
            if any(not x.isascii() or not x.isdecimal() or int(x) <= 0 for x in values):
                raise ValueError()
            children = {int(x) for x in values}
            if len(children) > 4096 or os.getpid() in children:
                raise ValueError()
            return children
        except (OSError, ValueError, UnicodeError):
            raise OwnedRuntimeError('CHILD_ENUMERATION_FAILED') from None

    def bind(self, pid):
        fd = None
        try:
            fd = os.pidfd_open(pid, 0)
            info = os.waitid(os.P_PIDFD, fd, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            if info is not None and info.si_pid != pid:
                raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
            return fd
        except ProcessLookupError:
            if fd is not None:
                os.close(fd)
            return None
        except (ChildProcessError, OSError, OwnedRuntimeError):
            if fd is not None:
                os.close(fd)
            raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED') from None

    def signal_child(self, fd, signum):
        try:
            # Recheck kernel-child relationship on the SAME pidfd just before signal.
            os.waitid(os.P_PIDFD, fd, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            signal.pidfd_send_signal(fd, signum, None, 0)
        except ProcessLookupError:
            pass
        except ChildProcessError:
            raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED') from None
        except OSError:
            raise OwnedRuntimeError('CHILD_SIGNAL_FAILED') from None

    def reap(self):
        try:
            for _ in range(4097):
                info = os.waitid(os.P_ALL, 0, os.WEXITED | os.WNOHANG)
                if info is None:
                    return False  # At least one live kernel child exists.
            raise OwnedRuntimeError('CHILD_WAIT_FAILED')
        except ChildProcessError:
            return True  # ECHILD, not merely an empty process listing.
        except OSError:
            raise OwnedRuntimeError('CHILD_WAIT_FAILED') from None

    def release(self, fd):
        os.close(fd)


def cleanup_children(kernel, *, budget=SUPERVISOR_CLEANUP_SECONDS,
                     clock=time.monotonic, sleep=time.sleep):
    """Bounded cleanup of proven direct/adopted children; never claim partial success."""
    started = clock()
    deadline = started + budget
    hard_at = started + min(13.0, budget * 0.7)
    try:
        while clock() < deadline:
            children = kernel.children()
            for pid in sorted(children):
                if clock() >= deadline:
                    return result('cleanup_failed', 'CLEANUP_TIMEOUT')
                fd = kernel.bind(pid)
                if fd is None:
                    continue
                try:
                    kernel.signal_child(fd, signal.SIGKILL if clock() >= hard_at else signal.SIGTERM)
                finally:
                    kernel.release(fd)
            no_children = kernel.reap()
            # Parent death can synchronously adopt grandchildren. Re-read before success.
            if no_children and not kernel.children() and kernel.reap():
                return result('stopped_verified')
            sleep(min(0.02, max(0.0, deadline - clock())))
        return result('cleanup_failed', 'CLEANUP_TIMEOUT')
    except OwnedRuntimeError as error:
        return result('cleanup_failed', error.reason)
    except Exception:
        return result('cleanup_failed', 'SUPERVISOR_FAILED')


class Wire:
    def __init__(self, channel):
        self.channel = channel
        self.buffer = b''

    def send(self, value, timeout=5):
        raw = json.dumps(value, separators=(',', ':'), ensure_ascii=True).encode() + b'\n'
        if len(raw) > MAX_MESSAGE:
            raise OwnedRuntimeError('PROTOCOL_INVALID')
        deadline = time.monotonic() + timeout
        view = memoryview(raw)
        while view:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([], [self.channel], [], max(0, remaining))[1]:
                raise OwnedRuntimeError('CONTROL_LOST')
            try:
                sent = self.channel.send(view, socket.MSG_DONTWAIT)
            except BlockingIOError:
                continue
            if not sent:
                raise EOFError()
            view = view[sent:]

    def receive(self, timeout):
        deadline = time.monotonic() + timeout
        while b'\n' not in self.buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.channel], [], [], max(0, remaining))[0]:
                return None
            chunk = self.channel.recv(65536)
            if not chunk:
                raise EOFError()
            self.buffer += chunk
            if len(self.buffer) > MAX_MESSAGE:
                raise OwnedRuntimeError('PROTOCOL_INVALID')
        line, self.buffer = self.buffer.split(b'\n', 1)
        try:
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError()
            return value
        except (ValueError, UnicodeError):
            raise OwnedRuntimeError('PROTOCOL_INVALID') from None


def private_log(path):
    path = Path(path)
    if not path.is_absolute() or path.parent.resolve() != path.parent:
        raise OwnedRuntimeError('COMMAND_START_FAILED')
    parent = path.parent.stat()
    if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.getuid():
        raise OwnedRuntimeError('COMMAND_START_FAILED')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    return os.fdopen(fd, 'wb')


class ServiceHandle:
    def __init__(self, runtime, handle):
        self._runtime, self._handle = runtime, handle

    def poll(self):
        return self._runtime.poll(self)


class OwnedRuntime:
    """Lazy client. All raw command output stays private to the caller/VM."""
    def __init__(self):
        self._proc = None
        self._wire = None
        self._channel = None
        self._next_id = 0
        self._closed = False
        self._ready = False
        self._terminal = False
        self._cleanup = result('not_started')

    def _start(self):
        if self._closed:
            raise OwnedRuntimeError('CONTROL_LOST')
        if self._proc is not None:
            if not self._ready:
                raise OwnedRuntimeError('CONTROL_LOST')
            return
        parent, child = socket.socketpair()
        try:
            self._proc = subprocess.Popen(
                [sys.executable, '-B', str(Path(__file__).resolve()), '--supervisor', str(child.fileno())],
                pass_fds=(child.fileno(),), start_new_session=True,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'})
        except Exception:
            parent.close()
            raise OwnedRuntimeError('SUPERVISOR_FAILED') from None
        finally:
            child.close()
        self._channel, self._wire = parent, Wire(parent)
        try:
            ready = self._wire.receive(5)
            if ready != {'ready': True}:
                self._terminal = True
                self._cleanup = (validate_cleanup(ready['cleanup'])
                                 if isinstance(ready, dict) and 'cleanup' in ready
                                 else result('cleanup_failed', 'CONTROL_LOST'))
                reason = ready.get('error', 'SUPERVISOR_FAILED') if isinstance(ready, dict) else 'CONTROL_LOST'
                raise OwnedRuntimeError(reason)
            self._ready = True
        except (EOFError, OSError):
            raise OwnedRuntimeError('CONTROL_LOST') from None

    def _lose_control(self):
        self._cleanup = result('cleanup_failed', 'CONTROL_LOST')
        self._terminal = True
        if self._channel is not None:
            self._channel.close()  # Trigger EOF cleanup immediately, not only at caller finally.

    def _request(self, operation, *, limit=5, **fields):
        self._start()
        self._next_id += 1
        request_id = self._next_id
        deadline = time.monotonic() + limit
        try:
            self._wire.send({'id': request_id, 'op': operation, **fields}, timeout=min(5, limit))
            while time.monotonic() < deadline:
                reply = self._wire.receive(max(0, deadline - time.monotonic()))
                if reply is None:
                    break
                if reply.get('id') != request_id:
                    continue  # A previously interrupted request may finish during close.
                if 'cleanup' in reply:
                    self._cleanup = validate_cleanup(reply['cleanup'])
                if reply.get('terminal') is True:
                    self._terminal = True
                if reply.get('error'):
                    raise OwnedRuntimeError(reply['error'])
                return reply
        except OwnedRuntimeError as error:
            if error.reason == 'CONTROL_LOST':
                self._lose_control()
            raise
        except (EOFError, OSError, ValueError):
            pass
        self._lose_control()
        raise OwnedRuntimeError('CONTROL_LOST')

    def start_service(self, args, *, env, log, cwd=None):
        reply = self._request('start', args=list(args), env=env,
                              log=str(log), cwd=None if cwd is None else str(cwd))
        handle = reply.get('handle')
        if type(handle) is not int or handle < 1:
            raise OwnedRuntimeError('PROTOCOL_INVALID')
        return ServiceHandle(self, handle)

    def start_adb_server(self, adb_path, *, env, log):
        reply = self._request('start_adb', args=[str(adb_path)], env=env, log=str(log), cwd=None)
        handle, port = reply.get('handle'), reply.get('port')
        if type(handle) is not int or handle < 1 or type(port) is not int or not 1 <= port <= 65535:
            raise OwnedRuntimeError('PROTOCOL_INVALID')
        return ServiceHandle(self, handle), port

    def poll(self, handle):
        if not isinstance(handle, ServiceHandle) or handle._runtime is not self:
            raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
        reply = self._request('poll', handle=handle._handle)
        code = reply.get('returncode')
        if code is not None and type(code) is not int:
            raise OwnedRuntimeError('PROTOCOL_INVALID')
        return code

    def run(self, args, *, env, timeout, log=None, cwd=None):
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 0 < timeout <= 900:
            raise OwnedRuntimeError('PROTOCOL_INVALID')
        try:
            reply = self._request('run', limit=timeout + CLOSE_SECONDS + 2,
                                  args=list(args), env=env, timeout=timeout,
                                  log=None if log is None else str(log),
                                  cwd=None if cwd is None else str(cwd))
        except OwnedRuntimeError as error:
            if error.reason == 'COMMAND_TIMEOUT':
                raise subprocess.TimeoutExpired(args, timeout) from None
            raise
        code, stdout, stderr = reply.get('returncode'), reply.get('stdout'), reply.get('stderr')
        if type(code) is not int or not isinstance(stdout, str) or not isinstance(stderr, str):
            raise OwnedRuntimeError('PROTOCOL_INVALID')
        return subprocess.CompletedProcess(args, code, stdout, stderr)

    def close(self):
        if self._closed:
            return self._cleanup.copy()
        deadline = time.monotonic() + CLOSE_SECONDS
        try:
            if self._proc is not None and not self._terminal:
                reply = self._request('close', limit=max(0.01, deadline - time.monotonic()))
                self._cleanup = validate_cleanup(reply['cleanup'])
        except Exception:
            self._cleanup = result('cleanup_failed', 'CONTROL_LOST')
        finally:
            self._closed = True
            if self._channel is not None:
                self._channel.close()  # EOF independently triggers supervisor cleanup.
            if self._proc is not None:
                try:
                    self._proc.wait(timeout=max(0.01, deadline - time.monotonic()))
                except (subprocess.TimeoutExpired, OSError):
                    self._cleanup = result('cleanup_failed', 'CONTROL_LOST')
        return self._cleanup.copy()


def validate_cleanup(value):
    if not isinstance(value, dict) or set(value) != {'state', 'reason'}:
        raise OwnedRuntimeError('PROTOCOL_INVALID')
    checked = result(value['state'], value['reason'])
    if (checked['state'] != 'cleanup_failed') != (checked['reason'] == 'NONE'):
        raise OwnedRuntimeError('PROTOCOL_INVALID')
    return checked


def validate_launch(request):
    args, env = request.get('args'), request.get('env')
    if (not isinstance(args, list) or not args or len(args) > 256
            or any(not isinstance(x, str) or '\x00' in x or len(x) > 65536 for x in args)
            or not isinstance(env, dict) or len(env) > 1024
            or any(not isinstance(k, str) or not isinstance(v, str) or '\x00' in k + v or '=' in k
                   for k, v in env.items())):
        raise OwnedRuntimeError('PROTOCOL_INVALID')
    cwd, log = request.get('cwd'), request.get('log')
    if cwd is not None and not isinstance(cwd, str):
        raise OwnedRuntimeError('PROTOCOL_INVALID')
    if log is not None and not isinstance(log, str):
        raise OwnedRuntimeError('PROTOCOL_INVALID')
    return args, env, cwd, log


def adb_listener(adb_path):
    """Bind once and pass this exact listening socket; never release/rebind a port."""
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        listener.bind(('127.0.0.1', 0))
        listener.listen(16)
        port = listener.getsockname()[1]
        fd = listener.fileno()
        return listener, [adb_path, '-L', 'acceptfd:' + str(fd), 'server', 'nodaemon'], (fd,), port
    except Exception:
        listener.close()
        raise OwnedRuntimeError('COMMAND_START_FAILED') from None


def supervisor(channel, *, kernel=None):
    wire = Wire(channel)
    kernel = kernel or ChildKernel()
    cleanup = None
    services = {}
    next_handle = 0
    pending = None
    active_id = 0
    prepared = False
    all_streams = []
    listeners = []
    abort = [False]

    def interrupted(signum, frame):
        abort[0] = True

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        try:
            kernel.prepare()
        except OwnedRuntimeError as error:
            cleanup = (cleanup_children(kernel) if getattr(kernel, 'probe_started', False)
                       else result('not_started'))
            wire.send({'error': error.reason, 'cleanup': cleanup})
            return
        prepared = True
        wire.send({'ready': True})
        while not abort[0]:
            if pending is not None:
                request_id, proc, out, err, deadline, logged = pending
                active_id = request_id
                code = proc.poll()
                if code is not None:
                    values = []
                    for stream in (out, err):
                        if stream is None or logged:
                            values.append('')
                        else:
                            stream.seek(0)
                            data = stream.read(MAX_CAPTURE + 1)
                            if len(data) > MAX_CAPTURE:
                                raise OwnedRuntimeError('OUTPUT_TOO_LARGE')
                            values.append(data.decode('utf-8', errors='replace'))
                    wire.send({'id': request_id, 'returncode': code, 'stdout': values[0], 'stderr': values[1]})
                    for stream in (out, err):
                        if stream is not None:
                            stream.close()
                    pending = None
                elif time.monotonic() >= deadline:
                    cleanup = cleanup_children(kernel)
                    wire.send({'id': request_id, 'error': 'COMMAND_TIMEOUT', 'cleanup': cleanup})
                    pending = None
            request = wire.receive(0.02)
            if request is None:
                continue
            rid, operation = request.get('id'), request.get('op')
            active_id = rid if type(rid) is int else 0
            if type(rid) is not int or rid < 1:
                raise OwnedRuntimeError('PROTOCOL_INVALID')
            if operation == 'close':
                cleanup = cleanup if cleanup is not None else cleanup_children(kernel)
                wire.send({'id': rid, 'cleanup': cleanup})
                return
            if pending is not None or cleanup is not None:
                wire.send({'id': rid, 'error': 'CONTROL_LOST'})
                continue
            if operation == 'poll':
                handle = request.get('handle')
                if type(handle) is not int or handle not in services:
                    wire.send({'id': rid, 'error': 'OWNERSHIP_UNVERIFIED'})
                else:
                    wire.send({'id': rid, 'returncode': services[handle].poll()})
                continue
            if operation not in ('start', 'start_adb', 'run'):
                raise OwnedRuntimeError('PROTOCOL_INVALID')
            args, env, cwd, log = validate_launch(request)
            timeout = request.get('timeout')
            if operation == 'run' and (type(timeout) not in (int, float) or not 0 < timeout <= 900):
                raise OwnedRuntimeError('PROTOCOL_INVALID')
            if operation in ('start', 'start_adb') and log is None:
                raise OwnedRuntimeError('PROTOCOL_INVALID')
            port = None
            pass_fds = ()
            if operation == 'start_adb':
                if len(args) != 1:
                    raise OwnedRuntimeError('PROTOCOL_INVALID')
                listener, args, pass_fds, port = adb_listener(args[0])
                listeners.append(listener)
            out = private_log(log) if log is not None else tempfile.TemporaryFile()
            err = None if log is not None else tempfile.TemporaryFile()
            all_streams.extend(x for x in (out, err) if x is not None)
            try:
                proc = subprocess.Popen(args, env=env, cwd=cwd, stdin=subprocess.DEVNULL,
                                        stdout=out, stderr=subprocess.STDOUT if err is None else err,
                                        pass_fds=pass_fds)
                fd = kernel.bind(proc.pid)
                if fd is None:
                    raise OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
                kernel.release(fd)
            except OwnedRuntimeError:
                raise
            except Exception:
                wire.send({'id': rid, 'error': 'COMMAND_START_FAILED'})
                continue
            if operation in ('start', 'start_adb'):
                next_handle += 1
                services[next_handle] = proc
                reply = {'id': rid, 'handle': next_handle}
                if port is not None:
                    reply['port'] = port
                wire.send(reply)
            else:
                pending = (rid, proc, out, err, time.monotonic() + timeout, log is not None)
    except (EOFError, BrokenPipeError, ConnectionResetError):
        pass
    except OwnedRuntimeError as error:
        cleanup = cleanup if cleanup is not None else cleanup_children(kernel)
        try:
            wire.send({'id': active_id, 'error': error.reason, 'cleanup': cleanup, 'terminal': True})
        except Exception:
            pass
    except Exception:
        cleanup = cleanup if cleanup is not None else cleanup_children(kernel)
        try:
            wire.send({'id': active_id, 'error': 'SUPERVISOR_FAILED', 'cleanup': cleanup, 'terminal': True})
        except Exception:
            pass
    finally:
        if cleanup is None and prepared:
            cleanup_children(kernel)
        for stream in all_streams:
            stream.close()
        for listener in listeners:
            listener.close()
        channel.close()


def preflight():
    """Check Linux ownership primitives in a disposable helper before any KVM grant."""
    runtime = OwnedRuntime()
    try:
        runtime._start()
    finally:
        status = runtime.close()
    if status['state'] != 'stopped_verified':
        raise OwnedRuntimeError(status['reason'] if status['reason'] != 'NONE' else 'SUPERVISOR_FAILED')
    return status


if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] != '--supervisor' or not sys.argv[2].isdecimal():
        raise SystemExit(2)
    supervisor(socket.socket(fileno=int(sys.argv[2])))
