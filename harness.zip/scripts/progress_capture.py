"""Bounded diagnostic-only fixed-tag reader for the already-owned emulator.

No device/server startup, log clearing, permissions, pass decisions or raw output.
The relay and adb child belong to the existing pidfd supervisor. Read their files
only after that supervisor verifies termination. Never retry a collection failure.
"""
import os
from pathlib import Path
import re
import signal
import stat
import struct
import subprocess
import sys

from progress_parser import parse_progress, empty, CASES, STEPS

TARGET = 'net.ankio.auto.isolatedui'
TAG = b'IsolatedUiStep'
LIMIT = 2 * 1024 * 1024
HEADER = struct.Struct('<HHiIIIII')  # Android logger_entry_v4, fixed pinned API 33.


def source_identity(packages, clock):
    """Exclusive user-0 package UID and a fresh guest realtime boundary.

Caller already verified a fresh emulator, empty third-party inventory, both
installed APK hashes, target manifest and the private ADB server/device identity.
The full package/UID inventory is private, bounded by the existing command cap.
"""
    if not isinstance(packages, str) or not isinstance(clock, str):
        raise ValueError('Invalid diagnostic identity')
    rows = []
    for line in packages.splitlines():
        m = re.fullmatch(r'package:([A-Za-z][A-Za-z0-9_.]*) uid:([1-9][0-9]{0,8})', line)
        if not m: raise ValueError('Invalid diagnostic identity')
        rows.append((m[1], int(m[2])))
    selected = [uid for package, uid in rows if package == TARGET]
    if len(selected) != 1 or not 10000 <= selected[0] <= 19999:
        raise ValueError('Invalid diagnostic identity')
    uid = selected[0]
    if sum(other == uid for _, other in rows) != 1:
        raise ValueError('Shared diagnostic identity')
    m = re.fullmatch(r'([1-9][0-9]{9})\.([0-9]{9})', clock)
    if not m: raise ValueError('Invalid diagnostic clock')
    return {'uid': uid, 'since_ns': int(m[1]) * 10**9 + int(m[2]), 'since': clock}


def logcat_args(adb, port, identity):
    if not isinstance(adb, str) or not Path(adb).is_absolute():
        raise ValueError('Invalid diagnostic endpoint')
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('Invalid diagnostic endpoint')
    if source_identity(f'package:{TARGET} uid:{identity["uid"]}', identity['since']) != identity:
        raise ValueError('Invalid diagnostic identity')
    return [adb, '-H', '127.0.0.1', '-P', str(port), '-s', 'emulator-5554',
            'exec-out', 'logcat', '-b', 'main', '-B', '--uid=' + str(identity['uid']),
            '-T', identity['since'], 'IsolatedUiStep:I', '*:S']


def start(runtime, adb, port, identity, root, env):
    # Validate before handing the fixed command to the owned relay.
    logcat_args(str(adb), port, identity)
    root = Path(root)
    runtime.start_service([sys.executable, '-B', str(Path(__file__).resolve()), '--relay',
        str(adb), str(port), str(identity['uid']), identity['since'],
        str(root/'progress-state-private.txt')], env=env, log=root/'progress-private.bin')


def stable_bytes(path, limit):
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        a = os.fstat(fd)
        if (not stat.S_ISREG(a.st_mode) or a.st_uid != os.getuid() or a.st_nlink != 1
                or a.st_size > limit): raise ValueError('Unsafe diagnostic file')
        data = bytearray()
        while len(data) <= limit:
            chunk = os.read(fd, min(65536, limit + 1 - len(data)))
            if not chunk: break
            data.extend(chunk)
        b = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if (any(getattr(a,k) != getattr(b,k) for k in fields)
                or len(data) != a.st_size or len(data) > limit):
            raise ValueError('Unstable diagnostic file')
        current = Path(path).lstat()
        if any(getattr(current,k) != getattr(a,k) for k in fields):
            raise ValueError('Replaced diagnostic file')
        return bytes(data)
    finally:
        if fd is not None: os.close(fd)


def decode(raw, identity):
    """Validate kernel UID/PID, timestamp, buffer, tag and payload before parsing.

A UID uniquely assigned to the just-installed target is the source authority.
PID comes from logd's header, must be positive and consistent for this one
instrumentation process. Neither UID/PID nor realtime leaves this component.
"""
    if type(raw) is not bytes or len(raw) > LIMIT: return empty()
    try:
        source_identity(f'package:{TARGET} uid:{identity["uid"]}', identity['since'])
        if identity['since_ns'] != source_identity(f'package:{TARGET} uid:{identity["uid"]}',identity['since'])['since_ns']:
            return empty()
        pos = 0; messages = []; pid = None; last_stamp = identity['since_ns']
        while pos < len(raw):
            if len(messages) >= 8192 or len(raw) - pos < HEADER.size: return empty()
            size, header, process, thread, seconds, nanos, buffer, uid = HEADER.unpack_from(raw, pos)
            if (header != HEADER.size or not 1 <= size <= 160 or process <= 0 or thread <= 0
                    or buffer != 0 or uid != identity['uid'] or nanos >= 10**9): return empty()
            stamp = seconds * 10**9 + nanos
            # Freshness rejection window, not a command timeout or extended test budget.
            if not last_stamp <= stamp <= identity['since_ns'] + 660 * 10**9: return empty()
            last_stamp = stamp
            if pid is not None and process != pid: return empty()
            pid = process
            pos += header
            if pos + size > len(raw): return empty()
            payload = raw[pos:pos+size]; pos += size
            prefix = b'\x04' + TAG + b'\0'  # Android INFO priority.
            if not payload.startswith(prefix) or not payload.endswith(b'\0'): return empty()
            message = payload[len(prefix):-1]
            if not message or len(message) > 128 or b'\0' in message or b'\n' in message: return empty()
            messages.append(message + b'\n')
        return parse_progress(b''.join(messages))
    except (KeyError, TypeError, ValueError, struct.error):
        return empty()


def _finish(root, identity, cleanup):
    if cleanup != {'state':'stopped_verified','reason':'NONE'} or identity is None:
        return empty()
    try:
        if stable_bytes(Path(root)/'progress-state-private.txt',32) != b'stopped\n': return empty()
        return decode(stable_bytes(Path(root)/'progress-private.bin', LIMIT), identity)
    except (OSError, ValueError):
        return empty()


def diagnostic(value):
    # Android 13 binary logcat may lose stdio-buffered tail records on teardown.
    # Even a complete local frame sequence proves only an observed prefix.
    return {**value, 'tail_completeness':'unverified'}


def finish(root, identity, cleanup):
    return diagnostic(_finish(root,identity,cleanup))


def checked(data):
    """Exact public schema; diagnostics do not grant a test result."""
    def exact(value, keys):
        if type(value) is not dict or set(value) != set(keys): raise ValueError('Invalid progress schema')
    def bounded(value):
        if value is not None and (type(value) is not int or not 0 <= value <= 600000):
            raise ValueError('Invalid progress time')
    exact(data, {'diagnostic_state','cases','active_case','open_steps','last_event_ms','tail_completeness'})
    if data['tail_completeness']!='unverified':raise ValueError('Unproven progress tail')
    state = data['diagnostic_state']
    if state not in ('invalid','missing','incomplete','observed'): raise ValueError('Invalid progress state')
    rows = data['cases']
    if type(rows) is not list or len(rows) != 19: raise ValueError('Invalid progress cases')
    active_rows = []
    latest = None
    for code, row in zip(CASES, rows):
        exact(row, {'case','begin_ms','end_ms'})
        if row['case'] != code: raise ValueError('Invalid progress case')
        begin, end = row['begin_ms'], row['end_ms']
        bounded(begin); bounded(end)
        if end is not None and (begin is None or end < begin): raise ValueError('Invalid progress range')
        if begin is not None and end is None: active_rows.append(code)
        for value in (begin,end):
            if value is not None: latest = max(latest or 0,value)
    # Parser cases are sequential; public JSON cannot invent overlapping cases.
    ranges=sorted((r['begin_ms'],r['end_ms'] if r['end_ms'] is not None else 600001)
                  for r in rows if r['begin_ms'] is not None)
    previous_end=-1
    for begin,end in ranges:
        if begin<previous_end:raise ValueError('Overlapping progress cases')
        previous_end=end
    steps = data['open_steps']
    if (type(steps) is not list or len(steps) > 8 or any(type(x) is not str or x not in STEPS-{'CASE'} for x in steps)
            or len(set(steps)) != len(steps)): raise ValueError('Invalid progress steps')
    active = data['active_case']; last = data['last_event_ms']; bounded(last)
    if state in ('invalid','missing'):
        if data != diagnostic(empty(state)): raise ValueError('Invalid progress empty state')
    else:
        if last is None or latest is None or last < latest: raise ValueError('Invalid progress latest time')
        if state == 'incomplete':
            if active not in CASES or active_rows != [active]: raise ValueError('Invalid active progress case')
        elif active is not None or active_rows or steps: raise ValueError('Invalid completed progress state')
        if active != 'C05' and any(s.startswith('SWIPE_') or s in {'MAIN','IDLE','POINTER_DOWN','POINTER_MOVE','POINTER_UP'} for s in steps):
            raise ValueError('Invalid detail case')
    return data


class PacketFilter:
    """Binary logcat bypasses display-tag filters: filter BEFORE disk retention.

Only the bounded unique-UID stream is read. Other well-formed tags are discarded
in memory. Bad identity/framing invalidates the entire collection. No arbitrary
packet/error bytes are returned by this component.
    """
    def __init__(self, identity, emit):
        self.identity=identity; self.emit=emit; self.buffer=bytearray()
        self.total=0; self.retained=0; self.count=0; self.invalid=False
        self.pid=None; self.last_stamp=identity['since_ns']

    def feed(self, chunk):
        if self.invalid: return
        self.total+=len(chunk)
        # Bound parsing cost too. Further input is discarded until owned cleanup.
        if self.total > 8*1024*1024:
            self.invalid=True;self.buffer.clear();return
        self.buffer.extend(chunk)
        while len(self.buffer)>=HEADER.size:
            size,header,pid,tid,seconds,nanos,log_id,uid=HEADER.unpack_from(self.buffer)
            if (header!=HEADER.size or not 4<=size<=4096 or pid<=0 or tid<=0
                    or log_id!=0 or uid!=self.identity['uid'] or nanos>=10**9):
                self.invalid=True;break
            stamp=seconds*10**9+nanos
            if not self.last_stamp<=stamp<=self.identity['since_ns']+660*10**9:
                self.invalid=True;break
            if self.pid is not None and self.pid!=pid:
                self.invalid=True;break
            if len(self.buffer)<header+size: break
            raw=bytes(self.buffer[:header+size]);del self.buffer[:header+size]
            payload=raw[header:]
            tag_end=payload.find(b'\0',1)
            if not 2<=payload[0]<=8 or not 1<tag_end<=129 or not payload.endswith(b'\0'):
                self.invalid=True;break
            self.pid=pid;self.last_stamp=stamp
            if payload[1:tag_end]!=TAG:
                continue  # Discard unrelated target logs without retaining their bytes.
            if payload[0]!=4 or size>160:
                self.invalid=True;break
            message=payload[tag_end+1:-1]
            match=re.fullmatch(rb'UI_STEP_V1\|([1-9][0-9]{0,3})\|(C(?:0[1-9]|1[0-9]))\|([A-Z_]+)\|(BEGIN|END|ERROR)\|(0|[1-9][0-9]{0,5})',message)
            if (not match or len(message)>128 or match[3].decode('ascii') not in STEPS
                    or int(match[5])>600000):
                self.invalid=True;break
            self.count+=1;self.retained+=len(raw)
            if self.count>8192 or self.retained>LIMIT:
                self.invalid=True;break
            self.emit(raw)
        if self.invalid:self.buffer.clear()

    def complete(self):
        return not self.invalid and not self.buffer


def relay(args, *, popen=subprocess.Popen, read=os.read, write=os.write):
    """Only the supervisor stops these processes. Never signal by a numeric PID."""
    if len(args) != 5: return 2
    stopped = [False]
    def stopping(signum, frame): stopped[0] = True
    signal.signal(signal.SIGTERM, stopping); signal.signal(signal.SIGINT, stopping)
    state = None
    try:
        adb, port, uid, since, state_path = args
        identity = source_identity(f'package:{TARGET} uid:{uid}', since)
        command = logcat_args(adb, int(port), identity)
        state = os.open(state_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        def status(value):
            os.lseek(state, 0, os.SEEK_SET); os.ftruncate(state, 0); os.write(state, value); os.fsync(state)
        status(b'starting\n')
        child = popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        def retain(raw):
            offset=0
            while offset<len(raw):
                written=write(1,raw[offset:])
                if written<=0:raise OSError('Diagnostic write failed')
                offset+=written
        parser=PacketFilter(identity,retain)
        while True:
            chunk = read(child.stdout.fileno(), 65536)
            if not chunk: break
            parser.feed(chunk)
            # Continue draining without retention; the same supervisor ends it.
        child.stdout.close()
        child.wait()
        status(b'stopped\n' if stopped[0] and parser.complete() else b'invalid\n')
        return 0
    except Exception:
        # No exception/raw bytes reach stdout or stderr.
        if state is not None:
            try:
                os.lseek(state,0,os.SEEK_SET);os.ftruncate(state,0);os.write(state,b'invalid\n')
            except OSError: pass
        return 1
    finally:
        if state is not None: os.close(state)


if __name__ == '__main__':
    raise SystemExit(relay(sys.argv[2:]) if len(sys.argv) > 1 and sys.argv[1] == '--relay' else 2)
