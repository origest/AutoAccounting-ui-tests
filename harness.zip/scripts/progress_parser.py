"""Diagnostic-only allowlist, after progress_capture verifies logd source headers.

All test-success gating stays in the unchanged instrumentation parser. No reads,
commands, raw strings or error messages are returned by this component.
"""
import re

CASES = tuple(f'C{x:02d}' for x in range(1, 20))
STEPS = frozenset('''CASE SETUP_RESET SETUP_BACKEND SETUP_HOST SETUP_IDLE
TEARDOWN_HOST TEARDOWN_REQUESTS TEARDOWN_DATABASE
SWIPE_INSERT_INITIAL SWIPE_SHOW SWIPE_INITIAL_ROWS SWIPE_FIRST
SWIPE_REQUEST_OBSERVED SWIPE_SECOND SWIPE_INSERT_SECOND SWIPE_RELEASE
SWIPE_FINAL_ROWS SWIPE_FINAL_ERROR MAIN IDLE POINTER_DOWN POINTER_MOVE POINTER_UP'''.split())


# Closed vocabulary only. A reason identifies a validator, not a runtime cause.
# No raw text, exception, UID/PID, path or user data belongs in these fields.
REASON_PHASE = {
    'UNCLASSIFIED': 'unavailable', 'NONE': 'none',
    **dict.fromkeys(('SETUP_UNAVAILABLE', 'SETUP_PACKAGE_QUERY', 'SETUP_CLOCK_QUERY',
                     'SETUP_IDENTITY', 'SETUP_SERVER', 'SETUP_RELAY_START'), 'setup'),
    'CLEANUP_UNVERIFIED': 'cleanup',
    **dict.fromkeys(('RELAY_STATE_INVALID', 'RELAY_START', 'RELAY_READ',
                     'RELAY_WRITE', 'RELAY_WAIT', 'RELAY_STATE_WRITE', 'RELAY_STOP_UNVERIFIED'), 'relay'),
    **dict.fromkeys(('STATE_FILE_UNREADABLE', 'BINARY_FILE_UNREADABLE',
                     'FILE_UNSAFE', 'FILE_UNSTABLE', 'FILE_REPLACED'), 'stable_file'),
    **dict.fromkeys(('BINARY_INPUT', 'BINARY_IDENTITY', 'BINARY_LIMIT', 'BINARY_HEADER',
                     'BINARY_SOURCE', 'BINARY_TIME', 'BINARY_PID', 'BINARY_TRUNCATED',
                     'BINARY_TAG', 'BINARY_PAYLOAD', 'BINARY_STREAM_LIMIT'), 'binary'),
    **dict.fromkeys(('SEQUENCE_INPUT', 'SEQUENCE_ENCODING', 'SEQUENCE_FRAMING',
                     'SEQUENCE_LIMIT', 'SEQUENCE_TOKEN', 'SEQUENCE_NUMBER',
                     'SEQUENCE_TIME', 'SEQUENCE_CASE', 'SEQUENCE_STEP'), 'sequence'),
    'PUBLIC_SCHEMA': 'schema',
}


def empty(state='invalid', *, reason=None):
    reason = reason or ('UNCLASSIFIED' if state == 'invalid' else 'NONE')
    return {'diagnostic_state': state, 'reason': reason, 'phase': REASON_PHASE[reason], 'cases': [
        {'case': case, 'begin_ms': None, 'end_ms': None} for case in CASES],
        'active_case': None, 'open_steps': [], 'last_event_ms': None}


def parse_progress(raw):
    if type(raw) is not bytes or len(raw) > 2 * 1024 * 1024:
        return empty(reason='SEQUENCE_INPUT')
    try:
        text = raw.decode('ascii')
    except UnicodeError:
        return empty(reason='SEQUENCE_ENCODING')
    if text and not text.endswith('\n'):
        return empty(reason='SEQUENCE_FRAMING')
    lines = text.splitlines()
    if len(lines) > 8192 or any(len(line) > 128 for line in lines):
        return empty(reason='SEQUENCE_LIMIT')
    # No CR, tabs, NUL, Unicode line separators or embedded protocol content.
    if any(ord(ch) < 32 and ch != '\n' or ord(ch) > 126 for ch in text):
        return empty(reason='SEQUENCE_ENCODING')
    result = empty('missing')
    rows = {row['case']: row for row in result['cases']}
    active = None
    stack = []
    last = -1
    seen = set()
    sequence = 0
    for index, line in enumerate(lines):
        if index == 0 and line == '--------- beginning of main':
            continue
        match = re.fullmatch(r'UI_STEP_V1\|([1-9][0-9]{0,3})\|(C(?:0[1-9]|1[0-9]))\|([A-Z_]+)\|(BEGIN|END|ERROR)\|(0|[1-9][0-9]{0,5})', line)
        if not match:
            return empty(reason='SEQUENCE_TOKEN')
        number, case, step, event, value = match.groups()
        if int(number) != sequence + 1:
            return empty(reason='SEQUENCE_NUMBER')
        sequence += 1
        elapsed = int(value)
        if step not in STEPS:
            return empty(reason='SEQUENCE_TOKEN')
        if elapsed > 600000 or elapsed < last:
            return empty(reason='SEQUENCE_TIME')
        last = elapsed
        if step == 'CASE':
            if event == 'BEGIN':
                if active is not None or case in seen:
                    return empty(reason='SEQUENCE_CASE')
                active = case
                seen.add(case)
                rows[case]['begin_ms'] = elapsed
            elif event == 'END':
                if active != case or stack:
                    return empty(reason='SEQUENCE_CASE')
                rows[case]['end_ms'] = elapsed
                active = None
            else:
                return empty(reason='SEQUENCE_CASE')
        else:
            detail = step.startswith('SWIPE_') or step in {'MAIN', 'IDLE', 'POINTER_DOWN', 'POINTER_MOVE', 'POINTER_UP'}
            if active != case or detail and case != 'C05':
                return empty(reason='SEQUENCE_STEP')
            if event == 'BEGIN':
                if len(stack) >= 8 or step in stack:
                    return empty(reason='SEQUENCE_STEP')
                stack.append(step)
            else:
                if not stack or stack.pop() != step:
                    return empty(reason='SEQUENCE_STEP')
    result.update(diagnostic_state=('missing' if last < 0 else 'incomplete' if active else 'observed'),
                  active_case=active, open_steps=stack, last_event_ms=(last if last >= 0 else None))
    return result
