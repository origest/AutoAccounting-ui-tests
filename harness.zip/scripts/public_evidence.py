"""Publish only schema-validated synthetic metadata, never raw tool logs."""
import ast
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import xml.etree.ElementTree as ET

from result_parser import junit_xml
from safe_scratch import MIN_FREE

ROOT=Path(__file__).resolve().parents[1]
DIRECTORY=ROOT/'evidence'
MARKER='.evidence-owned.json'
BASE_FILES={'summary.json','identity.json','kvm.json','disk.json','TEST-isolated-ui.xml'}
FILES=BASE_FILES|{'cleanup.json','instrumentation.json','progress.json'}
CONTEXT=('GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','GITHUB_SHA','GITHUB_REPOSITORY')
STAGES={'preflight','prepare-build','build','audit-apks','reclaim-build','prepare-runtime','boot','instrumentation','restore','cleanup'}
DISK_STAGES={'initial','before-build','build-monitor','after-owned-build-reclaim','before-emulator'}
KVM_STATES={'not_needed','lease_active','original_acl_verified','restore_failed'}

# Categories are diagnostic hints only, not inferred root causes. No matched bytes leave the VM.
BUILD_FAILURE_REASONS = frozenset({
    'UNKNOWN', 'WRAPPER_STARTUP', 'GRADLE_DISTRIBUTION_DOWNLOAD',
    'GRADLE_DISTRIBUTION_CHECKSUM', 'DEPENDENCY_VERIFICATION', 'PLUGIN_RESOLUTION',
    'DEPENDENCY_RESOLUTION', 'SDK_LOCATION', 'SDK_PACKAGE', 'SDK_LICENSE',
    'JAVA_VERSION', 'JAVA_TOOLCHAIN', 'COMPILATION', 'GRADLE_DAEMON_DISAPPEARED',
    'EXPLICIT_OUT_OF_MEMORY', 'TLS_CERTIFICATE', 'NETWORK_CONNECTION',
})


def classify_build_failure(path, exit_code):
    """Read at most 256 KiB from an owned regular log and return two bounded values."""
    integer(exit_code, -255, 255)
    if exit_code == 0: raise ValueError('Build failure requires nonzero exit')
    result = {'reason': 'UNKNOWN', 'exit_code': exit_code}
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        st = os.fstat(fd)
        if (not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid() or st.st_nlink != 1):
            return result
        os.lseek(fd, max(0, st.st_size - 256 * 1024), os.SEEK_SET)
        tail = os.read(fd, 256 * 1024).decode('utf-8', errors='replace')
    except (OSError, ValueError):
        return result
    finally:
        if fd is not None: os.close(fd)
    # Ignore earlier routine repository misses when Gradle provides a final failure section.
    sections = re.split(r'(?m)^FAILURE: (?:Build failed with an exception\.|Build completed with [0-9]+ failures\.)',tail)
    section = sections[-1]
    lower = section.lower()
    rules = (
        ('GRADLE_DISTRIBUTION_CHECKSUM', ('verification of gradle distribution failed',)),
        ('WRAPPER_STARTUP', ('could not find or load main class org.gradle.wrapper.gradlewrappermain',)),
        ('GRADLE_DISTRIBUTION_DOWNLOAD', ('could not download gradle distribution', 'org.gradle.wrapper.download')),
        ('DEPENDENCY_VERIFICATION', ('dependency verification failed',)),
        ('EXPLICIT_OUT_OF_MEMORY', ('java.lang.outofmemoryerror', 'java heap space', 'gc overhead limit exceeded')),
        ('GRADLE_DAEMON_DISAPPEARED', ('gradle build daemon disappeared unexpectedly',)),
        ('SDK_LOCATION', ('sdk location not found',)),
        ('SDK_LICENSE', ('licenses have not been accepted', 'license for package')),
        ('SDK_PACKAGE', ('failed to find build tools revision', 'failed to find platform sdk', 'failed to find target with hash string')),
        ('JAVA_VERSION', ('android gradle plugin requires java', 'unsupported class file major version', 'invalid source release')),
        ('JAVA_TOOLCHAIN', ('java_home is set to an invalid directory', 'cannot find a java installation', 'no locally installed toolchains match')),
        ('TLS_CERTIFICATE', ('pkix path building failed', 'unable to find valid certification path')),
        ('NETWORK_CONNECTION', ('network is unreachable', 'connection timed out', 'connect timed out', 'connection refused', 'unknownhostexception')),
        ('PLUGIN_RESOLUTION', ('plugin repositories (could not resolve plugin artifact',)),
        ('DEPENDENCY_RESOLUTION', ('could not resolve all files for configuration', 'could not resolve all artifacts for configuration')),
        ('COMPILATION', ('compilation error. see log for more details', 'compilation failed;')),
    )
    for reason, patterns in rules:
        if any(pattern in lower for pattern in patterns):
            result['reason'] = reason
            break
    return result


def checked_build_failure(data):
    exact(data, {'reason', 'exit_code'})
    if not isinstance(data['reason'],str) or data['reason'] not in BUILD_FAILURE_REASONS:
        raise ValueError('Unknown build category')
    integer(data['exit_code'], -255, 255)
    if data['exit_code'] == 0: raise ValueError('Failure cannot have zero exit')
    return {'reason': data['reason'], 'exit_code': data['exit_code']}


def context(): return {k:os.environ[k] for k in CONTEXT}


def receipt(directory):
    st=directory.stat()
    return {'identity':context(),'inode':st.st_ino,'device':st.st_dev,'uid':os.getuid()}


def init():
    if DIRECTORY!=DIRECTORY.resolve(): raise ValueError('Evidence path is not canonical')
    DIRECTORY.mkdir(mode=0o700,exist_ok=False)
    fd=os.open(DIRECTORY/MARKER,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as out: json.dump(receipt(DIRECTORY),out)
    write('cleanup.json',{'runtime':{'state':'not_started','reason':'NONE'},
        'kvm_attempts':{'main':None,'always':None},'evidence_errors':[]})


def regular(path,limit):
    st=path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_nlink!=1 or st.st_size>limit:
        raise ValueError('Evidence is not a bounded owned regular file')


def no_duplicates(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise ValueError('Duplicate JSON key')
        result[key]=value
    return result


def read_json(path,limit=128*1024):
    regular(path,limit)
    return json.loads(path.read_text(),object_pairs_hook=no_duplicates)


def validate():
    if DIRECTORY!=DIRECTORY.resolve(): raise ValueError('Evidence directory is a link')
    st=DIRECTORY.lstat()
    if not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.getuid() or stat.S_IMODE(st.st_mode)!=0o700:
        raise ValueError('Evidence directory is not newly owned')
    if read_json(DIRECTORY/MARKER,4096)!=receipt(DIRECTORY): raise ValueError('Evidence receipt mismatch')
    if any(p.name not in FILES|{MARKER} for p in DIRECTORY.iterdir()): raise ValueError('Unexpected evidence file')


def write(name,value):
    validate()
    if name not in FILES or not name.endswith('.json'): raise ValueError('Unexpected evidence output')
    path=DIRECTORY/name
    prior=None
    if path.exists() or path.is_symlink():
        regular(path,128*1024); prior=path.stat()
    encoded=json.dumps(value,indent=2)+'\n'
    if len(encoded.encode())>128*1024: raise ValueError('Evidence output too large')
    fd,temporary=tempfile.mkstemp(prefix='.evidence-update-',dir=DIRECTORY.parent)
    try:
        with os.fdopen(fd,'w') as out:
            out.write(encoded); out.flush(); os.fsync(out.fileno())
        validate()
        if prior is not None:
            regular(path,128*1024)
            current=path.stat()
            if (current.st_dev,current.st_ino)!=(prior.st_dev,prior.st_ino):
                raise ValueError('Evidence destination changed')
        elif path.exists() or path.is_symlink(): raise ValueError('Evidence destination appeared')
        os.replace(temporary,path)
    finally:
        if os.path.lexists(temporary): os.unlink(temporary)


def write_junit(cases):
    validate()
    path=DIRECTORY/'TEST-isolated-ui.xml'
    if path.exists() or path.is_symlink(): regular(path,64*1024)
    value=junit_xml(cases)
    if len(value.encode())>64*1024: raise ValueError('JUnit too large')
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as out: out.write(value)


def record_kvm_restore(result):
    # An always-step must never adopt a pre-existing/unowned output directory.
    if not DIRECTORY.exists() and not DIRECTORY.is_symlink(): return
    validate(); checked_json('kvm.json',result)
    old_path=DIRECTORY/'kvm.json'
    if old_path.exists() or old_path.is_symlink():
        old=checked_json('kvm.json',read_json(old_path))
        if old['changed_permissions'] and result['state']=='not_needed':
            raise ValueError('A prior KVM grant cannot become an unverified no-change state')
    write('kvm.json',result)


EVIDENCE_TARGETS=frozenset({'summary','instrumentation','runtime','kvm','cleanup','progress'})


def _cleanup(): return checked_json('cleanup.json',read_json(DIRECTORY/'cleanup.json'))


def evidence_error(source,target):
    if source not in ('main','always') or target not in EVIDENCE_TARGETS: raise ValueError('Unknown evidence error')
    error={'source':source,'target':target,'reason':'EVIDENCE_RECORD_FAILED'}
    print('EVIDENCE_DIAGNOSTIC '+json.dumps(error,sort_keys=True))
    try:
        data=_cleanup()
        if error not in data['evidence_errors']: data['evidence_errors'].append(error)
        write('cleanup.json',checked_json('cleanup.json',data))
    except Exception: pass  # Fixed console record remains when persistence itself fails.
    return False


def record_runtime(result):
    try:
        checked_runtime(result)
        print('RUNTIME_DIAGNOSTIC '+json.dumps(result,sort_keys=True))
        data=_cleanup(); data['runtime']=result
        write('cleanup.json',checked_json('cleanup.json',data))
        return True
    except Exception: return evidence_error('main','runtime')


def record_restore_attempt(source,result):
    if source not in ('main','always'): raise ValueError('Unknown restore source')
    try:
        checked_json('kvm.json',result)
        print('KVM_RESTORE_DIAGNOSTIC '+json.dumps({'source':source,'result':result},sort_keys=True))
        data=_cleanup()
        if data['kvm_attempts'][source] is not None: raise ValueError('Duplicate restore attempt')
        data['kvm_attempts'][source]=result
        write('cleanup.json',checked_json('cleanup.json',data))
    except Exception: return evidence_error(source,'cleanup')
    try:
        record_kvm_restore(result)
        return True
    except Exception: return evidence_error(source,'kvm')


def checked_runtime(data):
    from owned_runtime import RUNTIME_REASONS
    exact(data,{'state','reason'})
    if (data['state'] not in ('not_started','running','stopped_verified','cleanup_failed')
            or data['reason'] not in RUNTIME_REASONS): raise ValueError('Unknown runtime diagnostic')
    if data['state'] in ('not_started','running','stopped_verified') and data['reason']!='NONE':
        raise ValueError('Runtime state/reason mismatch')
    if data['state']=='cleanup_failed' and data['reason']=='NONE': raise ValueError('Missing runtime failure reason')
    return data


def cleanup_succeeded(data):
    from kvm_access import restore_succeeded
    checked_json('cleanup.json',data)
    attempts=[r for r in data['kvm_attempts'].values() if r is not None]
    return (not data['evidence_errors'] and data['runtime']['state'] in ('not_started','stopped_verified')
            and all(restore_succeeded(r) for r in attempts))


def exact(value,keys):
    if not isinstance(value,dict) or set(value)!=set(keys): raise ValueError('Unexpected evidence schema')


def integer(value,lower=0,upper=2**50):
    if type(value) is not int or not lower<=value<=upper: raise ValueError('Invalid integer')


def digest(value,n):
    if not isinstance(value,str) or not re.fullmatch('[0-9a-f]{'+str(n)+'}',value): raise ValueError('Invalid digest')


def known_error_codes():
    # Only hard-coded require/exception codes from the reviewed scripts, never arbitrary strings.
    codes={'ValueError','OSError','FileNotFoundError','PermissionError','TimeoutExpired',
           'HTTPError','URLError','KeyError','RuntimeError','KeyboardInterrupt','InterruptedError',
           'UNEXPECTED_FAILURE','INTERRUPTED','KVM_RESTORE_FAILED','CLEANUP_FAILED','EVIDENCE_RECORD_FAILED'}
    for filename in ('run_ui.py','kvm_access.py','owned_runtime.py'):
        tree=ast.parse((ROOT/'scripts'/filename).read_text())
        for node in ast.walk(tree):
            if isinstance(node,ast.Constant) and isinstance(node.value,str) and re.fullmatch('[A-Z][A-Z0-9_]+',node.value):
                codes.add(node.value)
    from owned_runtime import RUNTIME_REASONS
    codes.update('RUNTIME_'+reason for reason in RUNTIME_REASONS if reason!='NONE')
    return codes


def checked_json(name,data):
    if name=='summary.json':
        if data.get('status')=='passed':
            exact(data,{'status','tests','failures','errors','skipped','device_api','device_abi','new_build'})
            if data!={'status':'passed','tests':19,'failures':0,'errors':0,'skipped':0,
                      'device_api':33,'device_abi':'x86_64','new_build':True}: raise ValueError('Unexpected pass summary')
            for key in ('tests','failures','errors','skipped','device_api'): integer(data[key])
        else:
            keys={'status','stage','code','new_build'}
            if 'build_failure' in data:
                keys.add('build_failure')
                if data.get('stage')!='build' or data.get('code')!='BUILD_FAILED':
                    raise ValueError('Build category outside failed build')
                checked_build_failure(data['build_failure'])
            exact(data,keys)
            if (data['status']!='blocked-or-failed' or data['stage'] not in STAGES
                    or data['code'] not in known_error_codes()): raise ValueError('Unexpected failure summary')
        if data['new_build'] is not True: raise ValueError('Not a new-build result')
        return data
    if name=='kvm.json':
        fields={'changed_permissions','restore_verified','state'}
        if 'diagnostic' in data:
            fields.add('diagnostic')
            from kvm_access import RESTORE_PHASES,RESTORE_REASONS,ACL_READBACK,RECEIPT_STATES,ACL_DIFFERENCE_FIELDS
            d=data['diagnostic']
            diagnostic_fields={'phase','reason','write_attempted','acl_readback','receipt'}
            if isinstance(d,dict) and 'acl_difference' in d:
                diagnostic_fields.add('acl_difference')
                difference=d['acl_difference']
                exact(difference,{'from_original','from_lease'})
                for categories in difference.values():
                    exact(categories,ACL_DIFFERENCE_FIELDS)
                    if any(type(v) is not bool for v in categories.values()) or not any(categories.values()):
                        raise ValueError('Invalid ACL difference categories')
                if (d.get('phase')!='acl_compare' or d.get('reason')!='KVM_ACL_CHANGED_EXTERNALLY'
                        or d.get('write_attempted') is not False or d.get('acl_readback')!='unexpected'
                        or d.get('receipt')!='pending' or data.get('state')!='restore_failed'
                        or data.get('restore_verified') is not False or data.get('changed_permissions') is not True):
                    raise ValueError('ACL difference outside refused unknown state')
            exact(d,diagnostic_fields)
            if (d['phase'] not in RESTORE_PHASES or d['reason'] not in RESTORE_REASONS
                    or type(d['write_attempted']) is not bool or d['acl_readback'] not in ACL_READBACK
                    or d['receipt'] not in RECEIPT_STATES): raise ValueError('Unknown KVM diagnostic')
            if data['restore_verified'] and d['acl_readback']!='original':
                raise ValueError('Verified restoration requires original ACL readback')
            if d['reason']=='NONE' and d['phase']!='complete': raise ValueError('Incomplete restore diagnostic')
        exact(data,fields)
        if (type(data['changed_permissions']) is not bool or type(data['restore_verified']) is not bool
                or data['state'] not in KVM_STATES): raise ValueError('Invalid KVM status')
        if data['state'] in ('lease_active','restore_failed') and data['restore_verified']:
            raise ValueError('Active or failed lease cannot be restored')
        if data['state']=='not_needed' and (data['changed_permissions'] or data['restore_verified']):
            raise ValueError('No-change state cannot claim verified restoration')
        if data['state']=='original_acl_verified' and not (data['changed_permissions'] and data['restore_verified']):
            raise ValueError('Restoration state inconsistent')
        return data
    if name=='cleanup.json':
        exact(data,{'runtime','kvm_attempts','evidence_errors'})
        checked_runtime(data['runtime'])
        exact(data['kvm_attempts'],{'main','always'})
        for result in data['kvm_attempts'].values():
            if result is not None:
                checked_json('kvm.json',result)
                if 'diagnostic' not in result: raise ValueError('Restore attempt lacks diagnostics')
        errors=data['evidence_errors']
        if not isinstance(errors,list) or len(errors)>12: raise ValueError('Unbounded evidence errors')
        seen=set()
        for error in errors:
            exact(error,{'source','target','reason'})
            if (error['source'] not in ('main','always') or error['target'] not in EVIDENCE_TARGETS
                    or error['reason']!='EVIDENCE_RECORD_FAILED'): raise ValueError('Unknown evidence error')
            key=(error['source'],error['target'])
            if key in seen: raise ValueError('Duplicate evidence error')
            seen.add(key)
        return data
    if name=='progress.json':
        from progress_capture import checked
        return checked(data)
    if name=='instrumentation.json':
        exact(data,{'cases','protocol_state'})
        if data['protocol_state'] not in ('complete','incomplete','invalid'): raise ValueError('Unknown protocol state')
        expected=json.loads((ROOT/'expected-tests.json').read_text())
        wanted={(x['class'],x['method']) for x in expected}
        cases=data['cases']
        if not isinstance(cases,list) or len(cases)!=19: raise ValueError('Unexpected partial case count')
        seen=set()
        for case in cases:
            exact(case,{'class','method','state'})
            key=(case['class'],case['method'])
            if key not in wanted or key in seen or case['state'] not in ('passed','failed','skipped','started','unknown'):
                raise ValueError('Unexpected partial case')
            if data['protocol_state']=='invalid' and case['state']!='unknown': raise ValueError('Invalid protocol cannot claim outcomes')
            seen.add(key)
        if sum(case['state']=='started' for case in cases)>1:
            raise ValueError('Multiple partial cases cannot be active')
        if data['protocol_state']=='complete' and any(case['state'] in ('unknown','started') for case in cases):
            raise ValueError('Complete protocol lacks terminal observations')
        return data
    if name=='disk.json':
        if not isinstance(data,list) or not data or len(data)>600: raise ValueError('Invalid disk samples')
        for point in data:
            exact(point,{'stage','free_bytes','minimum_bytes'})
            if point['stage'] not in DISK_STAGES or point['minimum_bytes']!=MIN_FREE: raise ValueError('Wrong disk gate')
            integer(point['minimum_bytes']); integer(point['free_bytes'])
        return {'checks':len(data),'minimum_observed_free_bytes':min(x['free_bytes'] for x in data),
                'required_free_bytes':MIN_FREE}
    if name=='identity.json':
        exact(data,{'kind','commit','source_bundle_sha256','apks'})
        if data['kind']!='new-public-source-build' or data['commit']!=os.environ['GITHUB_SHA']: raise ValueError('Identity mismatch')
        digest(data['commit'],40); digest(data['source_bundle_sha256'],64)
        config=json.loads((ROOT/'runtime-lock.json').read_text())
        if data['source_bundle_sha256']!=config['source']['sha256']: raise ValueError('Source identity mismatch')
        exact(data['apks'],{'target','instrumentation'})
        for key,value in data['apks'].items():
            exact(value,{'sha256','size','package','certificate_sha256','manifest'})
            package='net.ankio.auto.isolatedui'+('.test' if key=='instrumentation' else '')
            if value['package']!=package: raise ValueError('Wrong package')
            digest(value['sha256'],64); digest(value['certificate_sha256'],64); integer(value['size'],1,100*1024**2)
            exact(value['manifest'],{'package','test_only','requested_permissions','production_components'})
            m=value['manifest']
            if m['package']!=package or type(m['test_only']) is not bool: raise ValueError('Wrong manifest identity')
            for field in ('requested_permissions','production_components'):
                integer(m[field],0,0)
            if key=='target' and not m['test_only']: raise ValueError('Target not test-only')
        if data['apks']['target']['certificate_sha256']!=data['apks']['instrumentation']['certificate_sha256']:
            raise ValueError('Signer mismatch')
        return data
    raise ValueError('Unrecognized evidence file')


def checked_junit(path):
    regular(path,64*1024)
    raw=path.read_text()
    if '<!DOCTYPE' in raw.upper() or '<!ENTITY' in raw.upper(): raise ValueError('DTD forbidden')
    root=ET.fromstring(raw)
    if root.tag!='testsuite' or root.attrib!={'name':'isolated-ui','tests':'19','failures':'0','errors':'0','skipped':'0'}:
        raise ValueError('Unexpected JUnit suite')
    if (root.text or '').strip() or (root.tail or '').strip(): raise ValueError('Unexpected JUnit text')
    expected=json.loads((ROOT/'expected-tests.json').read_text())
    wanted={(x['class'],x['method']) for x in expected}; cases=[]
    for item in root:
        if item.tag!='testcase' or set(item.attrib)!={'classname','name'} or len(item) or (item.text or '').strip() or (item.tail or '').strip():
            raise ValueError('Unexpected JUnit content')
        case=(item.get('classname'),item.get('name'))
        if case not in wanted or case in cases: raise ValueError('Unexpected JUnit method')
        cases.append(case)
    if len(cases)!=19 or set(cases)!=wanted: raise ValueError('Incomplete JUnit cases')
    return junit_xml(cases)


def publish():
    validate()
    if not (DIRECTORY/'summary.json').is_file(): raise ValueError('Missing summary')
    records=[]
    for name in sorted(FILES):
        path=DIRECTORY/name
        if not path.exists() and not path.is_symlink(): continue
        value=checked_junit(path) if name.endswith('.xml') else checked_json(name,read_json(path))
        records.append((name,value))
    by_name=dict(records)
    if 'cleanup.json' not in by_name: raise ValueError('Missing cleanup diagnostics')
    cleanup_ok=cleanup_succeeded(by_name['cleanup.json'])
    if by_name['summary.json']['status']=='passed' and not cleanup_ok:
        # Test success does not hide a later cleanup/evidence failure. First test
        # failures are never replaced: this only derives a failure from a pass.
        by_name['summary.json']={'status':'blocked-or-failed','stage':'cleanup',
                                'code':'CLEANUP_FAILED','new_build':True}
        records=[(name,by_name['summary.json'] if name=='summary.json' else value) for name,value in records]
    if by_name['summary.json']['status']=='passed':
        cleanup=by_name['cleanup.json']
        if (cleanup['runtime']['state']!='stopped_verified'
                or any(r is None for r in cleanup['kvm_attempts'].values())
                or by_name.get('kvm.json')!=cleanup['kvm_attempts']['always']):
            raise ValueError('Passing evidence lacks explicit runtime/restore completion')
        if (not BASE_FILES.issubset(by_name) or by_name['kvm.json']['state'] not in ('not_needed','original_acl_verified')
                or by_name['disk.json']['minimum_observed_free_bytes']<MIN_FREE):
            raise ValueError('Passing evidence lacks complete results or verified restore')
    # Every value is reconstructed or strictly schema validated. No raw file concatenation.
    text='\n'.join(json.dumps({'evidence':name,'value':value},ensure_ascii=True) for name,value in records)+'\n'
    if len(text.encode())>512*1024: raise ValueError('Public evidence exceeds bound')
    summary=os.environ.get('GITHUB_STEP_SUMMARY')
    rendered='## Isolated UI validation\n\n```json\n'+text+'```\n'
    if summary:
        sink=Path(summary)
        if sink.exists() or sink.is_symlink(): regular(sink,1024*1024)
        existing=sink.stat().st_size if sink.exists() else 0
        if existing+len(rendered.encode())>1024*1024: raise ValueError('Step summary exceeds 1 MiB')
        # This platform-provided per-step sink contains only the validated payload.
        with open(summary,'a') as out: out.write(rendered)
    print(text,end='')


if __name__=='__main__':
    try: publish()
    except Exception:
        print('Public evidence withheld: validation failed; raw logs were not published.')
        raise SystemExit(1)
