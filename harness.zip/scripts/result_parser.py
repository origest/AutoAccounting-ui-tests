"""Fail closed on missing, duplicated, skipped or unexpected instrumentation cases."""
import re
import xml.etree.ElementTree as ET


def parse_output(text, expected):
    wanted = {(x['class'], x['method']) for x in expected}
    if len(wanted) != 19 or len(expected) != 19:
        raise ValueError('Expected exactly 19 unique cases')
    bundle = {}
    ended = []
    active = None
    final = False
    for line in text.splitlines():
        for prefix,pattern in [
            ('INSTRUMENTATION_STATUS:',r'^INSTRUMENTATION_STATUS: [^=]+=.*$'),
            ('INSTRUMENTATION_STATUS_CODE:',r'^INSTRUMENTATION_STATUS_CODE: -?\d+\s*$'),
            ('INSTRUMENTATION_CODE:',r'^INSTRUMENTATION_CODE: -?\d+\s*$')]:
            if line.startswith(prefix) and not re.fullmatch(pattern,line):
                raise ValueError('Malformed instrumentation protocol line')
        if line.startswith(('INSTRUMENTATION_ABORTED','INSTRUMENTATION_RESULT: shortMsg=')):
            raise ValueError('Instrumentation aborted or reported a short failure')
        match = re.match(r'^INSTRUMENTATION_STATUS: ([^=]+)=(.*)$', line)
        if match:
            if final or match[1] in bundle:
                raise ValueError('Status after final result or duplicate bundle key')
            bundle[match[1]] = match[2]
        match = re.match(r'^INSTRUMENTATION_STATUS_CODE: (-?\d+)\s*$', line)
        if match:
            if final:
                raise ValueError('Test status after final result')
            code = int(match[1])
            identity = (bundle.get('class'), bundle.get('test'))
            if code not in (0, 1) or identity not in wanted:
                raise ValueError('Unexpected, failed or skipped test status')
            if bundle.get('numtests') != '19':
                raise ValueError('Instrumentation count was not 19')
            if code == 1:
                if active is not None or identity in ended:
                    raise ValueError('Overlapping or repeated test start')
                active = identity
            else:
                if active != identity:
                    raise ValueError('Test finished before or without its matching start')
                ended.append(identity)
                active = None
            bundle = {}
        match = re.match(r'^INSTRUMENTATION_CODE: (-?\d+)\s*$', line)
        if match:
            if final or int(match[1]) != -1 or active is not None or bundle or len(ended) != 19:
                raise ValueError('Premature, repeated or incomplete final result')
            final = True
    if not final or active is not None or bundle or len(ended) != 19 or set(ended) != wanted:
        raise ValueError('Missing, repeated or incomplete instrumentation results')
    if 'INSTRUMENTATION_FAILED' in text or 'FAILURES!!!' in text:
        raise ValueError('Runner reported failure')
    return ended


def junit_xml(cases):
    root = ET.Element('testsuite', name='isolated-ui', tests='19', failures='0',
                      errors='0', skipped='0')
    for classname, name in cases:
        ET.SubElement(root, 'testcase', classname=classname, name=name)
    return ET.tostring(root, encoding='unicode') + '\n'


# Partial evidence is diagnostic only; never use it as the success gate.
PARTIAL_EXPECTED_CASES = (
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'successfulEmptyResponseShowsEmptyNotError'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'transportFailureShowsErrorAndActualRetryTapRecovers'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'nonSuccessAndMissingDataNeverMasqueradeAsEmpty'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'programmaticNavigationPauseStopsPollingAndReentryRefreshes'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'destroyedViewCancelsInflightReadAndNewPageRecovers'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'activityRecreationRestoresNewFragmentFiltersPagesAndScroll'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'emptyPickerDoesNotImplicitlyClearExistingLink'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'failedSaveKeepsEditorAndRetryPersistsExactlyOnce'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'committedCreateWithLostResponseReconcilesWithoutDuplicateRefund'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'repeatedConfirmWhileSavingCannotCreateDuplicateRefunds'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'explicitClearNeedsPickerAndEditorConfirmationToPersist'),
)
MAX_PARTIAL_BYTES = 2 * 1024 * 1024
MAX_PARTIAL_LINE_BYTES = 16 * 1024
MAX_PARTIAL_LINES = 16384
_PARTIAL_KEYS = ('class', 'current', 'id', 'numtests', 'stack', 'stream', 'test')
_PARTIAL_TERMINAL = {0: 'passed', -1: 'failed', -2: 'failed', -3: 'skipped', -4: 'skipped'}
FAILURE_HINTS = frozenset({'UNKNOWN', 'HELPER_DEADLINE', 'HELPER_INTERRUPTED',
                           'HELPER_PRIOR_GUARD', 'HELPER_CHECKED_ACTION', 'MULTIPLE_FAILURES'})

# Exact reviewed Java source signals. Changed source/line numbers fail to UNKNOWN.
# This is unauthenticated diagnostic text, not proof of origin or a root cause.
_HELPER_FAILURE_PREFIXES = {
    ('java.lang.AssertionError: UI_TEST_DEADLINE_EXCEEDED',
     '\tat net.ankio.auto.isolated.UiTestDeadline.get(UiTestDeadline.java:30)'): 'HELPER_DEADLINE',
    ('java.lang.AssertionError: UI_TEST_WAIT_INTERRUPTED',
     '\tat net.ankio.auto.isolated.UiTestDeadline.get(UiTestDeadline.java:35)'): 'HELPER_INTERRUPTED',
    ('java.lang.AssertionError: UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS',
     '\tat net.ankio.auto.isolated.UiTestDeadline.assertHealthy(UiTestDeadline.java:15)'): 'HELPER_PRIOR_GUARD',
    ('java.lang.AssertionError: UI_TEST_MAIN_ACTION_FAILED',
     '\tat net.ankio.auto.isolated.UiTestDeadline.get(UiTestDeadline.java:40)'): 'HELPER_CHECKED_ACTION',
}


def _failure_hint(stack):
    """Project only fixed top-level signals; never inspect nested errors or return raw text."""
    if type(stack) is not str or len(stack) > MAX_PARTIAL_BYTES:
        return 'UNKNOWN'
    head = stack.split('\n', 2)
    if len(head) >= 2:
        hint = _HELPER_FAILURE_PREFIXES.get((head[0], head[1]))
        # JUnit MultipleFailureException.printStackTrace can concatenate errors
        # without its own header. Never mistake the first flattened block for a
        # single top-level error. Tail syntax is checked, never mined for hints.
        tail = head[2].split('\n') if len(head) == 3 else []
        if hint is not None and all(
                line == '' and index == len(tail) - 1
                or re.fullmatch(r'\t+at [^\s()]+\([^()\n]+\)', line) is not None
                or re.fullmatch(r'\t+\.\.\. [1-9][0-9]{0,4} more', line) is not None
                or line.startswith('Caused by: ') and len(line) > len('Caused by: ')
                or re.fullmatch(r'\t+Suppressed: .+', line) is not None
                for index, line in enumerate(tail)):
            return hint
    # JUnit's multi-error message has opaque summary lines before its first frame.
    # This narrow type-only exception does NOT identify a helper signal or first cause.
    if re.fullmatch(r'org\.junit\.(?:internal\.)?runners\.model\.MultipleFailureException: '
                    r'There were (?:[2-9]|[1-5][0-9]|6[0-4]) errors:', head[0]):
        return 'MULTIPLE_FAILURES'
    return 'UNKNOWN'


# Fixed source/compiled-call mapping. IDs below reference only this literal method table.
# Every row is an ordered complete helper-caller path, nearest throwable first.
# File-only $r8 bridge tokens are deliberate DEX no-position encodings, NOT Unknown Source.
# No wildcard, line range, synthetic-name prefix, arbitrary frame skipping or graph search.
SITE_SOURCE_SHA256 = 'a0352fcf35b668d1ff1cb41e14b5fe6320dde9054c70f861d2c8029e8e7419df'
# Provenance anchors, not a requirement that future newly signed APK bytes match.
SITE_MAPPING_APK_SHA256 = 'ece4440493edfd6af24627dff66dfb132f47bfb4404a4ece0efd3439beaad5e3'
SITE_MAPPING_DEX_SHA256 = 'af20e4259ddcb46124af08f39ef5508eb6495562a5318fcf93ce849295767974'
MAX_FAILURE_SITE_BYTES = 32 * 1024
MAX_FAILURE_SITE_FRAMES = 128
_SITE_METHODS = (
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'onMainUntil$lambda$0', 'IsolatedUiFixture.kt'),  # 0
    ('net.ankio.auto.isolated.IsolatedUiProgress', 'step', 'IsolatedUiProgress.kt'),  # 1
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'step', 'IsolatedUiFixture.kt'),  # 2
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'onMainUntil', 'IsolatedUiFixture.kt'),  # 3
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'onMain', 'IsolatedUiFixture.kt'),  # 4
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'showData', 'DataPageIsolatedUiTest.kt'),  # 5
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'successfulEmptyResponseShowsEmptyNotError', 'DataPageIsolatedUiTest.kt'),  # 6
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'await', 'IsolatedUiFixture.kt'),  # 7
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'await$default', 'IsolatedUiFixture.kt'),  # 8
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'setUpIsolatedUi$lambda$0', 'IsolatedUiFixture.kt'),  # 9
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'setUpIsolatedUi', 'IsolatedUiFixture.kt'),  # 10
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'waitForUiIdle$lambda$0', 'IsolatedUiFixture.kt'),  # 11
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'waitForUiIdle', 'IsolatedUiFixture.kt'),  # 12
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'setUpIsolatedUi$lambda$3', 'IsolatedUiFixture.kt'),  # 13
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi$lambda$0', 'IsolatedUiFixture.kt'),  # 14
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi', 'IsolatedUiFixture.kt'),  # 15
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi$lambda$1', 'IsolatedUiFixture.kt'),  # 16
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi$lambda$3', 'IsolatedUiFixture.kt'),  # 17
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'transportFailureShowsErrorAndActualRetryTapRecovers', 'DataPageIsolatedUiTest.kt'),  # 18
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'root', 'DataPageIsolatedUiTest.kt'),  # 19
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'click', 'IsolatedUiFixture.kt'),  # 20
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tapView', 'IsolatedUiFixture.kt'),  # 21
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'screenBounds', 'IsolatedUiFixture.kt'),  # 22
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'gesture', 'IsolatedUiFixture.kt'),  # 23
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'nonSuccessAndMissingDataNeverMasqueradeAsEmpty', 'DataPageIsolatedUiTest.kt'),  # 24
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage', 'DataPageIsolatedUiTest.kt'),  # 25
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$1', 'DataPageIsolatedUiTest.kt'),  # 26
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning', 'DataPageIsolatedUiTest.kt'),  # 27
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$2', 'DataPageIsolatedUiTest.kt'),  # 28
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'swipeRefresh', 'DataPageIsolatedUiTest.kt'),  # 29
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$3', 'DataPageIsolatedUiTest.kt'),  # 30
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$4', 'DataPageIsolatedUiTest.kt'),  # 31
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$5', 'DataPageIsolatedUiTest.kt'),  # 32
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$8', 'DataPageIsolatedUiTest.kt'),  # 33
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$9', 'DataPageIsolatedUiTest.kt'),  # 34
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'programmaticNavigationPauseStopsPollingAndReentryRefreshes', 'DataPageIsolatedUiTest.kt'),  # 35
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'destroyedViewCancelsInflightReadAndNewPageRecovers', 'DataPageIsolatedUiTest.kt'),  # 36
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry', 'DataPageIsolatedUiTest.kt'),  # 37
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset', 'DataPageIsolatedUiTest.kt'),  # 38
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'gesture$default', 'IsolatedUiFixture.kt'),  # 39
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'activityRecreationRestoresNewFragmentFiltersPagesAndScroll', 'DataPageIsolatedUiTest.kt'),  # 40
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'editor', 'IsolatedUiFixture.kt'),  # 41
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen', 'RefundIsolatedUiTest.kt'),  # 42
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'dialogRoot', 'IsolatedUiFixture.kt'),  # 43
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'picker', 'RefundIsolatedUiTest.kt'),  # 44
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'rootWith', 'IsolatedUiFixture.kt'),  # 45
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'waitCandidates', 'RefundIsolatedUiTest.kt'),  # 46
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'choose', 'RefundIsolatedUiTest.kt'),  # 47
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft', 'RefundIsolatedUiTest.kt'),  # 48
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'backFromPicker', 'RefundIsolatedUiTest.kt'),  # 49
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'changeAmount', 'RefundIsolatedUiTest.kt'),  # 50
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'editor$default', 'IsolatedUiFixture.kt'),  # 51
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'emptyPickerDoesNotImplicitlyClearExistingLink', 'RefundIsolatedUiTest.kt'),  # 52
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation', 'RefundIsolatedUiTest.kt'),  # 53
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'failedSaveKeepsEditorAndRetryPersistsExactlyOnce', 'RefundIsolatedUiTest.kt'),  # 54
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected', 'RefundIsolatedUiTest.kt'),  # 55
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'committedCreateWithLostResponseReconcilesWithoutDuplicateRefund', 'RefundIsolatedUiTest.kt'),  # 56
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'repeatedConfirmWhileSavingCannotCreateDuplicateRefunds', 'RefundIsolatedUiTest.kt'),  # 57
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'explicitClearNeedsPickerAndEditorConfirmationToPersist', 'RefundIsolatedUiTest.kt'),  # 58
)
_SITE_DEX_BRIDGES = {
    0: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$pqc2xdtwzS3tWCErdAcoZS6IlfA(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda15.invoke(D8$$SyntheticClass:0)'),
    9: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$cTst6Nu5ADFQ8TVX561Stnp5Qeg(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda7.invoke(D8$$SyntheticClass:0)'),
    11: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$pUg6uQlFEPVmt5tCemyoCI8Zhds(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda11.invoke(D8$$SyntheticClass:0)'),
    13: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$07Pyuv9zJ2kRCfyp7CBoQ1TOcog(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda10.invoke(D8$$SyntheticClass:0)'),
    14: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$g6xdu23qiUVM2D-ub6pwC4Zybeg(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)'),
    16: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$N4SXqmxRK9CcrqtxjHmQf7SlbB8(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda4.invoke(D8$$SyntheticClass:0)'),
    17: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$WaOj41n6C1vpbMNobTY6ChKtTw8(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda6.invoke(D8$$SyntheticClass:0)'),
    26: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$-y-x0tKBNCV1CW7OKnPQARpOq_o(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda57.invoke(D8$$SyntheticClass:0)'),
    28: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$U-sNSdtjQRVHYXNfm7m3MhpxQlo(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda58.invoke(D8$$SyntheticClass:0)'),
    30: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$FQk0sWiJcK0-d3eQ6iiiO0NBL8A(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda59.invoke(D8$$SyntheticClass:0)'),
    31: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$eOmV61CHsV3RcGkbIDs80GIOlNg(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda60.invoke(D8$$SyntheticClass:0)'),
    32: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$HXc04oMjhDoIOGTwaD5_n4UU0bg(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda61.invoke(D8$$SyntheticClass:0)'),
    33: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$DnhC9e_xqJvBbHRXr9-tN6rN3YQ(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda64.invoke(D8$$SyntheticClass:0)'),
    34: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$7APsH5oLpg2KBrLZd_fL_w5gA-M(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda56.invoke(D8$$SyntheticClass:0)'),
}
_SITE_ROWS = (
    (1, 'BODY_C01_L041', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 6:41'),
    (1, 'BODY_C01_L042', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 6:42'),
    (1, 'BODY_C01_L043', 'MAIN', '0:111 1:66 2:41 3:105 4:103 6:43'),
    (0, 'SETUP_RESET', 'MAIN', '0:111 1:66 2:41 3:105 4:103 9:50 1:66 2:41 10:50'),
    (0, 'SETUP_IDLE', 'IDLE', '11:124 1:66 2:41 12:118 13:57 1:66 2:41 10:57'),
    (0, 'TEARDOWN_HOST_FINISH', 'MAIN', '0:111 1:66 2:41 3:105 4:103 14:67 1:66 2:41 15:66'),
    (0, 'TEARDOWN_HOST_DESTROYED', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 14:68 1:66 2:41 15:66'),
    (0, 'TEARDOWN_REQUESTS', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 16:72 1:66 2:41 15:72'),
    (0, 'TEARDOWN_DATABASE', 'CLEANUP', '17:89 1:66 2:41 15:87'),
    (2, 'BODY_C02_L052', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 18:52'),
    (2, 'BODY_C02_L053', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 18:53'),
    (2, 'BODY_C02_L054', 'MAIN', '0:111 1:66 2:41 3:105 4:103 18:54'),
    (2, 'BODY_C02_L057', 'MAIN', '0:111 1:66 2:41 3:105 4:103 19:26 18:57'),
    (2, 'BODY_C02_L057', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 18:57'),
    (2, 'BODY_C02_L057', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 18:57'),
    (2, 'BODY_C02_L057', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 18:57'),
    (2, 'BODY_C02_L057', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 18:57'),
    (2, 'BODY_C02_L058', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 18:58'),
    (2, 'BODY_C02_L059', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 18:59'),
    (3, 'BODY_C03_L068', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 24:68'),
    (3, 'BODY_C03_L069', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 24:69'),
    (3, 'BODY_C03_L072', 'MAIN', '0:111 1:66 2:41 3:105 4:103 19:26 24:72'),
    (3, 'BODY_C03_L072', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 24:72'),
    (3, 'BODY_C03_L072', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 24:72'),
    (3, 'BODY_C03_L072', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 24:72'),
    (3, 'BODY_C03_L072', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 24:72'),
    (3, 'BODY_C03_L073', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 24:73'),
    (3, 'BODY_C03_L076', 'MAIN', '0:111 1:66 2:41 3:105 4:103 24:76'),
    (3, 'BODY_C03_L078', 'MAIN', '0:111 1:66 2:41 3:105 4:103 19:26 24:78'),
    (3, 'BODY_C03_L078', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 24:78'),
    (3, 'BODY_C03_L078', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 24:78'),
    (3, 'BODY_C03_L078', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 24:78'),
    (3, 'BODY_C03_L078', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 24:78'),
    (3, 'BODY_C03_L079', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 24:79'),
    (4, 'BODY_C04_L083', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 25:83'),
    (4, 'BODY_C04_L084', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 25:84'),
    (4, 'BODY_C04_L086', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 25:86'),
    (5, 'SWIPE_SHOW', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 26:93 1:66 2:41 27:93'),
    (5, 'SWIPE_INITIAL_ROWS', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 28:94 1:66 2:41 27:94'),
    (5, 'SWIPE_FIRST', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 29:33 30:99 1:66 2:41 27:99'),
    (5, 'SWIPE_FIRST', 'IDLE', '11:124 1:66 2:41 12:118 23:197 29:36 30:99 1:66 2:41 27:99'),
    (5, 'SWIPE_REQUEST_OBSERVED', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 31:100 1:66 2:41 27:100'),
    (5, 'SWIPE_SECOND', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 29:33 32:101 1:66 2:41 27:101'),
    (5, 'SWIPE_SECOND', 'IDLE', '11:124 1:66 2:41 12:118 23:197 29:36 32:101 1:66 2:41 27:101'),
    (5, 'SWIPE_FINAL_ROWS', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 33:111 1:66 2:41 27:110'),
    (5, 'SWIPE_FINAL_ERROR', 'MAIN', '0:111 1:66 2:41 3:105 4:103 34:115 1:66 2:41 27:115'),
    (6, 'BODY_C06_L119', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 35:119'),
    (6, 'BODY_C06_L120', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 35:120'),
    (6, 'BODY_C06_L121', 'MAIN', '0:111 1:66 2:41 3:105 4:103 35:121'),
    (6, 'BODY_C06_L127', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 35:127'),
    (6, 'BODY_C06_L132', 'MAIN', '0:111 1:66 2:41 3:105 4:103 35:132'),
    (6, 'BODY_C06_L133', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 35:133'),
    (7, 'BODY_C07_L139', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 36:139'),
    (7, 'BODY_C07_L140', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 36:140'),
    (7, 'BODY_C07_L141', 'MAIN', '0:111 1:66 2:41 3:105 4:103 36:141'),
    (7, 'BODY_C07_L142', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 36:142'),
    (7, 'BODY_C07_L146', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 36:146'),
    (7, 'BODY_C07_L147', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 36:147'),
    (7, 'BODY_C07_L148', 'MAIN', '0:111 1:66 2:41 3:105 4:103 36:148'),
    (8, 'BODY_C08_L159', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 37:159'),
    (8, 'BODY_C08_L160', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 37:160'),
    (8, 'BODY_C08_L161', 'MAIN', '0:111 1:66 2:41 3:105 4:103 19:26 37:161'),
    (8, 'BODY_C08_L161', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 37:161'),
    (8, 'BODY_C08_L161', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 37:161'),
    (8, 'BODY_C08_L161', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 37:161'),
    (8, 'BODY_C08_L161', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 37:161'),
    (8, 'BODY_C08_L163', 'MAIN', '0:111 1:66 2:41 3:105 4:103 37:163'),
    (8, 'BODY_C08_L167', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 37:167'),
    (8, 'BODY_C08_L167', 'IDLE', '11:124 1:66 2:41 12:118 21:160 37:167'),
    (8, 'BODY_C08_L167', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 37:167'),
    (8, 'BODY_C08_L167', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 37:167'),
    (8, 'BODY_C08_L168', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 37:168'),
    (8, 'BODY_C08_L173', 'MAIN', '0:111 1:66 2:41 3:105 4:103 37:173'),
    (8, 'BODY_C08_L179', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 37:179'),
    (8, 'BODY_C08_L184', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 37:184'),
    (8, 'BODY_C08_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 37:185'),
    (8, 'BODY_C08_L195', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 37:195'),
    (8, 'BODY_C08_L196', 'MAIN', '0:111 1:66 2:41 3:105 4:103 37:196'),
    (9, 'BODY_C09_L206', 'MAIN', '0:111 1:66 2:41 3:105 4:103 5:25 38:206'),
    (9, 'BODY_C09_L207', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 38:207'),
    (9, 'BODY_C09_L208', 'MAIN', '0:111 1:66 2:41 3:105 4:103 38:208'),
    (9, 'BODY_C09_L210', 'MAIN', '0:111 1:66 2:41 3:105 4:103 38:210'),
    (9, 'BODY_C09_L211', 'IDLE', '11:124 1:66 2:41 12:118 38:211'),
    (9, 'BODY_C09_L212', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 38:212'),
    (9, 'BODY_C09_L213', 'IDLE', '11:124 1:66 2:41 12:118 23:197 39:177 38:213'),
    (9, 'BODY_C09_L215', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 38:215'),
    (9, 'BODY_C09_L216', 'MAIN', '0:111 1:66 2:41 3:105 4:103 38:216'),
    (9, 'BODY_C09_L217', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 38:217'),
    (9, 'BODY_C09_L228', 'MAIN', '0:111 1:66 2:41 3:105 4:103 38:228'),
    (9, 'BODY_C09_L230', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 38:230'),
    (9, 'BODY_C09_L233', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 38:233'),
    (9, 'BODY_C09_L234', 'MAIN', '0:111 1:66 2:41 3:105 4:103 38:234'),
    (10, 'BODY_C10_L247', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:247'),
    (10, 'BODY_C10_L253', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 40:253'),
    (10, 'BODY_C10_L254', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:254'),
    (10, 'BODY_C10_L255', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:255'),
    (10, 'BODY_C10_L256', 'IDLE', '11:124 1:66 2:41 12:118 40:256'),
    (10, 'BODY_C10_L257', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 40:257'),
    (10, 'BODY_C10_L258', 'IDLE', '11:124 1:66 2:41 12:118 23:197 39:177 40:258'),
    (10, 'BODY_C10_L260', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 40:260'),
    (10, 'BODY_C10_L261', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:261'),
    (10, 'BODY_C10_L262', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 40:262'),
    (10, 'BODY_C10_L273', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:273'),
    (10, 'BODY_C10_L277', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:277'),
    (10, 'BODY_C10_L284', 'IDLE', '11:124 1:66 2:41 12:118 40:284'),
    (10, 'BODY_C10_L286', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:286'),
    (10, 'BODY_C10_L290', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 40:290'),
    (10, 'BODY_C10_L291', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:291'),
    (10, 'BODY_C10_L292', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 40:292'),
    (10, 'BODY_C10_L295', 'MAIN', '0:111 1:66 2:41 3:105 4:103 40:295'),
    (11, 'BODY_C11_L066', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 42:66'),
    (11, 'BODY_C11_L067', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 44:23 42:67'),
    (11, 'BODY_C11_L067', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 44:23 42:67'),
    (11, 'BODY_C11_L067', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 44:23 42:67'),
    (11, 'BODY_C11_L067', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 44:23 42:67'),
    (11, 'BODY_C11_L067', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 44:23 42:67'),
    (11, 'BODY_C11_L067', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 44:24 42:67'),
    (11, 'BODY_C11_L067', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 44:25 42:67'),
    (11, 'BODY_C11_L068', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 46:29 42:68'),
    (11, 'BODY_C11_L069', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:36 42:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:37 42:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:40 42:69'),
    (11, 'BODY_C11_L069', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 47:41 42:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 47:42 42:69'),
    (11, 'BODY_C11_L069', 'IDLE', '11:124 1:66 2:41 12:118 21:160 47:42 42:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 47:42 42:69'),
    (11, 'BODY_C11_L069', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 47:42 42:69'),
    (11, 'BODY_C11_L070', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 42:70'),
    (11, 'BODY_C11_L070', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 42:70'),
    (11, 'BODY_C11_L070', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 42:70'),
    (11, 'BODY_C11_L070', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 42:70'),
    (11, 'BODY_C11_L071', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 42:71'),
    (11, 'BODY_C11_L074', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 42:74'),
    (11, 'BODY_C11_L074', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 42:74'),
    (11, 'BODY_C11_L074', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 42:74'),
    (11, 'BODY_C11_L074', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 42:74'),
    (11, 'BODY_C11_L074', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 42:74'),
    (11, 'BODY_C11_L075', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 42:75'),
    (11, 'BODY_C11_L077', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 42:77'),
    (12, 'BODY_C12_L093', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 48:93'),
    (12, 'BODY_C12_L094', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 44:23 48:94'),
    (12, 'BODY_C12_L094', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 44:23 48:94'),
    (12, 'BODY_C12_L094', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 44:23 48:94'),
    (12, 'BODY_C12_L094', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 44:23 48:94'),
    (12, 'BODY_C12_L094', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 44:23 48:94'),
    (12, 'BODY_C12_L094', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 44:24 48:94'),
    (12, 'BODY_C12_L094', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 44:25 48:94'),
    (12, 'BODY_C12_L095', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 46:29 48:95'),
    (12, 'BODY_C12_L096', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:36 48:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:37 48:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:40 48:96'),
    (12, 'BODY_C12_L096', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 47:41 48:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 47:42 48:96'),
    (12, 'BODY_C12_L096', 'IDLE', '11:124 1:66 2:41 12:118 21:160 47:42 48:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 47:42 48:96'),
    (12, 'BODY_C12_L096', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 47:42 48:96'),
    (12, 'BODY_C12_L097', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 49:47 48:97'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 50:51 48:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 50:51 48:98'),
    (12, 'BODY_C12_L098', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 50:51 48:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 50:51 48:98'),
    (12, 'BODY_C12_L098', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 50:51 48:98'),
    (12, 'BODY_C12_L098', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 50:52 48:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 50:53 48:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 50:55 48:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 50:56 48:98'),
    (12, 'BODY_C12_L098', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 50:56 48:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 50:56 48:98'),
    (12, 'BODY_C12_L098', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 50:56 48:98'),
    (12, 'BODY_C12_L098', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 50:57 48:98'),
    (12, 'BODY_C12_L099', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 48:99'),
    (12, 'BODY_C12_L099', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 48:99'),
    (12, 'BODY_C12_L099', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 48:99'),
    (12, 'BODY_C12_L099', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 48:99'),
    (12, 'BODY_C12_L099', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 48:99'),
    (12, 'BODY_C12_L100', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 48:100'),
    (13, 'BODY_C13_L112', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 51:210 52:112'),
    (13, 'BODY_C13_L113', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 44:23 52:113'),
    (13, 'BODY_C13_L113', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 44:23 52:113'),
    (13, 'BODY_C13_L113', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 44:23 52:113'),
    (13, 'BODY_C13_L113', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 44:23 52:113'),
    (13, 'BODY_C13_L113', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 44:23 52:113'),
    (13, 'BODY_C13_L113', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 44:24 52:113'),
    (13, 'BODY_C13_L113', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 44:25 52:113'),
    (13, 'BODY_C13_L114', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 52:114'),
    (13, 'BODY_C13_L115', 'MAIN', '0:111 1:66 2:41 3:105 4:103 52:115'),
    (13, 'BODY_C13_L119', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 49:47 52:119'),
    (13, 'BODY_C13_L120', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 52:120'),
    (13, 'BODY_C13_L120', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 52:120'),
    (13, 'BODY_C13_L120', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 52:120'),
    (13, 'BODY_C13_L120', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 52:120'),
    (13, 'BODY_C13_L120', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 52:120'),
    (14, 'BODY_C14_L128', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 51:210 53:128'),
    (14, 'BODY_C14_L129', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 44:23 53:129'),
    (14, 'BODY_C14_L129', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 44:23 53:129'),
    (14, 'BODY_C14_L129', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 44:23 53:129'),
    (14, 'BODY_C14_L129', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 44:23 53:129'),
    (14, 'BODY_C14_L129', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 44:23 53:129'),
    (14, 'BODY_C14_L129', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 44:24 53:129'),
    (14, 'BODY_C14_L129', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 44:25 53:129'),
    (14, 'BODY_C14_L130', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 53:130'),
    (14, 'BODY_C14_L131', 'MAIN', '0:111 1:66 2:41 3:105 4:103 53:131'),
    (14, 'BODY_C14_L135', 'MAIN', '0:111 1:66 2:41 3:105 4:103 53:135'),
    (14, 'BODY_C14_L138', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 53:138'),
    (14, 'BODY_C14_L138', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 53:138'),
    (14, 'BODY_C14_L138', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 53:138'),
    (14, 'BODY_C14_L138', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 53:138'),
    (14, 'BODY_C14_L139', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 53:139'),
    (14, 'BODY_C14_L141', 'MAIN', '0:111 1:66 2:41 3:105 4:103 53:141'),
    (14, 'BODY_C14_L142', 'IDLE', '11:124 1:66 2:41 12:118 23:197 53:142'),
    (14, 'BODY_C14_L147', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 46:29 53:147'),
    (14, 'BODY_C14_L148', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:36 53:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:37 53:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:111 1:66 2:41 3:105 4:103 47:40 53:148'),
    (14, 'BODY_C14_L148', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 47:41 53:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 47:42 53:148'),
    (14, 'BODY_C14_L148', 'IDLE', '11:124 1:66 2:41 12:118 21:160 47:42 53:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 47:42 53:148'),
    (14, 'BODY_C14_L148', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 47:42 53:148'),
    (14, 'BODY_C14_L149', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 49:47 53:149'),
    (14, 'BODY_C14_L150', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 53:150'),
    (14, 'BODY_C14_L150', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 53:150'),
    (14, 'BODY_C14_L150', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 53:150'),
    (14, 'BODY_C14_L150', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 53:150'),
    (14, 'BODY_C14_L150', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 53:150'),
    (15, 'BODY_C15_L160', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 54:160'),
    (15, 'BODY_C15_L163', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 54:163'),
    (15, 'BODY_C15_L163', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 54:163'),
    (15, 'BODY_C15_L163', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 54:163'),
    (15, 'BODY_C15_L163', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 54:163'),
    (15, 'BODY_C15_L163', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 54:163'),
    (15, 'BODY_C15_L164', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 54:164'),
    (15, 'BODY_C15_L168', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 54:168'),
    (15, 'BODY_C15_L168', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 54:168'),
    (15, 'BODY_C15_L168', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 54:168'),
    (15, 'BODY_C15_L168', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 54:168'),
    (15, 'BODY_C15_L168', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 54:168'),
    (15, 'BODY_C15_L169', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 54:169'),
    (16, 'BODY_C16_L178', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 55:178'),
    (16, 'BODY_C16_L179', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 55:179'),
    (16, 'BODY_C16_L179', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 55:179'),
    (16, 'BODY_C16_L179', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 55:179'),
    (16, 'BODY_C16_L179', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 55:179'),
    (16, 'BODY_C16_L179', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 55:179'),
    (16, 'BODY_C16_L180', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 55:180'),
    (16, 'BODY_C16_L183', 'MAIN', '0:111 1:66 2:41 3:105 4:103 55:183'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 50:51 55:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 50:51 55:185'),
    (16, 'BODY_C16_L185', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 50:51 55:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 50:51 55:185'),
    (16, 'BODY_C16_L185', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 50:51 55:185'),
    (16, 'BODY_C16_L185', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 50:52 55:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 50:53 55:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 50:55 55:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 50:56 55:185'),
    (16, 'BODY_C16_L185', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 50:56 55:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 50:56 55:185'),
    (16, 'BODY_C16_L185', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 50:56 55:185'),
    (16, 'BODY_C16_L185', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 50:57 55:185'),
    (16, 'BODY_C16_L186', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 55:186'),
    (16, 'BODY_C16_L186', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 55:186'),
    (16, 'BODY_C16_L186', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 55:186'),
    (16, 'BODY_C16_L186', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 55:186'),
    (16, 'BODY_C16_L186', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 55:186'),
    (16, 'BODY_C16_L187', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 55:187'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 50:51 55:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 50:51 55:189'),
    (16, 'BODY_C16_L189', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 50:51 55:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 50:51 55:189'),
    (16, 'BODY_C16_L189', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 50:51 55:189'),
    (16, 'BODY_C16_L189', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 50:52 55:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 50:53 55:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 50:55 55:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 50:56 55:189'),
    (16, 'BODY_C16_L189', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 50:56 55:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 50:56 55:189'),
    (16, 'BODY_C16_L189', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 50:56 55:189'),
    (16, 'BODY_C16_L189', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 50:57 55:189'),
    (16, 'BODY_C16_L190', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 55:190'),
    (16, 'BODY_C16_L190', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 55:190'),
    (16, 'BODY_C16_L190', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 55:190'),
    (16, 'BODY_C16_L190', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 55:190'),
    (16, 'BODY_C16_L190', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 55:190'),
    (16, 'BODY_C16_L191', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 55:191'),
    (17, 'BODY_C17_L200', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 56:200'),
    (17, 'BODY_C17_L201', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 56:201'),
    (17, 'BODY_C17_L201', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 56:201'),
    (17, 'BODY_C17_L201', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 56:201'),
    (17, 'BODY_C17_L201', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 56:201'),
    (17, 'BODY_C17_L201', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 56:201'),
    (17, 'BODY_C17_L202', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 56:202'),
    (17, 'BODY_C17_L205', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 56:205'),
    (17, 'BODY_C17_L205', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 56:205'),
    (17, 'BODY_C17_L205', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 56:205'),
    (17, 'BODY_C17_L205', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 56:205'),
    (17, 'BODY_C17_L205', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 56:205'),
    (17, 'BODY_C17_L206', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 56:206'),
    (18, 'BODY_C18_L216', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 57:216'),
    (18, 'BODY_C18_L217', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 57:217'),
    (18, 'BODY_C18_L218', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 57:218'),
    (18, 'BODY_C18_L218', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 57:218'),
    (18, 'BODY_C18_L218', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 57:218'),
    (18, 'BODY_C18_L218', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 57:218'),
    (18, 'BODY_C18_L219', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 57:219'),
    (18, 'BODY_C18_L220', 'MAIN', '0:111 1:66 2:41 3:105 4:103 57:220'),
    (18, 'BODY_C18_L221', 'IDLE', '11:124 1:66 2:41 12:118 23:197 57:221'),
    (18, 'BODY_C18_L223', 'MAIN', '0:111 1:66 2:41 3:105 4:103 57:223'),
    (18, 'BODY_C18_L226', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 57:226'),
    (19, 'BODY_C19_L235', 'MAIN', '0:111 1:66 2:41 3:105 4:103 41:216 58:235'),
    (19, 'BODY_C19_L236', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 44:23 58:236'),
    (19, 'BODY_C19_L236', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 44:23 58:236'),
    (19, 'BODY_C19_L236', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 44:23 58:236'),
    (19, 'BODY_C19_L236', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 44:23 58:236'),
    (19, 'BODY_C19_L236', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 44:23 58:236'),
    (19, 'BODY_C19_L236', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 44:24 58:236'),
    (19, 'BODY_C19_L236', 'MAIN', '0:111 1:66 2:41 3:105 4:103 45:200 44:25 58:236'),
    (19, 'BODY_C19_L237', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 46:29 58:237'),
    (19, 'BODY_C19_L238', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 58:238'),
    (19, 'BODY_C19_L238', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 58:238'),
    (19, 'BODY_C19_L238', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 58:238'),
    (19, 'BODY_C19_L238', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 58:238'),
    (19, 'BODY_C19_L240', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 58:240'),
    (19, 'BODY_C19_L240', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 58:240'),
    (19, 'BODY_C19_L240', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 58:240'),
    (19, 'BODY_C19_L240', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 58:240'),
    (19, 'BODY_C19_L241', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 58:241'),
    (19, 'BODY_C19_L243', 'MAIN', '0:111 1:66 2:41 3:105 4:103 43:223 58:243'),
    (19, 'BODY_C19_L243', 'MAIN', '0:111 1:66 2:41 3:105 4:103 21:155 20:150 58:243'),
    (19, 'BODY_C19_L243', 'IDLE', '11:124 1:66 2:41 12:118 21:160 20:150 58:243'),
    (19, 'BODY_C19_L243', 'MAIN', '0:111 1:66 2:41 3:105 4:103 22:167 21:161 20:150 58:243'),
    (19, 'BODY_C19_L243', 'IDLE', '11:124 1:66 2:41 12:118 23:197 21:162 20:150 58:243'),
    (19, 'BODY_C19_L244', 'POLL_MAIN', '0:111 1:66 2:41 3:105 7:136 8:127 58:244'),
)

def _build_failure_sites():
    paths, pairs = {}, {}
    for index, phase, wait, encoded in _SITE_ROWS:
        frames = []
        for token in encoded.split(' '):
            method_id, line = map(int, token.split(':'))
            cls, method, file = _SITE_METHODS[method_id]
            frames.append(f'{cls}.{method}({file}:{line})')
            frames.extend(_SITE_DEX_BRIDGES.get(method_id, ()))
        identities = PARTIAL_EXPECTED_CASES if index == 0 else (PARTIAL_EXPECTED_CASES[index - 1],)
        for identity in identities:
            key = (identity, tuple(frames))
            if key in paths and paths[key] != (phase, wait):
                raise ValueError('Conflicting fixed failure-site map')
            paths[key] = (phase, wait)
            pairs.setdefault(identity, set()).add((phase, wait))
    return paths, pairs


_FAILURE_SITE_PATHS, _FAILURE_SITE_PAIRS = _build_failure_sites()
_SITE_GET_HINTS = frozenset({'HELPER_DEADLINE', 'HELPER_INTERRUPTED', 'HELPER_CHECKED_ACTION'})


def failure_site_allowed(identity, state, hint, phase, wait):
    """Validate only finite published values, including their case/hint relationship."""
    if type(phase) is not str or type(wait) is not str:
        return False
    if state != 'failed':
        return phase == wait == 'NOT_APPLICABLE'
    if phase == wait == 'UNKNOWN':
        return True
    return hint in _SITE_GET_HINTS and (phase, wait) in _FAILURE_SITE_PAIRS.get(identity, ())


def _site_primary_frames(stack):
    """Validate the first trace and the nesting syntax without mining secondary data."""
    lines = stack.split('\n')[1:]
    if lines and lines[-1] == '':
        lines.pop()
    primary = []
    cursor = 0
    while cursor < len(lines):
        match = re.fullmatch(r'\tat ([^\s()]+\([^()\n]+\))', lines[cursor])
        if match is None:
            break
        primary.append(match[1])
        if len(primary) > MAX_FAILURE_SITE_FRAMES:
            return None
        cursor += 1
    # Each enclosed trace's elision is bounded by its actual enclosing trace,
    # including that trace's own previously validated elision. No tail is mined.
    contexts = {0: {'count': len(primary), 'enclosing': None, 'elided': False}}
    nested_count = 0
    for line in lines[cursor:]:
        header = re.fullmatch(r'(\t*)(Suppressed: |Caused by: )(.+)', line)
        if header:
            tabs, caption, _ = header.groups()
            depth = len(tabs)
            parent = depth - 1 if caption == 'Suppressed: ' else depth
            if parent < 0 or parent not in contexts or depth > 16:
                return None
            nested_count += 1
            if nested_count > 128:
                return None
            enclosing = contexts[parent]['count']
            contexts = {d: value for d, value in contexts.items() if d <= parent}
            contexts[depth] = {'count': 0, 'enclosing': enclosing, 'elided': False}
            continue
        # An enclosed frame/elision requires an actual preceding exception header.
        if nested_count == 0:
            return None
        depth = max(contexts)
        frame = re.fullmatch(r'(\t+)at [^\s()]+\([^()\n]+\)', line)
        if frame:
            if len(frame[1]) != depth + 1 or contexts[depth]['elided']:
                return None
            contexts[depth]['count'] += 1
            continue
        elision = re.fullmatch(r'(\t+)\.\.\. ([1-9][0-9]{0,4}) more', line)
        if elision and len(elision[1]) == depth + 1 and not contexts[depth]['elided']:
            count = int(elision[2])
            if contexts[depth]['enclosing'] is None or count > contexts[depth]['enclosing']:
                return None
            contexts[depth]['elided'] = True
            contexts[depth]['count'] += count
            continue
        return None
    return tuple(primary)


def _failure_site(stack, identity, hint):
    """Project a complete fixed first-Throwable DEX caller chain, never a root cause.

    Unknown or omitted generated bridges are not repaired. In particular a plain
    JVM/static-lambda chain without its proven DEX bridges is not accepted. A
    file-only token is allowed only for the exact frozen no-position $r8 bridge.
    Input remains unauthenticated; an exactly copied complete trace is not proof
    of execution. Do not use these diagnostics as an alternate pass gate.
    """
    unknown = ('UNKNOWN', 'UNKNOWN')
    if (type(stack) is not str or hint not in _SITE_GET_HINTS
            or len(stack) > MAX_FAILURE_SITE_BYTES or _failure_hint(stack) != hint):
        return unknown
    try:
        if len(stack.encode('utf-8', errors='strict')) > MAX_FAILURE_SITE_BYTES:
            return unknown
    except UnicodeError:
        return unknown
    primary = _site_primary_frames(stack)
    if primary is None:
        return unknown
    # The official printer may trim the runner tail. Only the exact full root
    # chain is recognized here: no arbitrary framework frame can extend it.
    return _FAILURE_SITE_PATHS.get((identity, primary[1:]), unknown)


def _partial_result(states=None, protocol_state='invalid', ordinals=None, hints=None, sites=None):
    states = states or {}
    ordinals = ordinals or {}
    hints = hints or {}
    sites = sites or {}
    return {'cases': [{'class': c, 'method': m, 'state': states.get((c, m), 'unknown'),
                       'execution_ordinal': ordinals.get((c, m)),
                       'failure_hint': hints.get((c, m), 'UNKNOWN' if states.get((c, m)) == 'failed'
                                                 else 'NOT_APPLICABLE'),
                       'failure_phase': sites.get((c, m), ('UNKNOWN', 'UNKNOWN') if states.get((c, m)) == 'failed'
                                                  else ('NOT_APPLICABLE', 'NOT_APPLICABLE'))[0],
                       'failure_wait': sites.get((c, m), ('UNKNOWN', 'UNKNOWN') if states.get((c, m)) == 'failed'
                                                 else ('NOT_APPLICABLE', 'NOT_APPLICABLE'))[1]}
                      for c, m in PARTIAL_EXPECTED_CASES], 'protocol_state': protocol_state}


def _partial_expected_valid(expected):
    # A damaged config must not become a second way of publishing arbitrary names.
    return (type(expected) is list and len(expected) == 19
            and all(type(x) is dict and set(x) == {'class', 'method'}
                    and type(x['class']) is str and type(x['method']) is str for x in expected)
            and len({(x['class'], x['method']) for x in expected}) == 19
            and {(x['class'], x['method']) for x in expected} == set(PARTIAL_EXPECTED_CASES))


def parse_partial_output(raw, expected):
    """Return bounded, allowlisted observations, not a test-success determination.

    Malformed/ambiguous input invalidates *all* observations. Only fully terminated
    status bundles count. A clean EOF between or inside bundles is incomplete;
    unterminated lines, bad encoding and unexpected protocol are invalid. Android
    am's sorted bundle-key order is required to reject field-order injection.
    Opaque stack/stream text never leaves this function. Input is unauthenticated
    console protocol; this parser is deliberately not an alternate success gate.
    """
    import unicodedata

    if not _partial_expected_valid(expected):
        return _partial_result()
    if type(raw) not in (bytes, str) or len(raw) > MAX_PARTIAL_BYTES:
        return _partial_result()
    try:
        if type(raw) is str:
            raw = raw.encode('utf-8', errors='strict')
        if len(raw) > MAX_PARTIAL_BYTES:
            return _partial_result()
        text = raw.decode('utf-8', errors='strict').replace('\r\n', '\n')
    except UnicodeError:
        return _partial_result()
    # Do not use splitlines(): Unicode separators could manufacture protocol lines.
    if (text and not text.endswith('\n')) or any(
            unicodedata.category(ch) in {'Cc', 'Cf', 'Cs', 'Zl', 'Zp'}
            and ch not in '\n\t' for ch in text):
        return _partial_result()
    lines = text.split('\n')
    if len(lines) > MAX_PARTIAL_LINES + 1:
        return _partial_result()
    if any(len(line.encode('utf-8')) > MAX_PARTIAL_LINE_BYTES for line in lines):
        return _partial_result()

    wanted = set(PARTIAL_EXPECTED_CASES)
    known_classes = {c for c, _ in wanted}
    known_methods = {m for _, m in wanted}
    states = {}
    ordinals = {}
    hints = {}
    sites = {}
    bundle = {}
    field = None
    opaque = []
    active = None
    active_number = None
    ended = 0
    final = False
    result_stream = False
    last_class = None

    def invalid():
        return _partial_result()

    def valid_result_line(line):
        failed = 'failed' in states.values()
        if 'FAILURES!!!' in line and not failed:
            return False
        if re.fullmatch(r'OK \(\d+ tests?\)', line) and failed:
            return False
        if all(state == 'passed' for state in states.values()):
            return (line == '' or line == 'OK (19 tests)'
                    or re.fullmatch(r'Time: [0-9]{1,6}(?:\.[0-9]{1,9})?', line) is not None)
        return True

    def finish_opaque():
        nonlocal opaque
        if field in ('stack', 'stream'):
            bundle[field] = '\n'.join(opaque)
        opaque = []

    for line in lines[:-1]:
        if final:
            if line:
                return invalid()
            continue
        if 'INSTRUMENTATION_' in line and not line.startswith('INSTRUMENTATION_'):
            return invalid()
        if line.startswith('INSTRUMENTATION_STATUS: '):
            if result_stream:
                return invalid()
            finish_opaque()
            match = re.fullmatch(r'INSTRUMENTATION_STATUS: ([a-z]+)=(.*)', line)
            if not match:
                return invalid()
            key, value = match.groups()
            if (key not in _PARTIAL_KEYS or key in bundle
                    or (field is not None and _PARTIAL_KEYS.index(key) <= _PARTIAL_KEYS.index(field))
                    or 'INSTRUMENTATION_' in value):
                return invalid()
            if not bundle and key != 'class':
                return invalid()
            if key == 'class' and value not in known_classes:
                return invalid()
            if key == 'test' and (value not in known_methods or (bundle['class'], value) not in wanted):
                return invalid()
            if key == 'numtests' and value != '19':
                return invalid()
            if key == 'id' and value != 'AndroidJUnitRunner':
                return invalid()
            if key == 'current' and not re.fullmatch(r'(?:[1-9]|1[0-9])', value):
                return invalid()
            bundle[key] = value
            field = key
            if key in ('stack', 'stream'):
                opaque = [value]
            continue
        if line.startswith('INSTRUMENTATION_STATUS_CODE: '):
            if result_stream:
                return invalid()
            finish_opaque()
            match = re.fullmatch(r'INSTRUMENTATION_STATUS_CODE: (0|1|-[1-4])', line)
            if not match or not {'class', 'test', 'numtests'} <= set(bundle):
                return invalid()
            identity = (bundle['class'], bundle['test'])
            if identity not in wanted:
                return invalid()
            code = int(match[1])
            number = bundle.get('current')
            stream = bundle.get('stream')
            start_stream = ('', '\n' + identity[0] + ':')
            if code == 1:
                if (active is not None or identity in states or 'stack' in bundle
                        or (stream is not None and stream not in start_stream)
                        or (number is not None and number != str(ended + 1))):
                    return invalid()
                # A class header is only emitted when the runner changes class.
                if stream == '\n' + identity[0] + ':' and last_class == identity[0]:
                    return invalid()
                active = identity
                active_number = number
                states[identity] = 'started'
                # Observe the validated start sequence, never the config/list order.
                # Optional runner current must already agree with ended + 1 above.
                ordinals[identity] = ended + 1
                last_class = identity[0]
            else:
                if active != identity or number != active_number:
                    return invalid()
                if code == 0 and ('stack' in bundle or (stream is not None and stream != '.')):
                    return invalid()
                if code == -3 and ('stack' in bundle or (stream is not None and stream not in start_stream)):
                    return invalid()
                states[identity] = _PARTIAL_TERMINAL[code]
                if code in (-1, -2):
                    hints[identity] = _failure_hint(bundle.get('stack'))
                    sites[identity] = _failure_site(bundle.get('stack'), identity, hints[identity])
                active = None
                active_number = None
                ended += 1
            bundle = {}
            field = None
            opaque = []
            continue
        if line.startswith('INSTRUMENTATION_RESULT: stream='):
            if result_stream or bundle or active is not None or ended != 19:
                return invalid()
            result_stream = True
            result_value = line[len('INSTRUMENTATION_RESULT: stream='):]
            if 'INSTRUMENTATION_' in result_value or not valid_result_line(result_value):
                return invalid()
            continue
        if line.startswith('INSTRUMENTATION_CODE: '):
            if line != 'INSTRUMENTATION_CODE: -1' or bundle or active is not None or ended != 19:
                return invalid()
            final = True
            continue
        # Includes malformed STATUS/RESULT, aborts, shortMsg, unsupported fields,
        # runner failure markers and protocol-looking lines embedded in raw text.
        if line.startswith('INSTRUMENTATION_') or 'INSTRUMENTATION_' in line:
            return invalid()
        if result_stream:
            # Contradictory footer text must not leave 19 apparently successful
            # observations. Ordinary failure prose remains private and is never
            # an alternate source of case identities or status.
            if not valid_result_line(line):
                return invalid()
            continue
        if field in ('stack', 'stream'):
            opaque.append(line)
            continue
        if line:
            return invalid()
    return _partial_result(states, 'complete' if final else 'incomplete', ordinals, hints, sites)


def read_partial_output(path, expected):
    """Read a stable owned regular file, with no symlinks/FIFO waits or raw errors."""
    import os
    import stat

    if not _partial_expected_valid(expected):
        return _partial_result()
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_nlink != 1 or before.st_size > MAX_PARTIAL_BYTES):
            return _partial_result()
        chunks = []
        size = 0
        while size < before.st_size:
            chunk = os.read(fd, min(65536, before.st_size - size))
            if not chunk:
                break
            size += len(chunk)
            if size > before.st_size:
                return _partial_result()
            chunks.append(chunk)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
                  'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if (size != before.st_size
                or any(getattr(before, k) != getattr(after, k) for k in fields)):
            return _partial_result()
        return parse_partial_output(b''.join(chunks), expected)
    except (OSError, ValueError, TypeError):
        return _partial_result()
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
