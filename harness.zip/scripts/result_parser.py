"""Fail closed on missing, duplicated, skipped or unexpected instrumentation cases."""
import re
import xml.etree.ElementTree as ET


def parse_output(text, expected):
    wanted = {(x['class'], x['method']) for x in expected}
    if len(wanted) != 19 or len(expected) != 19:
        raise ValueError('Expected exactly 19 unique cases')
    bundle = {}
    ended = []
    active = None
    final = False
    for line in text.splitlines():
        for prefix,pattern in [
            ('INSTRUMENTATION_STATUS:',r'^INSTRUMENTATION_STATUS: [^=]+=.*$'),
            ('INSTRUMENTATION_STATUS_CODE:',r'^INSTRUMENTATION_STATUS_CODE: -?\d+\s*$'),
            ('INSTRUMENTATION_CODE:',r'^INSTRUMENTATION_CODE: -?\d+\s*$')]:
            if line.startswith(prefix) and not re.fullmatch(pattern,line):
                raise ValueError('Malformed instrumentation protocol line')
        if line.startswith(('INSTRUMENTATION_ABORTED','INSTRUMENTATION_RESULT: shortMsg=')):
            raise ValueError('Instrumentation aborted or reported a short failure')
        match = re.match(r'^INSTRUMENTATION_STATUS: ([^=]+)=(.*)$', line)
        if match:
            if final or match[1] in bundle:
                raise ValueError('Status after final result or duplicate bundle key')
            bundle[match[1]] = match[2]
        match = re.match(r'^INSTRUMENTATION_STATUS_CODE: (-?\d+)\s*$', line)
        if match:
            if final:
                raise ValueError('Test status after final result')
            code = int(match[1])
            identity = (bundle.get('class'), bundle.get('test'))
            if code not in (0, 1) or identity not in wanted:
                raise ValueError('Unexpected, failed or skipped test status')
            if bundle.get('numtests') != '19':
                raise ValueError('Instrumentation count was not 19')
            if code == 1:
                if active is not None or identity in ended:
                    raise ValueError('Overlapping or repeated test start')
                active = identity
            else:
                if active != identity:
                    raise ValueError('Test finished before or without its matching start')
                ended.append(identity)
                active = None
            bundle = {}
        match = re.match(r'^INSTRUMENTATION_CODE: (-?\d+)\s*$', line)
        if match:
            if final or int(match[1]) != -1 or active is not None or bundle or len(ended) != 19:
                raise ValueError('Premature, repeated or incomplete final result')
            final = True
    if not final or active is not None or bundle or len(ended) != 19 or set(ended) != wanted:
        raise ValueError('Missing, repeated or incomplete instrumentation results')
    if 'INSTRUMENTATION_FAILED' in text or 'FAILURES!!!' in text:
        raise ValueError('Runner reported failure')
    return ended


def junit_xml(cases):
    root = ET.Element('testsuite', name='isolated-ui', tests='19', failures='0',
                      errors='0', skipped='0')
    for classname, name in cases:
        ET.SubElement(root, 'testcase', classname=classname, name=name)
    return ET.tostring(root, encoding='unicode') + '\n'


# Partial evidence is diagnostic only; never use it as the success gate.
PARTIAL_EXPECTED_CASES = (
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'successfulEmptyResponseShowsEmptyNotError'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'transportFailureShowsErrorAndActualRetryTapRecovers'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'nonSuccessAndMissingDataNeverMasqueradeAsEmpty'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'programmaticNavigationPauseStopsPollingAndReentryRefreshes'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'destroyedViewCancelsInflightReadAndNewPageRecovers'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'activityRecreationRestoresNewFragmentFiltersPagesAndScroll'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'emptyPickerDoesNotImplicitlyClearExistingLink'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'failedSaveKeepsEditorAndRetryPersistsExactlyOnce'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'committedCreateWithLostResponseReconcilesWithoutDuplicateRefund'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'repeatedConfirmWhileSavingCannotCreateDuplicateRefunds'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'explicitClearNeedsPickerAndEditorConfirmationToPersist'),
)
MAX_PARTIAL_BYTES = 2 * 1024 * 1024
MAX_PARTIAL_LINE_BYTES = 16 * 1024
MAX_PARTIAL_LINES = 16384
_PARTIAL_KEYS = ('class', 'current', 'id', 'numtests', 'stack', 'stream', 'test')
_PARTIAL_TERMINAL = {0: 'passed', -1: 'failed', -2: 'failed', -3: 'skipped', -4: 'skipped'}


def _partial_result(states=None, protocol_state='invalid'):
    states = states or {}
    return {'cases': [{'class': c, 'method': m, 'state': states.get((c, m), 'unknown')}
                      for c, m in PARTIAL_EXPECTED_CASES], 'protocol_state': protocol_state}


def _partial_expected_valid(expected):
    # A damaged config must not become a second way of publishing arbitrary names.
    return (type(expected) is list and len(expected) == 19
            and all(type(x) is dict and set(x) == {'class', 'method'}
                    and type(x['class']) is str and type(x['method']) is str for x in expected)
            and len({(x['class'], x['method']) for x in expected}) == 19
            and {(x['class'], x['method']) for x in expected} == set(PARTIAL_EXPECTED_CASES))


def parse_partial_output(raw, expected):
    """Return bounded, allowlisted observations, not a test-success determination.

    Malformed/ambiguous input invalidates *all* observations. Only fully terminated
    status bundles count. A clean EOF between or inside bundles is incomplete;
    unterminated lines, bad encoding and unexpected protocol are invalid. Android
    am's sorted bundle-key order is required to reject field-order injection.
    Opaque stack/stream text never leaves this function. Input is unauthenticated
    console protocol; this parser is deliberately not an alternate success gate.
    """
    import unicodedata

    if not _partial_expected_valid(expected):
        return _partial_result()
    if type(raw) not in (bytes, str) or len(raw) > MAX_PARTIAL_BYTES:
        return _partial_result()
    try:
        if type(raw) is str:
            raw = raw.encode('utf-8', errors='strict')
        if len(raw) > MAX_PARTIAL_BYTES:
            return _partial_result()
        text = raw.decode('utf-8', errors='strict').replace('\r\n', '\n')
    except UnicodeError:
        return _partial_result()
    # Do not use splitlines(): Unicode separators could manufacture protocol lines.
    if (text and not text.endswith('\n')) or any(
            unicodedata.category(ch) in {'Cc', 'Cf', 'Cs', 'Zl', 'Zp'}
            and ch not in '\n\t' for ch in text):
        return _partial_result()
    lines = text.split('\n')
    if len(lines) > MAX_PARTIAL_LINES + 1:
        return _partial_result()
    if any(len(line.encode('utf-8')) > MAX_PARTIAL_LINE_BYTES for line in lines):
        return _partial_result()

    wanted = set(PARTIAL_EXPECTED_CASES)
    known_classes = {c for c, _ in wanted}
    known_methods = {m for _, m in wanted}
    states = {}
    bundle = {}
    field = None
    opaque = []
    active = None
    active_number = None
    ended = 0
    final = False
    result_stream = False
    last_class = None

    def invalid():
        return _partial_result()

    def valid_result_line(line):
        failed = 'failed' in states.values()
        if 'FAILURES!!!' in line and not failed:
            return False
        if re.fullmatch(r'OK \(\d+ tests?\)', line) and failed:
            return False
        if all(state == 'passed' for state in states.values()):
            return (line == '' or line == 'OK (19 tests)'
                    or re.fullmatch(r'Time: [0-9]{1,6}(?:\.[0-9]{1,9})?', line) is not None)
        return True

    def finish_opaque():
        nonlocal opaque
        if field in ('stack', 'stream'):
            bundle[field] = '\n'.join(opaque)
        opaque = []

    for line in lines[:-1]:
        if final:
            if line:
                return invalid()
            continue
        if 'INSTRUMENTATION_' in line and not line.startswith('INSTRUMENTATION_'):
            return invalid()
        if line.startswith('INSTRUMENTATION_STATUS: '):
            if result_stream:
                return invalid()
            finish_opaque()
            match = re.fullmatch(r'INSTRUMENTATION_STATUS: ([a-z]+)=(.*)', line)
            if not match:
                return invalid()
            key, value = match.groups()
            if (key not in _PARTIAL_KEYS or key in bundle
                    or (field is not None and _PARTIAL_KEYS.index(key) <= _PARTIAL_KEYS.index(field))
                    or 'INSTRUMENTATION_' in value):
                return invalid()
            if not bundle and key != 'class':
                return invalid()
            if key == 'class' and value not in known_classes:
                return invalid()
            if key == 'test' and (value not in known_methods or (bundle['class'], value) not in wanted):
                return invalid()
            if key == 'numtests' and value != '19':
                return invalid()
            if key == 'id' and value != 'AndroidJUnitRunner':
                return invalid()
            if key == 'current' and not re.fullmatch(r'(?:[1-9]|1[0-9])', value):
                return invalid()
            bundle[key] = value
            field = key
            if key in ('stack', 'stream'):
                opaque = [value]
            continue
        if line.startswith('INSTRUMENTATION_STATUS_CODE: '):
            if result_stream:
                return invalid()
            finish_opaque()
            match = re.fullmatch(r'INSTRUMENTATION_STATUS_CODE: (0|1|-[1-4])', line)
            if not match or not {'class', 'test', 'numtests'} <= set(bundle):
                return invalid()
            identity = (bundle['class'], bundle['test'])
            if identity not in wanted:
                return invalid()
            code = int(match[1])
            number = bundle.get('current')
            stream = bundle.get('stream')
            start_stream = ('', '\n' + identity[0] + ':')
            if code == 1:
                if (active is not None or identity in states or 'stack' in bundle
                        or (stream is not None and stream not in start_stream)
                        or (number is not None and number != str(ended + 1))):
                    return invalid()
                # A class header is only emitted when the runner changes class.
                if stream == '\n' + identity[0] + ':' and last_class == identity[0]:
                    return invalid()
                active = identity
                active_number = number
                states[identity] = 'started'
                last_class = identity[0]
            else:
                if active != identity or number != active_number:
                    return invalid()
                if code == 0 and ('stack' in bundle or (stream is not None and stream != '.')):
                    return invalid()
                if code == -3 and ('stack' in bundle or (stream is not None and stream not in start_stream)):
                    return invalid()
                states[identity] = _PARTIAL_TERMINAL[code]
                active = None
                active_number = None
                ended += 1
            bundle = {}
            field = None
            opaque = []
            continue
        if line.startswith('INSTRUMENTATION_RESULT: stream='):
            if result_stream or bundle or active is not None or ended != 19:
                return invalid()
            result_stream = True
            result_value = line[len('INSTRUMENTATION_RESULT: stream='):]
            if 'INSTRUMENTATION_' in result_value or not valid_result_line(result_value):
                return invalid()
            continue
        if line.startswith('INSTRUMENTATION_CODE: '):
            if line != 'INSTRUMENTATION_CODE: -1' or bundle or active is not None or ended != 19:
                return invalid()
            final = True
            continue
        # Includes malformed STATUS/RESULT, aborts, shortMsg, unsupported fields,
        # runner failure markers and protocol-looking lines embedded in raw text.
        if line.startswith('INSTRUMENTATION_') or 'INSTRUMENTATION_' in line:
            return invalid()
        if result_stream:
            # Contradictory footer text must not leave 19 apparently successful
            # observations. Ordinary failure prose remains private and is never
            # an alternate source of case identities or status.
            if not valid_result_line(line):
                return invalid()
            continue
        if field in ('stack', 'stream'):
            opaque.append(line)
            continue
        if line:
            return invalid()
    return _partial_result(states, 'complete' if final else 'incomplete')


def read_partial_output(path, expected):
    """Read a stable owned regular file, with no symlinks/FIFO waits or raw errors."""
    import os
    import stat

    if not _partial_expected_valid(expected):
        return _partial_result()
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_nlink != 1 or before.st_size > MAX_PARTIAL_BYTES):
            return _partial_result()
        chunks = []
        size = 0
        while size < before.st_size:
            chunk = os.read(fd, min(65536, before.st_size - size))
            if not chunk:
                break
            size += len(chunk)
            if size > before.st_size:
                return _partial_result()
            chunks.append(chunk)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
                  'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if (size != before.st_size
                or any(getattr(before, k) != getattr(after, k) for k in fields)):
            return _partial_result()
        return parse_partial_output(b''.join(chunks), expected)
    except (OSError, ValueError, TypeError):
        return _partial_result()
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
