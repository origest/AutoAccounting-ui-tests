"""Fail closed on missing, duplicated, skipped or unexpected instrumentation cases."""
import re
import xml.etree.ElementTree as ET


def parse_output(text, expected):
    wanted = {(x['class'], x['method']) for x in expected}
    if len(wanted) != 19 or len(expected) != 19:
        raise ValueError('Expected exactly 19 unique cases')
    bundle = {}
    ended = []
    active = None
    final = False
    for line in text.splitlines():
        for prefix,pattern in [
            ('INSTRUMENTATION_STATUS:',r'^INSTRUMENTATION_STATUS: [^=]+=.*$'),
            ('INSTRUMENTATION_STATUS_CODE:',r'^INSTRUMENTATION_STATUS_CODE: -?\d+\s*$'),
            ('INSTRUMENTATION_CODE:',r'^INSTRUMENTATION_CODE: -?\d+\s*$')]:
            if line.startswith(prefix) and not re.fullmatch(pattern,line):
                raise ValueError('Malformed instrumentation protocol line')
        if line.startswith(('INSTRUMENTATION_ABORTED','INSTRUMENTATION_RESULT: shortMsg=')):
            raise ValueError('Instrumentation aborted or reported a short failure')
        match = re.match(r'^INSTRUMENTATION_STATUS: ([^=]+)=(.*)$', line)
        if match:
            if final or match[1] in bundle:
                raise ValueError('Status after final result or duplicate bundle key')
            bundle[match[1]] = match[2]
        match = re.match(r'^INSTRUMENTATION_STATUS_CODE: (-?\d+)\s*$', line)
        if match:
            if final:
                raise ValueError('Test status after final result')
            code = int(match[1])
            identity = (bundle.get('class'), bundle.get('test'))
            if code not in (0, 1) or identity not in wanted:
                raise ValueError('Unexpected, failed or skipped test status')
            if bundle.get('numtests') != '19':
                raise ValueError('Instrumentation count was not 19')
            if code == 1:
                if active is not None or identity in ended:
                    raise ValueError('Overlapping or repeated test start')
                active = identity
            else:
                if active != identity:
                    raise ValueError('Test finished before or without its matching start')
                ended.append(identity)
                active = None
            bundle = {}
        match = re.match(r'^INSTRUMENTATION_CODE: (-?\d+)\s*$', line)
        if match:
            if final or int(match[1]) != -1 or active is not None or bundle or len(ended) != 19:
                raise ValueError('Premature, repeated or incomplete final result')
            final = True
    if not final or active is not None or bundle or len(ended) != 19 or set(ended) != wanted:
        raise ValueError('Missing, repeated or incomplete instrumentation results')
    if 'INSTRUMENTATION_FAILED' in text or 'FAILURES!!!' in text:
        raise ValueError('Runner reported failure')
    return ended


def junit_xml(cases):
    root = ET.Element('testsuite', name='isolated-ui', tests='19', failures='0',
                      errors='0', skipped='0')
    for classname, name in cases:
        ET.SubElement(root, 'testcase', classname=classname, name=name)
    return ET.tostring(root, encoding='unicode') + '\n'
