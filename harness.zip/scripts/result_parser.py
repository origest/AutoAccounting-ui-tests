"""Fail closed on missing, duplicated, skipped or unexpected instrumentation cases."""
import re
import xml.etree.ElementTree as ET


def parse_output(text, expected):
    wanted = {(x['class'], x['method']) for x in expected}
    if len(wanted) != 19 or len(expected) != 19:
        raise ValueError('Expected exactly 19 unique cases')
    bundle = {}
    ended = []
    active = None
    final = False
    for line in text.splitlines():
        for prefix,pattern in [
            ('INSTRUMENTATION_STATUS:',r'^INSTRUMENTATION_STATUS: [^=]+=.*$'),
            ('INSTRUMENTATION_STATUS_CODE:',r'^INSTRUMENTATION_STATUS_CODE: -?\d+\s*$'),
            ('INSTRUMENTATION_CODE:',r'^INSTRUMENTATION_CODE: -?\d+\s*$')]:
            if line.startswith(prefix) and not re.fullmatch(pattern,line):
                raise ValueError('Malformed instrumentation protocol line')
        if line.startswith(('INSTRUMENTATION_ABORTED','INSTRUMENTATION_RESULT: shortMsg=')):
            raise ValueError('Instrumentation aborted or reported a short failure')
        match = re.match(r'^INSTRUMENTATION_STATUS: ([^=]+)=(.*)$', line)
        if match:
            if final or match[1] in bundle:
                raise ValueError('Status after final result or duplicate bundle key')
            bundle[match[1]] = match[2]
        match = re.match(r'^INSTRUMENTATION_STATUS_CODE: (-?\d+)\s*$', line)
        if match:
            if final:
                raise ValueError('Test status after final result')
            code = int(match[1])
            identity = (bundle.get('class'), bundle.get('test'))
            if code not in (0, 1) or identity not in wanted:
                raise ValueError('Unexpected, failed or skipped test status')
            if bundle.get('numtests') != '19':
                raise ValueError('Instrumentation count was not 19')
            if code == 1:
                if active is not None or identity in ended:
                    raise ValueError('Overlapping or repeated test start')
                active = identity
            else:
                if active != identity:
                    raise ValueError('Test finished before or without its matching start')
                ended.append(identity)
                active = None
            bundle = {}
        match = re.match(r'^INSTRUMENTATION_CODE: (-?\d+)\s*$', line)
        if match:
            if final or int(match[1]) != -1 or active is not None or bundle or len(ended) != 19:
                raise ValueError('Premature, repeated or incomplete final result')
            final = True
    if not final or active is not None or bundle or len(ended) != 19 or set(ended) != wanted:
        raise ValueError('Missing, repeated or incomplete instrumentation results')
    if 'INSTRUMENTATION_FAILED' in text or 'FAILURES!!!' in text:
        raise ValueError('Runner reported failure')
    return ended


def junit_xml(cases):
    root = ET.Element('testsuite', name='isolated-ui', tests='19', failures='0',
                      errors='0', skipped='0')
    for classname, name in cases:
        ET.SubElement(root, 'testcase', classname=classname, name=name)
    return ET.tostring(root, encoding='unicode') + '\n'


# Partial evidence is diagnostic only; never use it as the success gate.
PARTIAL_EXPECTED_CASES = (
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'successfulEmptyResponseShowsEmptyNotError'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'transportFailureShowsErrorAndActualRetryTapRecovers'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'nonSuccessAndMissingDataNeverMasqueradeAsEmpty'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'programmaticNavigationPauseStopsPollingAndReentryRefreshes'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'destroyedViewCancelsInflightReadAndNewPageRecovers'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset'),
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'activityRecreationRestoresNewFragmentFiltersPagesAndScroll'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'emptyPickerDoesNotImplicitlyClearExistingLink'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'failedSaveKeepsEditorAndRetryPersistsExactlyOnce'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'committedCreateWithLostResponseReconcilesWithoutDuplicateRefund'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'repeatedConfirmWhileSavingCannotCreateDuplicateRefunds'),
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'explicitClearNeedsPickerAndEditorConfirmationToPersist'),
)
MAX_PARTIAL_BYTES = 2 * 1024 * 1024
MAX_PARTIAL_LINE_BYTES = 16 * 1024
MAX_PARTIAL_LINES = 16384
_PARTIAL_KEYS = ('class', 'current', 'id', 'numtests', 'stack', 'stream', 'test')
_PARTIAL_TERMINAL = {0: 'passed', -1: 'failed', -2: 'failed', -3: 'skipped', -4: 'skipped'}
FAILURE_HINTS = frozenset({'UNKNOWN', 'HELPER_DEADLINE', 'HELPER_INTERRUPTED',
                           'HELPER_PRIOR_GUARD', 'HELPER_CHECKED_ACTION', 'MULTIPLE_FAILURES'})

# Exact reviewed Java source signals. Changed source/line numbers fail to UNKNOWN.
# This is unauthenticated diagnostic text, not proof of origin or a root cause.
_HELPER_FAILURE_PREFIXES = {
    ('java.lang.AssertionError: UI_TEST_DEADLINE_EXCEEDED',
     '\tat net.ankio.auto.isolated.UiTestDeadline.get(UiTestDeadline.java:102)'): 'HELPER_DEADLINE',
    ('java.lang.AssertionError: UI_TEST_WAIT_INTERRUPTED',
     '\tat net.ankio.auto.isolated.UiTestDeadline.get(UiTestDeadline.java:106)'): 'HELPER_INTERRUPTED',
    ('java.lang.AssertionError: UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS',
     '\tat net.ankio.auto.isolated.UiTestDeadline.assertHealthy(UiTestDeadline.java:19)'): 'HELPER_PRIOR_GUARD',
    ('java.lang.AssertionError: UI_TEST_MAIN_ACTION_FAILED',
     '\tat net.ankio.auto.isolated.UiTestDeadline.get(UiTestDeadline.java:119)'): 'HELPER_CHECKED_ACTION',
}


def _failure_hint(stack):
    """Project only fixed top-level signals; never inspect nested errors or return raw text."""
    if type(stack) is not str or len(stack) > MAX_PARTIAL_BYTES:
        return 'UNKNOWN'
    head = stack.split('\n', 2)
    if len(head) >= 2:
        hint = _HELPER_FAILURE_PREFIXES.get((head[0], head[1]))
        # JUnit MultipleFailureException.printStackTrace can concatenate errors
        # without its own header. Never mistake the first flattened block for a
        # single top-level error. Tail syntax is checked, never mined for hints.
        tail = head[2].split('\n') if len(head) == 3 else []
        if hint is not None and all(
                line == '' and index == len(tail) - 1
                or re.fullmatch(r'\t+at [^\s()]+\([^()\n]+\)', line) is not None
                or re.fullmatch(r'\t+\.\.\. [1-9][0-9]{0,4} more', line) is not None
                or line.startswith('Caused by: ') and len(line) > len('Caused by: ')
                or re.fullmatch(r'\t+Suppressed: .+', line) is not None
                for index, line in enumerate(tail)):
            return hint
    # JUnit's multi-error message has opaque summary lines before its first frame.
    # This narrow type-only exception does NOT identify a helper signal or first cause.
    if re.fullmatch(r'org\.junit\.(?:internal\.)?runners\.model\.MultipleFailureException: '
                    r'There were (?:[2-9]|[1-5][0-9]|6[0-4]) errors:', head[0]):
        return 'MULTIPLE_FAILURES'
    return 'UNKNOWN'


# Fixed source/compiled-call mapping. IDs below reference only this literal method table.
# Every row is an ordered complete helper-caller path, nearest throwable first.
# File-only $r8 bridge tokens are deliberate DEX no-position encodings, NOT Unknown Source.
# No wildcard, line range, synthetic-name prefix, arbitrary frame skipping or graph search.
SITE_SOURCE_SHA256 = 'c8e9d02ba1e991114777e52d41432d6acbdfd8acf54d0b24f8a84b74565513c3'
# Provenance anchors, not a requirement that future newly signed APK bytes match.
SITE_MAPPING_APK_SHA256 = 'db9ddd889862c9e41835ce6474f659365d60d7855db8734dadf8f9fd8d668586'
SITE_MAPPING_DEX_SHA256 = '9cb76a5ca8fdac65b9443935c47b2a71d8a3bde73dcab55e9c42bad6c5a4b182'
MAX_FAILURE_SITE_BYTES = 32 * 1024
MAX_FAILURE_SITE_FRAMES = 128
_SITE_METHODS = (
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'onMainUntil$lambda$0', 'IsolatedUiFixture.kt'),  # 0
    ('net.ankio.auto.isolated.IsolatedUiProgress', 'step', 'IsolatedUiProgress.kt'),  # 1
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'step', 'IsolatedUiFixture.kt'),  # 2
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'onMainUntil', 'IsolatedUiFixture.kt'),  # 3
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'onMain', 'IsolatedUiFixture.kt'),  # 4
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'showData', 'DataPageIsolatedUiTest.kt'),  # 5
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'successfulEmptyResponseShowsEmptyNotError', 'DataPageIsolatedUiTest.kt'),  # 6
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'await', 'IsolatedUiFixture.kt'),  # 7
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'await$default', 'IsolatedUiFixture.kt'),  # 8
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'transportFailureShowsErrorAndActualRetryTapRecovers', 'DataPageIsolatedUiTest.kt'),  # 9
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'root', 'DataPageIsolatedUiTest.kt'),  # 10
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tapView', 'IsolatedUiFixture.kt'),  # 11
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'click', 'IsolatedUiFixture.kt'),  # 12
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'waitForUiIdle$lambda$0', 'IsolatedUiFixture.kt'),  # 13
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'waitForUiIdle', 'IsolatedUiFixture.kt'),  # 14
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'screenBounds', 'IsolatedUiFixture.kt'),  # 15
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'gesture', 'IsolatedUiFixture.kt'),  # 16
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'gesture$default', 'IsolatedUiFixture.kt'),  # 17
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'nonSuccessAndMissingDataNeverMasqueradeAsEmpty', 'DataPageIsolatedUiTest.kt'),  # 18
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage', 'DataPageIsolatedUiTest.kt'),  # 19
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$1', 'DataPageIsolatedUiTest.kt'),  # 20
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning', 'DataPageIsolatedUiTest.kt'),  # 21
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$2', 'DataPageIsolatedUiTest.kt'),  # 22
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'swipeRefresh', 'DataPageIsolatedUiTest.kt'),  # 23
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$3', 'DataPageIsolatedUiTest.kt'),  # 24
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$4', 'DataPageIsolatedUiTest.kt'),  # 25
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$6', 'DataPageIsolatedUiTest.kt'),  # 26
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$10', 'DataPageIsolatedUiTest.kt'),  # 27
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning$lambda$11', 'DataPageIsolatedUiTest.kt'),  # 28
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'programmaticNavigationPauseStopsPollingAndReentryRefreshes', 'DataPageIsolatedUiTest.kt'),  # 29
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'destroyedViewCancelsInflightReadAndNewPageRecovers', 'DataPageIsolatedUiTest.kt'),  # 30
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry', 'DataPageIsolatedUiTest.kt'),  # 31
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset', 'DataPageIsolatedUiTest.kt'),  # 32
    ('net.ankio.auto.isolated.DataPageIsolatedUiTest', 'activityRecreationRestoresNewFragmentFiltersPagesAndScroll', 'DataPageIsolatedUiTest.kt'),  # 33
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'editor', 'IsolatedUiFixture.kt'),  # 34
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen', 'RefundIsolatedUiTest.kt'),  # 35
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'dialogRoot', 'IsolatedUiFixture.kt'),  # 36
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'picker', 'RefundIsolatedUiTest.kt'),  # 37
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'rootWith', 'IsolatedUiFixture.kt'),  # 38
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'waitCandidates', 'RefundIsolatedUiTest.kt'),  # 39
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'choose', 'RefundIsolatedUiTest.kt'),  # 40
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft', 'RefundIsolatedUiTest.kt'),  # 41
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'backFromPicker', 'RefundIsolatedUiTest.kt'),  # 42
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'changeAmount', 'RefundIsolatedUiTest.kt'),  # 43
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'editor$default', 'IsolatedUiFixture.kt'),  # 44
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'emptyPickerDoesNotImplicitlyClearExistingLink', 'RefundIsolatedUiTest.kt'),  # 45
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation', 'RefundIsolatedUiTest.kt'),  # 46
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'failedSaveKeepsEditorAndRetryPersistsExactlyOnce', 'RefundIsolatedUiTest.kt'),  # 47
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected', 'RefundIsolatedUiTest.kt'),  # 48
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'committedCreateWithLostResponseReconcilesWithoutDuplicateRefund', 'RefundIsolatedUiTest.kt'),  # 49
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'repeatedConfirmWhileSavingCannotCreateDuplicateRefunds', 'RefundIsolatedUiTest.kt'),  # 50
    ('net.ankio.auto.isolated.RefundIsolatedUiTest', 'explicitClearNeedsPickerAndEditorConfirmationToPersist', 'RefundIsolatedUiTest.kt'),  # 51
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'setUpIsolatedUi$lambda$0', 'IsolatedUiFixture.kt'),  # 52
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'setUpIsolatedUi', 'IsolatedUiFixture.kt'),  # 53
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'setUpIsolatedUi$lambda$3', 'IsolatedUiFixture.kt'),  # 54
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi$lambda$0', 'IsolatedUiFixture.kt'),  # 55
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi', 'IsolatedUiFixture.kt'),  # 56
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi$lambda$1', 'IsolatedUiFixture.kt'),  # 57
    ('net.ankio.auto.isolated.IsolatedUiFixture', 'tearDownIsolatedUi$lambda$3', 'IsolatedUiFixture.kt'),  # 58
)
_SITE_DEX_BRIDGES = {
    0: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$pqc2xdtwzS3tWCErdAcoZS6IlfA(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda15.invoke(D8$$SyntheticClass:0)'),
    13: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$pUg6uQlFEPVmt5tCemyoCI8Zhds(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda11.invoke(D8$$SyntheticClass:0)'),
    20: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$-y-x0tKBNCV1CW7OKnPQARpOq_o(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda61.invoke(D8$$SyntheticClass:0)'),
    22: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$plXp6NcjKlez-GGPCMep3K514Ms(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda62.invoke(D8$$SyntheticClass:0)'),
    24: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$FQk0sWiJcK0-d3eQ6iiiO0NBL8A(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda63.invoke(D8$$SyntheticClass:0)'),
    25: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$3_A0imME6xz17EoMXrXmbOUVucI(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda64.invoke(D8$$SyntheticClass:0)'),
    26: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$BUzMVGFpHj2pf9ERvbTt1QLBkOw(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda65.invoke(D8$$SyntheticClass:0)'),
    27: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$z-V1dyqMoBScb4_lelhNVEkkurE(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda59.invoke(D8$$SyntheticClass:0)'),
    28: ('net.ankio.auto.isolated.DataPageIsolatedUiTest.$r8$lambda$8JaX1-EuFAUb0dL5Iyp0yHRwflw(DataPageIsolatedUiTest.kt)', 'net.ankio.auto.isolated.DataPageIsolatedUiTest$$ExternalSyntheticLambda60.invoke(D8$$SyntheticClass:0)'),
    52: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$cTst6Nu5ADFQ8TVX561Stnp5Qeg(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda7.invoke(D8$$SyntheticClass:0)'),
    54: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$07Pyuv9zJ2kRCfyp7CBoQ1TOcog(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda10.invoke(D8$$SyntheticClass:0)'),
    55: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$g6xdu23qiUVM2D-ub6pwC4Zybeg(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)'),
    57: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$N4SXqmxRK9CcrqtxjHmQf7SlbB8(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda4.invoke(D8$$SyntheticClass:0)'),
    58: ('net.ankio.auto.isolated.IsolatedUiFixture.$r8$lambda$RmgVF9zXgM-f7nyQO6VdKT-bO84(IsolatedUiFixture.kt)', 'net.ankio.auto.isolated.IsolatedUiFixture$$ExternalSyntheticLambda6.invoke(D8$$SyntheticClass:0)'),
}
_SITE_ROWS = (
    (1, 'BODY_C01_L052', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 6:52'),
    (1, 'BODY_C01_L053', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 6:53'),
    (1, 'BODY_C01_L054', 'MAIN', '0:110 1:66 2:40 3:104 4:102 6:54'),
    (2, 'BODY_C02_L063', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 9:63'),
    (2, 'BODY_C02_L064', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 9:64'),
    (2, 'BODY_C02_L065', 'MAIN', '0:110 1:66 2:40 3:104 4:102 9:65'),
    (2, 'BODY_C02_L068', 'MAIN', '0:110 1:66 2:40 3:104 4:102 10:26 9:68'),
    (2, 'BODY_C02_L068', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 9:68'),
    (2, 'BODY_C02_L068', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 9:68'),
    (2, 'BODY_C02_L068', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 9:68'),
    (2, 'BODY_C02_L068', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 9:68'),
    (2, 'BODY_C02_L069', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 9:69'),
    (2, 'BODY_C02_L070', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 9:70'),
    (3, 'BODY_C03_L079', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 18:79'),
    (3, 'BODY_C03_L080', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 18:80'),
    (3, 'BODY_C03_L083', 'MAIN', '0:110 1:66 2:40 3:104 4:102 10:26 18:83'),
    (3, 'BODY_C03_L083', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 18:83'),
    (3, 'BODY_C03_L083', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 18:83'),
    (3, 'BODY_C03_L083', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 18:83'),
    (3, 'BODY_C03_L083', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 18:83'),
    (3, 'BODY_C03_L084', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 18:84'),
    (3, 'BODY_C03_L087', 'MAIN', '0:110 1:66 2:40 3:104 4:102 18:87'),
    (3, 'BODY_C03_L089', 'MAIN', '0:110 1:66 2:40 3:104 4:102 10:26 18:89'),
    (3, 'BODY_C03_L089', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 18:89'),
    (3, 'BODY_C03_L089', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 18:89'),
    (3, 'BODY_C03_L089', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 18:89'),
    (3, 'BODY_C03_L089', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 18:89'),
    (3, 'BODY_C03_L090', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 18:90'),
    (4, 'BODY_C04_L094', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 19:94'),
    (4, 'BODY_C04_L095', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 19:95'),
    (4, 'BODY_C04_L097', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 19:97'),
    (5, 'SWIPE_SHOW', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 20:106 1:66 2:40 21:106'),
    (5, 'SWIPE_INITIAL_ROWS', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 22:108 1:66 2:40 21:107'),
    (5, 'SWIPE_FIRST', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 23:44 24:121 1:66 2:40 21:121'),
    (5, 'SWIPE_REQUEST_OBSERVED', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 25:124 1:66 2:40 21:123'),
    (5, 'SWIPE_SECOND', 'MAIN', '0:110 1:66 2:40 3:104 4:102 26:157 1:66 2:40 21:156'),
    (5, 'SWIPE_SECOND', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 23:44 26:161 1:66 2:40 21:156'),
    (5, 'SWIPE_SECOND', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 26:162 1:66 2:40 21:156'),
    (5, 'BODY_C05_L171', 'MAIN', '0:110 1:66 2:40 3:104 4:102 21:171'),
    (5, 'SWIPE_FINAL_ROWS', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 27:180 1:66 2:40 21:179'),
    (5, 'SWIPE_FINAL_ERROR', 'MAIN', '0:110 1:66 2:40 3:104 4:102 28:187 1:66 2:40 21:187'),
    (6, 'BODY_C06_L191', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 29:191'),
    (6, 'BODY_C06_L192', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 29:192'),
    (6, 'BODY_C06_L193', 'MAIN', '0:110 1:66 2:40 3:104 4:102 29:193'),
    (6, 'BODY_C06_L199', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 29:199'),
    (6, 'BODY_C06_L204', 'MAIN', '0:110 1:66 2:40 3:104 4:102 29:204'),
    (6, 'BODY_C06_L205', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 29:205'),
    (7, 'BODY_C07_L211', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 30:211'),
    (7, 'BODY_C07_L212', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 30:212'),
    (7, 'BODY_C07_L213', 'MAIN', '0:110 1:66 2:40 3:104 4:102 30:213'),
    (7, 'BODY_C07_L214', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 30:214'),
    (7, 'BODY_C07_L218', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 30:218'),
    (7, 'BODY_C07_L219', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 30:219'),
    (7, 'BODY_C07_L220', 'MAIN', '0:110 1:66 2:40 3:104 4:102 30:220'),
    (8, 'BODY_C08_L231', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 31:231'),
    (8, 'BODY_C08_L232', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 31:232'),
    (8, 'BODY_C08_L233', 'MAIN', '0:110 1:66 2:40 3:104 4:102 10:26 31:233'),
    (8, 'BODY_C08_L233', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 31:233'),
    (8, 'BODY_C08_L233', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 31:233'),
    (8, 'BODY_C08_L233', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 31:233'),
    (8, 'BODY_C08_L233', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 31:233'),
    (8, 'BODY_C08_L235', 'MAIN', '0:110 1:66 2:40 3:104 4:102 31:235'),
    (8, 'BODY_C08_L239', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 31:239'),
    (8, 'BODY_C08_L239', 'IDLE', '13:127 1:66 2:40 14:120 11:167 31:239'),
    (8, 'BODY_C08_L239', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 31:239'),
    (8, 'BODY_C08_L239', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 31:239'),
    (8, 'BODY_C08_L240', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 31:240'),
    (8, 'BODY_C08_L245', 'MAIN', '0:110 1:66 2:40 3:104 4:102 31:245'),
    (8, 'BODY_C08_L251', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 31:251'),
    (8, 'BODY_C08_L256', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 31:256'),
    (8, 'BODY_C08_L257', 'MAIN', '0:110 1:66 2:40 3:104 4:102 31:257'),
    (8, 'BODY_C08_L267', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 31:267'),
    (8, 'BODY_C08_L268', 'MAIN', '0:110 1:66 2:40 3:104 4:102 31:268'),
    (9, 'BODY_C09_L278', 'MAIN', '0:110 1:66 2:40 3:104 4:102 5:25 32:278'),
    (9, 'BODY_C09_L279', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 32:279'),
    (9, 'BODY_C09_L280', 'MAIN', '0:110 1:66 2:40 3:104 4:102 32:280'),
    (9, 'BODY_C09_L282', 'MAIN', '0:110 1:66 2:40 3:104 4:102 32:282'),
    (9, 'BODY_C09_L283', 'IDLE', '13:127 1:66 2:40 14:120 32:283'),
    (9, 'BODY_C09_L284', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 32:284'),
    (9, 'BODY_C09_L285', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 32:285'),
    (9, 'BODY_C09_L287', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 32:287'),
    (9, 'BODY_C09_L288', 'MAIN', '0:110 1:66 2:40 3:104 4:102 32:288'),
    (9, 'BODY_C09_L289', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 32:289'),
    (9, 'BODY_C09_L300', 'MAIN', '0:110 1:66 2:40 3:104 4:102 32:300'),
    (9, 'BODY_C09_L302', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 32:302'),
    (9, 'BODY_C09_L305', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 32:305'),
    (9, 'BODY_C09_L306', 'MAIN', '0:110 1:66 2:40 3:104 4:102 32:306'),
    (10, 'BODY_C10_L319', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:319'),
    (10, 'BODY_C10_L325', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 33:325'),
    (10, 'BODY_C10_L326', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:326'),
    (10, 'BODY_C10_L327', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:327'),
    (10, 'BODY_C10_L328', 'IDLE', '13:127 1:66 2:40 14:120 33:328'),
    (10, 'BODY_C10_L329', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 33:329'),
    (10, 'BODY_C10_L330', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 33:330'),
    (10, 'BODY_C10_L332', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 33:332'),
    (10, 'BODY_C10_L333', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:333'),
    (10, 'BODY_C10_L334', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 33:334'),
    (10, 'BODY_C10_L345', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:345'),
    (10, 'BODY_C10_L349', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:349'),
    (10, 'BODY_C10_L356', 'IDLE', '13:127 1:66 2:40 14:120 33:356'),
    (10, 'BODY_C10_L358', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:358'),
    (10, 'BODY_C10_L362', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 33:362'),
    (10, 'BODY_C10_L363', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:363'),
    (10, 'BODY_C10_L364', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 33:364'),
    (10, 'BODY_C10_L367', 'MAIN', '0:110 1:66 2:40 3:104 4:102 33:367'),
    (11, 'BODY_C11_L066', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 35:66'),
    (11, 'BODY_C11_L067', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 37:23 35:67'),
    (11, 'BODY_C11_L067', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 37:23 35:67'),
    (11, 'BODY_C11_L067', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 37:23 35:67'),
    (11, 'BODY_C11_L067', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 37:23 35:67'),
    (11, 'BODY_C11_L067', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 37:23 35:67'),
    (11, 'BODY_C11_L067', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 37:24 35:67'),
    (11, 'BODY_C11_L067', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 37:25 35:67'),
    (11, 'BODY_C11_L068', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 39:29 35:68'),
    (11, 'BODY_C11_L069', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:36 35:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:37 35:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:40 35:69'),
    (11, 'BODY_C11_L069', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 40:41 35:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 40:42 35:69'),
    (11, 'BODY_C11_L069', 'IDLE', '13:127 1:66 2:40 14:120 11:167 40:42 35:69'),
    (11, 'BODY_C11_L069', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 40:42 35:69'),
    (11, 'BODY_C11_L069', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 40:42 35:69'),
    (11, 'BODY_C11_L070', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 35:70'),
    (11, 'BODY_C11_L070', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 35:70'),
    (11, 'BODY_C11_L070', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 35:70'),
    (11, 'BODY_C11_L070', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 35:70'),
    (11, 'BODY_C11_L071', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 35:71'),
    (11, 'BODY_C11_L074', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 35:74'),
    (11, 'BODY_C11_L074', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 35:74'),
    (11, 'BODY_C11_L074', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 35:74'),
    (11, 'BODY_C11_L074', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 35:74'),
    (11, 'BODY_C11_L074', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 35:74'),
    (11, 'BODY_C11_L075', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 35:75'),
    (11, 'BODY_C11_L077', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 35:77'),
    (12, 'BODY_C12_L093', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 41:93'),
    (12, 'BODY_C12_L094', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 37:23 41:94'),
    (12, 'BODY_C12_L094', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 37:23 41:94'),
    (12, 'BODY_C12_L094', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 37:23 41:94'),
    (12, 'BODY_C12_L094', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 37:23 41:94'),
    (12, 'BODY_C12_L094', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 37:23 41:94'),
    (12, 'BODY_C12_L094', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 37:24 41:94'),
    (12, 'BODY_C12_L094', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 37:25 41:94'),
    (12, 'BODY_C12_L095', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 39:29 41:95'),
    (12, 'BODY_C12_L096', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:36 41:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:37 41:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:40 41:96'),
    (12, 'BODY_C12_L096', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 40:41 41:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 40:42 41:96'),
    (12, 'BODY_C12_L096', 'IDLE', '13:127 1:66 2:40 14:120 11:167 40:42 41:96'),
    (12, 'BODY_C12_L096', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 40:42 41:96'),
    (12, 'BODY_C12_L096', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 40:42 41:96'),
    (12, 'BODY_C12_L097', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 42:47 41:97'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 43:51 41:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 43:51 41:98'),
    (12, 'BODY_C12_L098', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 43:51 41:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 43:51 41:98'),
    (12, 'BODY_C12_L098', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 43:51 41:98'),
    (12, 'BODY_C12_L098', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 43:52 41:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 43:53 41:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 43:55 41:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 43:56 41:98'),
    (12, 'BODY_C12_L098', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 43:56 41:98'),
    (12, 'BODY_C12_L098', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 43:56 41:98'),
    (12, 'BODY_C12_L098', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 43:56 41:98'),
    (12, 'BODY_C12_L098', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 43:57 41:98'),
    (12, 'BODY_C12_L099', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 41:99'),
    (12, 'BODY_C12_L099', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 41:99'),
    (12, 'BODY_C12_L099', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 41:99'),
    (12, 'BODY_C12_L099', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 41:99'),
    (12, 'BODY_C12_L099', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 41:99'),
    (12, 'BODY_C12_L100', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 41:100'),
    (13, 'BODY_C13_L112', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 44:253 45:112'),
    (13, 'BODY_C13_L113', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 37:23 45:113'),
    (13, 'BODY_C13_L113', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 37:23 45:113'),
    (13, 'BODY_C13_L113', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 37:23 45:113'),
    (13, 'BODY_C13_L113', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 37:23 45:113'),
    (13, 'BODY_C13_L113', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 37:23 45:113'),
    (13, 'BODY_C13_L113', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 37:24 45:113'),
    (13, 'BODY_C13_L113', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 37:25 45:113'),
    (13, 'BODY_C13_L114', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 45:114'),
    (13, 'BODY_C13_L115', 'MAIN', '0:110 1:66 2:40 3:104 4:102 45:115'),
    (13, 'BODY_C13_L119', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 42:47 45:119'),
    (13, 'BODY_C13_L120', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 45:120'),
    (13, 'BODY_C13_L120', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 45:120'),
    (13, 'BODY_C13_L120', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 45:120'),
    (13, 'BODY_C13_L120', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 45:120'),
    (13, 'BODY_C13_L120', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 45:120'),
    (14, 'BODY_C14_L128', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 44:253 46:128'),
    (14, 'BODY_C14_L129', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 37:23 46:129'),
    (14, 'BODY_C14_L129', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 37:23 46:129'),
    (14, 'BODY_C14_L129', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 37:23 46:129'),
    (14, 'BODY_C14_L129', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 37:23 46:129'),
    (14, 'BODY_C14_L129', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 37:23 46:129'),
    (14, 'BODY_C14_L129', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 37:24 46:129'),
    (14, 'BODY_C14_L129', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 37:25 46:129'),
    (14, 'BODY_C14_L130', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 46:130'),
    (14, 'BODY_C14_L131', 'MAIN', '0:110 1:66 2:40 3:104 4:102 46:131'),
    (14, 'BODY_C14_L135', 'MAIN', '0:110 1:66 2:40 3:104 4:102 46:135'),
    (14, 'BODY_C14_L138', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 46:138'),
    (14, 'BODY_C14_L138', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 46:138'),
    (14, 'BODY_C14_L138', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 46:138'),
    (14, 'BODY_C14_L138', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 46:138'),
    (14, 'BODY_C14_L139', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 46:139'),
    (14, 'BODY_C14_L141', 'MAIN', '0:110 1:66 2:40 3:104 4:102 46:141'),
    (14, 'BODY_C14_L142', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 46:142'),
    (14, 'BODY_C14_L147', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 39:29 46:147'),
    (14, 'BODY_C14_L148', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:36 46:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:37 46:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:110 1:66 2:40 3:104 4:102 40:40 46:148'),
    (14, 'BODY_C14_L148', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 40:41 46:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 40:42 46:148'),
    (14, 'BODY_C14_L148', 'IDLE', '13:127 1:66 2:40 14:120 11:167 40:42 46:148'),
    (14, 'BODY_C14_L148', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 40:42 46:148'),
    (14, 'BODY_C14_L148', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 40:42 46:148'),
    (14, 'BODY_C14_L149', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 42:47 46:149'),
    (14, 'BODY_C14_L150', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 46:150'),
    (14, 'BODY_C14_L150', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 46:150'),
    (14, 'BODY_C14_L150', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 46:150'),
    (14, 'BODY_C14_L150', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 46:150'),
    (14, 'BODY_C14_L150', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 46:150'),
    (15, 'BODY_C15_L160', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 47:160'),
    (15, 'BODY_C15_L163', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 47:163'),
    (15, 'BODY_C15_L163', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 47:163'),
    (15, 'BODY_C15_L163', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 47:163'),
    (15, 'BODY_C15_L163', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 47:163'),
    (15, 'BODY_C15_L163', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 47:163'),
    (15, 'BODY_C15_L164', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 47:164'),
    (15, 'BODY_C15_L168', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 47:168'),
    (15, 'BODY_C15_L168', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 47:168'),
    (15, 'BODY_C15_L168', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 47:168'),
    (15, 'BODY_C15_L168', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 47:168'),
    (15, 'BODY_C15_L168', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 47:168'),
    (15, 'BODY_C15_L169', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 47:169'),
    (16, 'BODY_C16_L178', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 48:178'),
    (16, 'BODY_C16_L179', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 48:179'),
    (16, 'BODY_C16_L179', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 48:179'),
    (16, 'BODY_C16_L179', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 48:179'),
    (16, 'BODY_C16_L179', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 48:179'),
    (16, 'BODY_C16_L179', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 48:179'),
    (16, 'BODY_C16_L180', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 48:180'),
    (16, 'BODY_C16_L183', 'MAIN', '0:110 1:66 2:40 3:104 4:102 48:183'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 43:51 48:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 43:51 48:185'),
    (16, 'BODY_C16_L185', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 43:51 48:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 43:51 48:185'),
    (16, 'BODY_C16_L185', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 43:51 48:185'),
    (16, 'BODY_C16_L185', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 43:52 48:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 43:53 48:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 43:55 48:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 43:56 48:185'),
    (16, 'BODY_C16_L185', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 43:56 48:185'),
    (16, 'BODY_C16_L185', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 43:56 48:185'),
    (16, 'BODY_C16_L185', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 43:56 48:185'),
    (16, 'BODY_C16_L185', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 43:57 48:185'),
    (16, 'BODY_C16_L186', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 48:186'),
    (16, 'BODY_C16_L186', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 48:186'),
    (16, 'BODY_C16_L186', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 48:186'),
    (16, 'BODY_C16_L186', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 48:186'),
    (16, 'BODY_C16_L186', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 48:186'),
    (16, 'BODY_C16_L187', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 48:187'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 43:51 48:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 43:51 48:189'),
    (16, 'BODY_C16_L189', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 43:51 48:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 43:51 48:189'),
    (16, 'BODY_C16_L189', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 43:51 48:189'),
    (16, 'BODY_C16_L189', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 43:52 48:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 43:53 48:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 43:55 48:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 43:56 48:189'),
    (16, 'BODY_C16_L189', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 43:56 48:189'),
    (16, 'BODY_C16_L189', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 43:56 48:189'),
    (16, 'BODY_C16_L189', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 43:56 48:189'),
    (16, 'BODY_C16_L189', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 43:57 48:189'),
    (16, 'BODY_C16_L190', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 48:190'),
    (16, 'BODY_C16_L190', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 48:190'),
    (16, 'BODY_C16_L190', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 48:190'),
    (16, 'BODY_C16_L190', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 48:190'),
    (16, 'BODY_C16_L190', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 48:190'),
    (16, 'BODY_C16_L191', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 48:191'),
    (17, 'BODY_C17_L200', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 49:200'),
    (17, 'BODY_C17_L201', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 49:201'),
    (17, 'BODY_C17_L201', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 49:201'),
    (17, 'BODY_C17_L201', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 49:201'),
    (17, 'BODY_C17_L201', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 49:201'),
    (17, 'BODY_C17_L201', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 49:201'),
    (17, 'BODY_C17_L202', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 49:202'),
    (17, 'BODY_C17_L205', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 49:205'),
    (17, 'BODY_C17_L205', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 49:205'),
    (17, 'BODY_C17_L205', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 49:205'),
    (17, 'BODY_C17_L205', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 49:205'),
    (17, 'BODY_C17_L205', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 49:205'),
    (17, 'BODY_C17_L206', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 49:206'),
    (18, 'BODY_C18_L216', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 50:216'),
    (18, 'BODY_C18_L217', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 50:217'),
    (18, 'BODY_C18_L218', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 50:218'),
    (18, 'BODY_C18_L218', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 50:218'),
    (18, 'BODY_C18_L218', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 50:218'),
    (18, 'BODY_C18_L218', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 50:218'),
    (18, 'BODY_C18_L219', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 50:219'),
    (18, 'BODY_C18_L220', 'MAIN', '0:110 1:66 2:40 3:104 4:102 50:220'),
    (18, 'BODY_C18_L221', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 50:221'),
    (18, 'BODY_C18_L223', 'MAIN', '0:110 1:66 2:40 3:104 4:102 50:223'),
    (18, 'BODY_C18_L226', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 50:226'),
    (19, 'BODY_C19_L235', 'MAIN', '0:110 1:66 2:40 3:104 4:102 34:259 51:235'),
    (19, 'BODY_C19_L236', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 37:23 51:236'),
    (19, 'BODY_C19_L236', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 37:23 51:236'),
    (19, 'BODY_C19_L236', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 37:23 51:236'),
    (19, 'BODY_C19_L236', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 37:23 51:236'),
    (19, 'BODY_C19_L236', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 37:23 51:236'),
    (19, 'BODY_C19_L236', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 37:24 51:236'),
    (19, 'BODY_C19_L236', 'MAIN', '0:110 1:66 2:40 3:104 4:102 38:243 37:25 51:236'),
    (19, 'BODY_C19_L237', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 39:29 51:237'),
    (19, 'BODY_C19_L238', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 51:238'),
    (19, 'BODY_C19_L238', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 51:238'),
    (19, 'BODY_C19_L238', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 51:238'),
    (19, 'BODY_C19_L238', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 51:238'),
    (19, 'BODY_C19_L240', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 51:240'),
    (19, 'BODY_C19_L240', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 51:240'),
    (19, 'BODY_C19_L240', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 51:240'),
    (19, 'BODY_C19_L240', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 51:240'),
    (19, 'BODY_C19_L241', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 51:241'),
    (19, 'BODY_C19_L243', 'MAIN', '0:110 1:66 2:40 3:104 4:102 36:266 51:243'),
    (19, 'BODY_C19_L243', 'MAIN', '0:110 1:66 2:40 3:104 4:102 11:162 12:157 51:243'),
    (19, 'BODY_C19_L243', 'IDLE', '13:127 1:66 2:40 14:120 11:167 12:157 51:243'),
    (19, 'BODY_C19_L243', 'MAIN', '0:110 1:66 2:40 3:104 4:102 15:174 11:168 12:157 51:243'),
    (19, 'BODY_C19_L243', 'IDLE', '13:127 1:66 2:40 14:120 16:240 17:185 11:169 12:157 51:243'),
    (19, 'BODY_C19_L244', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 51:244'),
    (0, 'SETUP_RESET', 'MAIN', '0:110 1:66 2:40 3:104 4:102 52:49 1:66 2:40 53:49'),
    (0, 'SETUP_IDLE', 'IDLE', '13:127 1:66 2:40 14:120 54:56 1:66 2:40 53:56'),
    (0, 'TEARDOWN_HOST_FINISH', 'MAIN', '0:110 1:66 2:40 3:104 4:102 55:66 1:66 2:40 56:65'),
    (0, 'TEARDOWN_HOST_DESTROYED', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 55:67 1:66 2:40 56:65'),
    (0, 'TEARDOWN_REQUESTS', 'POLL_MAIN', '0:110 1:66 2:40 3:104 7:143 8:134 57:71 1:66 2:40 56:71'),
    (0, 'TEARDOWN_DATABASE', 'CLEANUP', '58:88 1:66 2:40 56:86'),
)

def _build_failure_sites():
    paths, pairs = {}, {}
    for index, phase, wait, encoded in _SITE_ROWS:
        frames = []
        for token in encoded.split(' '):
            method_id, line = map(int, token.split(':'))
            cls, method, file = _SITE_METHODS[method_id]
            frames.append(f'{cls}.{method}({file}:{line})')
            frames.extend(_SITE_DEX_BRIDGES.get(method_id, ()))
        identities = PARTIAL_EXPECTED_CASES if index == 0 else (PARTIAL_EXPECTED_CASES[index - 1],)
        for identity in identities:
            key = (identity, tuple(frames))
            if key in paths and paths[key] != (phase, wait):
                raise ValueError('Conflicting fixed failure-site map')
            paths[key] = (phase, wait)
            pairs.setdefault(identity, set()).add((phase, wait))
    return paths, pairs


_FAILURE_SITE_PATHS, _FAILURE_SITE_PAIRS = _build_failure_sites()
_SITE_GET_HINTS = frozenset({'HELPER_DEADLINE', 'HELPER_INTERRUPTED', 'HELPER_CHECKED_ACTION'})


def failure_site_allowed(identity, state, hint, phase, wait):
    """Validate only finite published values, including their case/hint relationship."""
    if type(phase) is not str or type(wait) is not str:
        return False
    if state != 'failed':
        return phase == wait == 'NOT_APPLICABLE'
    if phase == wait == 'UNKNOWN':
        return True
    return hint in _SITE_GET_HINTS and (phase, wait) in _FAILURE_SITE_PAIRS.get(identity, ())


def _site_primary_frames(stack):
    """Validate the first trace and the nesting syntax without mining secondary data."""
    lines = stack.split('\n')[1:]
    if lines and lines[-1] == '':
        lines.pop()
    primary = []
    cursor = 0
    while cursor < len(lines):
        match = re.fullmatch(r'\tat ([^\s()]+\([^()\n]+\))', lines[cursor])
        if match is None:
            break
        primary.append(match[1])
        if len(primary) > MAX_FAILURE_SITE_FRAMES:
            return None
        cursor += 1
    # Each enclosed trace's elision is bounded by its actual enclosing trace,
    # including that trace's own previously validated elision. No tail is mined.
    contexts = {0: {'count': len(primary), 'enclosing': None, 'elided': False}}
    nested_count = 0
    for line in lines[cursor:]:
        header = re.fullmatch(r'(\t*)(Suppressed: |Caused by: )(.+)', line)
        if header:
            tabs, caption, _ = header.groups()
            depth = len(tabs)
            parent = depth - 1 if caption == 'Suppressed: ' else depth
            if parent < 0 or parent not in contexts or depth > 16:
                return None
            nested_count += 1
            if nested_count > 128:
                return None
            enclosing = contexts[parent]['count']
            contexts = {d: value for d, value in contexts.items() if d <= parent}
            contexts[depth] = {'count': 0, 'enclosing': enclosing, 'elided': False}
            continue
        # An enclosed frame/elision requires an actual preceding exception header.
        if nested_count == 0:
            return None
        depth = max(contexts)
        frame = re.fullmatch(r'(\t+)at [^\s()]+\([^()\n]+\)', line)
        if frame:
            if len(frame[1]) != depth + 1 or contexts[depth]['elided']:
                return None
            contexts[depth]['count'] += 1
            continue
        elision = re.fullmatch(r'(\t+)\.\.\. ([1-9][0-9]{0,4}) more', line)
        if elision and len(elision[1]) == depth + 1 and not contexts[depth]['elided']:
            count = int(elision[2])
            if contexts[depth]['enclosing'] is None or count > contexts[depth]['enclosing']:
                return None
            contexts[depth]['elided'] = True
            contexts[depth]['count'] += count
            continue
        return None
    return tuple(primary)


def _failure_site(stack, identity, hint):
    """Project a complete fixed first-Throwable DEX caller chain, never a root cause.

    Unknown or omitted generated bridges are not repaired. In particular a plain
    JVM/static-lambda chain without its proven DEX bridges is not accepted. A
    file-only token is allowed only for the exact frozen no-position $r8 bridge.
    Input remains unauthenticated; an exactly copied complete trace is not proof
    of execution. Do not use these diagnostics as an alternate pass gate.
    """
    unknown = ('UNKNOWN', 'UNKNOWN')
    if (type(stack) is not str or hint not in _SITE_GET_HINTS
            or len(stack) > MAX_FAILURE_SITE_BYTES or _failure_hint(stack) != hint):
        return unknown
    try:
        if len(stack.encode('utf-8', errors='strict')) > MAX_FAILURE_SITE_BYTES:
            return unknown
    except UnicodeError:
        return unknown
    primary = _site_primary_frames(stack)
    if primary is None:
        return unknown
    # The official printer may trim the runner tail. Only the exact full root
    # chain is recognized here: no arbitrary framework frame can extend it.
    return _FAILURE_SITE_PATHS.get((identity, primary[1:]), unknown)


def _partial_result(states=None, protocol_state='invalid', ordinals=None, hints=None, sites=None):
    states = states or {}
    ordinals = ordinals or {}
    hints = hints or {}
    sites = sites or {}
    return {'cases': [{'class': c, 'method': m, 'state': states.get((c, m), 'unknown'),
                       'execution_ordinal': ordinals.get((c, m)),
                       'failure_hint': hints.get((c, m), 'UNKNOWN' if states.get((c, m)) == 'failed'
                                                 else 'NOT_APPLICABLE'),
                       'failure_phase': sites.get((c, m), ('UNKNOWN', 'UNKNOWN') if states.get((c, m)) == 'failed'
                                                  else ('NOT_APPLICABLE', 'NOT_APPLICABLE'))[0],
                       'failure_wait': sites.get((c, m), ('UNKNOWN', 'UNKNOWN') if states.get((c, m)) == 'failed'
                                                 else ('NOT_APPLICABLE', 'NOT_APPLICABLE'))[1]}
                      for c, m in PARTIAL_EXPECTED_CASES], 'protocol_state': protocol_state}


def _partial_expected_valid(expected):
    # A damaged config must not become a second way of publishing arbitrary names.
    return (type(expected) is list and len(expected) == 19
            and all(type(x) is dict and set(x) == {'class', 'method'}
                    and type(x['class']) is str and type(x['method']) is str for x in expected)
            and len({(x['class'], x['method']) for x in expected}) == 19
            and {(x['class'], x['method']) for x in expected} == set(PARTIAL_EXPECTED_CASES))


def parse_partial_output(raw, expected):
    """Return bounded, allowlisted observations, not a test-success determination.

    Malformed/ambiguous input invalidates *all* observations. Only fully terminated
    status bundles count. A clean EOF between or inside bundles is incomplete;
    unterminated lines, bad encoding and unexpected protocol are invalid. Android
    am's sorted bundle-key order is required to reject field-order injection.
    Opaque stack/stream text never leaves this function. Input is unauthenticated
    console protocol; this parser is deliberately not an alternate success gate.
    """
    import unicodedata

    if not _partial_expected_valid(expected):
        return _partial_result()
    if type(raw) not in (bytes, str) or len(raw) > MAX_PARTIAL_BYTES:
        return _partial_result()
    try:
        if type(raw) is str:
            raw = raw.encode('utf-8', errors='strict')
        if len(raw) > MAX_PARTIAL_BYTES:
            return _partial_result()
        text = raw.decode('utf-8', errors='strict').replace('\r\n', '\n')
    except UnicodeError:
        return _partial_result()
    # Do not use splitlines(): Unicode separators could manufacture protocol lines.
    if (text and not text.endswith('\n')) or any(
            unicodedata.category(ch) in {'Cc', 'Cf', 'Cs', 'Zl', 'Zp'}
            and ch not in '\n\t' for ch in text):
        return _partial_result()
    lines = text.split('\n')
    if len(lines) > MAX_PARTIAL_LINES + 1:
        return _partial_result()
    if any(len(line.encode('utf-8')) > MAX_PARTIAL_LINE_BYTES for line in lines):
        return _partial_result()

    wanted = set(PARTIAL_EXPECTED_CASES)
    known_classes = {c for c, _ in wanted}
    known_methods = {m for _, m in wanted}
    states = {}
    ordinals = {}
    hints = {}
    sites = {}
    bundle = {}
    field = None
    opaque = []
    active = None
    active_number = None
    ended = 0
    final = False
    result_stream = False
    last_class = None

    def invalid():
        return _partial_result()

    def valid_result_line(line):
        failed = 'failed' in states.values()
        if 'FAILURES!!!' in line and not failed:
            return False
        if re.fullmatch(r'OK \(\d+ tests?\)', line) and failed:
            return False
        if all(state == 'passed' for state in states.values()):
            return (line == '' or line == 'OK (19 tests)'
                    or re.fullmatch(r'Time: [0-9]{1,6}(?:\.[0-9]{1,9})?', line) is not None)
        return True

    def finish_opaque():
        nonlocal opaque
        if field in ('stack', 'stream'):
            bundle[field] = '\n'.join(opaque)
        opaque = []

    for line in lines[:-1]:
        if final:
            if line:
                return invalid()
            continue
        if 'INSTRUMENTATION_' in line and not line.startswith('INSTRUMENTATION_'):
            return invalid()
        if line.startswith('INSTRUMENTATION_STATUS: '):
            if result_stream:
                return invalid()
            finish_opaque()
            match = re.fullmatch(r'INSTRUMENTATION_STATUS: ([a-z]+)=(.*)', line)
            if not match:
                return invalid()
            key, value = match.groups()
            if (key not in _PARTIAL_KEYS or key in bundle
                    or (field is not None and _PARTIAL_KEYS.index(key) <= _PARTIAL_KEYS.index(field))
                    or 'INSTRUMENTATION_' in value):
                return invalid()
            if not bundle and key != 'class':
                return invalid()
            if key == 'class' and value not in known_classes:
                return invalid()
            if key == 'test' and (value not in known_methods or (bundle['class'], value) not in wanted):
                return invalid()
            if key == 'numtests' and value != '19':
                return invalid()
            if key == 'id' and value != 'AndroidJUnitRunner':
                return invalid()
            if key == 'current' and not re.fullmatch(r'(?:[1-9]|1[0-9])', value):
                return invalid()
            bundle[key] = value
            field = key
            if key in ('stack', 'stream'):
                opaque = [value]
            continue
        if line.startswith('INSTRUMENTATION_STATUS_CODE: '):
            if result_stream:
                return invalid()
            finish_opaque()
            match = re.fullmatch(r'INSTRUMENTATION_STATUS_CODE: (0|1|-[1-4])', line)
            if not match or not {'class', 'test', 'numtests'} <= set(bundle):
                return invalid()
            identity = (bundle['class'], bundle['test'])
            if identity not in wanted:
                return invalid()
            code = int(match[1])
            number = bundle.get('current')
            stream = bundle.get('stream')
            start_stream = ('', '\n' + identity[0] + ':')
            if code == 1:
                if (active is not None or identity in states or 'stack' in bundle
                        or (stream is not None and stream not in start_stream)
                        or (number is not None and number != str(ended + 1))):
                    return invalid()
                # A class header is only emitted when the runner changes class.
                if stream == '\n' + identity[0] + ':' and last_class == identity[0]:
                    return invalid()
                active = identity
                active_number = number
                states[identity] = 'started'
                # Observe the validated start sequence, never the config/list order.
                # Optional runner current must already agree with ended + 1 above.
                ordinals[identity] = ended + 1
                last_class = identity[0]
            else:
                if active != identity or number != active_number:
                    return invalid()
                if code == 0 and ('stack' in bundle or (stream is not None and stream != '.')):
                    return invalid()
                if code == -3 and ('stack' in bundle or (stream is not None and stream not in start_stream)):
                    return invalid()
                states[identity] = _PARTIAL_TERMINAL[code]
                if code in (-1, -2):
                    hints[identity] = _failure_hint(bundle.get('stack'))
                    sites[identity] = _failure_site(bundle.get('stack'), identity, hints[identity])
                active = None
                active_number = None
                ended += 1
            bundle = {}
            field = None
            opaque = []
            continue
        if line.startswith('INSTRUMENTATION_RESULT: stream='):
            if result_stream or bundle or active is not None or ended != 19:
                return invalid()
            result_stream = True
            result_value = line[len('INSTRUMENTATION_RESULT: stream='):]
            if 'INSTRUMENTATION_' in result_value or not valid_result_line(result_value):
                return invalid()
            continue
        if line.startswith('INSTRUMENTATION_CODE: '):
            if line != 'INSTRUMENTATION_CODE: -1' or bundle or active is not None or ended != 19:
                return invalid()
            final = True
            continue
        # Includes malformed STATUS/RESULT, aborts, shortMsg, unsupported fields,
        # runner failure markers and protocol-looking lines embedded in raw text.
        if line.startswith('INSTRUMENTATION_') or 'INSTRUMENTATION_' in line:
            return invalid()
        if result_stream:
            # Contradictory footer text must not leave 19 apparently successful
            # observations. Ordinary failure prose remains private and is never
            # an alternate source of case identities or status.
            if not valid_result_line(line):
                return invalid()
            continue
        if field in ('stack', 'stream'):
            opaque.append(line)
            continue
        if line:
            return invalid()
    return _partial_result(states, 'complete' if final else 'incomplete', ordinals, hints, sites)


def read_partial_output(path, expected):
    """Read a stable owned regular file, with no symlinks/FIFO waits or raw errors."""
    import os
    import stat

    if not _partial_expected_valid(expected):
        return _partial_result()
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_nlink != 1 or before.st_size > MAX_PARTIAL_BYTES):
            return _partial_result()
        chunks = []
        size = 0
        while size < before.st_size:
            chunk = os.read(fd, min(65536, before.st_size - size))
            if not chunk:
                break
            size += len(chunk)
            if size > before.st_size:
                return _partial_result()
            chunks.append(chunk)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
                  'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if (size != before.st_size
                or any(getattr(before, k) != getattr(after, k) for k in fields)):
            return _partial_result()
        return parse_partial_output(b''.join(chunks), expected)
    except (OSError, ValueError, TypeError):
        return _partial_result()
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
