#!/usr/bin/env python3
"""One reviewed public source build and one disposable unrooted UI test run.

All raw logs and APKs remain in this VM. Only allowlisted synthetic metadata
and JUnit leave it. Only the authorized temporary current-UID KVM ACL may change;
no account access, remote caches or retries.
"""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tarfile
import time
import urllib.request
import zipfile

from archive_safety import sha256, unpack_zip, unpack_pinned_aosp33
from result_parser import parse_output, junit_xml, read_partial_output
from manifest_audit import audit_manifest
import public_evidence
import progress_capture
from kvm_access import ensure_access, restore_outcome, restore_succeeded, KvmError
from owned_runtime import OwnedRuntime, RuntimeFailure, preflight
from safe_scratch import create, reclaim, validate, disk_gate

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence'
RUNNER = 'net.ankio.auto.isolated.IsolatedUiTestRunner'
TARGET = 'net.ankio.auto.isolatedui'
TEST = TARGET + '.test'
STAGE = 'preflight'
EVIDENCE_READY = False
ACTIVE_ROOT = None
ACTIVE_IDENTITY = None
BUILD_FAILURE = None
PROCESS_CLEANUP_OK = True
EVIDENCE_OK = True


class Blocked(Exception):
    pass


def require(condition, code):
    if not condition:
        raise Blocked(code)


def json_file(name, value):
    public_evidence.write(name,value)


def check_disk(root, points, stage):
    point = disk_gate(root)
    points.append({'stage': stage, **point})
    json_file('disk.json', points)


def command(args, *, env=None, cwd=None, timeout=60, log=None, runtime=None):
    if runtime is not None:
        p=runtime.run(args,env=env,cwd=cwd,timeout=timeout,log=log)
        require(p.returncode==0,'SUBPROCESS_FAILED')
        return (p.stdout or '').strip()
    if log:
        with Path(log).open('wb') as out:
            p = subprocess.run(args, stdout=out, stderr=subprocess.STDOUT,
                               env=env, cwd=cwd, timeout=timeout)
        require(p.returncode == 0, 'SUBPROCESS_FAILED')
        return ''
    p = subprocess.run(args, capture_output=True, text=True, env=env,
                       cwd=cwd, timeout=timeout)
    require(p.returncode == 0, 'SUBPROCESS_FAILED')
    return p.stdout.strip()


def close_runtime(runtime):
    global PROCESS_CLEANUP_OK,EVIDENCE_OK
    try:
        result=runtime.close()
        public_evidence.checked_runtime(result)
    except Exception:
        result={'state':'cleanup_failed','reason':'SUPERVISOR_FAILED'}
    PROCESS_CLEANUP_OK &= result['state'] in ('not_started','stopped_verified') and result['reason']=='NONE'
    try:
        if not public_evidence.record_runtime(result): EVIDENCE_OK=False
    except Exception:
        EVIDENCE_OK=False
        try: public_evidence.evidence_error('main','runtime')
        except Exception: print('Runtime evidence recording failed.')
    return result


def record_partial(raw,expected):
    global EVIDENCE_OK
    try:
        result=read_partial_output(raw,expected)
        public_evidence.write('instrumentation.json',public_evidence.checked_json('instrumentation.json',result))
    except Exception:
        EVIDENCE_OK=False
        public_evidence.evidence_error('main','instrumentation')


def prepare_progress(runtime, adb, server_port, root, env, adbc, server):
    try:
        identity=progress_capture.source_identity(
            adbc('shell','pm','list','packages','--user','0','-U'),
            adbc('shell','date','+%s.%N'))
        require(server.poll() is None,'ADB_SERVER_EXITED')
        progress_capture.start(runtime,adb,server_port,identity,root,env)
        return identity
    except (RuntimeFailure,subprocess.TimeoutExpired,InterruptedError):
        # Timeout/control failures may already have terminated the whole runtime.
        # Never issue instrumentation afterward or replace the first exception.
        raise
    except Blocked as error:
        if str(error) != 'SUBPROCESS_FAILED': raise
        return None
    except Exception:
        # Only non-terminal collection/parse failures are diagnostic-only.
        return None


def record_progress(root, identity, cleanup):
    global EVIDENCE_OK
    try:
        result=progress_capture.finish(root,identity,cleanup)
        public_evidence.write('progress.json',public_evidence.checked_json('progress.json',result))
    except Exception:
        EVIDENCE_OK=False
        try: public_evidence.evidence_error('main','progress')
        except Exception: print('Progress evidence recording failed.')


def fetch(spec, target):
    url = spec['url']
    require(url.startswith(('https://dl.google.com/android/repository/',
                            'https://github.com/adoptium/temurin21-binaries/releases/download/')),
            'NONALLOWLISTED_TOOL_SOURCE')
    target.parent.mkdir(exist_ok=True)
    with urllib.request.urlopen(url, timeout=60) as response, target.open('xb') as out:
        total = 0
        while chunk := response.read(1024*1024):
            total += len(chunk)
            require(total <= spec['size'], 'TOOL_DOWNLOAD_TOO_LARGE')
            out.write(chunk)
    require(total == spec['size'] and sha256(target) == spec['sha256'], 'TOOL_HASH_MISMATCH')


def prepare_tools(root, config, keys):
    downloads = root / 'downloads'; downloads.mkdir(exist_ok=True)
    sdk = root / 'sdk'; sdk.mkdir(exist_ok=True)
    for key in keys:
        archive = downloads / (key + ('.tar.gz' if key == 'jdk' else '.zip'))
        fetch(config['downloads'][key], archive)
        output = root / ('unpack-' + key)
        if key == 'jdk':
            output.mkdir()
            with tarfile.open(archive) as tf:
                tf.extractall(output, filter='data')
            children = list(output.iterdir())
            require(len(children) == 1 and children[0].is_dir(), 'JDK_ARCHIVE_LAYOUT')
            children[0].rename(root / 'jdk')
        else:
            if key == 'aosp33':
                unpack_pinned_aosp33(archive, output)
            else:
                unpack_zip(archive, output)
            if key == 'platform36':
                children = list(output.iterdir())
                require(len(children) == 1 and children[0].is_dir(), 'PLATFORM_ARCHIVE_LAYOUT')
                (sdk/'platforms').mkdir(exist_ok=True)
                children[0].rename(sdk/'platforms/android-36')
            elif key == 'build_tools':
                require((output/'android-15').is_dir(), 'BUILD_TOOLS_LAYOUT')
                (sdk/'build-tools').mkdir(exist_ok=True)
                (output/'android-15').rename(sdk/'build-tools/35.0.0')
            elif key == 'aosp33':
                require((output/'x86_64').is_dir(), 'SYSTEM_IMAGE_LAYOUT')
                (sdk/'system-images/android-33/default').mkdir(parents=True)
                (output/'x86_64').rename(sdk/'system-images/android-33/default/x86_64')
            else:
                dirname = {'platform_tools':'platform-tools','emulator':'emulator'}[key]
                (output/dirname).rename(sdk/dirname)
        # Only the exact verified archive downloaded by this function.
        archive.unlink()
        output.rmdir()


def source(root, config):
    spec = config['source']
    require(spec['mode'] == 'zip', 'SOURCE_BUNDLE_REQUIRED')
    relative = Path(spec['path'])
    require(relative.name == str(relative) and relative.suffix == '.zip', 'SOURCE_BUNDLE_PATH')
    bundle = ROOT/relative
    require(not bundle.is_symlink() and bundle.stat().st_size <= 25*1024**2,
            'SOURCE_BUNDLE_INVALID')
    require(sha256(bundle) == spec['sha256'], 'SOURCE_BUNDLE_HASH_MISMATCH')
    build = root/'build'
    unpack_zip(bundle, build, max_bytes=150*1024**2)
    require((build/'gradlew').is_file() and (build/'settings.gradle.kts').is_file(),
            'SOURCE_BUNDLE_LAYOUT')
    require(not (build/'.github/workflows').exists() and not (build/'.git').exists(),
            'SOURCE_BUNDLE_UNREVIEWED_AUTOMATION')
    return build


def verify_apk(apk, package, tools, env, instrumentation):
    badging = command([str(tools/'aapt2'), 'dump', 'badging', str(apk)], env=env)
    require(re.search(r"^package: name='"+re.escape(package)+r"'", badging, re.M), 'APK_PACKAGE')
    tree = command([str(tools/'aapt2'), 'dump', 'xmltree', '--file',
                    'AndroidManifest.xml', str(apk)], env=env)
    manifest=audit_manifest(tree,instrumentation)
    signing = command([str(tools/'apksigner'),'verify','--print-certs',str(apk)], env=env)
    certificates = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-f]{64})$', signing, re.M)
    require(len(certificates) == 1, 'APK_SIGNATURE')
    with zipfile.ZipFile(apk) as z:
        require(z.testzip() is None, 'APK_ZIP_CORRUPT')
        for name in z.namelist():
            low = name.lower()
            require(not (low.endswith('.tflite') or 'bugly' in low or
                         low.startswith(('assets/columbus/', 'assets/samsung/'))),
                    'APK_EXCLUDED_VENDOR_PAYLOAD')
            if re.fullmatch(r'classes\d*\.dex',name):
                data=z.read(name)
                require(b'Lcom/tencent/bugly/' not in data and b'Lcom/equationl/ncnnandroidppocr/' not in data,
                        'APK_EXCLUDED_VENDOR_CODE')
    return {'sha256':sha256(apk), 'size':apk.stat().st_size, 'package':package,
            'certificate_sha256':certificates[0], 'manifest':manifest}


def main():
    global STAGE,EVIDENCE_READY,ACTIVE_ROOT,ACTIVE_IDENTITY,BUILD_FAILURE
    public_evidence.init()
    EVIDENCE_READY=True
    config = json.loads((ROOT/'runtime-lock.json').read_text())
    expected = json.loads((ROOT/'expected-tests.json').read_text())
    points = []
    require(config.get('publication_review') == 'approved', 'PUBLICATION_REVIEW_PENDING')
    require(os.environ.get('GITHUB_ACTIONS') == 'true'
            and os.environ.get('GITHUB_REPOSITORY') == config['repository']
            and os.environ.get('GITHUB_JOB') == 'isolated-ui'
            and os.environ.get('GITHUB_RUN_ATTEMPT') == '1', 'RUN_SCOPE')
    commit = os.environ.get('EXPECTED_COMMIT','')
    require(re.fullmatch('[0-9a-f]{40}',commit) and commit == os.environ.get('GITHUB_SHA'), 'COMMIT_SCOPE')
    require(command(['git','rev-parse','HEAD'],cwd=ROOT) == commit, 'CHECKOUT_SCOPE')
    identity = {k:os.environ[k] for k in ('GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','GITHUB_SHA','GITHUB_REPOSITORY')}
    # Probe required Linux ownership primitives before any KVM ACL or build action.
    preflight()
    root = create(os.environ['RUNNER_TEMP'], identity)
    ACTIVE_ROOT,ACTIVE_IDENTITY=root,identity
    check_disk(root,points,'initial')
    kvm=ensure_access(root,identity)
    json_file('kvm.json',kvm)
    fd=os.open('/dev/kvm',os.O_RDWR|os.O_NOFOLLOW)
    try: require(fcntl.ioctl(fd,0xAE00,0) == 12, 'KVM_API_UNAVAILABLE')
    finally: os.close(fd)
    STAGE = 'prepare-build'
    print('Preparing the reviewed source and pinned build tools.')
    build=source(root,config)
    from source_contract import check_wrapper
    check_wrapper((build/'gradle/wrapper/gradle-wrapper.properties').read_text())
    require((build/'gradle/verification-metadata.xml').is_file(),'GRADLE_DEPENDENCY_VERIFICATION_MISSING')
    prepare_tools(root,config,['jdk','platform36','build_tools','platform_tools'])
    sdk=root/'sdk'
    existing_sdk=Path(os.environ.get('ANDROID_HOME','/usr/local/lib/android/sdk'))
    if (existing_sdk/'licenses').is_dir():
        shutil.copytree(existing_sdk/'licenses',sdk/'licenses')
    env=os.environ.copy()
    # Dependency tools receive no GitHub token and no shared Gradle cache.
    for name in ('GITHUB_TOKEN','GH_TOKEN','ACTIONS_RUNTIME_TOKEN','ACTIONS_ID_TOKEN_REQUEST_TOKEN'):
        env.pop(name,None)
    env.update(JAVA_HOME=str(root/'jdk'),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
               GRADLE_USER_HOME=str(root/'gradle-home'),ANDROID_USER_HOME=str(root/'android-user'),
               ANDROID_AVD_HOME=str(root/'avd'),ANDROID_EMULATOR_HOME=str(root/'android-user'),
               ANDROID_SERIAL='emulator-5554',TZ='UTC')
    env['PATH']=str(root/'jdk/bin')+':'+str(sdk/'platform-tools')+':'+env['PATH']
    (build/'local.properties').write_text(f'sdk.dir={sdk}\n')
    check_disk(root,points,'before-build')
    STAGE = 'build'
    print('Building the two isolated UI packages; raw build output remains in this VM.')
    log=root/'build-private.log'
    args=['bash','gradlew','--no-daemon','--max-workers=2','--console=plain',
          '--no-build-cache','--no-configuration-cache','--no-scan','--dependency-verification=strict',
          '-PisolatedUiTests=true','-Pandroid.builder.sdkDownload=false',
          '-Dorg.gradle.java.installations.auto-download=false',
          '-Pkotlin.compiler.execution.strategy=in-process',
          ':app:assembleIsolatedUi',':app:assembleIsolatedUiAndroidTest']
    build_runtime=OwnedRuntime()
    require(public_evidence.record_runtime({'state':'running','reason':'NONE'}),'EVIDENCE_RECORD_FAILED')
    try:
        proc=build_runtime.start_service(args,cwd=build,env=env,log=log)
        deadline=time.monotonic()+900
        while proc.poll() is None:
            require(time.monotonic()<deadline,'BUILD_TIMEOUT')
            check_disk(root,points,'build-monitor')
            time.sleep(2)
        returncode=proc.poll()
        if returncode != 0: BUILD_FAILURE=public_evidence.classify_build_failure(log,returncode)
        require(returncode==0,'BUILD_FAILED')
    finally:
        close_runtime(build_runtime)
    if not PROCESS_CLEANUP_OK:
        STAGE='cleanup';raise Blocked('RUNTIME_CLEANUP_FAILED')
    STAGE = 'audit-apks'
    apks=root/'apks'; apks.mkdir()
    records={}
    for key,pattern,package in [('target','app/build/outputs/apk/isolatedUi/*.apk',TARGET),
                               ('instrumentation','app/build/outputs/apk/androidTest/isolatedUi/*.apk',TEST)]:
        found=list(build.glob(pattern))
        require(len(found)==1,'APK_OUTPUT_COUNT')
        destination=apks/(key+'.apk'); shutil.copyfile(found[0],destination)
        records[key]=verify_apk(destination,package,sdk/'build-tools/35.0.0',env,key=='instrumentation')
    require(records['target']['certificate_sha256']==records['instrumentation']['certificate_sha256'],
            'APK_CERTIFICATE_MISMATCH')
    json_file('identity.json',{'kind':'new-public-source-build','commit':commit,
                              'source_bundle_sha256':config['source']['sha256'],'apks':records})
    # Preserve the audited APKs and metadata, reclaim only this run's owned copies.
    STAGE = 'reclaim-build'
    reclaim(root,identity)
    check_disk(root,points,'after-owned-build-reclaim')
    STAGE = 'prepare-runtime'
    prepare_tools(root,config,['emulator','aosp33'])
    reclaim(root,identity,('downloads',))
    check_disk(root,points,'before-emulator')
    emulator=sdk/'emulator/emulator'; adb=sdk/'platform-tools/adb'
    runtime=OwnedRuntime()
    progress_identity=None
    progress_attempted=False
    require(public_evidence.record_runtime({'state':'running','reason':'NONE'}),'EVIDENCE_RECORD_FAILED')
    try:
        acceleration=command([str(emulator),'-accel-check'],env=env,timeout=30,runtime=runtime)
        require(re.search(r'KVM.*usable',acceleration,re.I),'KVM_ACCELERATION_UNAVAILABLE')
        avd=root/'avd'; avd.mkdir(); device=avd/'aa-isolated-ui.avd'; device.mkdir()
        (avd/'aa-isolated-ui.ini').write_text(f'avd.ini.encoding=UTF-8\npath={device}\ntarget=android-33\n')
        (device/'config.ini').write_text('AvdId=aa-isolated-ui\navd.ini.encoding=UTF-8\nabi.type=x86_64\n'
            'hw.cpu.arch=x86_64\nhw.cpu.ncore=2\nhw.ramSize=3072\nhw.lcd.width=720\n'
            'hw.lcd.height=1280\nhw.lcd.density=320\nhw.keyboard=yes\nhw.gpu.enabled=yes\n'
            'hw.gpu.mode=swiftshader_indirect\ndisk.dataPartition.size=2G\n'
            f'image.sysdir.1={sdk}/system-images/android-33/default/x86_64/\n'
            'tag.id=default\ntag.display=Default\nPlayStore.enabled=false\nshowDeviceFrame=no\n')
        server,server_port=runtime.start_adb_server(str(adb),env=env,log=root/'adb-private.log')
        env['ANDROID_ADB_SERVER_PORT']=str(server_port)
        env['ADB_SERVER_SOCKET']='tcp:127.0.0.1:'+str(server_port)
        # Numeric 127.0.0.1 is an explicit remote-host client mode in the pinned
        # ADB protocol implementation: connection failure does not auto-start.
        adb_base=[str(adb),'-H','127.0.0.1','-P',str(server_port)]
        def adb_command(*args,timeout=30,log=None):
            require(server.poll() is None,'ADB_SERVER_EXITED')
            result=command([*adb_base,*args],env=env,timeout=timeout,log=log,runtime=runtime)
            require(server.poll() is None,'ADB_SERVER_EXITED')
            return result
        def adbc(*args,timeout=30):
            return adb_command('-s','emulator-5554',*args,timeout=timeout)
        require(len(adb_command('devices',timeout=60).splitlines())==1,'PREEXISTING_DEVICE')
        STAGE='boot'
        print('Starting one fresh Android 13 x86_64 emulator without guest root.')
        proc=runtime.start_service([str(emulator),'-avd','aa-isolated-ui','-port','5554','-no-window',
            '-no-audio','-no-boot-anim','-no-snapshot','-no-metrics','-accel','on',
            '-gpu','swiftshader_indirect','-memory','3072','-cores','2'],env=env,log=root/'emulator-private.log')
        deadline=time.monotonic()+240
        while True:
            require(proc.poll() is None,'EMULATOR_EXITED')
            require(time.monotonic()<deadline,'EMULATOR_BOOT_TIMEOUT')
            require(server.poll() is None,'ADB_SERVER_EXITED')
            p=runtime.run([*adb_base,'-s','emulator-5554','shell','getprop','sys.boot_completed'],
                          env=env,timeout=5)
            if p.returncode==0 and p.stdout.strip()=='1': break
            time.sleep(1)
        require(adbc('emu','avd','name').splitlines()[0]=='aa-isolated-ui','DEVICE_IDENTITY')
        require(adbc('shell','getprop','ro.build.version.sdk')=='33','DEVICE_API')
        require(adbc('shell','getprop','ro.product.cpu.abi')=='x86_64','DEVICE_ABI')
        require(adbc('shell','getprop','ro.kernel.qemu')=='1','DEVICE_EMULATOR')
        require(adbc('shell','id','-u')=='2000','DEVICE_NOT_UNROOTED')
        require(adbc('shell','getenforce')=='Enforcing','DEVICE_SELINUX')
        require(not adbc('shell','pm','list','packages','-3'),'PREEXISTING_GUEST_APP')
        adbc('shell','input','keyevent','82')
        for key,package in [('target',TARGET),('instrumentation',TEST)]:
            apk=apks/(key+'.apk')
            require(sha256(apk)==records[key]['sha256'],'APK_CHANGED_BEFORE_INSTALL')
            adbc('install','-t',str(apk),timeout=120)
            installed=adbc('shell','pm','path',package)
            require(re.fullmatch(r'package:/data/app/[A-Za-z0-9_+=~./-]+/base\.apk',installed),'INSTALLED_APK_PATH')
            require(adbc('shell','sha256sum',installed[8:]).split()[0]==records[key]['sha256'],
                    'INSTALLED_APK_HASH')
        STAGE='instrumentation'
        progress_attempted=True
        # A unique fresh target UID, not the instrumentation package UID.
        progress_identity=prepare_progress(runtime,adb,server_port,root,env,adbc,server)
        raw=root/'instrumentation-private.txt'
        classes=','.join(sorted({x['class'] for x in expected}))
        try:
            adb_command('-s','emulator-5554','shell','am','instrument','-w','-r',
                        '-e','class',classes,TEST+'/'+RUNNER,timeout=600,log=raw)
        finally:
            # Partial observations are diagnostic only. They never grant success.
            record_partial(raw,expected)
        require(raw.stat().st_size <= 2*1024**2,'TEST_OUTPUT_TOO_LARGE')
        cases=parse_output(raw.read_text(errors='replace'),expected)
        for key in records:
            require(sha256(apks/(key+'.apk'))==records[key]['sha256'],'APK_CHANGED_AFTER_TEST')
        public_evidence.write_junit(cases)
        json_file('summary.json',{'status':'passed','tests':19,'failures':0,'errors':0,'skipped':0,
                                 'device_api':33,'device_abi':'x86_64','new_build':True})
        print('19 isolated UI cases passed, with zero failures, errors or skips.')
    finally:
        cleanup=close_runtime(runtime)
        # Includes command-timeout cleanup. No new ADB action follows the test.
        if progress_attempted: record_progress(root,progress_identity,cleanup)
    if not PROCESS_CLEANUP_OK:
        STAGE='cleanup';raise Blocked('RUNTIME_CLEANUP_FAILED')


def entrypoint():
    status=0
    try:
        main()
    except Exception as error:
        if isinstance(error,RuntimeFailure): code=error.code
        else: code=str(error) if isinstance(error,(Blocked,KvmError)) else type(error).__name__
        try:
            if code not in public_evidence.known_error_codes(): code='UNEXPECTED_FAILURE'
        except Exception: code='UNEXPECTED_FAILURE'
        summary={'status':'blocked-or-failed','stage':STAGE,'code':code,'new_build':True}
        if STAGE=='build' and code=='BUILD_FAILED' and BUILD_FAILURE is not None:
            summary['build_failure']=public_evidence.checked_build_failure(BUILD_FAILURE)
        if EVIDENCE_READY:
            try: json_file('summary.json',summary)
            except Exception: public_evidence.evidence_error('main','summary')
        print(f'Isolated UI run stopped at {STAGE}: {code}. No automatic retry.')
        status=1
    finally:
        if ACTIVE_ROOT is not None:
            try:
                result=restore_outcome(ACTIVE_ROOT,ACTIVE_IDENTITY)
                restore_ok=restore_succeeded(result)
                recorded=public_evidence.record_restore_attempt('main',result) if EVIDENCE_READY else False
            except Exception:
                restore_ok=False;recorded=False
                try: public_evidence.evidence_error('main','kvm')
                except Exception: print('KVM evidence recording failed.')
            if not restore_ok or not recorded:
                if status==0:
                    # No first failure exists. Do not overwrite an earlier failure.
                    if EVIDENCE_READY:
                        try: json_file('summary.json',{'status':'blocked-or-failed','stage':'cleanup',
                                                      'code':'CLEANUP_FAILED','new_build':True})
                        except Exception: public_evidence.evidence_error('main','summary')
                status=1
        if not PROCESS_CLEANUP_OK or not EVIDENCE_OK:
            if status==0 and EVIDENCE_READY:
                try: json_file('summary.json',{'status':'blocked-or-failed','stage':'cleanup',
                                              'code':'CLEANUP_FAILED','new_build':True})
                except Exception: public_evidence.evidence_error('main','summary')
            status=1
    return status


if __name__=='__main__':
    def interrupted(signum,frame): raise Blocked('INTERRUPTED')
    signal.signal(signal.SIGTERM,interrupted)
    signal.signal(signal.SIGINT,interrupted)
    raise SystemExit(entrypoint())
