"""Own only a new per-job directory. Never reclaim runner-preinstalled content."""
import json
import os
from pathlib import Path
import re
import shutil
import stat

GIB = 1024 ** 3
MIN_FREE = (6 * GIB * 12 + 9) // 10 + GIB  # Existing 8.2 GiB gate, unchanged.
MARKER = '.isolated-ui-owned.json'
RECLAIM = ('build', 'gradle-home', 'downloads')


def canonical(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts or path != path.resolve():
        raise ValueError('Unsafe scratch path')
    return path


def receipt(root, identity):
    st = root.stat()
    return {'path': str(root), 'inode': st.st_ino, 'device': st.st_dev,
            'uid': os.getuid(), 'identity': identity}


def create(parent, identity):
    parent = canonical(parent)
    if not parent.is_dir() or parent == Path('/'):
        raise ValueError('Invalid scratch parent')
    root = parent / 'aa-public-ui-one-job'
    root.mkdir(mode=0o700, exist_ok=False)
    (root / MARKER).write_text(json.dumps(receipt(root, identity)))
    return root


def validate(root, identity):
    root = canonical(root)
    st = root.stat()
    marker = root / MARKER
    if (not stat.S_ISDIR(st.st_mode) or st.st_uid != os.getuid()
            or stat.S_IMODE(st.st_mode) != 0o700 or marker.is_symlink()
            or marker.stat().st_nlink != 1 or marker.stat().st_size > 8192
            or json.loads(marker.read_text()) != receipt(root, identity)):
        raise ValueError('Invalid scratch ownership receipt')


def mounts():
    paths = []
    for line in Path('/proc/self/mountinfo').read_bytes().splitlines():
        fields = line.split()
        if len(fields) < 7:
            raise ValueError('Cannot verify mount boundaries')
        raw = re.sub(rb'\\([0-7]{3})', lambda m: bytes([int(m[1], 8)]), fields[4])
        paths.append(Path(os.fsdecode(raw)))
    if not paths:
        raise ValueError('Cannot verify mount boundaries')
    return paths


def inspect(path, device):
    st = path.lstat()
    if stat.S_ISLNK(st.st_mode):
        return  # rmtree unlinks this entry, never its target.
    if st.st_dev != device or st.st_uid != os.getuid() or os.path.ismount(path):
        raise ValueError('Foreign-owned or mounted scratch entry')
    if path.is_dir():
        for child in path.iterdir():
            inspect(child, device)
    elif not path.is_file():
        raise ValueError('Special file in scratch cleanup')


def reclaim(root, identity, names=RECLAIM):
    validate(root, identity)
    if any(name not in RECLAIM for name in names):
        raise ValueError('Cleanup target is not allowlisted')
    targets = [root / name for name in names if (root / name).exists()]
    for target in targets:
        canonical(target)
        if not target.is_dir():
            raise ValueError('Cleanup target is not an owned directory')
        if any(m == target or target in m.parents for m in mounts()):
            raise ValueError('Mount inside cleanup target')
        inspect(target, root.stat().st_dev)
    for target in targets:
        shutil.rmtree(target)


def disk_gate(path):
    free = shutil.disk_usage(path).free
    if free < MIN_FREE:
        raise ValueError('Disk free space is below the unchanged 8.2 GiB gate')
    return {'free_bytes': free, 'minimum_bytes': MIN_FREE}
