"""Exact reviewed Gradle distribution pin, with no comments or duplicate ambiguity."""
import re

EXPECTED_URL='https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip'
EXPECTED_HASH='f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6'


def check_wrapper(text):
    values={}
    for line in text.splitlines():
        line=line.strip()
        if not line or line.startswith(('#','!')): continue
        if '=' not in line or line.endswith('\\'): raise ValueError('Unsupported wrapper property syntax')
        key,value=line.split('=',1); key=key.strip(); value=value.strip()
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9]*',key): raise ValueError('Unsupported wrapper property key')
        if key in values: raise ValueError('Duplicate wrapper property')
        values[key]=value
    if values.get('distributionUrl')!=EXPECTED_URL or values.get('distributionSha256Sum')!=EXPECTED_HASH:
        raise ValueError('Gradle distribution lock mismatch')
