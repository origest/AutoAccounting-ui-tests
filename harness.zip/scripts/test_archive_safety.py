from pathlib import Path
from contextlib import ExitStack
import copy
import inspect
import json
import os
import struct
from types import SimpleNamespace
from unittest.mock import patch
import archive_safety as safety
import stat
import tempfile
import unittest
import warnings
import zipfile
from archive_safety import unpack_zip


class ZipTests(unittest.TestCase):
    def make(self, parent, names):
        archive = Path(parent)/'source.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(archive, 'w') as out:
                for name in names:
                    out.writestr(name, b'hello')
        return archive

    def test_accepts_plain_source(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = self.make(temp, ['settings.gradle.kts','app/src/test.kt'])
            unpack_zip(archive, Path(temp)/'out')
            self.assertEqual((Path(temp)/'out/app/src/test.kt').read_text(), 'hello')

    def test_rejects_traversal_absolute_duplicate_and_backslash(self):
        for names in [['../bad'], ['/bad'], ['x','x'], ['x\\y'], ['x/./y'], ['x//y']]:
            with self.subTest(names=names), tempfile.TemporaryDirectory() as temp:
                with self.assertRaises(ValueError):
                    unpack_zip(self.make(temp,names), Path(temp)/'out')

    def test_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = Path(temp)/'source.zip'
            entry=zipfile.ZipInfo('link'); entry.create_system=3
            entry.external_attr=(stat.S_IFLNK|0o777)<<16
            with zipfile.ZipFile(archive,'w') as out: out.writestr(entry,'/tmp')
            with self.assertRaises(ValueError): unpack_zip(archive,Path(temp)/'out')

    def test_rejects_expansion(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                unpack_zip(self.make(temp,['a']),Path(temp)/'out',max_bytes=4)

    def test_rejects_nul_in_original_zip_name(self):
        with tempfile.TemporaryDirectory() as temp:
            archive=self.make(temp,['safeZevil'])
            archive.write_bytes(archive.read_bytes().replace(b'safeZevil',b'safe\x00evil'))
            with self.assertRaises(ValueError): unpack_zip(archive,Path(temp)/'out')


class PinnedImageTests(unittest.TestCase):
    def infos(self):
        entries=[]
        for name,size,mode in safety.AOSP33_MEMBERS:
            entry=zipfile.ZipInfo(name); entry.file_size=size; entry.external_attr=mode<<16
            entries.append(entry)
        return entries

    def valid_stat(self, **changes):
        values=dict(st_mode=stat.S_IFREG|0o600,st_nlink=1,st_uid=os.getuid(),
                    st_size=safety.AOSP33_ARCHIVE_SIZE,st_dev=1,st_ino=2,
                    st_mtime_ns=3,st_ctime_ns=4)
        values.update(changes)
        return SimpleNamespace(**values)

    def mocks(self, stack, *, digest=None, infos=None, stat_result=None, free=64*1024**3):
        fstat=stack.enter_context(patch.object(safety.os,'fstat',return_value=stat_result or self.valid_stat()))
        hashed=stack.enter_context(patch.object(safety.hashlib,'file_digest',return_value=SimpleNamespace(
            hexdigest=lambda: safety.AOSP33_ARCHIVE_SHA256 if digest is None else digest)))
        archive=stack.enter_context(patch.object(safety.zipfile,'ZipFile'))
        archive.return_value.__enter__.return_value.infolist.return_value=self.infos() if infos is None else infos
        disk=stack.enter_context(patch.object(safety.shutil,'disk_usage',return_value=SimpleNamespace(free=free)))
        extracted=stack.enter_context(patch.object(safety,'unpack_zip'))
        return fstat,hashed,archive,disk,extracted

    def test_exact_contract_matches_lock_and_budget(self):
        lock=json.loads((Path(__file__).resolve().parents[1]/'runtime-lock.json').read_text())['downloads']['aosp33']
        self.assertEqual(safety.AOSP33_ARCHIVE_SIZE,lock['size'])
        self.assertEqual(safety.AOSP33_ARCHIVE_SHA256,lock['sha256'])
        self.assertEqual(len(safety.AOSP33_MEMBERS),19)
        self.assertEqual(sum(size for _,size,_ in safety.AOSP33_MEMBERS),4457578928)
        self.assertEqual(safety.AOSP33_EXPANDED_SIZE,4457578928)
        self.assertEqual(unpack_zip.__kwdefaults__['max_bytes'],4*1024**3)
        self.assertEqual(safety.MIN_FREE,8804682957)
        safety._check_aosp33_members(self.infos())

    def test_member_contract_rejects_missing_added_duplicate_and_reordered(self):
        infos=self.infos()
        for changed in (infos[:-1],infos+[copy.copy(infos[0])],infos[:1]+infos,infos[::-1]):
            with self.subTest(count=len(changed)),self.assertRaises(ValueError):
                safety._check_aosp33_members(changed)

    def test_member_contract_rejects_path_nul_symlink_special_size_and_directory(self):
        cases=('traversal','absolute','nul','symlink','special','size','directory','mode')
        for kind in cases:
            changed=self.infos(); first=changed[0]
            if kind=='traversal': first.filename=first.orig_filename='../escape'
            elif kind=='absolute': first.filename=first.orig_filename='/escape'
            elif kind=='nul': first.orig_filename=first.filename+'\x00escape'
            elif kind=='symlink': first.external_attr=(stat.S_IFLNK|0o777)<<16
            elif kind=='special': first.external_attr=(stat.S_IFIFO|0o644)<<16
            elif kind=='size': first.file_size+=1
            elif kind=='directory': first.filename=first.orig_filename=first.filename+'/'
            elif kind=='mode': first.external_attr=(stat.S_IFREG|0o755)<<16
            with self.subTest(kind=kind),self.assertRaises(ValueError):
                safety._check_aosp33_members(changed)

    def test_rejects_wrong_size_before_hash_or_unpack(self):
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            path=Path(temp)/'archive'; path.write_bytes(b'fixture')
            _,hashed,archive,_,extracted=self.mocks(stack,stat_result=self.valid_stat(st_size=7))
            with self.assertRaises(ValueError): safety.unpack_pinned_aosp33(path,Path(temp)/'out')
            hashed.assert_not_called(); archive.assert_not_called(); extracted.assert_not_called()
            self.assertFalse((Path(temp)/'out').exists())

    def test_rejects_wrong_hash_before_metadata_or_unpack(self):
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            path=Path(temp)/'archive'; path.write_bytes(b'fixture')
            _,_,archive,_,extracted=self.mocks(stack,digest='0'*64)
            with self.assertRaises(ValueError): safety.unpack_pinned_aosp33(path,Path(temp)/'out')
            archive.assert_not_called(); extracted.assert_not_called()
            self.assertFalse((Path(temp)/'out').exists())

    def test_rejects_contract_mismatch_before_unpack(self):
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            path=Path(temp)/'archive'; path.write_bytes(b'fixture')
            _,_,_,_,extracted=self.mocks(stack,infos=self.infos()[:-1])
            with self.assertRaises(ValueError): safety.unpack_pinned_aosp33(path,Path(temp)/'out')
            extracted.assert_not_called(); self.assertFalse((Path(temp)/'out').exists())

    def test_rejects_archive_symlink_and_nonregular_or_shared_ownership(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'archive'; path.write_bytes(b'fixture')
            link=Path(temp)/'link'; link.symlink_to(path)
            with self.assertRaises(OSError): safety.unpack_pinned_aosp33(link,Path(temp)/'out')
            for changes in ({'st_mode':stat.S_IFIFO|0o600},{'st_nlink':2},{'st_uid':os.getuid()+1}):
                with self.subTest(changes=changes),ExitStack() as stack:
                    _,hashed,archive,_,extracted=self.mocks(stack,stat_result=self.valid_stat(**changes))
                    with self.assertRaises(ValueError): safety.unpack_pinned_aosp33(path,Path(temp)/'out')
                    hashed.assert_not_called(); archive.assert_not_called(); extracted.assert_not_called()

    def test_uses_same_handle_and_only_exact_budget_after_validation(self):
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            path=Path(temp)/'archive'; path.write_bytes(b'fixture')
            _,hashed,archive,_,extracted=self.mocks(stack)
            safety.unpack_pinned_aosp33(path,Path(temp)/'out')
            handle=hashed.call_args.args[0]
            self.assertIs(handle,archive.call_args.args[0])
            self.assertIs(handle,extracted.call_args.args[0])
            self.assertEqual(extracted.call_args.kwargs,{'max_bytes':4457578928,'minimum_free':8804682957})
            self.assertTrue(handle.closed)

    def test_requires_full_expansion_plus_reserve_before_unpack(self):
        needed=safety.AOSP33_EXPANDED_SIZE+safety.MIN_FREE+16*1024**2
        with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
            path=Path(temp)/'archive'; path.write_bytes(b'fixture')
            _,_,_,_,extracted=self.mocks(stack,free=needed-1)
            with self.assertRaises(ValueError): safety.unpack_pinned_aosp33(path,Path(temp)/'out')
            extracted.assert_not_called()

    def test_rechecks_reserve_and_archive_stability_after_unpack(self):
        for kind in ('disk','size','modified'):
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
                path=Path(temp)/'archive'; path.write_bytes(b'fixture')
                fstat,_,_,disk,extracted=self.mocks(stack)
                if kind=='disk': disk.side_effect=[SimpleNamespace(free=64*1024**3),SimpleNamespace(free=safety.MIN_FREE-1)]
                elif kind=='size': fstat.side_effect=[self.valid_stat(),self.valid_stat(st_size=safety.AOSP33_ARCHIVE_SIZE+1)]
                else: fstat.side_effect=[self.valid_stat(),self.valid_stat(st_mtime_ns=5)]
                with self.assertRaises(ValueError): safety.unpack_pinned_aosp33(path,Path(temp)/'out')
                extracted.assert_called_once()

    def test_generic_zip_still_rejects_declared_expansion_above_four_gib(self):
        with tempfile.TemporaryDirectory() as temp:
            archive=Path(temp)/'generic.zip'
            with zipfile.ZipFile(archive,'w') as z:
                z.writestr('one',b''); z.writestr('two',b'')
            data=bytearray(archive.read_bytes()); start=0
            while True:
                start=data.find(b'PK\x01\x02',start)
                if start<0: break
                struct.pack_into('<L',data,start+24,3*1024**3); start+=4
            archive.write_bytes(data)
            with self.assertRaisesRegex(ValueError,'ZIP expansion exceeds bound'):
                unpack_zip(archive,Path(temp)/'out')
            self.assertEqual(list((Path(temp)/'out').iterdir()),[])

    def test_generic_zip_refuses_existing_destination_and_never_overwrites(self):
        with tempfile.TemporaryDirectory() as temp:
            archive=Path(temp)/'generic.zip'
            with zipfile.ZipFile(archive,'w') as z: z.writestr('kept',b'new')
            out=Path(temp)/'out'; out.mkdir(); (out/'kept').write_bytes(b'original')
            with self.assertRaises(FileExistsError): unpack_zip(archive,out)
            self.assertEqual((out/'kept').read_bytes(),b'original')

    def test_reserved_write_refuses_low_disk_before_writing_payload(self):
        with tempfile.TemporaryDirectory() as temp:
            archive=Path(temp)/'generic.zip'
            with zipfile.ZipFile(archive,'w') as z: z.writestr('payload',b'synthetic')
            with patch.object(safety.shutil,'disk_usage',return_value=SimpleNamespace(free=safety.MIN_FREE)),self.assertRaises(ValueError):
                unpack_zip(archive,Path(temp)/'out',minimum_free=safety.MIN_FREE)
            self.assertEqual((Path(temp)/'out/payload').read_bytes(),b'')

    def test_dispatch_reserves_special_budget_for_aosp_only(self):
        import run_ui
        for key,member in (('aosp33','x86_64'),('emulator','emulator')):
            with self.subTest(key=key),tempfile.TemporaryDirectory() as temp:
                root=Path(temp)
                def fake_fetch(spec,target): target.write_bytes(b'fixture')
                def fake_unpack(archive,out):
                    (out/member).mkdir(parents=True)
                with patch.object(run_ui,'fetch',side_effect=fake_fetch),\
                     patch.object(run_ui,'unpack_zip',side_effect=fake_unpack) as general,\
                     patch.object(run_ui,'unpack_pinned_aosp33',side_effect=fake_unpack) as pinned:
                    run_ui.prepare_tools(root,{'downloads':{key:{}}},[key])
                self.assertEqual(pinned.call_count,1 if key=='aosp33' else 0)
                self.assertEqual(general.call_count,0 if key=='aosp33' else 1)

    def test_source_retains_150_mib_limit_and_pinned_dispatch_requires_fetch_first(self):
        import run_ui
        source=inspect.getsource(run_ui.source)
        self.assertIn('unpack_zip(bundle, build, max_bytes=150*1024**2)',source)
        with tempfile.TemporaryDirectory() as temp,patch.object(run_ui,'fetch',side_effect=run_ui.Blocked('TOOL_HASH_MISMATCH')),\
             patch.object(run_ui,'unpack_pinned_aosp33') as pinned:
            with self.assertRaises(run_ui.Blocked):
                run_ui.prepare_tools(Path(temp),{'downloads':{'aosp33':{}}},['aosp33'])
            pinned.assert_not_called()


if __name__ == '__main__': unittest.main()
