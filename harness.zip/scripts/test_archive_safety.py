from pathlib import Path
import stat
import tempfile
import unittest
import warnings
import zipfile
from archive_safety import unpack_zip


class ZipTests(unittest.TestCase):
    def make(self, parent, names):
        archive = Path(parent)/'source.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(archive, 'w') as out:
                for name in names:
                    out.writestr(name, b'hello')
        return archive

    def test_accepts_plain_source(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = self.make(temp, ['settings.gradle.kts','app/src/test.kt'])
            unpack_zip(archive, Path(temp)/'out')
            self.assertEqual((Path(temp)/'out/app/src/test.kt').read_text(), 'hello')

    def test_rejects_traversal_absolute_duplicate_and_backslash(self):
        for names in [['../bad'], ['/bad'], ['x','x'], ['x\\y'], ['x/./y'], ['x//y']]:
            with self.subTest(names=names), tempfile.TemporaryDirectory() as temp:
                with self.assertRaises(ValueError):
                    unpack_zip(self.make(temp,names), Path(temp)/'out')

    def test_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = Path(temp)/'source.zip'
            entry=zipfile.ZipInfo('link'); entry.create_system=3
            entry.external_attr=(stat.S_IFLNK|0o777)<<16
            with zipfile.ZipFile(archive,'w') as out: out.writestr(entry,'/tmp')
            with self.assertRaises(ValueError): unpack_zip(archive,Path(temp)/'out')

    def test_rejects_expansion(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                unpack_zip(self.make(temp,['a']),Path(temp)/'out',max_bytes=4)

    def test_rejects_nul_in_original_zip_name(self):
        with tempfile.TemporaryDirectory() as temp:
            archive=self.make(temp,['safeZevil'])
            archive.write_bytes(archive.read_bytes().replace(b'safeZevil',b'safe\x00evil'))
            with self.assertRaises(ValueError): unpack_zip(archive,Path(temp)/'out')


if __name__ == '__main__': unittest.main()
