import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from bootstrap import bootstrap, EXPECTED_FILES


class BootstrapTests(unittest.TestCase):
    def bundle(self, root, *, change=None):
        entries = {n:b'# synthetic harness fixture\n' for n in EXPECTED_FILES}
        entries['runtime-lock.json'] = json.dumps({'publication_review':'approved',
            'repository':'origest/AutoAccounting-ui-tests', 'public_scope':'source-only-no-apk',
            'temporary_kvm_uid_acl_authorized':True}).encode()
        if change: change(entries)
        bundle = root/'harness.zip'
        with zipfile.ZipFile(bundle, 'w') as z:
            for name, data in entries.items(): z.writestr(name, data)
        return hashlib.sha256(bundle.read_bytes()).hexdigest(), bundle.stat().st_size

    def test_accepts_exact_bundle_without_executing_files(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, GITHUB_REPOSITORY='origest/AutoAccounting-ui-tests'):
            root=Path(temp); work=root/'checkout'; work.mkdir(); runtime=root/'temp'; runtime.mkdir()
            digest,size=self.bundle(work); bootstrap(work,runtime,digest,size)
            self.assertEqual(set(p.relative_to(work).as_posix() for p in work.rglob('*') if p.is_file())-{'harness.zip'},EXPECTED_FILES)

    def test_rejects_changed_hash_or_existing_destination(self):
        for bad_hash in (True,False):
            with self.subTest(bad_hash=bad_hash),tempfile.TemporaryDirectory() as temp:
                root=Path(temp); work=root/'checkout'; work.mkdir(); runtime=root/'temp'; runtime.mkdir()
                digest,size=self.bundle(work)
                if not bad_hash: (work/'scripts').symlink_to(root/'missing')
                with self.assertRaises(ValueError): bootstrap(work,runtime,'0'*64 if bad_hash else digest,size)

    def test_rejects_unsafe_missing_duplicate_and_oversized_members(self):
        changes=[lambda e:e.update({'../escape':b'bad'}),lambda e:e.pop('scripts/run_ui.py'),
                 lambda e:e.update({'scripts/run_ui.py':b'a'*(128*1024+1)}),
                 lambda e:e.update({'scripts/evil.py':b'bad'}),lambda e:e.update({'/escape':b'bad'})]
        for change in changes:
            with tempfile.TemporaryDirectory() as temp:
                root=Path(temp); work=root/'checkout'; work.mkdir(); runtime=root/'temp'; runtime.mkdir()
                digest,size=self.bundle(work,change=change)
                with self.assertRaises(ValueError): bootstrap(work,runtime,digest,size)
        for kind in ('duplicate','symlink','nul'):
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as temp:
                root=Path(temp); work=root/'checkout'; work.mkdir(); runtime=root/'temp'; runtime.mkdir()
                self.bundle(work)
                with zipfile.ZipFile(work/'harness.zip','a') as z:
                    if kind=='symlink':
                        i=zipfile.ZipInfo('scripts/new.py'); i.external_attr=(stat.S_IFLNK|0o777)<<16; z.writestr(i,'target')
                    elif kind=='nul': z.writestr('scripts/nul\x00evil.py','bad')
                    else:
                        import warnings
                        with warnings.catch_warnings():
                            warnings.simplefilter('ignore'); z.writestr('scripts/run_ui.py','bad')
                bundle=work/'harness.zip'; digest=hashlib.sha256(bundle.read_bytes()).hexdigest()
                with self.assertRaises(ValueError): bootstrap(work,runtime,digest,bundle.stat().st_size)

    def test_rejects_wrong_repository_or_pending_approval(self):
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ,GITHUB_REPOSITORY='origest/other'):
            root=Path(temp); work=root/'checkout'; work.mkdir(); runtime=root/'temp'; runtime.mkdir()
            digest,size=self.bundle(work)
            with self.assertRaises(ValueError): bootstrap(work,runtime,digest,size)

    def test_workflow_embeds_identical_audited_bootstrap(self):
        root=Path(__file__).resolve().parents[1]
        workflow=(root/'.github/workflows/isolated-ui.yml').read_text()
        embedded=workflow.split('          # BOOTSTRAP_BEGIN\n',1)[1].split('          # BOOTSTRAP_END\n',1)[0]
        self.assertEqual('\n'.join(line[10:] for line in embedded.splitlines())+'\n',(root/'scripts/bootstrap.py').read_text())


if __name__=='__main__': unittest.main()
