import ast
import contextlib
import copy
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import public_evidence as p
import kvm_access as k
import run_ui as run
from owned_runtime import RuntimeFailure


def restored(reason='NONE'):
    return {'changed_permissions':True,'restore_verified':True,'state':'original_acl_verified',
            'diagnostic':{'phase':'complete' if reason=='NONE' else 'receipt_commit','reason':reason,
                'write_attempted':True,'acl_readback':'original',
                'receipt':'committed' if reason=='NONE' else 'failed'}}


def acl_mismatch():
    before={'user:':'rw-','group:':'rw-','other:':'---'}
    after=k.expected_after(before,123456789)
    return {'changed_permissions':True,'restore_verified':False,'state':'restore_failed',
            'diagnostic':{'phase':'acl_compare','reason':'KVM_ACL_CHANGED_EXTERNALLY',
                'write_attempted':False,'acl_readback':'unexpected','receipt':'pending',
                'acl_difference':k.acl_difference({**after,'group:987654321':'r--'},before,after,123456789)}}


class DiagnosticEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.location=patch.object(p,'DIRECTORY',self.root/'evidence');self.location.start()
        self.env=patch.dict(os.environ,{'GITHUB_RUN_ID':'1','GITHUB_RUN_ATTEMPT':'1',
            'GITHUB_SHA':'a'*40,'GITHUB_REPOSITORY':'origest/test','GITHUB_STEP_SUMMARY':str(self.root/'summary')})
        self.env.start();p.init()
        self.failure={'status':'blocked-or-failed','stage':'instrumentation','code':'TimeoutExpired','new_build':True}
    def tearDown(self):self.env.stop();self.location.stop();self.temp.cleanup()

    def test_restore_diagnostics_do_not_replace_primary_failure(self):
        p.write('summary.json',self.failure)
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertTrue(p.record_restore_attempt('main',restored('RECEIPT_WRITE_FAILED')))
            self.assertTrue(p.record_restore_attempt('always',restored()))
            p.publish()
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json'),self.failure)
        cleanup=p.read_json(p.DIRECTORY/'cleanup.json')
        self.assertFalse(p.cleanup_succeeded(cleanup))
        self.assertEqual(cleanup['kvm_attempts']['main']['diagnostic']['reason'],'RECEIPT_WRITE_FAILED')

    def test_evidence_failure_does_not_misclassify_verified_acl(self):
        original=p.write
        def fail_kvm(name,data):
            if name=='kvm.json':raise OSError('PRIVATE_SECRET_PATH')
            return original(name,data)
        with patch.object(p,'write',side_effect=fail_kvm),contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertFalse(p.record_restore_attempt('main',restored()))
        cleanup=p.read_json(p.DIRECTORY/'cleanup.json')
        self.assertTrue(cleanup['kvm_attempts']['main']['restore_verified'])
        self.assertEqual(cleanup['evidence_errors'],[{'source':'main','target':'kvm','reason':'EVIDENCE_RECORD_FAILED'}])
        self.assertNotIn('PRIVATE_SECRET_PATH',out.getvalue())

    def test_evidence_update_failure_preserves_first_failure(self):
        p.write('summary.json',self.failure)
        with patch.object(p.os,'replace',side_effect=OSError('PRIVATE')):
            with self.assertRaises(OSError):p.write('summary.json',{'invalid':'value'})
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json'),self.failure)
        self.assertFalse(list(self.root.glob('.evidence-update-*')))

    def test_unknown_diagnostic_fields_and_false_readback_are_rejected(self):
        changes=[lambda d:d['diagnostic'].update(reason='PRIVATE'),
                 lambda d:d['diagnostic'].update(phase='PRIVATE'),
                 lambda d:d['diagnostic'].update(raw='PRIVATE'),
                 lambda d:d['diagnostic'].update(acl_readback='lease'),
                 lambda d:d['diagnostic'].update(write_attempted=1)]
        for change in changes:
            data=restored();change(data)
            with self.assertRaises(ValueError):p.checked_json('kvm.json',data)

    def test_acl_difference_is_strictly_fixed_boolean_schema(self):
        changes=[
            lambda d:d['diagnostic']['acl_difference'].update(raw='PRIVATE'),
            lambda d:d['diagnostic']['acl_difference'].pop('from_original'),
            lambda d:d['diagnostic']['acl_difference'].update(from_lease=[]),
            lambda d:d['diagnostic']['acl_difference']['from_original'].update(raw='PRIVATE'),
            lambda d:d['diagnostic']['acl_difference']['from_lease'].pop('mask_changed'),
        ]
        for value in (1,0,'true','PRIVATE',None,[],{}):
            changes.append(lambda d,value=value:d['diagnostic']['acl_difference']['from_lease'].update(mask_changed=value))
        for reference in ('from_original','from_lease'):
            changes.append(lambda d,reference=reference:d['diagnostic']['acl_difference'].update(
                {reference:{key:False for key in k.ACL_DIFFERENCE_FIELDS}}))
        for change in changes:
            with self.subTest(change=change):
                data=acl_mismatch();change(data)
                with self.assertRaises(ValueError):p.checked_json('kvm.json',data)

    def test_acl_difference_rejects_wrong_phase_reason_or_success_state(self):
        changes=[lambda d:d['diagnostic'].update(phase='restore_readback'),
                 lambda d:d['diagnostic'].update(reason='NONE'),
                 lambda d:d['diagnostic'].update(write_attempted=True),
                 lambda d:d['diagnostic'].update(acl_readback='original'),
                 lambda d:d['diagnostic'].update(receipt='committed'),
                 lambda d:d.update(state='original_acl_verified',restore_verified=True),
                 lambda d:d.update(changed_permissions=False)]
        for change in changes:
            data=acl_mismatch();change(data)
            with self.assertRaises(ValueError):p.checked_json('kvm.json',data)

    def test_acl_difference_publishes_only_categories_and_preserves_timeout(self):
        p.write('summary.json',self.failure)
        with contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertTrue(p.record_restore_attempt('main',acl_mismatch()))
            self.assertTrue(p.record_restore_attempt('always',acl_mismatch()))
            p.publish()
        cleanup=p.read_json(p.DIRECTORY/'cleanup.json')
        self.assertEqual(cleanup['kvm_attempts'],{'main':acl_mismatch(),'always':acl_mismatch()})
        self.assertFalse(p.cleanup_succeeded(cleanup))
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json'),self.failure)
        for secret in ('123456789','987654321','rw-','r--','/dev/kvm'):
            self.assertNotIn(secret,out.getvalue())
        self.assertIn('other_named_entries_changed',out.getvalue())

    def test_invalid_acl_difference_never_reaches_public_console_or_cleanup(self):
        data=acl_mismatch();data['diagnostic']['acl_difference']['from_lease']['raw']='PRIVATE'
        with contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertFalse(p.record_restore_attempt('main',data))
        self.assertNotIn('PRIVATE',out.getvalue())
        self.assertIsNone(p.read_json(p.DIRECTORY/'cleanup.json')['kvm_attempts']['main'])

    def test_new_category_evidence_loss_cannot_replace_primary_timeout(self):
        original=p.write
        def fail_new_diagnostics(name,data):
            if name in ('cleanup.json','kvm.json'):raise OSError('PRIVATE_RECORD_FAILURE')
            return original(name,data)
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':self.root,
            'ACTIVE_IDENTITY':{'test':'fake'},'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=subprocess.TimeoutExpired(['PRIVATE'],600)),\
             patch.object(run,'restore_outcome',return_value=acl_mismatch()),\
             patch.object(p,'write',side_effect=fail_new_diagnostics),contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.entrypoint(),1)
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json'),self.failure)
        self.assertNotIn('PRIVATE',out.getvalue())
        self.assertIn('EVIDENCE_RECORD_FAILED',out.getvalue())

    def test_previous_fixed_diagnostic_remains_compatible(self):
        old=acl_mismatch();old['diagnostic'].pop('acl_difference')
        self.assertEqual(p.checked_json('kvm.json',old),old)
        self.assertFalse(k.restore_succeeded(old))

    def test_complete_partial_cannot_contain_unknown_or_multiple_started(self):
        expected=json.loads((p.ROOT/'expected-tests.json').read_text())
        base={'protocol_state':'incomplete','cases':[{**x,'state':'unknown','execution_ordinal':None,
            'failure_hint':'NOT_APPLICABLE','failure_phase':'NOT_APPLICABLE',
            'failure_wait':'NOT_APPLICABLE'} for x in expected]}
        p.checked_json('instrumentation.json',base)
        invalid=copy.deepcopy(base);invalid['protocol_state']='complete'
        with self.assertRaises(ValueError):p.checked_json('instrumentation.json',invalid)
        invalid=copy.deepcopy(base)
        for ordinal,case in enumerate(invalid['cases'][:2],1):
            case['state']='started';case['execution_ordinal']=ordinal
        with self.assertRaises(ValueError):p.checked_json('instrumentation.json',invalid)
        invalid=copy.deepcopy(base);invalid['cases'][0]['method']='PRIVATE'
        with self.assertRaises(ValueError):p.checked_json('instrumentation.json',invalid)

    def test_preflight_failure_code_is_publishable_without_private_text(self):
        failure=dict(self.failure,stage='preflight',code=RuntimeFailure('CHILD_ENUMERATION_FAILED').code)
        p.write('summary.json',failure)
        with contextlib.redirect_stdout(io.StringIO()) as out:p.publish()
        self.assertIn('RUNTIME_CHILD_ENUMERATION_FAILED',out.getvalue())

    def test_missing_restore_attempts_cannot_publish_pass(self):
        p.write('summary.json',{'status':'passed','tests':19,'failures':0,'errors':0,
            'skipped':0,'device_api':33,'device_abi':'x86_64','new_build':True})
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()):p.publish()

    def test_duplicate_attempt_fails_closed_without_overwriting(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertTrue(p.record_restore_attempt('main',restored()))
            self.assertFalse(p.record_restore_attempt('main',restored('RECEIPT_WRITE_FAILED')))
        self.assertEqual(p.read_json(p.DIRECTORY/'cleanup.json')['kvm_attempts']['main'],restored())

    def test_entrypoint_keeps_timeout_when_cleanup_and_evidence_fail(self):
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':self.root,
            'ACTIVE_IDENTITY':{'test':'fake'},'PROCESS_CLEANUP_OK':False,'EVIDENCE_OK':False,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=subprocess.TimeoutExpired(['PRIVATE'],600)),\
             patch.object(run,'restore_outcome',return_value=restored('RECEIPT_WRITE_FAILED')),\
             contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.entrypoint(),1)
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json'),self.failure)
        self.assertNotIn('PRIVATE',out.getvalue())

    def test_entrypoint_does_not_call_verified_receipt_failure_restore_failed(self):
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':self.root,
            'ACTIVE_IDENTITY':{'test':'fake'},'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main'),\
             patch.object(run,'restore_outcome',return_value=restored('RECEIPT_WRITE_FAILED')),\
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(run.entrypoint(),1)
        self.assertTrue(p.read_json(p.DIRECTORY/'kvm.json')['restore_verified'])
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],'CLEANUP_FAILED')

    def test_cleanup_exception_and_record_exception_never_mask_first_timeout(self):
        class Broken:
            def close(self): raise OSError('PRIVATE_CLOSE')
        def primary():
            try: raise subprocess.TimeoutExpired(['PRIVATE'],600)
            finally: run.close_runtime(Broken())
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':self.root,
            'ACTIVE_IDENTITY':{'test':'fake'},'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=primary),\
             patch.object(run,'restore_outcome',return_value=restored()),\
             patch.object(p,'record_runtime',side_effect=ValueError('PRIVATE_RECORD')),\
             contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.entrypoint(),1)
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json'),self.failure)
        self.assertNotIn('PRIVATE',out.getvalue())

    def test_arbitrary_exception_name_or_message_is_not_published(self):
        class PRIVATE_EXCEPTION(Exception):pass
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,
                 'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        for error in (PRIVATE_EXCEPTION('PRIVATE_MESSAGE'),run.Blocked('PRIVATE_CODE')):
            with patch.multiple(run,**patches),patch.object(run,'main',side_effect=error),\
                 contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(run.entrypoint(),1)
            self.assertNotIn('PRIVATE',out.getvalue())
            self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],'UNEXPECTED_FAILURE')

    def test_always_entry_missing_environment_never_calls_acl_or_leaks(self):
        with patch.dict(os.environ,{},clear=True),patch.object(k,'restore_outcome') as restore,\
             contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(k.always_entrypoint(),1)
        restore.assert_not_called()
        self.assertIn('RESTORE_ENTRY_FAILED',out.getvalue())
        self.assertNotIn('Traceback',out.getvalue())

    def test_always_record_exception_is_fixed_and_never_calls_acl(self):
        with patch.dict(os.environ,RUNNER_TEMP=str(self.root)),\
             patch.object(k,'restore_outcome') as restore,\
             patch.object(p,'record_restore_attempt',side_effect=OSError('PRIVATE_PATH')),\
             contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(k.always_entrypoint(),1)
        restore.assert_not_called()
        self.assertIn('RESTORE_ENTRY_FAILED',out.getvalue())
        self.assertNotIn('PRIVATE',out.getvalue());self.assertNotIn('Traceback',out.getvalue())

    def test_preflight_before_grant_and_original_timeouts_unchanged(self):
        source=Path(run.__file__).read_text();tree=ast.parse(source)
        main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
        calls=[n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
        line=lambda name:min(n.lineno for n in calls if n.func.id==name)
        self.assertLess(line('preflight'),line('ensure_access'))
        for text in ('timeout=600','time.monotonic()+240','time.monotonic()+900'):
            self.assertIn(text,source)
        for forbidden in ('killpg(','.terminate(',"'start-server'","'kill-server'",'pkill','killall'):
            self.assertNotIn(forbidden,source)
        self.assertIn("'-H','127.0.0.1','-P'",source)
        self.assertIn("env['ANDROID_ADB_SERVER_PORT']=str(server_port)",source)


if __name__=='__main__':unittest.main()
