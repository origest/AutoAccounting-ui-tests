import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from safe_scratch import create
from kvm_access import ensure_access,restore_access,parse_acl,KvmError,LEASE,expected_after,write_lease,load_lease


class FakeSystem:
    def __init__(self,acl):
        self.values=copy.deepcopy(acl); self.calls=[]; self.race=False
    def identity(self): return {'device':1,'inode':2,'rdev':3,'uid':0,'gid':109}
    def acl(self): return self.values.copy()
    def writable(self): return self.values.get('user:'+str(os.getuid()))=='rw-'
    def grant(self,uid):
        self.calls.append('grant'); self.values=expected_after(self.values,uid); return 0
    def restore(self,before,uid):
        self.calls.append('restore')
        if self.race: self.values['user:87654']='r--'
        key='user:'+str(uid)
        if key in before: self.values[key]=before[key]
        else: self.values.pop(key,None)
        if 'mask:' not in before:
            self.values.pop('mask:',None)
            if any(k.startswith('user:') and k!='user:' for k in self.values): self.values['mask:']=self.values['group:']
        return 0


class KvmTests(unittest.TestCase):
    def basic(self): return {'user:':'rw-','group:':'rw-','other:':'---'}
    def test_original_no_mask_is_restored_without_added_mask(self):
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
            ensure_access(root,{'run':'one'},system=system)
            self.assertIn('mask:',system.values)
            status=restore_access(root,{'run':'one'},system=system)
            self.assertTrue(status['restore_verified']); self.assertEqual(system.values,self.basic())

    def test_preserves_existing_named_uid_and_other_entries(self):
        with tempfile.TemporaryDirectory() as temp:
            before={**self.basic(),'mask:':'rw-','user:'+str(os.getuid()):'r--','group:54321':'rw-'}
            root=create(temp,{'run':'one'}); system=FakeSystem(before)
            ensure_access(root,{'run':'one'},system=system)
            restore_access(root,{'run':'one'},system=system)
            self.assertEqual(system.values,before)

    def test_rejects_external_change_without_restore_write(self):
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
            ensure_access(root,{'run':'one'},system=system)
            system.values['group:54321']='r--'
            with self.assertRaises(KvmError): restore_access(root,{'run':'one'},system=system)
            self.assertEqual(system.calls,['grant'])

    def test_concurrent_unrelated_change_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
            ensure_access(root,{'run':'one'},system=system); system.race=True
            with self.assertRaises(KvmError): restore_access(root,{'run':'one'},system=system)
            self.assertEqual(system.values['user:87654'],'r--')

    def test_rejects_forged_before_that_expands_other_user(self):
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
            ensure_access(root,{'run':'one'},system=system)
            data=json.loads((root/LEASE).read_text()); data['before']['other:']='rw-'
            (root/LEASE).write_text(json.dumps(data))
            with self.assertRaises(KvmError): restore_access(root,{'run':'one'},system=system)
            self.assertEqual(system.calls,['grant'])

    def test_rejects_missing_or_dangling_lease(self):
        for dangling in (False,True):
            with self.subTest(dangling=dangling),tempfile.TemporaryDirectory() as temp:
                root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
                ensure_access(root,{'run':'one'},system=system); (root/LEASE).unlink()
                if dangling: (root/LEASE).symlink_to(root/'missing')
                with self.assertRaises(KvmError): restore_access(root,{'run':'one'},system=system)

    def test_rejects_mask_expansion_and_duplicate_acl(self):
        with self.assertRaises(KvmError): expected_after({**self.basic(),'mask:':'r--'},1001)
        with self.assertRaises(KvmError): parse_acl('user::rw-\nuser::rw-\ngroup::rw-\nother::---\n')

    def test_rejects_root_without_any_write(self):
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
            with self.assertRaises(KvmError): ensure_access(root,{'run':'one'},system=system,uid=0)
            self.assertFalse(system.calls)

    def test_atomic_update_failure_keeps_previous_receipt_and_can_restore(self):
        for failure in ('json.dump','os.fsync','os.replace'):
            with self.subTest(failure=failure),tempfile.TemporaryDirectory() as temp:
                root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
                ensure_access(root,{'run':'one'},system=system)
                original=(root/LEASE).read_bytes(); data=load_lease(root,{'run':'one'})
                data['restored']=True
                with patch('kvm_access.'+failure,side_effect=OSError('simulated interruption')):
                    with self.assertRaises(OSError): write_lease(root/LEASE,data)
                self.assertEqual((root/LEASE).read_bytes(),original)
                self.assertEqual(list(root.glob('.kvm-lease-update-*')),[])
                self.assertTrue(restore_access(root,{'run':'one'},system=system)['restore_verified'])

    def test_failed_post_grant_receipt_update_still_restores(self):
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'one'}); system=FakeSystem(self.basic())
            with patch('kvm_access.os.replace',side_effect=OSError('simulated disk full')):
                with self.assertRaises(OSError): ensure_access(root,{'run':'one'},system=system)
            self.assertFalse(load_lease(root,{'run':'one'})['applied'])
            self.assertTrue(restore_access(root,{'run':'one'},system=system)['restore_verified'])


if __name__=='__main__': unittest.main()
