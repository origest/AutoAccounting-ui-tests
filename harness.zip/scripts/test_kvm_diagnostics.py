import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import kvm_access as k
from safe_scratch import create
from test_kvm_access import FakeSystem


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.identity={'run':'fake-only'}
        self.root=create(self.tmp.name,self.identity)
        self.original={'user:':'rw-','group:':'rw-','other:':'---'}
        self.system=FakeSystem(self.original)
        self.guard=patch('kvm_access.subprocess.run',side_effect=AssertionError('Real system operation forbidden'))
        self.guard.start()
        k.ensure_access(self.root,self.identity,system=self.system)
    def tearDown(self): self.guard.stop();self.tmp.cleanup()
    def outcome(self): return k.restore_outcome(self.root,self.identity,system=self.system)
    def mutate_receipt(self,change):
        data=json.loads((self.root/k.LEASE).read_text());change(data)
        (self.root/k.LEASE).write_text(json.dumps(data))

    def test_original_readback_and_receipt_committed(self):
        result=self.outcome()
        self.assertTrue(result['restore_verified']);self.assertTrue(k.restore_succeeded(result))
        self.assertEqual(result['diagnostic'],{'phase':'complete','reason':'NONE',
            'write_attempted':True,'acl_readback':'original','receipt':'committed'})
        again=self.outcome()
        self.assertFalse(again['diagnostic']['write_attempted'])
        self.assertTrue(again['restore_verified'])
        self.assertEqual(self.system.calls,['grant','restore'])

    def test_unknown_acl_has_no_restore_write(self):
        self.system.values['group:54321']='r--'
        result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_ACL_CHANGED_EXTERNALLY')
        self.assertEqual(result['diagnostic']['phase'],'acl_compare')
        self.assertFalse(result['restore_verified']);self.assertEqual(self.system.calls,['grant'])

    def test_identity_change_after_acl_read_cannot_be_verified(self):
        identity=self.system.identity()
        with patch.object(self.system,'identity',side_effect=[identity,{**identity,'inode':999}]):
            result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_DEVICE_CHANGED')
        self.assertFalse(result['restore_verified']);self.assertEqual(self.system.calls,['grant'])

    def test_receipt_failure_does_not_erase_reliable_acl_readback(self):
        original=k.load_lease(self.root,self.identity)
        with patch('kvm_access.write_lease',side_effect=OSError('PRIVATE_PATH_SECRET')):
            result=self.outcome()
        self.assertTrue(result['restore_verified'])
        self.assertEqual(result['state'],'original_acl_verified')
        self.assertEqual(result['diagnostic']['receipt'],'failed')
        self.assertEqual(result['diagnostic']['reason'],'RECEIPT_WRITE_FAILED')
        self.assertFalse(k.restore_succeeded(result))
        self.assertEqual(k.load_lease(self.root,self.identity),original)
        self.assertNotIn('PRIVATE_PATH_SECRET',json.dumps(result))
        self.assertTrue(k.restore_succeeded(self.outcome()))

    def test_failed_command_and_original_readback_remain_distinct(self):
        restore=self.system.restore
        def fail_after_restore(*args): restore(*args);return 1
        with patch.object(self.system,'restore',side_effect=fail_after_restore): result=self.outcome()
        self.assertTrue(result['restore_verified'])
        self.assertEqual(result['diagnostic']['reason'],'KVM_RESTORE_COMMAND_FAILED')
        self.assertFalse(k.restore_succeeded(result))
        self.assertTrue(k.restore_succeeded(self.outcome()))

    def test_timeout_does_not_infer_acl_state(self):
        with patch.object(self.system,'restore',side_effect=subprocess.TimeoutExpired(['SECRET'],10,output=b'SECRET')):
            result=self.outcome()
        self.assertFalse(result['restore_verified'])
        self.assertEqual(result['diagnostic']['reason'],'KVM_RESTORE_COMMAND_TIMEOUT')
        self.assertNotIn('SECRET',json.dumps(result))

    def test_invalid_lease_schema_types_and_extra_fields_fail_closed(self):
        original=(self.root/k.LEASE).read_bytes()
        changes=[lambda d:d.update(applied='false'),lambda d:d.update(restored=1),
            lambda d:d.update(schema=True),lambda d:d.update(runner_uid=True),
            lambda d:d.update(extra='PRIVATE'),lambda d:d['device'].update(inode=True),
            lambda d:d['device'].update(extra=1),lambda d:d.update(before=[])]
        for change in changes:
            with self.subTest(change=change):
                (self.root/k.LEASE).write_bytes(original);self.mutate_receipt(change)
                result=self.outcome()
                self.assertFalse(result['restore_verified'])
                self.assertEqual(result['diagnostic']['reason'],'KVM_LEASE_INVALID')
                self.assertEqual(self.system.calls,['grant'])

    def test_duplicate_lease_json_keys_fail_closed(self):
        raw=(self.root/k.LEASE).read_text()
        (self.root/k.LEASE).write_text(raw[:-1]+',"applied":false}')
        result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_LEASE_INVALID')
        self.assertEqual(self.system.calls,['grant'])

    def test_required_receipt_scope_and_link_fail_closed(self):
        required=self.root/k.REQUIRED
        required.write_text(json.dumps({'identity':{'run':'other'},'runner_uid':os.getuid()}))
        self.assertEqual(self.outcome()['diagnostic']['reason'],'KVM_LEASE_SCOPE')
        required.unlink();required.symlink_to(self.root/'missing')
        self.assertFalse(self.outcome()['restore_verified'])
        self.assertEqual(self.system.calls,['grant'])

    def test_acl_read_error_is_fixed_and_preserves_no_write(self):
        with patch.object(self.system,'acl',side_effect=OSError('PRIVATE_UID_ACL')): result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'ACL_IO_FAILED')
        self.assertEqual(result['diagnostic']['phase'],'acl_read')
        self.assertEqual(self.system.calls,['grant']);self.assertNotIn('PRIVATE',json.dumps(result))

    def test_missing_lease_is_not_not_needed(self):
        (self.root/k.LEASE).unlink()
        result=self.outcome()
        self.assertTrue(result['changed_permissions']);self.assertFalse(result['restore_verified'])
        self.assertEqual(result['diagnostic']['reason'],'KVM_LEASE_MISSING')

    def test_real_restore_argv_is_only_mocked_and_minimal(self):
        from types import SimpleNamespace
        with patch('kvm_access.subprocess.run',return_value=SimpleNamespace(returncode=0)) as run:
            k.System().restore(self.original,os.getuid())
            self.assertEqual(run.call_args.args[0],['/usr/bin/sudo','-n','/usr/bin/setfacl',
                '--no-mask','-x','u:'+str(os.getuid())+',m','/dev/kvm'])


if __name__=='__main__':unittest.main()
