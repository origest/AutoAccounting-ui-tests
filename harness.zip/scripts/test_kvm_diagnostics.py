import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import kvm_access as k
from safe_scratch import create
from test_kvm_access import FakeSystem


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.identity={'run':'fake-only'}
        self.root=create(self.tmp.name,self.identity)
        self.original={'user:':'rw-','group:':'rw-','other:':'---'}
        self.system=FakeSystem(self.original)
        self.guard=patch('kvm_access.subprocess.run',side_effect=AssertionError('Real system operation forbidden'))
        self.guard.start()
        k.ensure_access(self.root,self.identity,system=self.system)
    def tearDown(self): self.guard.stop();self.tmp.cleanup()
    def outcome(self): return k.restore_outcome(self.root,self.identity,system=self.system)
    def mutate_receipt(self,change):
        data=json.loads((self.root/k.LEASE).read_text());change(data)
        (self.root/k.LEASE).write_text(json.dumps(data))

    def test_original_readback_and_receipt_committed(self):
        result=self.outcome()
        self.assertTrue(result['restore_verified']);self.assertTrue(k.restore_succeeded(result))
        self.assertEqual(result['diagnostic'],{'phase':'complete','reason':'NONE',
            'write_attempted':True,'acl_readback':'original','receipt':'committed'})
        again=self.outcome()
        self.assertFalse(again['diagnostic']['write_attempted'])
        self.assertTrue(again['restore_verified'])
        self.assertEqual(self.system.calls,['grant','restore'])

    def test_unknown_acl_has_no_restore_write(self):
        self.system.values['group:54321']='r--'
        result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_ACL_CHANGED_EXTERNALLY')
        self.assertEqual(result['diagnostic']['phase'],'acl_compare')
        self.assertFalse(result['restore_verified']);self.assertEqual(self.system.calls,['grant'])

    def test_each_unexpected_acl_category_is_bounded_and_never_written(self):
        import public_evidence as p
        lease=self.system.values.copy()
        mutations={
            'owner_permissions_changed':lambda d:d.update({'user:':'r--'}),
            'owning_group_permissions_changed':lambda d:d.update({'group:':'r--'}),
            'other_permissions_changed':lambda d:d.update({'other:':'r--'}),
            'mask_changed':lambda d:d.update({'mask:':'r--'}),
            'current_uid_entry_changed':lambda d:d.update({'user:'+str(os.getuid()):'r--'}),
            'other_named_entries_changed':lambda d:d.update({'group:54321':'r--'}),
        }
        for category,mutate in mutations.items():
            with self.subTest(category=category):
                self.system.values=lease.copy();mutate(self.system.values)
                unchanged=self.system.values.copy();result=self.outcome()
                p.checked_json('kvm.json',result)
                difference=result['diagnostic']['acl_difference']
                self.assertEqual(set(difference),{'from_original','from_lease'})
                self.assertEqual(difference['from_lease'],{key:key==category for key in k.ACL_DIFFERENCE_FIELDS})
                self.assertTrue(difference['from_original'][category])
                self.assertFalse(result['restore_verified']);self.assertFalse(k.restore_succeeded(result))
                self.assertFalse(result['diagnostic']['write_attempted'])
                self.assertEqual(self.system.values,unchanged);self.assertEqual(self.system.calls,['grant'])

    def test_acl_difference_pure_function_covers_added_removed_and_modified_named_entries(self):
        uid=123456789
        before={**self.original,'mask:':'rw-','user:'+str(uid):'r--',
                'user:876543210':'r--','group:987654321':'rw-'}
        after=k.expected_after(before,uid)
        for key in ('user:876543210','group:987654321'):
            for operation in ('remove','modify'):
                with self.subTest(key=key,operation=operation):
                    current=after.copy()
                    if operation=='remove':current.pop(key)
                    else:current[key]='---'
                    result=k.acl_difference(current,before,after,uid)
                    self.assertTrue(result['from_lease']['other_named_entries_changed'])
                    self.assertFalse(result['from_lease']['current_uid_entry_changed'])
        for key in ('user:765432109','group:654321098'):
            current={**after,key:'r--'}
            result=k.acl_difference(current,before,after,uid)
            self.assertTrue(result['from_lease']['other_named_entries_changed'])
            for secret in (str(uid),'876543210','987654321','765432109','654321098','rw-','r--','/dev/kvm'):
                self.assertNotIn(secret,json.dumps(result))

    def test_acl_difference_distinguishes_original_and_lease_without_claiming_unknown(self):
        uid=12345;after=k.expected_after(self.original,uid)
        original=k.acl_difference(self.original,self.original,after,uid)
        lease=k.acl_difference(after,self.original,after,uid)
        self.assertFalse(any(original['from_original'].values()))
        self.assertFalse(any(lease['from_lease'].values()))
        for result,reference in ((original,'from_lease'),(lease,'from_original')):
            self.assertEqual({key for key,value in result[reference].items() if value},
                             {'mask_changed','current_uid_entry_changed'})

    def test_category_projection_covers_every_combination_without_mutating_inputs(self):
        uid=12345;before={**self.original,'mask:':'rw-'};after=k.expected_after(before,uid)
        keys=['user:','group:','other:','mask:','user:'+str(uid),'group:54321']
        for bits in range(64):
            current=after.copy()
            for index,key in enumerate(keys):
                if bits & (1<<index):current[key]='r--'
            saved=copy.deepcopy((current,before,after))
            difference=k.acl_difference(current,before,after,uid)
            self.assertEqual((current,before,after),saved)
            for name,reference in (('from_original',before),('from_lease',after)):
                self.assertEqual(set(difference[name]),k.ACL_DIFFERENCE_FIELDS)
                self.assertTrue(all(type(value) is bool for value in difference[name].values()))
                self.assertEqual(any(difference[name].values()),current!=reference)
            self.assertEqual(sum(difference['from_lease'].values()),bits.bit_count())

    def test_acl_difference_reports_mask_and_current_entry_removals(self):
        uid=os.getuid();after=self.system.values.copy()
        current=after.copy();current.pop('user:'+str(uid))
        self.system.values=current
        result=self.outcome()
        self.assertTrue(result['diagnostic']['acl_difference']['from_lease']['current_uid_entry_changed'])
        # The retained mask differs from the original even after our UID disappears.
        self.assertTrue(result['diagnostic']['acl_difference']['from_original']['mask_changed'])
        self.assertEqual(self.system.calls,['grant'])
        # A minimal valid original ACL has neither a mask nor a named user.
        difference=k.acl_difference(self.original,self.original,after,uid)
        self.assertTrue(difference['from_lease']['mask_changed'])
        self.assertTrue(difference['from_lease']['current_uid_entry_changed'])

    def test_mismatch_uses_existing_acl_read_only_and_keeps_pending_receipt(self):
        self.system.values['other:']='r--'
        receipt=(self.root/k.LEASE).read_bytes()
        with patch.object(self.system,'acl',wraps=self.system.acl) as read,\
             patch.object(self.system,'identity',wraps=self.system.identity) as identity:
            result=self.outcome()
        self.assertEqual(read.call_count,1);self.assertEqual(identity.call_count,2)
        self.assertEqual((self.root/k.LEASE).read_bytes(),receipt)
        self.assertEqual(result['diagnostic']['receipt'],'pending')
        self.assertEqual(self.system.calls,['grant'])

    def test_original_lease_and_no_lease_do_not_emit_mismatch_categories(self):
        result=self.outcome()
        self.assertNotIn('acl_difference',result['diagnostic'])
        result=self.outcome()
        self.assertNotIn('acl_difference',result['diagnostic'])
        with tempfile.TemporaryDirectory() as temp:
            root=create(temp,{'run':'empty'})
            with patch.object(self.system,'acl',side_effect=AssertionError('Unexpected ACL read')):
                result=k.restore_outcome(root,{'run':'empty'},system=self.system)
        self.assertEqual(result['state'],'not_needed')
        self.assertNotIn('acl_difference',result['diagnostic'])

    def test_failed_device_binding_never_emits_acl_categories(self):
        self.system.values['other:']='r--';identity=self.system.identity()
        with patch.object(self.system,'identity',side_effect=[identity,{**identity,'gid':999}]):
            result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_DEVICE_CHANGED')
        self.assertNotIn('acl_difference',result['diagnostic'])
        self.assertEqual(self.system.calls,['grant'])

    def test_invalid_acl_read_never_emits_categories_or_secret_text(self):
        for text,reason in [('PRIVATE_ACL', 'KVM_ACL_INVALID'),
                ('user::rw-\nuser::r--\ngroup::rw-\nother::---\n','KVM_ACL_DUPLICATE'),
                ('user::rw-\nother::---\n','KVM_ACL_INCOMPLETE'),
                ('user::rw-\nuser:1234:rw-\ngroup::rw-\nother::---\n','KVM_ACL_MISSING_MASK')]:
            with self.subTest(reason=reason),patch.object(self.system,'acl',side_effect=lambda:k.parse_acl(text)):
                result=self.outcome()
            self.assertEqual(result['diagnostic']['reason'],reason)
            self.assertEqual(result['diagnostic']['phase'],'acl_read')
            self.assertNotIn('acl_difference',result['diagnostic'])
            self.assertNotIn('PRIVATE',json.dumps(result));self.assertEqual(self.system.calls,['grant'])

    def test_second_refusal_has_independent_categories_without_writing(self):
        self.system.values['other:']='r--';first=self.outcome()
        self.system.values['other:']='---';self.system.values['group:54321']='r--';second=self.outcome()
        self.assertTrue(first['diagnostic']['acl_difference']['from_lease']['other_permissions_changed'])
        self.assertFalse(second['diagnostic']['acl_difference']['from_lease']['other_permissions_changed'])
        self.assertTrue(second['diagnostic']['acl_difference']['from_lease']['other_named_entries_changed'])
        self.assertEqual(self.system.calls,['grant'])

    def test_identity_change_after_acl_read_cannot_be_verified(self):
        identity=self.system.identity()
        with patch.object(self.system,'identity',side_effect=[identity,{**identity,'inode':999}]):
            result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_DEVICE_CHANGED')
        self.assertFalse(result['restore_verified']);self.assertEqual(self.system.calls,['grant'])

    def test_receipt_failure_does_not_erase_reliable_acl_readback(self):
        original=k.load_lease(self.root,self.identity)
        with patch('kvm_access.write_lease',side_effect=OSError('PRIVATE_PATH_SECRET')):
            result=self.outcome()
        self.assertTrue(result['restore_verified'])
        self.assertEqual(result['state'],'original_acl_verified')
        self.assertEqual(result['diagnostic']['receipt'],'failed')
        self.assertEqual(result['diagnostic']['reason'],'RECEIPT_WRITE_FAILED')
        self.assertFalse(k.restore_succeeded(result))
        self.assertEqual(k.load_lease(self.root,self.identity),original)
        self.assertNotIn('PRIVATE_PATH_SECRET',json.dumps(result))
        self.assertTrue(k.restore_succeeded(self.outcome()))

    def test_failed_command_and_original_readback_remain_distinct(self):
        restore=self.system.restore
        def fail_after_restore(*args): restore(*args);return 1
        with patch.object(self.system,'restore',side_effect=fail_after_restore): result=self.outcome()
        self.assertTrue(result['restore_verified'])
        self.assertEqual(result['diagnostic']['reason'],'KVM_RESTORE_COMMAND_FAILED')
        self.assertFalse(k.restore_succeeded(result))
        self.assertTrue(k.restore_succeeded(self.outcome()))

    def test_timeout_does_not_infer_acl_state(self):
        with patch.object(self.system,'restore',side_effect=subprocess.TimeoutExpired(['SECRET'],10,output=b'SECRET')):
            result=self.outcome()
        self.assertFalse(result['restore_verified'])
        self.assertEqual(result['diagnostic']['reason'],'KVM_RESTORE_COMMAND_TIMEOUT')
        self.assertNotIn('SECRET',json.dumps(result))

    def test_invalid_lease_schema_types_and_extra_fields_fail_closed(self):
        original=(self.root/k.LEASE).read_bytes()
        changes=[lambda d:d.update(applied='false'),lambda d:d.update(restored=1),
            lambda d:d.update(schema=True),lambda d:d.update(runner_uid=True),
            lambda d:d.update(extra='PRIVATE'),lambda d:d['device'].update(inode=True),
            lambda d:d['device'].update(extra=1),lambda d:d.update(before=[])]
        for change in changes:
            with self.subTest(change=change):
                (self.root/k.LEASE).write_bytes(original);self.mutate_receipt(change)
                result=self.outcome()
                self.assertFalse(result['restore_verified'])
                self.assertEqual(result['diagnostic']['reason'],'KVM_LEASE_INVALID')
                self.assertEqual(self.system.calls,['grant'])

    def test_duplicate_lease_json_keys_fail_closed(self):
        raw=(self.root/k.LEASE).read_text()
        (self.root/k.LEASE).write_text(raw[:-1]+',"applied":false}')
        result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'KVM_LEASE_INVALID')
        self.assertEqual(self.system.calls,['grant'])

    def test_required_receipt_scope_and_link_fail_closed(self):
        required=self.root/k.REQUIRED
        required.write_text(json.dumps({'identity':{'run':'other'},'runner_uid':os.getuid()}))
        self.assertEqual(self.outcome()['diagnostic']['reason'],'KVM_LEASE_SCOPE')
        required.unlink();required.symlink_to(self.root/'missing')
        self.assertFalse(self.outcome()['restore_verified'])
        self.assertEqual(self.system.calls,['grant'])

    def test_acl_read_error_is_fixed_and_preserves_no_write(self):
        with patch.object(self.system,'acl',side_effect=OSError('PRIVATE_UID_ACL')): result=self.outcome()
        self.assertEqual(result['diagnostic']['reason'],'ACL_IO_FAILED')
        self.assertEqual(result['diagnostic']['phase'],'acl_read')
        self.assertEqual(self.system.calls,['grant']);self.assertNotIn('PRIVATE',json.dumps(result))

    def test_missing_lease_is_not_not_needed(self):
        (self.root/k.LEASE).unlink()
        result=self.outcome()
        self.assertTrue(result['changed_permissions']);self.assertFalse(result['restore_verified'])
        self.assertEqual(result['diagnostic']['reason'],'KVM_LEASE_MISSING')

    def test_real_restore_argv_is_only_mocked_and_minimal(self):
        from types import SimpleNamespace
        with patch('kvm_access.subprocess.run',return_value=SimpleNamespace(returncode=0)) as run:
            k.System().restore(self.original,os.getuid())
            self.assertEqual(run.call_args.args[0],['/usr/bin/sudo','-n','/usr/bin/setfacl',
                '--no-mask','-x','u:'+str(os.getuid())+',m','/dev/kvm'])


if __name__=='__main__':unittest.main()
