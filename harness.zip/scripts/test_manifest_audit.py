import unittest
from manifest_audit import audit_manifest, TARGET, RUNNER, APPLICATION, HOST


def tree(instrumentation=False):
    package=TARGET+'.test' if instrumentation else TARGET
    body=f'''  E: manifest (line=1)
    A: package="{package}"
      E: uses-sdk (line=1)
        A: android:minSdkVersion=29
        A: android:targetSdkVersion=36
      E: application (line=2)
        A: android:debuggable=true
        A: android:allowBackup=false
        A: android:testOnly=true
'''
    if instrumentation:
        body+=f'''      E: instrumentation (line=5)
        A: android:name="{RUNNER}"
        A: android:targetPackage="{TARGET}"
'''
    else:
        body+=f'''        A: android:name="{APPLICATION}"
          E: activity (line=5)
            A: android:name="{HOST}"
            A: android:exported=false
'''
    return body


class ManifestTests(unittest.TestCase):
    def test_accepts_expected_target_and_test(self):
        for kind in (False,True): self.assertEqual(audit_manifest(tree(kind),kind)['requested_permissions'],0)

    def test_accepts_full_android_namespace(self):
        audit_manifest(tree().replace('android:','http://schemas.android.com/apk/res/android:'),False)

    def test_instrumentation_may_omit_test_only(self):
        audit_manifest(tree(True).replace('        A: android:testOnly=true\n',''),True)

    def test_rejects_wrong_sdk(self):
        with self.assertRaises(ValueError): audit_manifest(tree().replace('minSdkVersion=29','minSdkVersion=28'),False)

    def test_rejects_exported_or_missing_flag(self):
        for bad in [tree().replace('exported=false','exported=true'),
                    tree().replace('            A: android:exported=false\n','')]:
            with self.assertRaises(ValueError): audit_manifest(bad,False)

    def test_rejects_alias_and_instrumentation_activity(self):
        for kind,bad in [(False,tree()+'          E: activity-alias (line=7)\n'),
                         (True,tree(True)+'      E: activity (line=7)\n')]:
            with self.subTest(kind=kind), self.assertRaises(ValueError): audit_manifest(bad,kind)

    def test_strings_in_metadata_do_not_prove_instrumentation_identity(self):
        bad=tree(True).replace(f'android:name="{RUNNER}"','android:name="other.Runner"')
        bad+=f'      E: meta-data (line=7)\n        A: android:value="{RUNNER}"\n'
        with self.assertRaises(ValueError): audit_manifest(bad,True)
        with self.assertRaises(ValueError): audit_manifest(tree(True).replace(f'android:targetPackage="{TARGET}"','android:targetPackage="other.app"'),True)

    def test_rejects_permissions_startup_and_missing_test_only(self):
        for tag in ['uses-permission','uses-permission-sdk-23','service','receiver','provider','intent-filter']:
            with self.subTest(tag=tag), self.assertRaises(ValueError):
                audit_manifest(tree()+f'      E: {tag} (line=8)\n',False)
        with self.assertRaises(ValueError): audit_manifest(tree().replace('android:testOnly=true','android:testOnly=false'),False)

    def test_rejects_nested_instrumentation_duplicate_app_and_duplicate_attribute(self):
        for bad in [tree(True).replace('      E: instrumentation','          E: instrumentation'),
                    tree()+'      E: application (line=10)\n',
                    tree()+'            A: android:exported=true\n']:
            with self.assertRaises(ValueError): audit_manifest(bad,'instrumentation' in bad)


if __name__=='__main__': unittest.main()
