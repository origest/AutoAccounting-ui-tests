import ctypes
import errno
import io
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import MagicMock, patch

import owned_runtime as r


class FakeClock:
    def __init__(self): self.now = 0.0
    def __call__(self): return self.now
    def sleep(self, value): self.now += value


class FakeKernel:
    """Only abstract child identities; no real process/syscall is touched."""
    def __init__(self, children=(11,), *, stubborn=False, adopted=()):
        self.live = set(children)
        self.stubborn = stubborn
        self.adopted = set(adopted)
        self.calls = []
        self.bound = {}
        self.next_fd = 100
        self.lost = False
    def children(self): self.calls.append(('children',)); return self.live.copy()
    def bind(self, pid):
        self.calls.append(('bind', pid))
        if self.lost: raise r.OwnedRuntimeError('OWNERSHIP_UNVERIFIED')
        self.next_fd += 1
        self.bound[self.next_fd] = pid
        return self.next_fd
    def signal_child(self, fd, signum):
        pid = self.bound[fd]
        self.calls.append(('signal', fd, signum))
        if not self.stubborn or signum == signal.SIGKILL:
            self.live.discard(pid)
            if self.adopted:
                self.live.update(self.adopted)
                self.adopted.clear()
    def release(self, fd): self.calls.append(('release', fd)); self.bound.pop(fd)
    def reap(self): self.calls.append(('reap',)); return not self.live


class CleanupTests(unittest.TestCase):
    def cleanup(self, kernel, budget=.2):
        clock = FakeClock()
        return r.cleanup_children(kernel, budget=budget, clock=clock, sleep=clock.sleep)
    def test_empty_requires_final_enumeration_and_echild(self):
        kernel = FakeKernel(())
        self.assertEqual(self.cleanup(kernel), r.result('stopped_verified'))
        self.assertEqual(kernel.calls, [('children',), ('reap',), ('children',), ('reap',)])
    def test_owned_child_bound_before_signal_and_released(self):
        kernel = FakeKernel()
        self.assertEqual(self.cleanup(kernel)['state'], 'stopped_verified')
        self.assertEqual(kernel.calls[:4], [('children',), ('bind', 11), ('signal', 101, signal.SIGTERM), ('release', 101)])
    def test_term_ignoring_child_is_killed_within_budget(self):
        kernel = FakeKernel(stubborn=True)
        self.assertEqual(self.cleanup(kernel)['state'], 'stopped_verified')
        self.assertTrue(any(x[0] == 'signal' and x[2] == signal.SIGKILL for x in kernel.calls))
    def test_adopted_setsid_grandchild_is_not_forgotten(self):
        kernel = FakeKernel(adopted=(22,))
        self.assertEqual(self.cleanup(kernel)['state'], 'stopped_verified')
        self.assertEqual([x[1] for x in kernel.calls if x[0] == 'bind'], [11, 22])
    def test_missing_children_is_failure_not_empty(self):
        kernel = FakeKernel()
        kernel.children = MagicMock(side_effect=r.OwnedRuntimeError('CHILD_ENUMERATION_FAILED'))
        self.assertEqual(self.cleanup(kernel), r.result('cleanup_failed', 'CHILD_ENUMERATION_FAILED'))
        self.assertFalse(any(x[0] == 'signal' for x in kernel.calls))
    def test_ownership_loss_never_signals(self):
        kernel = FakeKernel(); kernel.lost = True
        self.assertEqual(self.cleanup(kernel), r.result('cleanup_failed', 'OWNERSHIP_UNVERIFIED'))
        self.assertFalse(any(x[0] == 'signal' for x in kernel.calls))
    def test_empty_enumeration_with_live_child_is_not_success(self):
        kernel = FakeKernel()
        kernel.children = lambda: set()
        self.assertEqual(self.cleanup(kernel), r.result('cleanup_failed', 'CLEANUP_TIMEOUT'))
    def test_failed_kill_is_not_verified(self):
        kernel = FakeKernel()
        kernel.signal_child = MagicMock(side_effect=r.OwnedRuntimeError('CHILD_SIGNAL_FAILED'))
        self.assertEqual(self.cleanup(kernel), r.result('cleanup_failed', 'CHILD_SIGNAL_FAILED'))
        self.assertEqual(kernel.bound, {})
    def test_unexpected_exception_never_leaks_message(self):
        kernel = FakeKernel()
        kernel.children = MagicMock(side_effect=RuntimeError('SECRET_PID_PATH'))
        value = self.cleanup(kernel)
        self.assertEqual(value, r.result('cleanup_failed', 'SUPERVISOR_FAILED'))
        self.assertNotIn('SECRET', json.dumps(value))


class BindingTests(unittest.TestCase):
    def test_open_then_waitid_on_same_fd(self):
        events = []
        with patch.object(r.os, 'pidfd_open', side_effect=lambda pid, flags: events.append(('open', pid)) or 73), \
             patch.object(r.os, 'waitid', side_effect=lambda kind, fd, flags: events.append(('wait', kind, fd)) or None), \
             patch.object(r.signal, 'pidfd_send_signal', side_effect=lambda fd, sig, info, flags: events.append(('signal', fd, sig))), \
             patch.object(r.os, 'close'):
            kernel = r.ChildKernel()
            fd = kernel.bind(101)
            kernel.signal_child(fd, signal.SIGTERM)
        self.assertEqual(events, [('open', 101), ('wait', os.P_PIDFD, 73), ('wait', os.P_PIDFD, 73), ('signal', 73, signal.SIGTERM)])
    def test_reused_pid_is_rejected_as_not_our_child(self):
        with patch.object(r.os, 'pidfd_open', return_value=73), \
             patch.object(r.os, 'waitid', side_effect=ChildProcessError()), \
             patch.object(r.signal, 'pidfd_send_signal') as send, patch.object(r.os, 'close') as close:
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'OWNERSHIP_UNVERIFIED'):
                r.ChildKernel().bind(101)
            send.assert_not_called(); close.assert_called_once_with(73)
    def test_ownership_rechecked_immediately_before_signal(self):
        with patch.object(r.os, 'waitid', side_effect=ChildProcessError()), \
             patch.object(r.signal, 'pidfd_send_signal') as send:
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'OWNERSHIP_UNVERIFIED'):
                r.ChildKernel().signal_child(73, signal.SIGKILL)
            send.assert_not_called()
    def test_disappeared_child_is_not_replaced_by_pid_signal(self):
        with patch.object(r.os, 'pidfd_open', side_effect=ProcessLookupError()), \
             patch.object(r.signal, 'pidfd_send_signal') as send:
            self.assertIsNone(r.ChildKernel().bind(101)); send.assert_not_called()
    def test_reap_requires_echild_not_none(self):
        with patch.object(r.os, 'waitid', return_value=None): self.assertFalse(r.ChildKernel().reap())
        with patch.object(r.os, 'waitid', side_effect=ChildProcessError()): self.assertTrue(r.ChildKernel().reap())
    def test_children_read_is_bounded_and_missing_is_failure(self):
        kernel = r.ChildKernel()
        stream = io.StringIO('11 22')
        with patch.object(Path, 'open', return_value=stream): self.assertEqual(kernel.children(), {11, 22})
        for raw in ('x', '0', '11 ' * 22000, str(os.getpid())):
            with patch.object(Path, 'open', return_value=io.StringIO(raw)):
                with self.assertRaisesRegex(r.OwnedRuntimeError, 'CHILD_ENUMERATION_FAILED'): kernel.children()
        with patch.object(Path, 'open', side_effect=FileNotFoundError()):
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'CHILD_ENUMERATION_FAILED'): kernel.children()
    def test_missing_pidfd_capability_fails_before_probe_or_command(self):
        original = hasattr
        def availability(obj, name):
            return False if obj is r.os and name == 'P_PIDFD' else original(obj, name)
        with patch('builtins.hasattr', side_effect=availability), patch.object(r.subprocess, 'Popen') as spawn:
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'UNSUPPORTED_PLATFORM'):
                r.ChildKernel().prepare()
            spawn.assert_not_called()
    def test_subreaper_denial_fails_before_probe_or_command(self):
        kernel = r.ChildKernel()
        libc = MagicMock(); libc.prctl.return_value = -1
        with patch.object(kernel, 'children', return_value=set()), \
             patch.object(r.ctypes, 'CDLL', return_value=libc), patch.object(r.subprocess, 'Popen') as spawn:
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'UNSUPPORTED_PLATFORM'): kernel.prepare()
            spawn.assert_not_called()

    def test_native_tid_is_used(self):
        with patch.object(r.threading, 'get_native_id', return_value=123):
            self.assertEqual(str(r.ChildKernel().children_path), '/proc/self/task/123/children')


class ClientTests(unittest.TestCase):
    def test_constructor_and_unused_close_launch_nothing(self):
        with patch.object(r.subprocess, 'Popen') as spawn:
            runtime = r.OwnedRuntime()
            self.assertEqual(runtime.close(), r.result('not_started'))
            self.assertEqual(runtime.close(), r.result('not_started'))
            spawn.assert_not_called()
    def test_timeout_never_attaches_raw_output(self):
        runtime = r.OwnedRuntime()
        with patch.object(runtime, '_request', side_effect=r.OwnedRuntimeError('COMMAND_TIMEOUT')):
            with self.assertRaises(subprocess.TimeoutExpired) as caught:
                runtime.run(['private-command'], env={}, timeout=.1)
        self.assertIsNone(caught.exception.output); self.assertIsNone(caught.exception.stderr)
    def test_completed_process_preserves_nonzero_exit_for_caller(self):
        runtime = r.OwnedRuntime()
        with patch.object(runtime, '_request', return_value={'returncode': 17, 'stdout': 'x', 'stderr': 'y'}):
            value = runtime.run(['synthetic'], env={}, timeout=1)
        self.assertEqual((value.returncode, value.stdout, value.stderr), (17, 'x', 'y'))
    def test_adb_server_handle_and_port_are_strict(self):
        runtime = r.OwnedRuntime()
        with patch.object(runtime, '_request', return_value={'handle': 1, 'port': 1234}) as request:
            handle, port = runtime.start_adb_server('/owned/adb', env={}, log='/owned/log')
            self.assertIs(handle._runtime, runtime); self.assertEqual(port, 1234)
            self.assertEqual(request.call_args.args[0], 'start_adb')
        for port in (0, 65536, True, '5037'):
            with patch.object(runtime, '_request', return_value={'handle': 1, 'port': port}):
                with self.assertRaises(r.OwnedRuntimeError):
                    runtime.start_adb_server('/owned/adb', env={}, log='/owned/log')

    def test_foreign_handle_is_never_polled(self):
        one, two = r.OwnedRuntime(), r.OwnedRuntime()
        with patch.object(one, '_request') as request:
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'OWNERSHIP_UNVERIFIED'):
                one.poll(r.ServiceHandle(two, 1))
            request.assert_not_called()
    def test_close_control_loss_is_not_success_and_never_kills_supervisor(self):
        runtime = r.OwnedRuntime(); proc = MagicMock(); runtime._proc = proc
        with patch.object(runtime, '_request', side_effect=OSError('SECRET')):
            self.assertEqual(runtime.close(), r.result('cleanup_failed', 'CONTROL_LOST'))
        proc.kill.assert_not_called(); proc.terminate.assert_not_called()
    def test_control_loss_closes_channel_immediately(self):
        runtime = r.OwnedRuntime(); runtime._channel = MagicMock(); runtime._wire = MagicMock()
        runtime._wire.send.side_effect = r.OwnedRuntimeError('CONTROL_LOST')
        with patch.object(runtime, '_start'):
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'CONTROL_LOST'):
                runtime._request('poll', handle=1)
        runtime._channel.close.assert_called_once()
        self.assertEqual(runtime._cleanup, r.result('cleanup_failed', 'CONTROL_LOST'))

    def test_terminal_error_retains_verified_cleanup(self):
        runtime = r.OwnedRuntime(); runtime._proc = MagicMock(); runtime._terminal = True
        runtime._cleanup = r.result('stopped_verified')
        with patch.object(runtime, '_request') as request:
            self.assertEqual(runtime.close(), r.result('stopped_verified')); request.assert_not_called()
    def test_cleanup_schema_rejects_unknown_and_raw_fields(self):
        for value in ({'state':'stopped_verified','reason':'SECRET'},
                      {'state':'stopped_verified','reason':'NONE','pid':123},
                      {'state':'cleanup_failed','reason':'NONE'},
                      {'state':'not_started','reason':'CONTROL_LOST'}):
            with self.assertRaises(r.OwnedRuntimeError): r.validate_cleanup(value)
    def test_private_log_is_new_owned_regular_output(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); path = root/'private.log'
            with r.private_log(path) as stream: stream.write(b'private')
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            with self.assertRaises(FileExistsError): r.private_log(path)
            (root/'link').symlink_to(root/'missing')
            with self.assertRaises(FileExistsError): r.private_log(root/'link')
    def test_no_group_or_numeric_pid_kill_in_implementation(self):
        source = Path(r.__file__).read_text()
        for text in ('os.kill(', 'os.killpg(', "'pkill'", "'killall'", "Path('/proc').", 'os.listdir(\'/proc'):
            self.assertNotIn(text, source)


class WireTests(unittest.TestCase):
    def test_send_has_deadline_even_with_no_reader(self):
        first, second = socket.socketpair()
        try:
            first.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4096)
            begun = time.monotonic()
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'CONTROL_LOST'):
                r.Wire(first).send({'private': 'x' * (1024 * 1024)}, timeout=.03)
            self.assertLess(time.monotonic() - begun, .5)
        finally:
            first.close(); second.close()
    def test_wire_roundtrip_and_eof(self):
        first, second = socket.socketpair()
        try:
            r.Wire(first).send({'id': 1, 'op': 'close'})
            wire = r.Wire(second)
            self.assertEqual(wire.receive(1), {'id': 1, 'op': 'close'})
            first.close()
            with self.assertRaises(EOFError): wire.receive(1)
        finally:
            first.close(); second.close()


class SupervisorProtocolTests(unittest.TestCase):
    def make_wire(self, requests):
        wire = MagicMock(); wire.receive.side_effect = requests
        return wire
    def run_fake(self, requests, kernel=None):
        kernel = kernel or FakeKernel(())
        kernel.prepare = MagicMock()
        wire = self.make_wire(requests)
        with patch.object(r, 'Wire', return_value=wire), patch.object(r.signal, 'signal'):
            r.supervisor(MagicMock(), kernel=kernel)
        return wire, kernel
    def test_parent_eof_cleans_all_owned_children(self):
        kernel = FakeKernel(adopted=(22,))
        wire, kernel = self.run_fake([EOFError()], kernel)
        self.assertEqual(kernel.live, set())
        self.assertEqual(wire.send.call_args_list[0].args[0], {'ready':True})
    def test_explicit_close_returns_verified_only_after_cleanup(self):
        wire, kernel = self.run_fake([{'id':1,'op':'close'}], FakeKernel())
        self.assertEqual(wire.send.call_args_list[-1].args[0], {'id':1,'cleanup':r.result('stopped_verified')})
        self.assertFalse(kernel.live)
    def test_invalid_protocol_closes_without_new_command(self):
        with patch.object(r.subprocess, 'Popen') as spawn:
            wire, kernel = self.run_fake([{'id':1,'op':'PRIVATE_UNKNOWN'}])
            spawn.assert_not_called()
        final = wire.send.call_args_list[-1].args[0]
        self.assertEqual(final['error'], 'PROTOCOL_INVALID'); self.assertTrue(final['terminal'])
        self.assertNotIn('PRIVATE', json.dumps(final))
    def test_prepare_failure_never_starts_business_process(self):
        kernel = FakeKernel(())
        kernel.prepare = MagicMock(side_effect=r.OwnedRuntimeError('UNSUPPORTED_PLATFORM'))
        wire = MagicMock()
        with patch.object(r, 'Wire', return_value=wire), patch.object(r.signal, 'signal'), \
             patch.object(r.subprocess, 'Popen') as spawn:
            r.supervisor(MagicMock(), kernel=kernel)
        spawn.assert_not_called()
        self.assertEqual(wire.send.call_args.args[0], {'error':'UNSUPPORTED_PLATFORM','cleanup':r.result('not_started')})
    def test_command_timeout_cleans_runtime_and_preserves_timeout_reason(self):
        kernel = FakeKernel()
        proc = MagicMock(); proc.pid = 11; proc.poll.return_value = None
        request = {'id':1,'op':'run','args':['synthetic'],'env':{},'cwd':None,'log':None,'timeout':.1}
        with patch.object(r.subprocess, 'Popen', return_value=proc), \
             patch.object(r.time, 'monotonic', side_effect=[0.0, 1.0]):
            wire, kernel = self.run_fake([request, {'id':2,'op':'close'}], kernel)
        replies = [c.args[0] for c in wire.send.call_args_list]
        self.assertEqual(replies[1], {'id':1,'error':'COMMAND_TIMEOUT','cleanup':r.result('stopped_verified')})
        self.assertFalse(kernel.live)
    def test_service_owned_pid_is_bound_and_polled(self):
        kernel = FakeKernel()
        proc = MagicMock(); proc.pid = 11; proc.poll.return_value = None
        with tempfile.TemporaryDirectory() as temp, patch.object(r.subprocess, 'Popen', return_value=proc):
            request = {'id':1,'op':'start','args':['synthetic'],'env':{},'cwd':None,'log':str(Path(temp)/'log')}
            wire, kernel = self.run_fake([request, {'id':2,'op':'poll','handle':1}, {'id':3,'op':'close'}], kernel)
        replies = [c.args[0] for c in wire.send.call_args_list]
        self.assertEqual(replies[1], {'id':1,'handle':1})
        self.assertEqual(replies[2], {'id':2,'returncode':None})
        self.assertIn(('bind', 11), kernel.calls)
    def test_adb_listener_only_internal_fd_is_passed(self):
        kernel = FakeKernel()
        proc = MagicMock(); proc.pid = 11
        observed = []
        def launch(args, **kwargs):
            fd, = kwargs['pass_fds']
            with socket.fromfd(fd, socket.AF_INET, socket.SOCK_STREAM) as duplicate:
                observed.append((args, duplicate.getsockname(), duplicate.getsockopt(socket.SOL_SOCKET,socket.SO_ACCEPTCONN)))
            return proc
        with tempfile.TemporaryDirectory() as temp, patch.object(r.subprocess, 'Popen', side_effect=launch):
            request = {'id':1,'op':'start_adb','args':['/owned/adb'],'env':{},'cwd':None,'log':str(Path(temp)/'log')}
            wire, kernel = self.run_fake([request, {'id':2,'op':'close'}], kernel)
        reply = wire.send.call_args_list[1].args[0]
        self.assertEqual(observed[0][0][:2], ['/owned/adb','-L'])
        self.assertTrue(observed[0][0][2].startswith('acceptfd:'))
        self.assertEqual(observed[0][0][3:], ['server','nodaemon'])
        self.assertEqual(observed[0][1], ('127.0.0.1', reply['port']))
        self.assertEqual(observed[0][2], 1)

    def test_lost_ownership_on_close_is_not_relabelled_clean(self):
        kernel = FakeKernel(); kernel.lost = True
        wire, _ = self.run_fake([{'id':1,'op':'close'}], kernel)
        self.assertEqual(wire.send.call_args_list[-1].args[0]['cleanup'], r.result('cleanup_failed','OWNERSHIP_UNVERIFIED'))


NATIVE_CHILDREN = Path('/proc/self/task') / str(threading.get_native_id()) / 'children'


class ControlledLinuxTests(unittest.TestCase):
    def test_native_preflight_or_explicit_capability_block(self):
        if NATIVE_CHILDREN.exists():
            self.assertEqual(r.preflight(), r.result('stopped_verified'))
        else:
            with self.assertRaisesRegex(r.OwnedRuntimeError, 'CHILD_ENUMERATION_FAILED'):
                r.preflight()
    @unittest.skipUnless(NATIVE_CHILDREN.exists(), 'Kernel children enumeration unavailable; production tree path not verified here')
    def test_production_runtime_service_command_timeout_and_cleanup(self):
        with tempfile.TemporaryDirectory() as temp:
            runtime = r.OwnedRuntime()
            try:
                service = runtime.start_service([sys.executable,'-c','import time; time.sleep(30)'], env=dict(os.environ), log=Path(temp)/'service.log')
                self.assertIsNone(service.poll())
                result = runtime.run([sys.executable,'-c','print("fixture")'], env=dict(os.environ), timeout=2)
                self.assertEqual(result.stdout.strip(), 'fixture')
                with self.assertRaises(subprocess.TimeoutExpired):
                    runtime.run([sys.executable,'-c','import time; time.sleep(30)'], env=dict(os.environ), timeout=.05)
            finally:
                self.assertEqual(runtime.close(), r.result('stopped_verified'))
    def test_controlled_python_server_inherits_same_bound_listener(self):
        listener, args, fds, port = r.adb_listener('/never-executed-adb')
        proc = None
        try:
            code = ('import socket,sys; s=socket.socket(fileno=int(sys.argv[1])); '
                    'c,a=s.accept(); c.sendall(c.recv(32)); c.close(); s.close()')
            proc = subprocess.Popen([sys.executable, '-B', '-c', code, str(fds[0])],
                                    pass_fds=fds, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            with socket.create_connection(('127.0.0.1', port), timeout=2) as client:
                client.sendall(b'fixture'); self.assertEqual(client.recv(32), b'fixture')
            proc.wait(timeout=2)
            self.assertEqual(proc.returncode, 0)
            with socket.socket() as other:
                with self.assertRaises(OSError): other.bind(('127.0.0.1', port))
        finally:
            if proc is not None and proc.poll() is None:
                kernel = r.ChildKernel(); fd = kernel.bind(proc.pid)
                try: kernel.signal_child(fd, signal.SIGTERM)
                finally: kernel.release(fd)
                proc.wait(timeout=2)
            listener.close()

    def test_real_pidfd_rejects_self_as_not_child(self):
        with self.assertRaisesRegex(r.OwnedRuntimeError, 'OWNERSHIP_UNVERIFIED'):
            r.ChildKernel().bind(os.getpid())
    def test_unrelated_controlled_sibling_is_not_signalled(self):
        outside = subprocess.Popen([sys.executable, '-c', 'import os; os.read(0, 1)'],
                                   stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            code = ('import sys; from owned_runtime import ChildKernel,OwnedRuntimeError; '
                    'k=ChildKernel(); '
                    '\ntry: k.bind(int(sys.argv[1])); raise SystemExit(4)'
                    '\nexcept OwnedRuntimeError as e: print(e.code)')
            done = subprocess.run([sys.executable, '-B', '-c', code, str(outside.pid)],
                                  cwd=Path(r.__file__).parent, capture_output=True, text=True, timeout=3)
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual(done.stdout.strip(), 'RUNTIME_OWNERSHIP_UNVERIFIED')
            self.assertIsNone(outside.poll())
        finally:
            outside.stdin.close(); outside.wait(timeout=2)

    def test_real_owned_direct_child_pidfd_wait_signal_and_reap(self):
        # Run in a disposable helper, so tests never reap anyone else's child.
        code = '''
import sys,subprocess,signal,json
from owned_runtime import ChildKernel
p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(2)'])
k=ChildKernel(); fd=k.bind(p.pid)
try:
 k.signal_child(fd,signal.SIGTERM)
 p.wait(timeout=2)
 print(json.dumps({'terminated':p.returncode == -signal.SIGTERM}))
finally:
 k.release(fd)
'''
        done = subprocess.run([sys.executable,'-B','-c',code], cwd=Path(r.__file__).parent,
                              capture_output=True,text=True,timeout=5)
        self.assertEqual(done.returncode,0,done.stderr)
        self.assertTrue(json.loads(done.stdout)['terminated'])
    def test_real_subreaper_adoption_with_fixture_only_enumeration(self):
        # This tests real pidfd/subreaper semantics, NOT production /proc discovery.
        # The candidate PID list contains only a fixture's self-reported parent and
        # grandchild. waitid(P_PIDFD) rejects any candidate not currently our child.
        with tempfile.TemporaryDirectory() as temp:
            manifest = str(Path(temp)/'grandchild.pid')
            ready = str(Path(temp)/'ready')
            grandchild = ('import os,signal,time; from pathlib import Path; os.setsid(); '
                          'signal.signal(signal.SIGTERM,signal.SIG_IGN); '
                          f'Path({ready!r}).write_text("ready"); time.sleep(5)')
            child = ('import os,sys,signal,subprocess,time; from pathlib import Path; '
                     'signal.signal(signal.SIGTERM,signal.SIG_IGN); '
                     f'p=subprocess.Popen([sys.executable,"-c",{grandchild!r}]); '
                     f'Path({manifest!r}).write_text(str(p.pid)); time.sleep(5)')
            code = f'''
import ctypes,json,os,subprocess,sys,time
from pathlib import Path
from owned_runtime import ChildKernel,cleanup_children
libc=ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,1,0,0,0)==0
p=subprocess.Popen([sys.executable,'-c',{child!r}])
k=ChildKernel()
deadline=time.monotonic()+2
while not Path({ready!r}).exists() and time.monotonic()<deadline: time.sleep(.01)
assert Path({ready!r}).exists()
candidates={{p.pid,int(Path({manifest!r}).read_text())}}
def fixture_children():
 owned=set()
 for pid in candidates:
  fd=None
  try:
   fd=os.pidfd_open(pid,0)
   os.waitid(os.P_PIDFD,fd,os.WEXITED|os.WNOHANG|os.WNOWAIT)
   owned.add(pid)
  except (ProcessLookupError,ChildProcessError): pass
  finally:
   if fd is not None: os.close(fd)
 return owned
k.children=fixture_children
value=cleanup_children(k,budget=.5)
print(json.dumps({{'result':value,'echild':k.reap(),'fixture_enumeration_only':True}}))
'''
            done = subprocess.run([sys.executable,'-B','-c',code], cwd=Path(r.__file__).parent,
                                  capture_output=True,text=True,timeout=5,start_new_session=True)
            self.assertEqual(done.returncode,0,done.stderr)
            value = json.loads(done.stdout)
            self.assertEqual(value['result'], r.result('stopped_verified'))
            self.assertTrue(value['echild'])


if __name__ == '__main__': unittest.main()
