"""Synthetic packets and mock commands only; never invoke adb/logcat or devices."""
import ast
import contextlib
import copy
import io
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch, Mock
import progress_capture as c
import public_evidence as p
import run_ui as run
from progress_parser import empty
from owned_runtime import RuntimeFailure

IDENTITY=c.source_identity(f'package:{c.TARGET} uid:10123','1794270000.123456789')
CLEAN={'state':'stopped_verified','reason':'NONE'}


def packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0', **kwargs):
    payload=kwargs.pop('payload',b'\x04'+c.TAG+b'\0'+message+b'\0')
    fields=dict(size=len(payload),header=28,pid=321,tid=322,sec=1794270000,nsec=123456789,buffer=0,uid=10123)
    fields.update(kwargs)
    return c.HEADER.pack(*fields.values())+payload


def sample():
    return packet()+packet(b'UI_STEP_V1|2|C05|SWIPE_FIRST|BEGIN|3',nsec=126456789)+packet(b'UI_STEP_V1|3|C05|POINTER_UP|BEGIN|9',nsec=132456789)


class ProgressCaptureTests(unittest.TestCase):
    def test_verified_target_uid_not_instrumentation_package(self):
        listing=f'package:android uid:1000\npackage:{c.TARGET} uid:10123\npackage:{c.TARGET}.test uid:10124'
        self.assertEqual(c.source_identity(listing,IDENTITY['since']),IDENTITY)
        for bad in ('',listing+f'\npackage:shared uid:10123',listing+f'\npackage:{c.TARGET} uid:10125',listing.replace('10123','1000'),listing+'\nPRIVATE'):
            with self.assertRaises(ValueError):c.source_identity(bad,IDENTITY['since'])
        for value in ('PRIVATE','1794270000','0.000000000','1794270000.123456789\n','1794270000.12345'):
            with self.assertRaises(ValueError):c.source_identity(listing,value)

    def test_exact_fixed_tag_binary_command_private_existing_endpoint(self):
        args=c.logcat_args('/synthetic/adb',12000,IDENTITY)
        self.assertEqual(args,['/synthetic/adb','-H','127.0.0.1','-P','12000','-s','emulator-5554','exec-out','logcat','-b','main','-B','--uid=10123','-T','1794270000.123456789','IsolatedUiStep:I','*:S'])
        for port in (True,0,65536,'123'):
            with self.assertRaises(ValueError):c.logcat_args('/synthetic/adb',port,IDENTITY)
        with self.assertRaises(ValueError):c.logcat_args('adb',123,IDENTITY)
        wrong=dict(IDENTITY,since_ns=1)
        with self.assertRaises(ValueError):c.logcat_args('/synthetic/adb',123,wrong)

    def test_start_only_uses_existing_runtime_owned_relay(self):
        runtime=Mock()
        c.start(runtime,Path('/synthetic/adb'),12000,IDENTITY,Path('/private/run'),{'X':'Y'})
        args,kw=runtime.start_service.call_args
        self.assertIn('--relay',args[0]); self.assertIn('/private/run/progress-state-private.txt',args[0])
        self.assertEqual(kw['log'],Path('/private/run/progress-private.bin'))
        self.assertEqual(runtime.method_calls[0][0],'start_service')
        self.assertEqual(len(runtime.method_calls),1)

    def test_kernel_bound_sample_returns_fixed_diagnostics_no_raw_identity(self):
        data=c.diagnostic(c.decode(sample(),IDENTITY));c.checked(data)
        self.assertEqual(data['diagnostic_state'],'incomplete')
        self.assertEqual(data['active_case'],'C05')
        self.assertEqual(data['open_steps'],['SWIPE_FIRST','POINTER_UP'])
        for secret in ('10123','321','1794270000','IsolatedUiStep','UI_STEP_V1'):
            self.assertNotIn(secret,json.dumps(data))
        self.assertNotIn('passed',json.dumps(data))

    def test_wrong_kernel_identity_buffer_priority_tag_rejected(self):
        for bad in (packet(uid=10124),packet(pid=0),packet(tid=0),packet(buffer=1),packet(header=24),packet(header=32),
                    packet(payload=b'\x03'+c.TAG+b'\0UI_STEP_V1|1|C05|CASE|BEGIN|0\0'),
                    packet(payload=b'\x04OtherTag\0UI_STEP_V1|1|C05|CASE|BEGIN|0\0'),
                    packet()+packet(b'UI_STEP_V1|2|C05|MAIN|BEGIN|1',pid=456)):
            self.assertEqual(c.decode(bad,IDENTITY),empty())

    def test_old_future_rollback_invalid_timestamp_rejected(self):
        for bad in (packet(nsec=123456788),packet(sec=1794270661),packet(nsec=10**9),
                    packet(nsec=123456790)+packet(b'UI_STEP_V1|2|C05|MAIN|BEGIN|1',nsec=123456789)):
            self.assertEqual(c.decode(bad,IDENTITY),empty())

    def test_truncation_encoding_injection_overflow_rejected(self):
        for bad in (sample()[:-1],sample()+b'\0',b'x'*(c.LIMIT+1),packet(size=161),packet(message=b'\xff'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nPRIVATE'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\0PRIVATE'),
                    packet(payload=b'\x04'+c.TAG+b'\0UI_STEP_V1|1|C05|CASE|BEGIN|0'),
                    packet(b'UI_STEP_V1|2|C05|CASE|BEGIN|0'),sample()+packet()):
            self.assertEqual(c.decode(bad,IDENTITY),empty())
        self.assertEqual(c.decode(b'',IDENTITY),empty('missing'))

    def test_owned_stable_read_and_stop_required(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); raw=root/'progress-private.bin'; state=root/'progress-state-private.txt'
            raw.write_bytes(sample());state.write_bytes(b'stopped\n')
            self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(c.decode(sample(),IDENTITY)))
            for status in (b'starting\n',b'invalid\n',b'stopped\nPRIVATE'):
                state.write_bytes(status);self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(empty()))
            state.write_bytes(b'stopped\n')
            for cleanup in ({'state':'cleanup_failed','reason':'CLEANUP_TIMEOUT'},None,{'state':'stopped_verified','reason':'NONE','extra':1}):
                self.assertEqual(c.finish(root,IDENTITY,cleanup),c.diagnostic(empty()))
            self.assertEqual(c.finish(root,None,CLEAN),c.diagnostic(empty()))
            raw.write_bytes(b'x'*(c.LIMIT+1));self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(empty()))

    def test_links_fifo_wrong_owner_and_replaced_files_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); raw=root/'raw'; raw.write_bytes(b'safe')
            link=root/'link';link.symlink_to(raw)
            with self.assertRaises(OSError):c.stable_bytes(link,100)
            fifo=root/'fifo';os.mkfifo(fifo)
            with self.assertRaises(ValueError):c.stable_bytes(fifo,100)
            hard=root/'hard';os.link(raw,hard)
            with self.assertRaises(ValueError):c.stable_bytes(raw,100)
            hard.unlink()
            with patch.object(c.os,'getuid',return_value=os.getuid()+1):
                with self.assertRaises(ValueError):c.stable_bytes(raw,100)
            original=c.os.read
            def changing(fd,size):
                value=original(fd,size)
                if value:raw.write_bytes(b'changed')
                return value
            with patch.object(c.os,'read',side_effect=changing):
                with self.assertRaises(ValueError):c.stable_bytes(raw,100)

    def test_relay_caps_retained_bytes_and_never_prints_errors(self):
        for overflow,stop,expected in ((False,True,b'stopped\n'),(False,False,b'invalid\n'),(True,True,b'invalid\n')):
            with self.subTest(overflow=overflow,stop=stop),tempfile.TemporaryDirectory() as t:
                saved={};out=bytearray();chunks=iter([sample()*(c.LIMIT//len(sample())+1) if overflow else sample(),b''])
                def read(fd,n):
                    chunk=next(chunks)
                    if not chunk and stop:saved[signal.SIGTERM](signal.SIGTERM,None)
                    return chunk
                def write(fd,chunk):out.extend(chunk);return len(chunk)
                child=Mock();child.stdout.fileno.return_value=42;child.wait.return_value=-15
                with patch.object(c.signal,'signal',side_effect=lambda sig,fn:saved.update({sig:fn})),contextlib.redirect_stdout(io.StringIO()) as stdout,contextlib.redirect_stderr(io.StringIO()) as stderr:
                    code=c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],popen=Mock(return_value=child),read=read,write=write)
                self.assertEqual(code,0);self.assertEqual((Path(t)/'state').read_bytes(),expected)
                self.assertLessEqual(len(out),c.LIMIT);self.assertFalse(stdout.getvalue());self.assertFalse(stderr.getvalue())
                child.wait.assert_called_once_with()

    def test_binary_mixed_tags_filtered_before_disk_including_large_messages(self):
        output=[];filter=c.PacketFilter(IDENTITY,output.append)
        other=packet(payload=b'\x04OtherTargetTag\0'+b'PRIVATE_OTHER_LOG'*100+b'\0')
        later=packet(payload=b'\x04OtherTargetTag\0'+b'PRIVATE_OTHER_LOG'*100+b'\0',nsec=140000000)
        filter.feed(other+sample()+later)
        self.assertTrue(filter.complete())
        self.assertEqual(b''.join(output),sample())
        self.assertNotIn(b'PRIVATE_OTHER_LOG',b''.join(output))

    def test_split_headers_payloads_and_single_byte_chunks(self):
        raw=packet(payload=b'\x04OtherTargetTag\0'+b'PRIVATE_OTHER_LOG'*100+b'\0')+sample()
        for size in (1,2,27,28,29,128,65536):
            output=[];filter=c.PacketFilter(IDENTITY,output.append)
            for pos in range(0,len(raw),size):filter.feed(raw[pos:pos+size])
            self.assertTrue(filter.complete());self.assertEqual(b''.join(output),sample())

    def test_stream_filter_rejects_malformed_identity_restart_truncation(self):
        for raw in (packet(uid=10124),packet(header=24),packet(payload=b'\x04NoDelimiter'),
                    sample()[:-1],sample()+packet(pid=456),packet(size=4097),
                    packet(payload=b'\x03'+c.TAG+b'\0test\0'),
                    sample()+packet(sec=1794269999)):
            output=[];filter=c.PacketFilter(IDENTITY,output.append);filter.feed(raw)
            self.assertFalse(filter.complete())

    def test_fixed_tag_arbitrary_text_never_retained(self):
        for raw in (packet(message=b'PRIVATE_SECRET_STACK'),packet(message=b'UI_STEP_V1|1|C20|CASE|BEGIN|0'),
                    packet(message=b'UI_STEP_V1|1|C05|PRIVATE_SECRET|BEGIN|0'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|600001'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nPRIVATE'),packet(message=b'\xff')):
            output=[];filter=c.PacketFilter(IDENTITY,output.append);filter.feed(raw)
            self.assertFalse(filter.complete());self.assertFalse(output)

    def test_parsing_budget_and_fixed_tag_count_are_bounded(self):
        output=[];filter=c.PacketFilter(IDENTITY,output.append)
        filter.feed(b'x'*(8*1024*1024+1));self.assertFalse(filter.complete());self.assertFalse(output)
        output=[];filter=c.PacketFilter(IDENTITY,output.append)
        for _ in range(8193):filter.feed(packet())
        self.assertFalse(filter.complete());self.assertEqual(len(output),8192)

    def test_relay_start_failure_fixed_and_no_raw_exception(self):
        with tempfile.TemporaryDirectory() as t,patch.object(c.signal,'signal'),contextlib.redirect_stdout(io.StringIO()) as stdout,contextlib.redirect_stderr(io.StringIO()) as stderr:
            code=c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],popen=Mock(side_effect=OSError('PRIVATE_SECRET')))
            self.assertEqual(code,1);self.assertEqual((Path(t)/'state').read_bytes(),b'invalid\n')
            self.assertFalse(stdout.getvalue());self.assertFalse(stderr.getvalue())

    def test_strict_schema_rejects_every_nonfixed_field_and_type(self):
        data=c.diagnostic(c.decode(sample(),IDENTITY))
        changes=[lambda d:d.update(tail_completeness='complete'),lambda d:d.pop('tail_completeness'),lambda d:d.update(raw='PRIVATE'),lambda d:d.update(active_case='PRIVATE'),lambda d:d.update(diagnostic_state='passed'),
                 lambda d:d.update(cases=d['cases'][:-1]),lambda d:d['cases'][0].update(raw='PRIVATE'),
                 lambda d:d['cases'][0].update(case='C20'),lambda d:d['cases'][0].update(end_ms=2),
                 lambda d:d.update(last_event_ms=True),lambda d:d.update(last_event_ms=600001),
                 lambda d:d.update(last_event_ms=-1),lambda d:d.update(open_steps=['MAIN']*2),
                 lambda d:d.update(open_steps=['PRIVATE']),lambda d:d.update(diagnostic_state='observed'),
                 lambda d:d['cases'][4].update(begin_ms=False),lambda d:d.update(diagnostic_state='invalid'),
                 lambda d:d.update(diagnostic_state='missing')]
        for change in changes:
            bad=copy.deepcopy(data);change(bad)
            with self.assertRaises((ValueError,TypeError)):c.checked(bad)
        for state in ('missing','invalid'):self.assertEqual(c.checked(c.diagnostic(empty(state))),c.diagnostic(empty(state)))

    def test_public_case_ranges_cannot_overlap_or_follow_active_case(self):
        base=c.diagnostic(empty('observed'));base['last_event_ms']=10
        base['cases'][0].update(begin_ms=0,end_ms=5)
        base['cases'][1].update(begin_ms=4,end_ms=8)
        with self.assertRaises(ValueError):c.checked(base)
        base['cases'][1].update(begin_ms=5,end_ms=8);c.checked(base)
        base['diagnostic_state']='incomplete';base['active_case']='C01'
        base['cases'][0].update(begin_ms=0,end_ms=None)
        with self.assertRaises(ValueError):c.checked(base)
        # Same-millisecond closed zero-length cases may precede an active case.
        base['cases'][1].update(begin_ms=0,end_ms=0);c.checked(base)

    def test_valid_closed_prefix_never_claims_complete_tail(self):
        raw=packet()+packet(b'UI_STEP_V1|2|C05|CASE|END|1',nsec=124456789)
        data=c.diagnostic(c.decode(raw,IDENTITY));c.checked(data)
        self.assertEqual(data['diagnostic_state'],'observed')
        self.assertEqual(data['tail_completeness'],'unverified')
        # A whole subsequent CASE can be lost with no malformed partial frame.
        full=raw+packet(b'UI_STEP_V1|3|C01|CASE|BEGIN|2',nsec=125456789)+packet(b'UI_STEP_V1|4|C01|CASE|END|3',nsec=126456789)
        full_data=c.diagnostic(c.decode(full,IDENTITY));c.checked(full_data)
        self.assertEqual(full_data['tail_completeness'],'unverified')
        self.assertIsNone(data['cases'][0]['begin_ms'])
        self.assertEqual(full_data['cases'][0]['end_ms'],3)
        self.assertNotIn('passed',str(data))

    def test_wiring_keeps_600_deadline_and_collects_after_verified_close(self):
        source=Path(run.__file__).read_text();tree=ast.parse(source)
        self.assertIn('timeout=600,log=raw',source)
        self.assertIn('if progress_attempted: record_progress(root,progress_identity,cleanup)',source)
        self.assertIn('cleanup=close_runtime(runtime)',source)
        self.assertEqual(source.count('progress_capture.start('),1)
        self.assertIn('record_partial(raw,expected)',source)
        self.assertIn('cases=parse_output(raw.read_text(errors=\'replace\'),expected)',source)
        # No post-test adb dump and no unbounded reader or numeric PID signaling.
        self.assertNotIn("'logcat'",source)
        collector=Path(c.__file__).read_text()
        for forbidden in ('os.kill(','.terminate(','.kill(',"'start-server'","'kill-server'","'-c'","'root'"):
            self.assertNotIn(forbidden,collector)


class ProgressEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.env=patch.dict(os.environ,{'GITHUB_RUN_ID':'1','GITHUB_RUN_ATTEMPT':'1','GITHUB_SHA':'a'*40,'GITHUB_REPOSITORY':'origest/test'});self.env.start()
        self.location=patch.object(p,'DIRECTORY',self.root/'evidence');self.location.start();p.init()
    def tearDown(self):self.location.stop();self.env.stop();self.temp.cleanup()

    def test_timeout_still_publishes_fixed_step_partial_and_preserves_first_error(self):
        (self.root/'progress-private.bin').write_bytes(sample());(self.root/'progress-state-private.txt').write_bytes(b'stopped\n')
        expected=json.loads((p.ROOT/'expected-tests.json').read_text());raw=self.root/'instrumentation-private.txt'
        raw.write_text('INSTRUMENTATION_STATUS: class='+expected[4]['class']+'\nINSTRUMENTATION_STATUS: test='+expected[4]['method']+'\nINSTRUMENTATION_STATUS_CODE: 1\n')
        def timed_out():
            try:raise RuntimeFailure('COMMAND_TIMEOUT')
            finally:
                run.record_partial(raw,expected)
                run.record_progress(self.root,IDENTITY,CLEAN)
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=timed_out),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(run.entrypoint(),1);p.publish()
        summary=p.read_json(p.DIRECTORY/'summary.json')
        self.assertEqual(summary['code'],'RUNTIME_COMMAND_TIMEOUT')
        self.assertEqual(p.read_json(p.DIRECTORY/'progress.json')['open_steps'],['SWIPE_FIRST','POINTER_UP'])
        self.assertFalse((p.DIRECTORY/'TEST-isolated-ui.xml').exists())

    def test_precollector_terminal_errors_remain_first_and_no_instrument_runs(self):
        for error,code in ((RuntimeFailure('COMMAND_TIMEOUT'),'RUNTIME_COMMAND_TIMEOUT'),
                           (RuntimeFailure('CONTROL_LOST'),'RUNTIME_CONTROL_LOST'),
                           (subprocess.TimeoutExpired(['PRIVATE'],30),'TimeoutExpired'),
                           (run.Blocked('ADB_SERVER_EXITED'),'ADB_SERVER_EXITED'),
                           (run.Blocked('INTERRUPTED'),'INTERRUPTED')):
            instrument=Mock();adbc=Mock(side_effect=error)
            def main():
                run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,self.root,{},adbc,Mock())
                instrument()
            patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
            with patch.multiple(run,**patches),patch.object(run,'main',side_effect=main),contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(run.entrypoint(),1)
            instrument.assert_not_called();self.assertEqual(adbc.call_count,1)
            self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],code)
            self.assertNotIn('PRIVATE',out.getvalue())

    def test_precollector_only_nonterminal_failures_are_best_effort(self):
        for error in (ValueError('PRIVATE'),OSError('PRIVATE'),run.Blocked('SUBPROCESS_FAILED')):
            adbc=Mock(side_effect=error)
            self.assertIsNone(run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,self.root,{},adbc,Mock()))
        server=Mock();server.poll.return_value=None
        adbc=Mock(side_effect=[f'package:{c.TARGET} uid:10123',IDENTITY['since']])
        with patch.object(c,'start',side_effect=RuntimeFailure('CONTROL_LOST')):
            with self.assertRaises(RuntimeFailure) as caught:
                run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,self.root,{},adbc,server)
        self.assertEqual(caught.exception.reason,'CONTROL_LOST')

    def test_progress_persistence_failure_never_overwrites_timeout(self):
        def timed_out():
            try:raise RuntimeFailure('COMMAND_TIMEOUT')
            finally:run.record_progress(self.root,None,CLEAN)
        write=p.write
        def fails(name,data):
            if name=='progress.json':raise OSError('PRIVATE')
            return write(name,data)
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=timed_out),patch.object(p,'write',side_effect=fails),contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.entrypoint(),1)
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],'RUNTIME_COMMAND_TIMEOUT')
        self.assertNotIn('PRIVATE',out.getvalue());self.assertEqual(p.read_json(p.DIRECTORY/'cleanup.json')['evidence_errors'][0]['target'],'progress')

    def test_invalid_collection_cannot_publish_raw_or_grant_success(self):
        (self.root/'progress-private.bin').write_bytes(b'PRIVATE_UID_PATH_STACK');(self.root/'progress-state-private.txt').write_bytes(b'stopped\n')
        run.record_progress(self.root,IDENTITY,CLEAN)
        data=p.read_json(p.DIRECTORY/'progress.json');self.assertEqual(data,c.diagnostic(empty()))
        self.assertEqual(p.checked_json('progress.json',data),data)
        self.assertNotIn('PRIVATE',json.dumps(data));self.assertFalse((p.DIRECTORY/'summary.json').exists())

if __name__=='__main__':unittest.main()
