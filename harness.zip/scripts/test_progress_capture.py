"""Synthetic packets and mock commands only; never invoke adb/logcat or devices."""
import ast
import contextlib
import copy
import io
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch, Mock
import progress_capture as c
import public_evidence as p
import run_ui as run
from progress_parser import empty
from owned_runtime import RuntimeFailure

IDENTITY=c.source_identity(f'package:{c.TARGET} uid:10123','1794270000.123456789')
CLEAN={'state':'stopped_verified','reason':'NONE'}


def packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0', **kwargs):
    payload=kwargs.pop('payload',b'\x04'+c.TAG+b'\0'+message+b'\0')
    fields=dict(size=len(payload),header=28,pid=321,tid=322,sec=1794270000,nsec=123456789,buffer=0,uid=10123)
    fields.update(kwargs)
    return c.HEADER.pack(*fields.values())+payload


def sample():
    return packet()+packet(b'UI_STEP_V1|2|C05|SWIPE_FIRST|BEGIN|3',nsec=126456789)+packet(b'UI_STEP_V1|3|C05|POINTER_UP|BEGIN|9',nsec=132456789)


class ProgressCaptureTests(unittest.TestCase):
    def assertInvalid(self, value):
        self.assertEqual(value, empty(reason=value['reason']))
        self.assertNotEqual(value['reason'], 'UNCLASSIFIED')
        c.checked(c.diagnostic(value))

    def test_verified_target_uid_not_instrumentation_package(self):
        listing=f'package:android uid:1000\npackage:{c.TARGET} uid:10123\npackage:{c.TARGET}.test uid:10124'
        self.assertEqual(c.source_identity(listing,IDENTITY['since']),IDENTITY)
        for bad in ('',listing+f'\npackage:shared uid:10123',listing+f'\npackage:{c.TARGET} uid:10125',listing.replace('10123','1000'),listing+'\nPRIVATE'):
            with self.assertRaises(ValueError):c.source_identity(bad,IDENTITY['since'])
        for value in ('PRIVATE','1794270000','0.000000000','1794270000.123456789\n','1794270000.12345'):
            with self.assertRaises(ValueError):c.source_identity(listing,value)

    def test_exact_fixed_tag_binary_command_private_existing_endpoint(self):
        args=c.logcat_args('/synthetic/adb',12000,IDENTITY)
        self.assertEqual(args,['/synthetic/adb','-H','127.0.0.1','-P','12000','-s','emulator-5554','exec-out','logcat','-b','main','-B','--uid=10123','-T','1794270000.123456789','IsolatedUiStep:I','*:S'])
        for port in (True,0,65536,'123'):
            with self.assertRaises(ValueError):c.logcat_args('/synthetic/adb',port,IDENTITY)
        with self.assertRaises(ValueError):c.logcat_args('adb',123,IDENTITY)
        wrong=dict(IDENTITY,since_ns=1)
        with self.assertRaises(ValueError):c.logcat_args('/synthetic/adb',123,wrong)

    def test_start_only_uses_existing_runtime_owned_relay(self):
        runtime=Mock()
        c.start(runtime,Path('/synthetic/adb'),12000,IDENTITY,Path('/private/run'),{'X':'Y'})
        args,kw=runtime.start_service.call_args
        self.assertIn('--relay',args[0]); self.assertIn('/private/run/progress-state-private.txt',args[0])
        self.assertEqual(kw['log'],Path('/private/run/progress-private.bin'))
        self.assertEqual(runtime.method_calls[0][0],'start_service')
        self.assertEqual(len(runtime.method_calls),1)

    def test_kernel_bound_sample_returns_fixed_diagnostics_no_raw_identity(self):
        data=c.diagnostic(c.decode(sample(),IDENTITY));c.checked(data)
        self.assertEqual(data['diagnostic_state'],'incomplete')
        self.assertEqual(data['active_case'],'C05')
        self.assertEqual(data['open_steps'],['SWIPE_FIRST','POINTER_UP'])
        for secret in ('10123','321','1794270000','IsolatedUiStep','UI_STEP_V1'):
            self.assertNotIn(secret,json.dumps(data))
        self.assertNotIn('passed',json.dumps(data))

    def test_wrong_kernel_identity_buffer_priority_tag_rejected(self):
        for bad in (packet(uid=10124),packet(pid=0),packet(tid=0),packet(buffer=1),packet(header=24),packet(header=32),
                    packet(payload=b'\x03'+c.TAG+b'\0UI_STEP_V1|1|C05|CASE|BEGIN|0\0'),
                    packet(payload=b'\x04OtherTag\0UI_STEP_V1|1|C05|CASE|BEGIN|0\0'),
                    packet()+packet(b'UI_STEP_V1|2|C05|MAIN|BEGIN|1',pid=456)):
            self.assertInvalid(c.decode(bad,IDENTITY))

    def test_old_future_rollback_invalid_timestamp_rejected(self):
        for bad in (packet(nsec=123456788),packet(sec=1794270661),packet(nsec=10**9),
                    packet(nsec=123456790)+packet(b'UI_STEP_V1|2|C05|MAIN|BEGIN|1',nsec=123456789)):
            self.assertInvalid(c.decode(bad,IDENTITY))

    def test_truncation_encoding_injection_overflow_rejected(self):
        for bad in (sample()[:-1],sample()+b'\0',b'x'*(c.LIMIT+1),packet(size=161),packet(message=b'\xff'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nPRIVATE'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\0PRIVATE'),
                    packet(payload=b'\x04'+c.TAG+b'\0UI_STEP_V1|1|C05|CASE|BEGIN|0'),
                    packet(b'UI_STEP_V1|2|C05|CASE|BEGIN|0'),sample()+packet()):
            self.assertInvalid(c.decode(bad,IDENTITY))
        self.assertEqual(c.decode(b'',IDENTITY),empty('missing'))

    def test_owned_stable_read_and_stop_required(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); raw=root/'progress-private.bin'; state=root/'progress-state-private.txt'
            raw.write_bytes(sample());state.write_bytes(b'stopped\n')
            self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(c.decode(sample(),IDENTITY)))
            for status in (b'starting\n',b'invalid\n',b'stopped\nPRIVATE'):
                state.write_bytes(status);self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(empty(reason='RELAY_STATE_INVALID')))
            state.write_bytes(b'stopped\n')
            for cleanup in ({'state':'cleanup_failed','reason':'CLEANUP_TIMEOUT'},None,{'state':'stopped_verified','reason':'NONE','extra':1}):
                self.assertEqual(c.finish(root,IDENTITY,cleanup),c.diagnostic(empty(reason='CLEANUP_UNVERIFIED')))
            self.assertEqual(c.finish(root,None,CLEAN),c.diagnostic(empty(reason='SETUP_UNAVAILABLE')))
            raw.write_bytes(b'x'*(c.LIMIT+1));self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(empty(reason='FILE_UNSAFE')))

    def test_links_fifo_wrong_owner_and_replaced_files_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); raw=root/'raw'; raw.write_bytes(b'safe')
            link=root/'link';link.symlink_to(raw)
            with self.assertRaises(OSError):c.stable_bytes(link,100)
            fifo=root/'fifo';os.mkfifo(fifo)
            with self.assertRaises(ValueError):c.stable_bytes(fifo,100)
            hard=root/'hard';os.link(raw,hard)
            with self.assertRaises(ValueError):c.stable_bytes(raw,100)
            hard.unlink()
            with patch.object(c.os,'getuid',return_value=os.getuid()+1):
                with self.assertRaises(ValueError):c.stable_bytes(raw,100)
            original=c.os.read
            def changing(fd,size):
                value=original(fd,size)
                if value:raw.write_bytes(b'changed')
                return value
            with patch.object(c.os,'read',side_effect=changing):
                with self.assertRaises(ValueError):c.stable_bytes(raw,100)

    def test_relay_caps_retained_bytes_and_never_prints_errors(self):
        for overflow,stop,expected in ((False,True,b'stopped\n'),(False,False,b'invalid RELAY_STOP_UNVERIFIED\n'),(True,True,b'invalid BINARY_TIME\n')):
            with self.subTest(overflow=overflow,stop=stop),tempfile.TemporaryDirectory() as t:
                saved={};out=bytearray();chunks=iter([sample()*(c.LIMIT//len(sample())+1) if overflow else sample(),b''])
                def read(fd,n):
                    chunk=next(chunks)
                    if not chunk and stop:saved[signal.SIGTERM](signal.SIGTERM,None)
                    return chunk
                def write(fd,chunk):out.extend(chunk);return len(chunk)
                child=Mock();child.stdout.fileno.return_value=42;child.wait.return_value=-15
                with patch.object(c.signal,'signal',side_effect=lambda sig,fn:saved.update({sig:fn})),contextlib.redirect_stdout(io.StringIO()) as stdout,contextlib.redirect_stderr(io.StringIO()) as stderr:
                    code=c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],popen=Mock(return_value=child),read=read,write=write)
                self.assertEqual(code,0);self.assertEqual((Path(t)/'state').read_bytes(),expected)
                self.assertLessEqual(len(out),c.LIMIT);self.assertFalse(stdout.getvalue());self.assertFalse(stderr.getvalue())
                child.wait.assert_called_once_with()

    def test_binary_mixed_tags_filtered_before_disk_including_large_messages(self):
        output=[];filter=c.PacketFilter(IDENTITY,output.append)
        other=packet(payload=b'\x04OtherTargetTag\0'+b'PRIVATE_OTHER_LOG'*100+b'\0')
        later=packet(payload=b'\x04OtherTargetTag\0'+b'PRIVATE_OTHER_LOG'*100+b'\0',nsec=140000000)
        filter.feed(other+sample()+later)
        self.assertTrue(filter.complete())
        self.assertEqual(b''.join(output),sample())
        self.assertNotIn(b'PRIVATE_OTHER_LOG',b''.join(output))

    def test_split_headers_payloads_and_single_byte_chunks(self):
        raw=packet(payload=b'\x04OtherTargetTag\0'+b'PRIVATE_OTHER_LOG'*100+b'\0')+sample()
        for size in (1,2,27,28,29,128,65536):
            output=[];filter=c.PacketFilter(IDENTITY,output.append)
            for pos in range(0,len(raw),size):filter.feed(raw[pos:pos+size])
            self.assertTrue(filter.complete());self.assertEqual(b''.join(output),sample())

    def test_stream_filter_rejects_malformed_identity_restart_truncation(self):
        for raw in (packet(uid=10124),packet(header=24),packet(payload=b'\x04NoDelimiter'),
                    sample()[:-1],sample()+packet(pid=456),packet(size=4097),
                    packet(payload=b'\x03'+c.TAG+b'\0test\0'),
                    sample()+packet(sec=1794269999)):
            output=[];filter=c.PacketFilter(IDENTITY,output.append);filter.feed(raw)
            self.assertFalse(filter.complete())

    def test_fixed_tag_arbitrary_text_never_retained(self):
        for raw in (packet(message=b'PRIVATE_SECRET_STACK'),packet(message=b'UI_STEP_V1|1|C20|CASE|BEGIN|0'),
                    packet(message=b'UI_STEP_V1|1|C05|PRIVATE_SECRET|BEGIN|0'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|600001'),
                    packet(message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nPRIVATE'),packet(message=b'\xff')):
            output=[];filter=c.PacketFilter(IDENTITY,output.append);filter.feed(raw)
            self.assertFalse(filter.complete());self.assertFalse(output)

    def test_parsing_budget_and_fixed_tag_count_are_bounded(self):
        output=[];filter=c.PacketFilter(IDENTITY,output.append)
        filter.feed(b'x'*(8*1024*1024+1));self.assertFalse(filter.complete());self.assertFalse(output)
        output=[];filter=c.PacketFilter(IDENTITY,output.append)
        for _ in range(8193):filter.feed(packet())
        self.assertFalse(filter.complete());self.assertEqual(len(output),8192)

    def test_relay_start_failure_fixed_and_no_raw_exception(self):
        with tempfile.TemporaryDirectory() as t,patch.object(c.signal,'signal'),contextlib.redirect_stdout(io.StringIO()) as stdout,contextlib.redirect_stderr(io.StringIO()) as stderr:
            code=c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],popen=Mock(side_effect=OSError('PRIVATE_SECRET')))
            self.assertEqual(code,1);self.assertEqual((Path(t)/'state').read_bytes(),b'invalid RELAY_START\n')
            self.assertFalse(stdout.getvalue());self.assertFalse(stderr.getvalue())

    def test_strict_schema_rejects_every_nonfixed_field_and_type(self):
        data=c.diagnostic(c.decode(sample(),IDENTITY))
        changes=[lambda d:d.update(tail_completeness='complete'),lambda d:d.pop('tail_completeness'),lambda d:d.update(raw='PRIVATE'),lambda d:d.update(active_case='PRIVATE'),lambda d:d.update(diagnostic_state='passed'),
                 lambda d:d.update(cases=d['cases'][:-1]),lambda d:d['cases'][0].update(raw='PRIVATE'),
                 lambda d:d['cases'][0].update(case='C20'),lambda d:d['cases'][0].update(end_ms=2),
                 lambda d:d.update(last_event_ms=True),lambda d:d.update(last_event_ms=600001),
                 lambda d:d.update(last_event_ms=-1),lambda d:d.update(open_steps=['MAIN']*2),
                 lambda d:d.update(open_steps=['PRIVATE']),lambda d:d.update(diagnostic_state='observed'),
                 lambda d:d['cases'][4].update(begin_ms=False),lambda d:d.update(diagnostic_state='invalid'),
                 lambda d:d.update(diagnostic_state='missing')]
        for change in changes:
            bad=copy.deepcopy(data);change(bad)
            with self.assertRaises((ValueError,TypeError)):c.checked(bad)
        for state in ('missing','invalid'):self.assertEqual(c.checked(c.diagnostic(empty(state))),c.diagnostic(empty(state)))

    def test_public_case_ranges_cannot_overlap_or_follow_active_case(self):
        base=c.diagnostic(empty('observed'));base['last_event_ms']=10
        base['cases'][0].update(begin_ms=0,end_ms=5)
        base['cases'][1].update(begin_ms=4,end_ms=8)
        with self.assertRaises(ValueError):c.checked(base)
        base['cases'][1].update(begin_ms=5,end_ms=8);c.checked(base)
        base['diagnostic_state']='incomplete';base['active_case']='C01'
        base['cases'][0].update(begin_ms=0,end_ms=None)
        with self.assertRaises(ValueError):c.checked(base)
        # Same-millisecond closed zero-length cases may precede an active case.
        base['cases'][1].update(begin_ms=0,end_ms=0);c.checked(base)

    def test_valid_closed_prefix_never_claims_complete_tail(self):
        raw=packet()+packet(b'UI_STEP_V1|2|C05|CASE|END|1',nsec=124456789)
        data=c.diagnostic(c.decode(raw,IDENTITY));c.checked(data)
        self.assertEqual(data['diagnostic_state'],'observed')
        self.assertEqual(data['tail_completeness'],'unverified')
        # A whole subsequent CASE can be lost with no malformed partial frame.
        full=raw+packet(b'UI_STEP_V1|3|C01|CASE|BEGIN|2',nsec=125456789)+packet(b'UI_STEP_V1|4|C01|CASE|END|3',nsec=126456789)
        full_data=c.diagnostic(c.decode(full,IDENTITY));c.checked(full_data)
        self.assertEqual(full_data['tail_completeness'],'unverified')
        self.assertIsNone(data['cases'][0]['begin_ms'])
        self.assertEqual(full_data['cases'][0]['end_ms'],3)
        self.assertNotIn('passed',str(data))

    def test_wiring_keeps_600_deadline_and_collects_after_verified_close(self):
        source=Path(run.__file__).read_text();tree=ast.parse(source)
        self.assertIn('timeout=600,log=raw',source)
        self.assertIn('if progress_attempted: record_progress(root,progress_identity,cleanup,progress_setup)',source)
        self.assertIn('cleanup=close_runtime(runtime)',source)
        self.assertEqual(source.count('progress_capture.start('),1)
        self.assertIn('record_partial(raw,expected)',source)
        self.assertIn('cases=parse_output(raw.read_text(errors=\'replace\'),expected)',source)
        # No post-test adb dump and no unbounded reader or numeric PID signaling.
        self.assertNotIn("'logcat'",source)
        collector=Path(c.__file__).read_text()
        for forbidden in ('os.kill(','.terminate(','.kill(',"'start-server'","'kill-server'","'-c'","'root'"):
            self.assertNotIn(forbidden,collector)


class ProgressEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.env=patch.dict(os.environ,{'GITHUB_RUN_ID':'1','GITHUB_RUN_ATTEMPT':'1','GITHUB_SHA':'a'*40,'GITHUB_REPOSITORY':'origest/test'});self.env.start()
        self.location=patch.object(p,'DIRECTORY',self.root/'evidence');self.location.start();p.init()
    def tearDown(self):self.location.stop();self.env.stop();self.temp.cleanup()

    def test_timeout_still_publishes_fixed_step_partial_and_preserves_first_error(self):
        (self.root/'progress-private.bin').write_bytes(sample());(self.root/'progress-state-private.txt').write_bytes(b'stopped\n')
        expected=json.loads((p.ROOT/'expected-tests.json').read_text());raw=self.root/'instrumentation-private.txt'
        raw.write_text('INSTRUMENTATION_STATUS: class='+expected[4]['class']+'\nINSTRUMENTATION_STATUS: test='+expected[4]['method']+'\nINSTRUMENTATION_STATUS_CODE: 1\n')
        def timed_out():
            try:raise RuntimeFailure('COMMAND_TIMEOUT')
            finally:
                run.record_partial(raw,expected)
                run.record_progress(self.root,IDENTITY,CLEAN)
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=timed_out),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(run.entrypoint(),1);p.publish()
        summary=p.read_json(p.DIRECTORY/'summary.json')
        self.assertEqual(summary['code'],'RUNTIME_COMMAND_TIMEOUT')
        self.assertEqual(p.read_json(p.DIRECTORY/'progress.json')['open_steps'],['SWIPE_FIRST','POINTER_UP'])
        self.assertFalse((p.DIRECTORY/'TEST-isolated-ui.xml').exists())

    def test_precollector_terminal_errors_remain_first_and_no_instrument_runs(self):
        for error,code in ((RuntimeFailure('COMMAND_TIMEOUT'),'RUNTIME_COMMAND_TIMEOUT'),
                           (RuntimeFailure('CONTROL_LOST'),'RUNTIME_CONTROL_LOST'),
                           (subprocess.TimeoutExpired(['PRIVATE'],30),'TimeoutExpired'),
                           (run.Blocked('ADB_SERVER_EXITED'),'ADB_SERVER_EXITED'),
                           (run.Blocked('INTERRUPTED'),'INTERRUPTED')):
            instrument=Mock();adbc=Mock(side_effect=error)
            def main():
                run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,self.root,{},adbc,Mock())
                instrument()
            patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
            with patch.multiple(run,**patches),patch.object(run,'main',side_effect=main),contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(run.entrypoint(),1)
            instrument.assert_not_called();self.assertEqual(adbc.call_count,1)
            self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],code)
            self.assertNotIn('PRIVATE',out.getvalue())

    def test_precollector_only_nonterminal_failures_are_best_effort(self):
        for error in (ValueError('PRIVATE'),OSError('PRIVATE'),run.Blocked('SUBPROCESS_FAILED')):
            adbc=Mock(side_effect=error)
            self.assertIsNone(run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,self.root,{},adbc,Mock()))
        server=Mock();server.poll.return_value=None
        adbc=Mock(side_effect=[f'package:{c.TARGET} uid:10123',IDENTITY['since']])
        with patch.object(c,'start',side_effect=RuntimeFailure('CONTROL_LOST')):
            with self.assertRaises(RuntimeFailure) as caught:
                run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,self.root,{},adbc,server)
        self.assertEqual(caught.exception.reason,'CONTROL_LOST')

    def test_progress_persistence_failure_never_overwrites_timeout(self):
        def timed_out():
            try:raise RuntimeFailure('COMMAND_TIMEOUT')
            finally:run.record_progress(self.root,None,CLEAN)
        write=p.write
        def fails(name,data):
            if name=='progress.json':raise OSError('PRIVATE')
            return write(name,data)
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=timed_out),patch.object(p,'write',side_effect=fails),contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.entrypoint(),1)
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],'RUNTIME_COMMAND_TIMEOUT')
        self.assertNotIn('PRIVATE',out.getvalue());self.assertEqual(p.read_json(p.DIRECTORY/'cleanup.json')['evidence_errors'][0]['target'],'progress')

    def test_invalid_collection_cannot_publish_raw_or_grant_success(self):
        (self.root/'progress-private.bin').write_bytes(b'PRIVATE_UID_PATH_STACK');(self.root/'progress-state-private.txt').write_bytes(b'stopped\n')
        run.record_progress(self.root,IDENTITY,CLEAN)
        data=p.read_json(p.DIRECTORY/'progress.json');self.assertEqual(data,c.diagnostic(empty(reason='BINARY_TRUNCATED')))
        self.assertEqual(p.checked_json('progress.json',data),data)
        self.assertNotIn('PRIVATE',json.dumps(data));self.assertFalse((p.DIRECTORY/'summary.json').exists())


class ProgressReasonTests(unittest.TestCase):
    """Synthetic validator failures only, not reconstructed device evidence."""
    def test_binary_reasons_are_precise_and_discard_every_observation(self):
        samples=[(None,'BINARY_INPUT'),(b'x'*(c.LIMIT+1),'BINARY_LIMIT'),
                 (sample()[:-1],'BINARY_TRUNCATED'),(packet(header=24),'BINARY_HEADER'),
                 (packet(uid=10124),'BINARY_SOURCE'),(packet(nsec=10**9),'BINARY_TIME'),
                 (packet()+packet(pid=456),'BINARY_PID'),
                 (packet(payload=b'\x03'+c.TAG+b'\0synthetic\0'),'BINARY_TAG'),
                 (packet(message=b'two\nlines'),'BINARY_PAYLOAD'),
                 (packet(b'UI_STEP_V1|2|C05|CASE|BEGIN|0'),'SEQUENCE_NUMBER')]
        for raw,reason in samples:
            with self.subTest(reason=reason):
                data=c.decode(raw,IDENTITY)
                self.assertEqual(data,empty(reason=reason));c.checked(c.diagnostic(data))
        for identity in (None,{},dict(IDENTITY,since_ns=1),dict(IDENTITY,uid=10124)):
            self.assertEqual(c.decode(sample(),identity)['diagnostic_state'],'invalid')
        self.assertEqual(c.decode(sample(),None)['reason'],'BINARY_IDENTITY')

    def test_filter_first_reason_survives_later_bytes_and_errors(self):
        output=[];parser=c.PacketFilter(IDENTITY,output.append)
        parser.feed(packet(uid=10124));parser.feed(sample())
        parser.feed(b'PRIVATE'*100)
        parser.fail('BINARY_HEADER')
        self.assertEqual(parser.final_reason(),'BINARY_SOURCE')
        self.assertFalse(output);self.assertFalse(parser.complete())

    def test_filter_reasons_keep_strict_unrelated_tag_source_time_and_pid(self):
        other=lambda **kw: packet(payload=b'\x04OtherTag\0PRIVATE_OTHER\0',**kw)
        for raw,reason in ((other(uid=10124),'BINARY_SOURCE'),
                           (other(nsec=123456788),'BINARY_TIME'),
                           (sample()+other(pid=456,nsec=140000000),'BINARY_PID'),
                           (packet(size=4097),'BINARY_HEADER'),
                           (packet(message=b'PRIVATE'),'BINARY_PAYLOAD'),
                           (packet()[:-1],'BINARY_TRUNCATED'),
                           (b'x'*(8*1024*1024+1),'BINARY_STREAM_LIMIT')):
            output=[];parser=c.PacketFilter(IDENTITY,output.append);parser.feed(raw)
            self.assertEqual(parser.final_reason(),reason)
            self.assertFalse(parser.complete())
            self.assertNotIn(b'PRIVATE',b''.join(output))

    def test_private_relay_status_has_closed_vocabulary(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); state=root/'progress-state-private.txt'
            for reason in c.RELAY_REASONS:
                state.write_bytes(('invalid '+reason+'\n').encode())
                self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(empty(reason=reason)))
            for bad in (b'invalid PRIVATE\n',b'invalid BINARY_SOURCE\nPRIVATE',
                        b'invalid SETUP_IDENTITY\n',b'invalid NONE\n',b'invalid\n',b'\xff'):
                state.write_bytes(bad)
                self.assertEqual(c.finish(root,IDENTITY,CLEAN),c.diagnostic(empty(reason='RELAY_STATE_INVALID')))

    def test_setup_and_cleanup_precede_any_private_file_read(self):
        with patch.object(c,'stable_bytes',side_effect=AssertionError('No read permitted')):
            self.assertEqual(c.finish('/synthetic',None,CLEAN,{'reason':'SETUP_CLOCK_QUERY'})['reason'],'SETUP_CLOCK_QUERY')
            self.assertEqual(c.finish('/synthetic',None,None,{'reason':'SETUP_CLOCK_QUERY'})['reason'],'SETUP_CLOCK_QUERY')
            self.assertEqual(c.finish('/synthetic',IDENTITY,None)['reason'],'CLEANUP_UNVERIFIED')
            for bad in ({'reason':'PRIVATE'},{'reason':None},None):
                self.assertEqual(c.finish('/synthetic',None,CLEAN,bad)['reason'],'SETUP_UNAVAILABLE')

    def test_stable_file_reasons_distinguish_missing_and_unsafe(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);state=root/'progress-state-private.txt';raw=root/'progress-private.bin'
            self.assertEqual(c.finish(root,IDENTITY,CLEAN)['reason'],'STATE_FILE_UNREADABLE')
            state.write_bytes(b'stopped\n')
            self.assertEqual(c.finish(root,IDENTITY,CLEAN)['reason'],'BINARY_FILE_UNREADABLE')
            raw.write_bytes(sample());os.link(raw,root/'hard')
            self.assertEqual(c.finish(root,IDENTITY,CLEAN)['reason'],'FILE_UNSAFE')
        for reason in ('FILE_UNSTABLE','FILE_REPLACED'):
            with patch.object(c,'stable_bytes',side_effect=c.DiagnosticFailure(reason)):
                self.assertEqual(c.finish('/synthetic',IDENTITY,CLEAN)['reason'],reason)

    def test_all_reason_phase_pairs_are_fixed_and_consistent(self):
        for reason,phase in c.REASON_PHASE.items():
            if reason=='NONE': continue
            data=c.diagnostic(empty(reason=reason));c.checked(data)
            self.assertEqual(data['phase'],phase)
            for bad_reason,bad_phase in ((reason,'PRIVATE'),('PRIVATE',phase),('NONE','none'),
                                         (reason,None),([],phase),(None,phase)):
                bad=copy.deepcopy(data);bad.update(reason=bad_reason,phase=bad_phase)
                with self.assertRaises((ValueError,TypeError)):c.checked(bad)
        data=c.diagnostic(c.decode(sample(),IDENTITY))
        for field in ('reason','phase'):
            bad=copy.deepcopy(data);bad.pop(field)
            with self.assertRaises(ValueError):c.checked(bad)
        for reason in c.REASON_PHASE:
            if reason=='NONE': continue
            bad=copy.deepcopy(data);bad.update(reason=reason,phase=c.REASON_PHASE[reason])
            with self.assertRaises(ValueError):c.checked(bad)

    def test_relay_reports_first_filter_error_over_later_read_failure(self):
        with tempfile.TemporaryDirectory() as t,patch.object(c.signal,'signal'):
            child=Mock();child.stdout.fileno.return_value=42
            read=Mock(side_effect=[packet(header=24),OSError('PRIVATE')])
            code=c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],
                         popen=Mock(return_value=child),read=read,write=Mock())
            self.assertEqual(code,1)
            self.assertEqual((Path(t)/'state').read_bytes(),b'invalid BINARY_HEADER\n')

    def test_relay_start_read_write_wait_and_truncation_are_distinct(self):
        for stage in ('start','read','write','wait','truncated'):
            with self.subTest(stage=stage),tempfile.TemporaryDirectory() as t:
                saved={};child=Mock();child.stdout.fileno.return_value=42
                child.wait.return_value=-15
                chunks=iter([sample()[:-1] if stage=='truncated' else sample(),b''])
                def read(fd,n):
                    if stage=='read': raise OSError('PRIVATE')
                    chunk=next(chunks)
                    if not chunk:saved[signal.SIGTERM](signal.SIGTERM,None)
                    return chunk
                spawn=Mock(side_effect=OSError('PRIVATE')) if stage=='start' else Mock(return_value=child)
                write=Mock(side_effect=OSError('PRIVATE')) if stage=='write' else lambda fd,data:len(data)
                if stage=='wait':child.wait.side_effect=OSError('PRIVATE')
                with patch.object(c.signal,'signal',side_effect=lambda sig,fn:saved.update({sig:fn})),\
                     contextlib.redirect_stdout(io.StringIO()) as stdout,contextlib.redirect_stderr(io.StringIO()) as stderr:
                    c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],popen=spawn,read=read,write=write)
                reason='BINARY_TRUNCATED' if stage=='truncated' else 'RELAY_'+stage.upper()
                self.assertEqual((Path(t)/'state').read_bytes(),('invalid '+reason+'\n').encode())
                self.assertFalse(stdout.getvalue());self.assertFalse(stderr.getvalue())

    def test_final_status_failure_never_replaces_selected_terminal_reason(self):
        for truncated,stop,reason in ((True,True,'BINARY_TRUNCATED'),
                                     (False,False,'RELAY_STOP_UNVERIFIED'),
                                     (False,True,'RELAY_STATE_WRITE')):
            with self.subTest(reason=reason),tempfile.TemporaryDirectory() as t:
                saved={};child=Mock();child.stdout.fileno.return_value=42
                child.wait.return_value=-15
                chunks=iter([sample()[:-1] if truncated else sample(),b''])
                def read(fd,n):
                    chunk=next(chunks)
                    if not chunk and stop:saved[signal.SIGTERM](signal.SIGTERM,None)
                    return chunk
                with patch.object(c.signal,'signal',side_effect=lambda sig,fn:saved.update({sig:fn})),\
                     patch.object(c.os,'fsync',side_effect=[None,OSError('PRIVATE'),None]):
                    code=c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(Path(t)/'state')],
                                 popen=Mock(return_value=child),read=read,write=lambda fd,data:len(data))
                self.assertEqual(code,1)
                self.assertEqual((Path(t)/'state').read_bytes(),('invalid '+reason+'\n').encode())

    def test_setup_reason_records_failed_boundary_only(self):
        listing=f'package:{c.TARGET} uid:10123'
        for responses,reason in (([OSError('PRIVATE')],'SETUP_PACKAGE_QUERY'),
                                 ([listing,OSError('PRIVATE')],'SETUP_CLOCK_QUERY'),
                                 (['PRIVATE',IDENTITY['since']],'SETUP_IDENTITY')):
            setup={};server=Mock();server.poll.return_value=None
            result=run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,Path('/synthetic'),{},Mock(side_effect=responses),server,setup)
            self.assertIsNone(result);self.assertEqual(setup,{'reason':reason})
        setup={};server=Mock();server.poll.return_value=None
        with patch.object(c,'start',side_effect=OSError('PRIVATE')):
            self.assertIsNone(run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,Path('/synthetic'),{},Mock(side_effect=[listing,IDENTITY['since']]),server,setup))
        self.assertEqual(setup,{'reason':'SETUP_RELAY_START'})
        with patch.object(c,'start'):
            result=run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,Path('/synthetic'),{},Mock(side_effect=[listing,IDENTITY['since']]),server,setup)
        self.assertEqual(result,IDENTITY);self.assertEqual(setup,{})

    def test_actual_timeout_object_propagates_unchanged_at_each_setup_boundary(self):
        listing=f'package:{c.TARGET} uid:10123'
        for stage in ('package','clock','start'):
            original=subprocess.TimeoutExpired(['PRIVATE'],30)
            setup={};server=Mock();server.poll.return_value=None
            responses=([original] if stage=='package' else [listing,original] if stage=='clock' else [listing,IDENTITY['since']])
            with patch.object(c,'start',side_effect=original if stage=='start' else None),self.assertRaises(subprocess.TimeoutExpired) as caught:
                run.prepare_progress(Mock(),Path('/synthetic/adb'),12000,Path('/synthetic'),{},Mock(side_effect=responses),server,setup)
            self.assertIs(caught.exception,original)
            self.assertNotIn('PRIVATE',json.dumps(setup))


class ProgressSchemaFailureTests(unittest.TestCase):
    setUp = ProgressEvidenceTests.setUp
    tearDown = ProgressEvidenceTests.tearDown
    def test_schema_failure_publishes_only_fixed_empty_and_preserves_timeout(self):
        def timed_out():
            try:raise subprocess.TimeoutExpired(['PRIVATE'],600)
            finally:run.record_progress(self.root,IDENTITY,CLEAN)
        patches={'STAGE':'instrumentation','EVIDENCE_READY':True,'ACTIVE_ROOT':None,'PROCESS_CLEANUP_OK':True,'EVIDENCE_OK':True,'BUILD_FAILURE':None}
        bad=c.diagnostic(empty());bad.update(raw='PRIVATE',reason='PRIVATE')
        with patch.multiple(run,**patches),patch.object(run,'main',side_effect=timed_out),\
             patch.object(c,'finish',return_value=bad),contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(run.entrypoint(),1)
            self.assertFalse(run.EVIDENCE_OK)
        self.assertEqual(p.read_json(p.DIRECTORY/'summary.json')['code'],'TimeoutExpired')
        self.assertEqual(p.read_json(p.DIRECTORY/'progress.json'),c.diagnostic(empty(reason='PUBLIC_SCHEMA')))
        self.assertNotIn('PRIVATE',out.getvalue())
        self.assertFalse((p.DIRECTORY/'TEST-isolated-ui.xml').exists())


class OrdinaryTagCompatibilityTests(unittest.TestCase):
    """Official API 33 C-string layout, not reconstructed runtime log bytes."""
    def other(self, tag=b'', message=b'PRIVATE_OTHER', priority=4, **fields):
        return packet(payload=bytes([priority])+tag+b'\0'+message+b'\0', **fields)

    def filtered(self, raw, widths=(65536,)):
        output=[]; parser=c.PacketFilter(IDENTITY,output.append)
        offset=0; index=0
        while offset<len(raw):
            width=widths[index%len(widths)]; parser.feed(raw[offset:offset+width])
            offset+=width; index+=1
        return parser,b''.join(output)

    def test_empty_and_long_ordinary_tags_discarded_before_retention(self):
        for tag in (b'',b'O',b'O'*128,b'O'*129,b'O'*1024):
            for priority in range(2,9):
                with self.subTest(tag_size=len(tag),priority=priority):
                    raw=self.other(tag,priority=priority)+sample()
                    parser,output=self.filtered(raw)
                    self.assertTrue(parser.complete());self.assertIsNone(parser.final_reason())
                    self.assertEqual(output,sample());self.assertNotIn(b'PRIVATE_OTHER',output)
                    self.assertEqual(c.decode(output,IDENTITY),c.decode(sample(),IDENTITY))

    def test_empty_tag_and_empty_message_is_three_byte_complete_payload(self):
        parser,output=self.filtered(self.other(message=b''))
        self.assertTrue(parser.complete());self.assertEqual(output,b'')
        self.assertEqual(parser.total,c.HEADER.size+3)
        self.assertEqual(c.decode(output,IDENTITY),empty('missing'))

    def test_ordinary_empty_message_and_frame_size_boundaries(self):
        for tag_len in (1,128,129,4065,4093):
            parser,output=self.filtered(self.other(b'T'*tag_len,message=b''))
            self.assertTrue(parser.complete());self.assertEqual(output,b'')
        for raw in (self.other(b'T'*4094,message=b''),packet(payload=b'\x04\0'),packet(size=0)):
            parser,output=self.filtered(raw)
            self.assertEqual(parser.final_reason(),'BINARY_HEADER');self.assertFalse(output)

    def test_ordinary_utf8_newlines_and_protocol_lookalikes_are_not_progress(self):
        for tag in (b'',b'T'*129,b'\xc3\xa9'*70,b'\xc0\x80',b'\xed\xa0\x80'):
            msg=b'PRIVATE\n'+b'UI_STEP_V1|1|C01|CASE|BEGIN|123'+b'\n\xff'
            parser,output=self.filtered(self.other(tag,msg))
            self.assertTrue(parser.complete());self.assertEqual(output,b'')
            self.assertEqual(c.decode(output,IDENTITY),empty('missing'))

    def test_all_short_stream_split_points_are_equivalent(self):
        raw=self.other(message=b'')+sample()+self.other(b'O'*129,nsec=140000000)
        for split in range(len(raw)+1):
            output=[];parser=c.PacketFilter(IDENTITY,output.append)
            parser.feed(raw[:split]);parser.feed(raw[split:])
            self.assertTrue(parser.complete());self.assertEqual(b''.join(output),sample())
        for widths in ((1,),(2,),(27,28,29),(127,4096),(65536,)):
            parser,output=self.filtered(raw,widths)
            self.assertTrue(parser.complete());self.assertEqual(output,sample())

    def test_source_time_pid_checks_apply_to_discarded_empty_and_long_tags(self):
        invalids=(({'uid':10124},'BINARY_SOURCE'),({'pid':0},'BINARY_SOURCE'),
                  ({'tid':0},'BINARY_SOURCE'),({'buffer':1},'BINARY_SOURCE'),
                  ({'header':24},'BINARY_HEADER'),({'nsec':10**9},'BINARY_TIME'),
                  ({'nsec':123456788},'BINARY_TIME'),({'sec':1794270661},'BINARY_TIME'))
        for tag in (b'',b'O'*129):
            for fields,reason in invalids:
                parser,output=self.filtered(self.other(tag,**fields)+sample())
                self.assertEqual(parser.final_reason(),reason);self.assertFalse(output)
            parser,output=self.filtered(self.other(tag)+packet(pid=456))
            self.assertEqual(parser.final_reason(),'BINARY_PID');self.assertFalse(output)
            parser,output=self.filtered(sample()+self.other(tag,pid=456,nsec=140000000))
            self.assertEqual(parser.final_reason(),'BINARY_PID');self.assertEqual(output,sample())
            parser,output=self.filtered(self.other(tag,nsec=123456790)+packet())
            self.assertEqual(parser.final_reason(),'BINARY_TIME');self.assertFalse(output)

    def test_discarded_logs_update_whole_stream_pid_and_time_boundaries(self):
        raw=self.other(b'',nsec=123456789)+self.other(b'T'*129,nsec=124456789)
        parser,output=self.filtered(raw)
        self.assertEqual(parser.pid,321);self.assertEqual(parser.last_stamp,1794270000124456789)
        self.assertEqual(parser.count,0);self.assertEqual(parser.retained,0);self.assertFalse(output)
        parser.feed(packet(nsec=123456789));self.assertEqual(parser.final_reason(),'BINARY_TIME')

    def test_unknown_tags_cannot_bypass_retained_file_decoder(self):
        for tag in (b'',b'O',b'O'*129):
            raw=self.other(tag,message=b'UI_STEP_V1|1|C05|CASE|BEGIN|0')
            data=c.decode(raw,IDENTITY)
            self.assertEqual(data['diagnostic_state'],'invalid')
            self.assertEqual(data,empty(reason=data['reason']))
            self.assertEqual(c.decode(raw+sample(),IDENTITY)['diagnostic_state'],'invalid')

    def test_target_tag_matching_is_exact_bytes_without_normalization(self):
        for tag in (c.TAG+b'X',b' '+c.TAG,c.TAG+b' ',c.TAG.lower(),c.TAG+b'\xc0\x80'):
            parser,output=self.filtered(self.other(tag,b'UI_STEP_V1|1|C05|CASE|BEGIN|0')+sample())
            self.assertTrue(parser.complete());self.assertEqual(output,sample())
        for message in (b'UI_STEP_V1|1|C05|CASE|BEGIN|0\xc0\x80',b'\xed\xa0\x80'):
            parser,output=self.filtered(self.other(c.TAG,message))
            self.assertEqual(parser.final_reason(),'BINARY_PAYLOAD');self.assertFalse(output)

    def test_unrecognized_priority_or_missing_tag_delimiter_still_invalid(self):
        for payload in (b'\x04NoDelimiter',b'\x04'+b'T'*4067,b'\x04'+c.TAG):
            parser,output=self.filtered(packet(payload=payload)+sample())
            self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)
        for priority in (0,1,9,255):
            parser,output=self.filtered(self.other(priority=priority))
            self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)

    def test_complete_unrelated_tag_body_is_opaque_and_never_progress(self):
        for tag in (b'',b'Other',b'T'*129):
            for message in (b'',b'PRIVATE',b'PRIV\0ATE\0',b'\xff\nPRIVATE',
                            b'UI_STEP_V1|1|C05|CASE|BEGIN|0'):
                payload=b'\x04'+tag+b'\0'+message
                if len(payload)<3: continue  # Existing bounded frame minimum is three.
                parser,output=self.filtered(packet(payload=payload)+sample())
                self.assertTrue(parser.complete());self.assertEqual(output,sample())
                self.assertEqual(c.decode(output,IDENTITY),c.decode(sample(),IDENTITY))

    def test_aosp_capped_ordinary_message_discards_but_target_stays_invalid(self):
        # API 33 LOGGER_ENTRY_MAX_PAYLOAD is 4068; liblog cuts iovecs at that byte.
        for tag in (b'',b'O',b'O'*129):
            payload=(b'\x04'+tag+b'\0'+b'PRIVATE_'*600+b'\0')[:4068]
            self.assertEqual(len(payload),4068);self.assertFalse(payload.endswith(b'\0'))
            parser,output=self.filtered(packet(payload=payload)+sample(),(27,1,29,4096))
            self.assertTrue(parser.complete());self.assertEqual(output,sample())
            self.assertEqual(c.decode(packet(payload=payload),IDENTITY)['diagnostic_state'],'invalid')
        # Even when the whole message is clipped, a complete non-target tag is known.
        parser,output=self.filtered(packet(payload=b'\x04'+b'T'*4066+b'\0')+sample())
        self.assertTrue(parser.complete());self.assertEqual(output,sample())
        for size in (50,180,4068,4096):
            payload=b'\x04'+c.TAG+b'\0'+b'x'*(size-len(c.TAG)-2)
            parser,output=self.filtered(packet(payload=payload))
            self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)

    def test_fixed_tag_priority_size_and_payload_remain_strict(self):
        for priority in (2,3,5,6,7,8):
            parser,output=self.filtered(self.other(c.TAG,b'UI_STEP_V1|1|C05|CASE|BEGIN|0',priority))
            self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)
        parser,output=self.filtered(self.other(c.TAG,b'x'*145))
        self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)
        for message in (b'',b'PRIVATE',b'UI_STEP_V1|1|C05|CASE|BEGIN|0\0PRIVATE',
                        b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nPRIVATE',b'\xff'):
            parser,output=self.filtered(self.other(c.TAG,message))
            self.assertEqual(parser.final_reason(),'BINARY_PAYLOAD');self.assertFalse(output)

    def test_truncation_and_cross_frame_delimiters_never_recover(self):
        raw=self.other(b'')
        for split in range(1,len(raw)):
            parser,output=self.filtered(raw[:split])
            self.assertEqual(parser.final_reason(),'BINARY_TRUNCATED');self.assertFalse(output)
        parser,output=self.filtered(packet(payload=b'\x04NoDelimiter')+sample())
        self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)
        parser,output=self.filtered(self.other()+sample()+b'\0')
        self.assertEqual(parser.final_reason(),'BINARY_TRUNCATED');self.assertEqual(output,sample())

    def test_stream_cap_and_first_error_survive_ordinary_log_handling(self):
        parser,output=self.filtered(self.other()+packet(uid=10124))
        parser.feed(self.other(b'O'*129));parser.fail('BINARY_TAG')
        self.assertEqual(parser.final_reason(),'BINARY_SOURCE');self.assertFalse(output)
        parser,output=self.filtered(packet(payload=b'\x04NoDelimiter'))
        parser.feed(b'x'*(8*1024*1024+1));parser.feed(sample())
        self.assertEqual(parser.final_reason(),'BINARY_TAG');self.assertFalse(output)
        parser,output=self.filtered(self.other())
        parser.feed(b'x'*(8*1024*1024+1))
        self.assertEqual(parser.final_reason(),'BINARY_STREAM_LIMIT');self.assertFalse(output)

    def test_sequence_and_nesting_still_invalid_after_ordinary_discard(self):
        for follow,reason in ((b'UI_STEP_V1|3|C05|CASE|END|1','SEQUENCE_NUMBER'),
                              (b'UI_STEP_V1|2|C05|MAIN|END|1','SEQUENCE_STEP')):
            parser,output=self.filtered(self.other()+packet()+self.other(b'O'*129)+packet(follow))
            self.assertTrue(parser.complete())
            self.assertEqual(c.decode(output,IDENTITY),empty(reason=reason))

    def test_mocked_relay_retains_only_markers_then_finish_keeps_tail_unverified(self):
        with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()) as stdout,contextlib.redirect_stderr(io.StringIO()) as stderr:
            saved={};output=bytearray();child=Mock();child.stdout.fileno.return_value=42
            chunks=iter([self.other()+sample()+self.other(b'O'*129,nsec=140000000),b''])
            def read(fd,n):
                chunk=next(chunks)
                if not chunk:saved[signal.SIGTERM](signal.SIGTERM,None)
                return chunk
            def write(fd,raw):
                size=min(3,len(raw));output.extend(raw[:size]);return size
            root=Path(t);state=root/'progress-state-private.txt'
            with patch.object(c.signal,'signal',side_effect=lambda sig,fn:saved.update({sig:fn})):
                self.assertEqual(c.relay(['/synthetic/adb','12000','10123',IDENTITY['since'],str(state)],popen=Mock(return_value=child),read=read,write=write),0)
            self.assertEqual(state.read_bytes(),b'stopped\n');self.assertEqual(bytes(output),sample())
            (root/'progress-private.bin').write_bytes(output)
            value=c.finish(root,IDENTITY,CLEAN);c.checked(value)
            self.assertEqual(value['tail_completeness'],'unverified')
            self.assertEqual(value,c.diagnostic(c.decode(sample(),IDENTITY)))
            self.assertFalse(stdout.getvalue());self.assertFalse(stderr.getvalue())

if __name__=='__main__':unittest.main()
