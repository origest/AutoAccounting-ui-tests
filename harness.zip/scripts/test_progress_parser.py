"""Every log sample here is simulated; none is evidence from the November 10 run."""
import sys
import unittest
from pathlib import Path
from progress_parser import parse_progress, STEPS


def line(case='C05', step='CASE', event='BEGIN', t=0):
    return f'UI_STEP_V1|@SEQ@|{case}|{step}|{event}|{t}\n'.encode()

def parsed(raw):
    # Number synthetic samples in append order, except explicit tampering tests.
    if isinstance(raw, bytes):
        n = 0
        while b'@SEQ@' in raw:
            n += 1
            raw = raw.replace(b'@SEQ@', str(n).encode(), 1)
    return parse_progress(raw)


class ProgressParserTests(unittest.TestCase):
    def test_incomplete_pointer_step(self):
        result = parsed(line() + line(step='SWIPE_FIRST', t=3) + line(step='POINTER_UP', t=9))
        self.assertEqual('incomplete', result['diagnostic_state'])
        self.assertEqual(['SWIPE_FIRST', 'POINTER_UP'], result['open_steps'])
        self.assertEqual('C05', result['active_case'])
        self.assertIsNone(result['cases'][4]['end_ms'])
        self.assertNotIn('passed', str(result))

    def test_complete_steps_are_not_pass_results(self):
        raw = line() + line(step='MAIN', t=1) + line(step='MAIN', event='ERROR', t=2) + line(event='END', t=3)
        result = parsed(raw)
        self.assertEqual('observed', result['diagnostic_state'])
        self.assertEqual({'case': 'C05', 'begin_ms': 0, 'end_ms': 3}, result['cases'][4])
        self.assertNotIn('passed', str(result))

    def test_all_19_cases_with_arbitrary_execution_order(self):
        order = [5] + [n for n in range(1, 20) if n != 5]
        raw = b''.join(line(case=f'C{n:02d}', t=i*2) + line(case=f'C{n:02d}', event='END', t=i*2+1) for i,n in enumerate(order))
        result = parsed(raw)
        self.assertEqual('observed', result['diagnostic_state'])
        self.assertTrue(all(x['end_ms'] is not None for x in result['cases']))

    def test_missing_header_and_empty(self):
        self.assertEqual('missing', parsed(b'')['diagnostic_state'])
        self.assertEqual('missing', parsed(b'--------- beginning of main\n')['diagnostic_state'])
        self.assertEqual('incomplete', parsed(b'--------- beginning of main\n' + line())['diagnostic_state'])

    def test_invalid_discards_every_observation(self):
        bad = [b'secret@example.com\n', line(case='C20'), line(step='PATH'), line(t=600001),
               line(t=-1), line().replace(b'|0\n', b'|00\n'), line().replace(b'BEGIN', b'PASS'),
               line()[:-1], line()+line(), line()+line(case='C01'),
               line()+line(step='MAIN', event='END'),
               line()+line(step='MAIN')+line(event='END'),
               line(t=3)+line(step='MAIN', t=2),
               line()+line(step='MAIN')+line(step='IDLE', event='END'),
               line(case='C01')+line(case='C01',step='SWIPE_FIRST'),
               line()+line(event='ERROR'),
               line()+b'\x00\n', line()+b'\r\n', line()+b'\t\n', line()+b'\xff\n',
               line()+b'https://example.invalid/private\n',
               b'x'*129+b'\n', b'\n'*8193, b'x'*(2*1024*1024+1), 'not bytes', None]
        for raw in bad:
            with self.subTest(raw=repr(raw)[:100]):
                result=parsed(raw)
                self.assertEqual('invalid', result['diagnostic_state'])
                self.assertTrue(all(x['begin_ms'] is None for x in result['cases']))
                self.assertIsNone(result['active_case'])

    def test_schema_matches_source_fixed_tokens(self):
        import re, json, zipfile
        root=Path(__file__).resolve().parents[1]
        with zipfile.ZipFile(root/'source.zip') as z:
            source=z.read('app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/IsolatedUiProgress.kt').decode()
        enum=re.search(r'enum class Step \{(.*?)\}',source,re.S).group(1)
        self.assertEqual(STEPS, frozenset(re.findall(r'\b[A-Z_]+\b', enum)))
        expected=json.loads((root/'expected-tests.json').read_text())
        actual=re.findall(r'"([^"#]+#[^"#]+)" to "(C[0-9]+)"', source)
        self.assertEqual([(x['class']+'#'+x['method'],f'C{i:02d}') for i,x in enumerate(expected,1)], actual)

    def test_sequence_replay_gap_and_detail_scope_rejected(self):
        samples=[
            b'UI_STEP_V1|2|C05|CASE|BEGIN|0\n',
            b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nUI_STEP_V1|1|C05|MAIN|BEGIN|0\n',
            line()+line(step='MAIN')+line(step='MAIN'),
        ]
        for step in ('MAIN','IDLE','POINTER_DOWN','POINTER_MOVE','POINTER_UP'):
            samples.append(line(case='C01')+line(case='C01',step=step))
        for sample in samples:
            self.assertEqual('invalid', parsed(sample)['diagnostic_state'])

    def test_precise_sequence_reasons_keep_all_or_nothing_observations(self):
        samples=[(None,'SEQUENCE_INPUT'),(b'\xff\n','SEQUENCE_ENCODING'),
                 (line()[:-1],'SEQUENCE_FRAMING'),(b'x'*129+b'\n','SEQUENCE_LIMIT'),
                 (b'PRIVATE\n','SEQUENCE_TOKEN'),
                 (b'UI_STEP_V1|2|C05|CASE|BEGIN|0\n','SEQUENCE_NUMBER'),
                 (line(t=3)+line(step='MAIN',t=2),'SEQUENCE_TIME'),
                 (line()+line(event='END')+line(),'SEQUENCE_CASE'),
                 (line()+line(step='MAIN',event='END'),'SEQUENCE_STEP')]
        for raw,reason in samples:
            with self.subTest(reason=reason):
                result=parsed(raw)
                self.assertEqual(result['reason'],reason)
                self.assertEqual(result['phase'],'sequence')
                self.assertTrue(all(x['begin_ms'] is None for x in result['cases']))
                self.assertEqual(result['open_steps'],[])
                self.assertIsNone(result['last_event_ms'])

    def test_source_semantic_interleavings_are_synthetic_not_run_evidence(self):
        # Synchronized individual emissions cannot prevent A-BEGIN, B-BEGIN,
        # A-END, B-END if their action scopes overlap on different threads.
        crossed=(line()+line(step='MAIN')+line(step='IDLE')+
                 line(step='MAIN',event='END')+line(step='IDLE',event='END'))
        duplicate=line()+line(step='MAIN')+line(step='MAIN')
        unfinished=line()+line(step='MAIN')+line(event='END')
        # A missing Log.i delivery makes a sequence gap; no runtime claim.
        missing=b'UI_STEP_V1|1|C05|CASE|BEGIN|0\nUI_STEP_V1|3|C05|MAIN|BEGIN|1\n'
        for raw,reason in ((crossed,'SEQUENCE_STEP'),(duplicate,'SEQUENCE_STEP'),
                           (unfinished,'SEQUENCE_CASE'),(missing,'SEQUENCE_NUMBER')):
            self.assertEqual(parsed(raw)['reason'],reason)
        # Ordinary thrown actions unwind valid LIFO ERROR events, not a defect.
        unwound=(line()+line(step='MAIN')+line(step='IDLE')+
                 line(step='IDLE',event='ERROR')+line(step='MAIN',event='ERROR')+line(event='END'))
        self.assertEqual(parsed(unwound)['diagnostic_state'],'observed')
        self.assertEqual(parsed(unwound)['reason'],'NONE')

if __name__=='__main__': unittest.main()
