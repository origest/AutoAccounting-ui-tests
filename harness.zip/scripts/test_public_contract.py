import ast
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]


class PublicContractTests(unittest.TestCase):
    def test_exact_cases(self):
        expected=json.loads((ROOT/'expected-tests.json').read_text())
        self.assertEqual(len(expected),19)
        self.assertEqual(sum(x['class'].endswith('DataPageIsolatedUiTest') for x in expected),10)
        self.assertEqual(sum(x['class'].endswith('RefundIsolatedUiTest') for x in expected),9)

    def test_workflow_is_manual_and_small(self):
        text=(ROOT/'.github/workflows/isolated-ui.yml').read_text()
        self.assertIn('workflow_dispatch:',text)
        self.assertIn('timeout-minutes: 30',text)
        for forbidden in ('pull_request:', 'pull_request_target:', 'schedule:', '\n  push:',
                          'actions/cache@','actions/setup-java@','sudo ', 'retention-days: 90'):
            self.assertNotIn(forbidden,text)
        self.assertNotIn('evidence/instrumentation.txt',text)
        self.assertNotIn('*.apk',text)

    def test_no_privilege_or_network_setting_commands(self):
        source=(ROOT/'scripts/run_ui.py').read_text()
        ast.parse(source)
        for forbidden in ("'sudo'", "'chmod'", "'setfacl'", "'udevadm'", "'iptables'", "'ip6tables'",
                          "adbc('root'", "'settings','put'", "'svc','wifi'", "'svc','data'"):
            self.assertNotIn(forbidden,source)

    def test_only_runtime_official_dependencies(self):
        lock=json.loads((ROOT/'runtime-lock.json').read_text())
        self.assertEqual(set(lock['downloads']),{'jdk','platform36','build_tools','platform_tools','emulator','aosp33'})
        for entry in lock['downloads'].values():
            self.assertRegex(entry['sha256'],r'^[0-9a-f]{64}$')
            self.assertGreater(entry['size'],0)
        self.assertTrue(lock['original_saved_apks_are_not_used'])


if __name__=='__main__': unittest.main()
