import ast
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT=Path(__file__).resolve().parents[1]


class PublicContractTests(unittest.TestCase):
    def test_exact_cases(self):
        expected=json.loads((ROOT/'expected-tests.json').read_text())
        self.assertEqual(len(expected),19)
        self.assertEqual(sum(x['class'].endswith('DataPageIsolatedUiTest') for x in expected),10)
        self.assertEqual(sum(x['class'].endswith('RefundIsolatedUiTest') for x in expected),9)

    def test_workflow_is_manual_and_small(self):
        text=(ROOT/'.github/workflows/isolated-ui.yml').read_text()
        self.assertIn('workflow_dispatch:',text)
        self.assertIn('timeout-minutes: 30',text)
        for forbidden in ('pull_request:', 'pull_request_target:', 'schedule:', '\n  push:',
                          'actions/cache@','actions/setup-java@','sudo ', 'retention-days: 90'):
            self.assertNotIn(forbidden,text)
        self.assertNotIn('evidence/instrumentation.txt',text)
        self.assertNotIn('*.apk',text)

    def test_no_privilege_or_network_setting_commands(self):
        source=(ROOT/'scripts/run_ui.py').read_text()
        ast.parse(source)
        for forbidden in ("'sudo'", "'chmod'", "'setfacl'", "'udevadm'", "'iptables'", "'ip6tables'",
                          "adbc('root'", "'settings','put'", "'svc','wifi'", "'svc','data'"):
            self.assertNotIn(forbidden,source)

    def test_only_runtime_official_dependencies(self):
        lock=json.loads((ROOT/'runtime-lock.json').read_text())
        self.assertEqual(set(lock['downloads']),{'jdk','platform36','build_tools','platform_tools','emulator','aosp33'})
        for entry in lock['downloads'].values():
            self.assertRegex(entry['sha256'],r'^[0-9a-f]{64}$')
            self.assertGreater(entry['size'],0)
        self.assertTrue(lock['original_saved_apks_are_not_used'])

    def test_source_archive_size_hash_and_canonical_tree_are_bound(self):
        spec=json.loads((ROOT/'runtime-lock.json').read_text())['source']
        data=(ROOT/spec['path']).read_bytes()
        self.assertEqual(len(data),spec['size'])
        self.assertEqual(hashlib.sha256(data).hexdigest(),spec['sha256'])
        rows=[]
        with zipfile.ZipFile(ROOT/spec['path']) as archive:
            entries=archive.infolist()
            self.assertEqual(len(entries),953)
            self.assertEqual(len({i.filename for i in entries}),953)
            for info in sorted(entries,key=lambda i:i.filename):
                body=archive.read(info)
                rows.append(f'{stat.S_IMODE(info.external_attr >> 16):06o} '
                            f'{len(body)} {hashlib.sha256(body).hexdigest()} {info.filename}\n')
        self.assertEqual(hashlib.sha256(''.join(rows).encode()).hexdigest(),spec['tree_sha256'])

    def test_runner_rejects_mismatched_source_size_before_hash_or_extraction(self):
        import run_ui
        for size in (2,True,0,-1):
            with self.subTest(size=size),tempfile.TemporaryDirectory() as temporary:
                root=Path(temporary); (root/'source.zip').write_bytes(b'x')
                config={'source':{'mode':'zip','path':'source.zip','size':size,'sha256':'0'*64}}
                with patch.object(run_ui,'ROOT',root),patch.object(run_ui,'sha256') as digest,\
                        patch.object(run_ui,'unpack_zip') as unpack:
                    with self.assertRaisesRegex(run_ui.Blocked,'SOURCE_BUNDLE_INVALID'):
                        run_ui.source(root,config)
                    digest.assert_not_called(); unpack.assert_not_called()


if __name__=='__main__': unittest.main()
