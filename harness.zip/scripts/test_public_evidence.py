import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import public_evidence as p
from result_parser import junit_xml


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.env=patch.dict(os.environ,{'GITHUB_RUN_ID':'1','GITHUB_RUN_ATTEMPT':'1',
            'GITHUB_SHA':'a'*40,'GITHUB_REPOSITORY':'origest/test','GITHUB_STEP_SUMMARY':str(self.root/'summary.md')})
        self.env.start()
        self.location=patch.object(p,'DIRECTORY',self.root/'evidence'); self.location.start()
    def tearDown(self):
        self.location.stop(); self.env.stop(); self.temp.cleanup()

    def failure(self):
        return {'status':'blocked-or-failed','stage':'build','code':'BUILD_FAILED','new_build':True}

    def test_new_evidence_can_publish_sanitized_failure(self):
        p.init(); p.write('summary.json',self.failure())
        with contextlib.redirect_stdout(io.StringIO()) as out: p.publish()
        self.assertIn('BUILD_FAILED',out.getvalue())
        self.assertLess((self.root/'summary.md').stat().st_size,1024*1024)

    def test_never_adopts_existing_or_symlink_directory(self):
        p.DIRECTORY.mkdir()
        with self.assertRaises(FileExistsError): p.init()
        with self.assertRaises((ValueError,FileNotFoundError)): p.validate()
        p.DIRECTORY.rmdir(); other=self.root/'other'; other.mkdir(); p.DIRECTORY.symlink_to(other)
        with self.assertRaises(ValueError): p.init()

    def test_rejects_extra_json_fields_and_duplicate_keys(self):
        p.init(); bad=self.failure(); bad['raw_log']='DO_NOT_PUBLISH'
        p.write('summary.json',bad)
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()
        (p.DIRECTORY/'summary.json').write_text('{"status":1,"status":2}')
        with self.assertRaises(ValueError): p.read_json(p.DIRECTORY/'summary.json')

    def test_rejects_dangling_output_link_and_hardlink(self):
        p.init(); p.write('summary.json',self.failure())
        (p.DIRECTORY/'kvm.json').symlink_to(self.root/'missing')
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()
        (p.DIRECTORY/'kvm.json').unlink(); os.link(p.DIRECTORY/'summary.json',self.root/'linked')
        with self.assertRaises(ValueError): p.read_json(p.DIRECTORY/'summary.json')

    def test_pass_summary_alone_is_not_publishable(self):
        p.init(); p.write('summary.json',{'status':'passed','tests':19,'failures':0,'errors':0,
            'skipped':0,'device_api':33,'device_abi':'x86_64','new_build':True})
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()

    def test_junit_rejects_text_and_unknown_methods(self):
        p.init(); expected=json.loads((p.ROOT/'expected-tests.json').read_text())
        xml=junit_xml([(x['class'],x['method']) for x in expected]); path=p.DIRECTORY/'TEST-isolated-ui.xml'
        path.write_text(xml); self.assertEqual(p.checked_junit(path),xml)
        for bad in [xml.replace('<testcase','PRIVATE<testcase',1),
                    '<!DOCTYPE testsuite [<!ENTITY x "secret">]>'+xml,
                    xml.replace(expected[0]['method'],'private_unexpected_value')]:
            path.write_text(bad)
            with self.assertRaises(ValueError): p.checked_junit(path)

    def test_rejects_step_summary_overflow(self):
        p.init(); p.write('summary.json',self.failure())
        (self.root/'summary.md').write_text('x'*(1024*1024))
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()

    def test_cannot_downgrade_prior_kvm_change_when_scratch_disappears(self):
        p.init()
        for state in ('lease_active','restore_failed','original_acl_verified'):
            prior={'changed_permissions':True,'restore_verified':state=='original_acl_verified','state':state}
            p.write('kvm.json',prior)
            with self.assertRaises(ValueError):
                p.record_kvm_restore({'changed_permissions':False,'restore_verified':False,'state':'not_needed'})
            self.assertEqual(p.read_json(p.DIRECTORY/'kvm.json'),prior)

    def test_complete_pass_publishes_only_synthetic_schema(self):
        p.init(); p.write('summary.json',{'status':'passed','tests':19,'failures':0,'errors':0,
            'skipped':0,'device_api':33,'device_abi':'x86_64','new_build':True})
        result={'changed_permissions':False,'restore_verified':False,'state':'not_needed',
            'diagnostic':{'phase':'complete','reason':'NONE','write_attempted':False,
                          'acl_readback':'not_checked','receipt':'not_needed'}}
        p.write('kvm.json',result)
        p.write('cleanup.json',{'runtime':{'state':'stopped_verified','reason':'NONE'},
            'kvm_attempts':{'main':result,'always':result},'evidence_errors':[]})
        p.write('disk.json',[{'stage':'initial','free_bytes':p.MIN_FREE,'minimum_bytes':p.MIN_FREE}])
        config=json.loads((p.ROOT/'runtime-lock.json').read_text())
        apks={}
        for name,suffix in (('target',''),('instrumentation','.test')):
            package='net.ankio.auto.isolatedui'+suffix
            apks[name]={'sha256':'a'*64,'size':42,'package':package,'certificate_sha256':'b'*64,
                'manifest':{'package':package,'test_only':name=='target','requested_permissions':0,'production_components':0}}
        p.write('identity.json',{'kind':'new-public-source-build','commit':'a'*40,
            'source_bundle_sha256':config['source']['sha256'],'apks':apks})
        expected=json.loads((p.ROOT/'expected-tests.json').read_text())
        p.write_junit([(x['class'],x['method']) for x in expected])
        with contextlib.redirect_stdout(io.StringIO()) as out: p.publish()
        self.assertEqual(len(out.getvalue().splitlines()),6)
        self.assertIn('passed',out.getvalue())



class BuildFailureCategoryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.log=self.root/'private.log'
    def tearDown(self): self.temp.cleanup()
    def classify(self,text,exit_code=1):
        self.log.write_bytes(text if isinstance(text,bytes) else text.encode())
        return p.classify_build_failure(self.log,exit_code)
    def test_known_categories_are_fixed_values_only(self):
        cases={
            'Verification of Gradle distribution failed!':'GRADLE_DISTRIBUTION_CHECKSUM',
            'Could not find or load main class org.gradle.wrapper.GradleWrapperMain':'WRAPPER_STARTUP',
            'Could not download Gradle distribution from https://private.invalid/?token=PRIVATE':'GRADLE_DISTRIBUTION_DOWNLOAD',
            'Dependency verification failed for configuration :classpath':'DEPENDENCY_VERIFICATION',
            'Plugin Repositories (could not resolve plugin artifact private:private:private)':'PLUGIN_RESOLUTION',
            'Could not resolve all files for configuration PRIVATE':'DEPENDENCY_RESOLUTION',
            'SDK location not found. PRIVATE':'SDK_LOCATION',
            'Failed to find Build Tools revision PRIVATE':'SDK_PACKAGE',
            'licenses have not been accepted':'SDK_LICENSE',
            'Android Gradle plugin requires Java PRIVATE':'JAVA_VERSION',
            'JAVA_HOME is set to an invalid directory: PRIVATE':'JAVA_TOOLCHAIN',
            'Compilation error. See log for more details':'COMPILATION',
            'Gradle build daemon disappeared unexpectedly':'GRADLE_DAEMON_DISAPPEARED',
            'java.lang.OutOfMemoryError: Java heap space':'EXPLICIT_OUT_OF_MEMORY',
            'PKIX path building failed: PRIVATE':'TLS_CERTIFICATE',
            'Network is unreachable':'NETWORK_CONNECTION',
        }
        for text,reason in cases.items():
            with self.subTest(reason=reason):
                result=self.classify(text+'\nPRIVATE_SECRET=do-not-publish')
                self.assertEqual(result,{'reason':reason,'exit_code':1})
                self.assertNotIn('PRIVATE',json.dumps(result))
    def test_unknown_and_signals_do_not_infer_oom(self):
        self.assertEqual(self.classify('PRIVATE_SECRET=-9',-9),{'reason':'UNKNOWN','exit_code':-9})
        self.assertEqual(self.classify('Gradle build daemon disappeared unexpectedly',-9)['reason'],
                         'GRADLE_DAEMON_DISAPPEARED')
    def test_tail_is_bounded_and_final_failure_takes_precedence(self):
        self.assertEqual(self.classify('java.lang.OutOfMemoryError'+'x'*(300*1024))['reason'],'UNKNOWN')
        result=self.classify('java.lang.OutOfMemoryError\nFAILURE: Build failed with an exception.\n'
                             'Plugin Repositories (could not resolve plugin artifact SECRET)')
        self.assertEqual(result['reason'],'PLUGIN_RESOLUTION')
        multi=self.classify('java.lang.OutOfMemoryError\nFAILURE: Build completed with 2 failures.\nDependency verification failed')
        self.assertEqual(multi['reason'],'DEPENDENCY_VERIFICATION')
        with patch.object(p.os,'read',wraps=os.read) as read:
            p.classify_build_failure(self.log,1)
            self.assertEqual(read.call_count,1);self.assertEqual(read.call_args.args[1],256*1024)
    def test_invalid_utf8_never_leaks(self):
        self.assertEqual(self.classify(b'\xff\xfe PRIVATE\x00SECRET')['reason'],'UNKNOWN')
    def test_symlinks_hardlinks_missing_files_and_fifo_are_not_read(self):
        self.log.symlink_to(self.root/'missing')
        self.assertEqual(p.classify_build_failure(self.log,1)['reason'],'UNKNOWN');self.log.unlink()
        self.log.write_text('java.lang.OutOfMemoryError');os.link(self.log,self.root/'hardlink')
        self.assertEqual(p.classify_build_failure(self.log,1)['reason'],'UNKNOWN');self.log.unlink()
        os.mkfifo(self.log)
        self.assertEqual(p.classify_build_failure(self.log,1)['reason'],'UNKNOWN');self.log.unlink()
        self.assertEqual(p.classify_build_failure(self.log,1)['reason'],'UNKNOWN')
    def test_summary_rejects_unbounded_or_wrongly_scoped_fields(self):
        base={'status':'blocked-or-failed','stage':'build','code':'BUILD_FAILED','new_build':True,
              'build_failure':{'reason':'UNKNOWN','exit_code':1}}
        self.assertEqual(p.checked_json('summary.json',base),base)
        for bad in [dict(base,stage='instrumentation'),dict(base,code='BUILD_TIMEOUT'),
                    dict(base,build_failure={'reason':'SECRET','exit_code':1}),
                    dict(base,build_failure={'reason':'UNKNOWN','exit_code':0}),
                    dict(base,build_failure={'reason':'UNKNOWN','exit_code':True}),
                    dict(base,build_failure={'reason':'UNKNOWN','exit_code':256}),
                    dict(base,build_failure={'reason':'UNKNOWN','exit_code':1,'raw':'SECRET'})]:
            with self.assertRaises(ValueError):p.checked_json('summary.json',bad)
    def test_zero_bool_and_out_of_range_exit_are_rejected(self):
        for code in [0,True,256,-256,'1',None]:
            with self.assertRaises(ValueError):self.classify('SECRET',code)
    def test_publication_outputs_only_fixed_build_category(self):
        diagnostic=self.classify('Plugin Repositories (could not resolve plugin artifact SECRET_PERSONAL_VALUE)')
        values={'GITHUB_RUN_ID':'1','GITHUB_RUN_ATTEMPT':'1','GITHUB_SHA':'a'*40,
                'GITHUB_REPOSITORY':'origest/test','GITHUB_STEP_SUMMARY':str(self.root/'summary.md')}
        with patch.dict(os.environ,values),patch.object(p,'DIRECTORY',self.root/'evidence'):
            p.init();p.write('summary.json',{'status':'blocked-or-failed','stage':'build',
                'code':'BUILD_FAILED','new_build':True,'build_failure':diagnostic})
            with contextlib.redirect_stdout(io.StringIO()) as out:p.publish()
            self.assertIn('PLUGIN_RESOLUTION',out.getvalue())
            self.assertNotIn('SECRET_PERSONAL_VALUE',out.getvalue())
            self.assertNotIn('SECRET_PERSONAL_VALUE',(self.root/'summary.md').read_text())

if __name__=='__main__': unittest.main()
