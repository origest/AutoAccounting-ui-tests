import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import public_evidence as p
from result_parser import junit_xml


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.env=patch.dict(os.environ,{'GITHUB_RUN_ID':'1','GITHUB_RUN_ATTEMPT':'1',
            'GITHUB_SHA':'a'*40,'GITHUB_REPOSITORY':'origest/test','GITHUB_STEP_SUMMARY':str(self.root/'summary.md')})
        self.env.start()
        self.location=patch.object(p,'DIRECTORY',self.root/'evidence'); self.location.start()
    def tearDown(self):
        self.location.stop(); self.env.stop(); self.temp.cleanup()

    def failure(self):
        return {'status':'blocked-or-failed','stage':'build','code':'BUILD_FAILED','new_build':True}

    def test_new_evidence_can_publish_sanitized_failure(self):
        p.init(); p.write('summary.json',self.failure())
        with contextlib.redirect_stdout(io.StringIO()) as out: p.publish()
        self.assertIn('BUILD_FAILED',out.getvalue())
        self.assertLess((self.root/'summary.md').stat().st_size,1024*1024)

    def test_never_adopts_existing_or_symlink_directory(self):
        p.DIRECTORY.mkdir()
        with self.assertRaises(FileExistsError): p.init()
        with self.assertRaises((ValueError,FileNotFoundError)): p.validate()
        p.DIRECTORY.rmdir(); other=self.root/'other'; other.mkdir(); p.DIRECTORY.symlink_to(other)
        with self.assertRaises(ValueError): p.init()

    def test_rejects_extra_json_fields_and_duplicate_keys(self):
        p.init(); bad=self.failure(); bad['raw_log']='DO_NOT_PUBLISH'
        p.write('summary.json',bad)
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()
        (p.DIRECTORY/'summary.json').write_text('{"status":1,"status":2}')
        with self.assertRaises(ValueError): p.read_json(p.DIRECTORY/'summary.json')

    def test_rejects_dangling_output_link_and_hardlink(self):
        p.init(); p.write('summary.json',self.failure())
        (p.DIRECTORY/'kvm.json').symlink_to(self.root/'missing')
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()
        (p.DIRECTORY/'kvm.json').unlink(); os.link(p.DIRECTORY/'summary.json',self.root/'linked')
        with self.assertRaises(ValueError): p.read_json(p.DIRECTORY/'summary.json')

    def test_pass_summary_alone_is_not_publishable(self):
        p.init(); p.write('summary.json',{'status':'passed','tests':19,'failures':0,'errors':0,
            'skipped':0,'device_api':33,'device_abi':'x86_64','new_build':True})
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()

    def test_junit_rejects_text_and_unknown_methods(self):
        p.init(); expected=json.loads((p.ROOT/'expected-tests.json').read_text())
        xml=junit_xml([(x['class'],x['method']) for x in expected]); path=p.DIRECTORY/'TEST-isolated-ui.xml'
        path.write_text(xml); self.assertEqual(p.checked_junit(path),xml)
        for bad in [xml.replace('<testcase','PRIVATE<testcase',1),
                    '<!DOCTYPE testsuite [<!ENTITY x "secret">]>'+xml,
                    xml.replace(expected[0]['method'],'private_unexpected_value')]:
            path.write_text(bad)
            with self.assertRaises(ValueError): p.checked_junit(path)

    def test_rejects_step_summary_overflow(self):
        p.init(); p.write('summary.json',self.failure())
        (self.root/'summary.md').write_text('x'*(1024*1024))
        with self.assertRaises(ValueError),contextlib.redirect_stdout(io.StringIO()): p.publish()

    def test_cannot_downgrade_prior_kvm_change_when_scratch_disappears(self):
        p.init()
        for state in ('lease_active','restore_failed','original_acl_verified'):
            prior={'changed_permissions':True,'restore_verified':state=='original_acl_verified','state':state}
            p.write('kvm.json',prior)
            with self.assertRaises(ValueError):
                p.record_kvm_restore({'changed_permissions':False,'restore_verified':False,'state':'not_needed'})
            self.assertEqual(p.read_json(p.DIRECTORY/'kvm.json'),prior)

    def test_complete_pass_publishes_only_synthetic_schema(self):
        p.init(); p.write('summary.json',{'status':'passed','tests':19,'failures':0,'errors':0,
            'skipped':0,'device_api':33,'device_abi':'x86_64','new_build':True})
        p.write('kvm.json',{'changed_permissions':False,'restore_verified':False,'state':'not_needed'})
        p.write('disk.json',[{'stage':'initial','free_bytes':p.MIN_FREE,'minimum_bytes':p.MIN_FREE}])
        config=json.loads((p.ROOT/'runtime-lock.json').read_text())
        apks={}
        for name,suffix in (('target',''),('instrumentation','.test')):
            package='net.ankio.auto.isolatedui'+suffix
            apks[name]={'sha256':'a'*64,'size':42,'package':package,'certificate_sha256':'b'*64,
                'manifest':{'package':package,'test_only':name=='target','requested_permissions':0,'production_components':0}}
        p.write('identity.json',{'kind':'new-public-source-build','commit':'a'*40,
            'source_bundle_sha256':config['source']['sha256'],'apks':apks})
        expected=json.loads((p.ROOT/'expected-tests.json').read_text())
        p.write_junit([(x['class'],x['method']) for x in expected])
        with contextlib.redirect_stdout(io.StringIO()) as out: p.publish()
        self.assertEqual(len(out.getvalue().splitlines()),5)
        self.assertIn('passed',out.getvalue())


if __name__=='__main__': unittest.main()
