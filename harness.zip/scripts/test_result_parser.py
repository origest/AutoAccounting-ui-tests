import json
from pathlib import Path
import unittest
from result_parser import parse_output

EXPECTED = json.loads((Path(__file__).resolve().parents[1] / 'expected-tests.json').read_text())


def output(cases=EXPECTED):
    lines = []
    for case in cases:
        for code in (1, 0):
            lines += [f"INSTRUMENTATION_STATUS: class={case['class']}",
                      f"INSTRUMENTATION_STATUS: test={case['method']}",
                      'INSTRUMENTATION_STATUS: numtests=19',
                      f'INSTRUMENTATION_STATUS_CODE: {code}']
    return '\n'.join(lines) + '\nINSTRUMENTATION_CODE: -1\n'


class ParserTests(unittest.TestCase):
    def test_all_19(self):
        self.assertEqual(len(parse_output(output(), EXPECTED)), 19)

    def test_rejects_missing(self):
        with self.assertRaises(ValueError):
            parse_output(output(EXPECTED[:-1]), EXPECTED)

    def test_rejects_duplicate(self):
        with self.assertRaises(ValueError):
            parse_output(output(EXPECTED[:-1] + EXPECTED[:1]), EXPECTED)

    def test_rejects_failed_skipped_and_incomplete(self):
        for code in (-1, -2, -3, -4):
            with self.subTest(code=code), self.assertRaises(ValueError):
                parse_output(output().replace('STATUS_CODE: 0', f'STATUS_CODE: {code}', 1), EXPECTED)
        with self.assertRaises(ValueError):
            parse_output(output().replace('INSTRUMENTATION_CODE: -1', ''), EXPECTED)

    def test_rejects_wrong_count(self):
        with self.assertRaises(ValueError):
            parse_output(output().replace('numtests=19', 'numtests=18'), EXPECTED)

    def test_rejects_reordered_terminal_events(self):
        with self.assertRaises(ValueError):
            parse_output(output().replace('STATUS_CODE: 1', 'STATUS_CODE: 0', 1), EXPECTED)

    def test_rejects_extra_summary_failure(self):
        with self.assertRaises(ValueError):
            parse_output(output() + '\nINSTRUMENTATION_FAILED: crashed\n', EXPECTED)

    def test_rejects_terminal_before_start(self):
        wrong=output().replace('STATUS_CODE: 1','STATUS_CODE: X').replace('STATUS_CODE: 0','STATUS_CODE: 1').replace('STATUS_CODE: X','STATUS_CODE: 0')
        with self.assertRaises(ValueError): parse_output(wrong,EXPECTED)

    def test_rejects_premature_and_repeated_final(self):
        for wrong in ['INSTRUMENTATION_CODE: -1\n'+output(), output()+'INSTRUMENTATION_CODE: -1\n']:
            with self.subTest(wrong=wrong[:40]), self.assertRaises(ValueError): parse_output(wrong,EXPECTED)

    def test_rejects_tail_bundle(self):
        with self.assertRaises(ValueError):
            parse_output(output()+'INSTRUMENTATION_STATUS: class=unfinished\n',EXPECTED)

    def test_rejects_overlap(self):
        first=output().split('INSTRUMENTATION_STATUS_CODE: 1',1)[0]+'INSTRUMENTATION_STATUS_CODE: 1\n'
        with self.assertRaises(ValueError): parse_output(first+output(),EXPECTED)

    def test_rejects_malformed_protocol_and_abort(self):
        for tail in ['INSTRUMENTATION_STATUS_CODE: broken','INSTRUMENTATION_CODE: broken',
                     'INSTRUMENTATION_STATUS: broken','INSTRUMENTATION_ABORTED: error',
                     'INSTRUMENTATION_RESULT: shortMsg=crash']:
            with self.subTest(tail=tail),self.assertRaises(ValueError): parse_output(output()+tail,EXPECTED)


# These fixtures are synthetic protocol only, not real device test outcomes.
import os
import stat
import subprocess
import sys
import tempfile
import time
from unittest import mock
from result_parser import (parse_partial_output, read_partial_output, PARTIAL_EXPECTED_CASES,
                           MAX_PARTIAL_BYTES, MAX_PARTIAL_LINE_BYTES, MAX_PARTIAL_LINES)


def partial_bundle(case, code, number=1, *, stack=None, stream=None, extra=''):
    if stream is None:
        stream = '.' if code == 0 else ''
    lines = [f"INSTRUMENTATION_STATUS: class={case['class']}",
             f'INSTRUMENTATION_STATUS: current={number}',
             'INSTRUMENTATION_STATUS: id=AndroidJUnitRunner',
             'INSTRUMENTATION_STATUS: numtests=19']
    if stack is not None:
        lines.append('INSTRUMENTATION_STATUS: stack=' + stack)
    lines += ['INSTRUMENTATION_STATUS: stream=' + stream,
              f"INSTRUMENTATION_STATUS: test={case['method']}",
              f'INSTRUMENTATION_STATUS_CODE: {code}']
    return '\n'.join(lines) + '\n' + extra


def partial_run(cases=EXPECTED, codes=None, final=True, result=True):
    codes = codes or [0] * len(cases)
    text = ''
    last_class = None
    for number, (case, code) in enumerate(zip(cases, codes), 1):
        stream = '\n' + case['class'] + ':' if case['class'] != last_class else ''
        text += partial_bundle(case, 1, number, stream=stream)
        text += partial_bundle(case, code, number)
        last_class = case['class']
    if final:
        if result:
            text += ('INSTRUMENTATION_RESULT: stream=\nTime: 1.23\n\n'
                     + ('FAILURES!!!\nTests run: 19, Failures: 1\n' if any(c in (-1, -2) for c in codes)
                        else 'OK (19 tests)\n') + '\n')
        text += 'INSTRUMENTATION_CODE: -1\n'
    return text


class PartialParserTests(unittest.TestCase):
    def checked(self, raw):
        value = parse_partial_output(raw, EXPECTED)
        self.assertEqual(set(value), {'cases', 'protocol_state'})
        self.assertEqual(len(value['cases']), 19)
        self.assertEqual([(x['class'], x['method']) for x in value['cases']], list(PARTIAL_EXPECTED_CASES))
        for case in value['cases']:
            self.assertEqual(set(case), {'class', 'method', 'state', 'execution_ordinal', 'failure_hint', 'failure_phase', 'failure_wait'})
            self.assertIn(case['state'], {'passed', 'failed', 'skipped', 'started', 'unknown'})
            self.assertEqual(case['failure_hint'], 'UNKNOWN' if case['state'] == 'failed' else 'NOT_APPLICABLE')
            if case['state'] == 'unknown':
                self.assertIsNone(case['execution_ordinal'])
            else:
                self.assertIs(type(case['execution_ordinal']), int)
                self.assertIn(case['execution_ordinal'], range(1, 20))
        self.assertIn(value['protocol_state'], {'complete', 'incomplete', 'invalid'})
        return value

    def invalid(self, raw):
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'invalid')
        self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})
        return value

    def test_empty_has_no_observation(self):
        for raw in ('', b''):
            value = self.checked(raw)
            self.assertEqual(value['protocol_state'], 'incomplete')
            self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})

    def test_start_pass_and_unknown_are_distinct(self):
        raw = partial_run(EXPECTED[:1], final=False) + partial_bundle(EXPECTED[1], 1, 2)
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual([x['state'] for x in value['cases']], ['passed', 'started'] + ['unknown'] * 17)

    def test_full_complete_is_not_an_alternate_pass_gate(self):
        raw = partial_run()
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'complete')
        self.assertEqual({x['state'] for x in value['cases']}, {'passed'})
        self.assertEqual(len(parse_output(raw, EXPECTED)), 19)
        mixed = partial_run(codes=[-2, -3, -4, -1] + [0] * 15)
        value = self.checked(mixed)
        self.assertEqual(value['protocol_state'], 'complete')
        self.assertEqual([x['state'] for x in value['cases'][:4]], ['failed', 'skipped', 'skipped', 'failed'])
        with self.assertRaises(ValueError):
            parse_output(mixed, EXPECTED)

    def test_all_terminal_without_final_still_incomplete(self):
        value = self.checked(partial_run(final=False))
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual({x['state'] for x in value['cases']}, {'passed'})

    def test_complete_without_result_prose(self):
        self.assertEqual(self.checked(partial_run(result=False))['protocol_state'], 'complete')

    def test_valid_order_is_observed_not_inferred(self):
        value = self.checked(partial_run(list(reversed(EXPECTED))))
        self.assertEqual(value['protocol_state'], 'complete')
        self.assertEqual({x['state'] for x in value['cases']}, {'passed'})
        self.assertEqual([x['execution_ordinal'] for x in value['cases']], list(range(19, 0, -1)))

    def test_minimal_sorted_bundles(self):
        raw = ''
        for code in (1, 0):
            raw += (f"INSTRUMENTATION_STATUS: class={EXPECTED[0]['class']}\n"
                    'INSTRUMENTATION_STATUS: numtests=19\n'
                    f"INSTRUMENTATION_STATUS: test={EXPECTED[0]['method']}\n"
                    f'INSTRUMENTATION_STATUS_CODE: {code}\n')
        self.assertEqual(self.checked(raw)['cases'][0]['state'], 'passed')

    def test_failure_trace_is_never_exported(self):
        secret = 'https://private.invalid/a?token=SECRET /private/file SECRET_ENV'
        trace = 'java.lang.AssertionError: ' + secret + '\n\tat fixture.Test.body(Test.kt:1)'
        raw = partial_bundle(EXPECTED[0], 1) + partial_bundle(EXPECTED[0], -2, stack=trace,
            stream='\nError in ' + EXPECTED[0]['method'] + ':\n' + trace)
        value = self.checked(raw)
        self.assertEqual(value['cases'][0]['state'], 'failed')
        self.assertNotIn('SECRET', json.dumps(value))
        self.assertNotIn('private', json.dumps(value))

    def test_clean_partial_bundle_does_not_count_as_start(self):
        raw = partial_run(EXPECTED[:1], final=False)
        raw += f"INSTRUMENTATION_STATUS: class={EXPECTED[1]['class']}\n"
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual([x['state'] for x in value['cases'][:2]], ['passed', 'unknown'])

    def test_unknown_identity_never_appears_in_output(self):
        for key in ('class', 'method'):
            bad = dict(EXPECTED[0]); bad[key] = 'SECRET_UNAPPROVED'
            value = self.invalid(partial_bundle(bad, 1))
            self.assertNotIn('SECRET_UNAPPROVED', json.dumps(value))
        other = next(x for x in EXPECTED if x['class'] != EXPECTED[0]['class'])
        bad = dict(EXPECTED[0], method=other['method'])
        self.invalid(partial_bundle(bad, 1))

    def test_invalid_expected_never_becomes_an_allowlist(self):
        variants = [None, tuple(EXPECTED), EXPECTED[:-1], EXPECTED[:-1] + EXPECTED[:1],
                    [dict(x, extra='SECRET') for x in EXPECTED],
                    [dict(x, method='SECRET') for x in EXPECTED]]
        for expected in variants:
            with self.subTest(expected_type=type(expected).__name__):
                value = parse_partial_output(partial_run(), expected)
                self.assertEqual(value['protocol_state'], 'invalid')
                self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})
                self.assertNotIn('SECRET', json.dumps(value))

    def test_duplicate_fields_and_wrong_order(self):
        raw = partial_bundle(EXPECTED[0], 1)
        first = raw.splitlines()[0] + '\n'
        self.invalid(first + raw)
        self.invalid(raw.replace('INSTRUMENTATION_STATUS: id=AndroidJUnitRunner\n', '')
                     .replace('INSTRUMENTATION_STATUS_CODE: 1',
                              'INSTRUMENTATION_STATUS: id=AndroidJUnitRunner\nINSTRUMENTATION_STATUS_CODE: 1'))

    def test_overlap_terminal_without_start_and_identity_mismatch(self):
        start = partial_bundle(EXPECTED[0], 1)
        for raw in (partial_bundle(EXPECTED[0], 0), start + start,
                    start + partial_bundle(EXPECTED[1], 1, 2),
                    start + partial_bundle(EXPECTED[1], 0),
                    partial_run(EXPECTED[:1], final=False) + start):
            with self.subTest(raw_len=len(raw)):
                self.invalid(raw)

    def test_wrong_counts_current_id_and_unknown_fields(self):
        raw = partial_bundle(EXPECTED[0], 1)
        for wrong in ('numtests=18', 'numtests=019', 'numtests=999999999999999999',
                      'current=0', 'current=2', 'current=20', 'current=01', 'id=OtherRunner'):
            key = wrong.split('=')[0]
            valid = {'numtests': '19', 'current': '1', 'id': 'AndroidJUnitRunner'}[key]
            with self.subTest(wrong=wrong):
                self.invalid(raw.replace(key + '=' + valid, wrong))
        self.invalid(raw.replace('INSTRUMENTATION_STATUS: id=', 'INSTRUMENTATION_STATUS: unknown='))
        self.invalid(raw + partial_bundle(EXPECTED[0], 0, 2))

    def test_invalid_terminal_and_malformed_protocol(self):
        raw = partial_bundle(EXPECTED[0], 1)
        for code in ('2', '-5', '-999', '00', '+1', '1 ', 'broken', ''):
            self.invalid(raw.replace('STATUS_CODE: 1', 'STATUS_CODE: ' + code))
        for tail in ('INSTRUMENTATION_STATUS: broken\n', 'INSTRUMENTATION_CODE: broken\n',
                     'INSTRUMENTATION_ABORTED: SECRET\n', 'INSTRUMENTATION_FAILED: SECRET\n',
                     'INSTRUMENTATION_RESULT: shortMsg=SECRET\n', 'adb: SECRET\n'):
            self.invalid(raw + tail)

    def test_final_must_be_exact_and_last_and_after_all_cases(self):
        for raw in ('INSTRUMENTATION_CODE: -1\n',
                    partial_run(EXPECTED[:1]),
                    partial_run() + 'INSTRUMENTATION_CODE: -1\n',
                    partial_run() + partial_bundle(EXPECTED[0], 1),
                    partial_run().replace('INSTRUMENTATION_CODE: -1', 'INSTRUMENTATION_CODE: 0'),
                    partial_run() + 'unexpected tail\n',
                    partial_run().replace('INSTRUMENTATION_RESULT: stream=', 'INSTRUMENTATION_RESULT: unknown=')):
            self.invalid(raw)

    def test_stream_and_stack_cannot_turn_failure_into_pass(self):
        start = partial_bundle(EXPECTED[0], 1)
        self.invalid(partial_bundle(EXPECTED[0], 1, stack='java.lang.Error'))
        self.invalid(start + partial_bundle(EXPECTED[0], 0, stack='java.lang.Error'))
        self.invalid(start + partial_bundle(EXPECTED[0], 0, stream='SECRET error'))
        self.invalid(start + partial_bundle(EXPECTED[0], -3, stack='java.lang.Error'))
        self.invalid(partial_bundle(EXPECTED[0], 1, stream='SECRET not a class header'))

    def test_protocol_injection_rejected(self):
        start = partial_bundle(EXPECTED[0], 1)
        for injected in ('java.lang.Error\nINSTRUMENTATION_STATUS_CODE: 0',
                         'java.lang.Error\nINSTRUMENTATION_STATUS: class=' + EXPECTED[1]['class'],
                         'java.lang.Error\nINSTRUMENTATION_STATUS: test=' + EXPECTED[1]['method'],
                         'java.lang.Error\n INSTRUMENTATION_STATUS_CODE: 0',
                         'java.lang.Error INSTRUMENTATION_CODE: -1'):
            self.invalid(start + partial_bundle(EXPECTED[0], -2, stack=injected))
        self.invalid(partial_bundle(EXPECTED[0], 1, stream='\nINSTRUMENTATION_STATUS_CODE: 0'))
        self.invalid(partial_run() + '\nINSTRUMENTATION_STATUS_CODE: 0\n')
        self.invalid(' SECRET INSTRUMENTATION_STATUS_CODE: 0\n' + partial_run())

    def test_contradictory_failure_footer_invalidates_prior_passes(self):
        raw = partial_run()
        for bad in ('FAILURES!!!', 'arbitrary SECRET text', 'OK (18 tests)'):
            self.invalid(raw.replace('OK (19 tests)', bad))
            self.invalid(raw.replace('INSTRUMENTATION_RESULT: stream=', 'INSTRUMENTATION_RESULT: stream=' + bad))
        mixed = partial_run(codes=[-2] + [0] * 18)
        self.assertEqual(self.checked(mixed)['cases'][0]['state'], 'failed')
        self.invalid(mixed.replace('FAILURES!!!\nTests run: 19, Failures: 1', 'OK (19 tests)'))

    def test_utf8_control_characters_and_line_endings(self):
        good = partial_run().replace('\n', '\r\n').encode('utf-8')
        self.assertEqual(self.checked(good)['protocol_state'], 'complete')
        for bad in (b'\xff\n', b'\xc3\n', '\ud800\n', '\0\n', '\x1b[31m\n', '\x7f\n',
                    '\x85\n', '\u2028\n', '\u2029\n', '\u202e\n', '\u200b\n',
                    partial_run().replace('\n', '\r', 1)):
            with self.subTest(kind=type(bad).__name__):
                self.invalid(bad)

    def test_truncated_line_is_invalid_not_pass(self):
        for raw in (partial_bundle(EXPECTED[0], 1).rstrip('\n'), partial_run().rstrip('\n'),
                    partial_run(EXPECTED[:1], final=False) + 'INSTRUMENTATION_STAT',
                    partial_run(EXPECTED[:1], final=False) + 'INSTRUMENTATION_STATUS_CODE:\n'):
            self.invalid(raw)

    def test_bounds_and_unexpected_input_types(self):
        for raw in (b'x' * (MAX_PARTIAL_BYTES + 1), 'x' * (MAX_PARTIAL_BYTES + 1),
                    '界' * (MAX_PARTIAL_BYTES // 3 + 1),
                    'x' * (MAX_PARTIAL_LINE_BYTES + 1) + '\n',
                    '\n' * (MAX_PARTIAL_LINES + 1), None, bytearray(b''), {}, 3):
            self.invalid(raw)

    def test_no_repeated_class_header_on_same_class(self):
        raw = partial_run(EXPECTED[:1], final=False)
        same = next(x for x in EXPECTED[1:] if x['class'] == EXPECTED[0]['class'])
        self.invalid(raw + partial_bundle(same, 1, 2, stream='\n' + same['class'] + ':'))


class PartialReaderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='partial-parser-tests-')
        self.root = Path(self.temp.name)
        self.path = self.root / 'owned.txt'
        self.path.write_text(partial_run(EXPECTED[:1], final=False))

    def tearDown(self):
        self.temp.cleanup()

    def invalid_path(self, path):
        value = read_partial_output(path, EXPECTED)
        self.assertEqual(value['protocol_state'], 'invalid')
        self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})
        return value

    def test_reads_owned_stable_partial(self):
        value = read_partial_output(self.path, EXPECTED)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual(value['cases'][0]['state'], 'passed')

    def test_rejects_missing_directory_symlink_and_hardlink(self):
        self.invalid_path(self.root / 'missing')
        self.invalid_path(self.root)
        link = self.root / 'link'; link.symlink_to(self.path)
        self.invalid_path(link)
        hard = self.root / 'hard'; os.link(self.path, hard)
        self.invalid_path(self.path)
        self.invalid_path(hard)

    def test_fifo_returns_without_waiting(self):
        fifo = self.root / 'fifo'; os.mkfifo(fifo)
        started = time.monotonic()
        self.invalid_path(fifo)
        self.assertLess(time.monotonic() - started, 1)

    def test_rejects_oversize_before_read(self):
        with self.path.open('wb') as out:
            out.truncate(MAX_PARTIAL_BYTES + 1)
        with mock.patch('os.read', side_effect=AssertionError('must not read oversize')):
            self.invalid_path(self.path)

    def test_rejects_wrong_owner_and_unstable_stat(self):
        real = os.fstat
        def wrong_owner(fd):
            original = real(fd)
            copied = mock.Mock(wraps=original)
            copied.st_mode = original.st_mode; copied.st_uid = os.getuid() + 1
            return copied
        with mock.patch('os.fstat', side_effect=wrong_owner):
            self.invalid_path(self.path)
        calls = 0
        def unstable(fd):
            nonlocal calls
            original = real(fd); calls += 1
            if calls == 2:
                values = {k: getattr(original, k) for k in ('st_dev', 'st_ino', 'st_mode', 'st_uid',
                           'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}
                values['st_mtime_ns'] += 1
                return type('ChangedStat', (), values)()
            return original
        with mock.patch('os.fstat', side_effect=unstable):
            self.invalid_path(self.path)

    def test_read_errors_and_invalid_encoding_are_redacted(self):
        with mock.patch('os.read', side_effect=OSError('SECRET /private/token')):
            self.assertNotIn('SECRET', json.dumps(self.invalid_path(self.path)))
        self.path.write_bytes(b'\xff\n')
        self.invalid_path(self.path)

    def test_extra_bytes_after_initial_stat_are_invalid(self):
        real = os.read
        first = True
        def growing(fd, length):
            nonlocal first
            if first:
                first = False
                with self.path.open('ab') as output:
                    output.write(b'\n')
            return real(fd, length)
        with mock.patch('os.read', side_effect=growing):
            self.invalid_path(self.path)

    def test_short_subprocess_timeout_preserves_partial_file_only(self):
        raw = partial_run(EXPECTED[:1], final=False) + partial_bundle(EXPECTED[1], 1, 2)
        code = 'import sys,time;sys.stdout.write(' + repr(raw) + ');sys.stdout.flush();time.sleep(10)'
        with self.path.open('wb') as output:
            with self.assertRaises(subprocess.TimeoutExpired) as caught:
                subprocess.run([sys.executable, '-c', code], stdout=output, stderr=subprocess.STDOUT,
                               timeout=0.2, check=False)
        self.assertIsNone(caught.exception.stdout)
        value = read_partial_output(self.path, EXPECTED)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual([x['state'] for x in value['cases'][:2]], ['passed', 'started'])
        with self.assertRaises(ValueError):
            parse_output(self.path.read_text(), EXPECTED)


# Observed execution ordinals are diagnostic metadata only.
import copy
import public_evidence as evidence
import result_parser as parser


class ExecutionOrdinalTests(unittest.TestCase):
    def checked(self, raw):
        value = parser.parse_partial_output(raw, EXPECTED)
        self.assertEqual(evidence.checked_json('instrumentation.json', value), value)
        return value

    def test_forward_reverse_and_all_rotations_preserve_observed_order(self):
        orders = [list(reversed(EXPECTED))] + [EXPECTED[i:] + EXPECTED[:i] for i in range(19)]
        for order in orders:
            value = self.checked(partial_run(order))
            observed = sorted(value['cases'], key=lambda case: case['execution_ordinal'])
            self.assertEqual([(c['class'], c['method']) for c in observed],
                             [(c['class'], c['method']) for c in order])
            self.assertEqual([c['execution_ordinal'] for c in observed], list(range(1, 20)))
            self.assertEqual([(c['class'], c['method']) for c in value['cases']],
                             list(parser.PARTIAL_EXPECTED_CASES))

    def test_started_has_ordinal_and_unseen_remains_null(self):
        order = list(reversed(EXPECTED))
        raw = partial_run(order[:2], codes=[-2, 0], final=False) + partial_bundle(order[2], 1, 3)
        value = self.checked(raw)
        self.assertEqual([(c['state'], c['execution_ordinal']) for c in value['cases'][-3:]],
                         [('started', 3), ('passed', 2), ('failed', 1)])
        self.assertTrue(all(c['state'] == 'unknown' and c['execution_ordinal'] is None
                            for c in value['cases'][:-3]))

    def test_minimal_protocol_still_observes_start_order_without_current(self):
        raw = partial_run(list(reversed(EXPECTED)))
        raw = '\n'.join(line for line in raw.split('\n') if not line.startswith('INSTRUMENTATION_STATUS: current='))
        value = self.checked(raw)
        self.assertEqual([c['execution_ordinal'] for c in value['cases']], list(range(19, 0, -1)))

    def test_partial_unterminated_bundle_does_not_create_ordinal(self):
        raw = partial_run(EXPECTED[:1], final=False) + f"INSTRUMENTATION_STATUS: class={EXPECTED[1]['class']}\n"
        value = self.checked(raw)
        self.assertEqual(value['cases'][0]['execution_ordinal'], 1)
        self.assertIsNone(value['cases'][1]['execution_ordinal'])

    def test_invalid_protocol_clears_states_and_ordinals(self):
        raw = partial_run(EXPECTED[:2], final=False) + 'INSTRUMENTATION_STATUS_CODE: 0\n'
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'invalid')
        self.assertTrue(all(c['state'] == 'unknown' and c['execution_ordinal'] is None for c in value['cases']))

    def test_failure_skip_ordinals_do_not_relax_success_gate(self):
        for code in (-1, -2, -3, -4):
            raw = partial_run(codes=[code] + [0] * 18)
            value = self.checked(raw)
            self.assertEqual(value['protocol_state'], 'complete')
            self.assertEqual(value['cases'][0]['execution_ordinal'], 1)
            with self.assertRaises(ValueError): parser.parse_output(raw, EXPECTED)

    def test_secret_opaque_text_is_not_exported(self):
        secret = 'SYNTHETIC_SECRET_NOT_PUBLIC'
        raw = partial_bundle(EXPECTED[0], 1) + partial_bundle(EXPECTED[0], -2,
            stack='java.lang.AssertionError: ' + secret)
        value = self.checked(raw)
        self.assertNotIn(secret, json.dumps(value))
        self.assertEqual(value['cases'][0]['execution_ordinal'], 1)

    def test_schema_rejects_out_of_range_noninteger_and_missing_ordinals(self):
        base = self.checked(partial_run())
        for bad in (0, 20, True, False, 1.0, '1', None, [], {}):
            value = copy.deepcopy(base); value['cases'][0]['execution_ordinal'] = bad
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                evidence.checked_json('instrumentation.json', value)
        value = copy.deepcopy(base); del value['cases'][0]['execution_ordinal']
        with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)

    def test_schema_rejects_duplicates_and_gaps(self):
        value = self.checked(partial_run())
        value['cases'][1]['execution_ordinal'] = 1
        with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)
        value = self.checked(partial_run(EXPECTED[:1], final=False))
        value['cases'][0]['execution_ordinal'] = 2
        with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)

    def test_schema_rejects_unknown_or_invalid_case_claiming_ordinal(self):
        for state in ('incomplete', 'invalid'):
            value = parser.parse_partial_output('', EXPECTED); value['protocol_state'] = state
            value['cases'][0]['execution_ordinal'] = 1
            with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)

    def test_schema_rejects_active_case_before_terminal_and_multiple_active(self):
        value = self.checked(partial_run(EXPECTED[:2], final=False))
        value['cases'][0]['state'] = 'started'
        with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)
        value['cases'][1]['state'] = 'started'
        with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)

    def test_schema_rejects_unrecognized_identity_or_extra_raw_text(self):
        for field, bad in [('method', 'SYNTHETIC_PRIVATE'), ('raw', 'SYNTHETIC_PRIVATE')]:
            value = self.checked(partial_run()); value['cases'][0][field] = bad
            with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)


class FailureHintTests(unittest.TestCase):
    signals = (
        ('UI_TEST_DEADLINE_EXCEEDED', 'get', 102, 'HELPER_DEADLINE'),
        ('UI_TEST_WAIT_INTERRUPTED', 'get', 106, 'HELPER_INTERRUPTED'),
        ('UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS', 'assertHealthy', 19, 'HELPER_PRIOR_GUARD'),
        ('UI_TEST_MAIN_ACTION_FAILED', 'get', 119, 'HELPER_CHECKED_ACTION'),
    )

    @staticmethod
    def trace(token='UI_TEST_DEADLINE_EXCEEDED', method='get', line=102):
        return (f'java.lang.AssertionError: {token}\n'
                f'\tat net.ankio.auto.isolated.UiTestDeadline.{method}(UiTestDeadline.java:{line})')

    def failure(self, trace, code=-2):
        raw = partial_bundle(EXPECTED[0], 1) + partial_bundle(EXPECTED[0], code, stack=trace)
        value = parser.parse_partial_output(raw, EXPECTED)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual(value['cases'][0]['execution_ordinal'], 1)
        evidence.checked_json('instrumentation.json', value)
        return value

    def unknown(self, traces):
        for trace in traces:
            with self.subTest(trace=trace):
                self.assertEqual(self.failure(trace)['cases'][0]['failure_hint'], 'UNKNOWN')

    def test_exact_reviewed_helper_prefixes_are_fixed_hints(self):
        for token, method, line, hint in self.signals:
            for code in (-1, -2):
                value = self.failure(self.trace(token, method, line), code)
                self.assertEqual(value['cases'][0]['failure_hint'], hint)
                self.assertEqual(value['cases'][0]['state'], 'failed')

    def test_superseded_helper_source_and_unmapped_cancellation_stay_unknown(self):
        self.unknown((
            self.trace('UI_TEST_DEADLINE_EXCEEDED', 'get', 30),
            self.trace('UI_TEST_WAIT_INTERRUPTED', 'get', 35),
            self.trace('UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS', 'assertHealthy', 15),
            self.trace('UI_TEST_MAIN_ACTION_FAILED', 'get', 40),
            self.trace('UI_TEST_ACTION_CANCELLED', 'get', 111),
        ))

    def test_plain_assertion_business_failure_missing_and_empty_stack_are_unknown(self):
        self.unknown((None, '', 'java.lang.AssertionError: ordinary assertion\n\tat fixture.Test.run(Test.kt:1)',
                      'java.lang.IllegalStateException: business error\n\tat fixture.Test.run(Test.kt:1)'))

    def test_header_prefix_suffix_wrong_type_and_token_are_unknown(self):
        good = self.trace()
        self.unknown((good.replace('AssertionError:', 'IllegalStateException:'),
                      good.replace('EXCEEDED', 'EXCEEDED_EXTRA'), good.replace('UI_TEST', 'prefix UI_TEST'),
                      good.replace('EXCEEDED', 'EXCEEDED suffix'), 'Caused by: ' + good,
                      ' ' + good, '\n' + good, good.replace('AssertionError:', 'AssertionError: ')))

    def test_frame_must_be_immediate_exact_class_method_file_and_source_line(self):
        good = self.trace()
        self.unknown((good.replace('java:102', 'java:103'), good.replace('java:102', 'java:0102'),
                      good.replace('UiTestDeadline.get', 'UiTestDeadline.assertHealthy'),
                      good.replace('net.ankio.auto.isolated.UiTestDeadline', 'other.UiTestDeadline'),
                      good.replace('(UiTestDeadline.java:102)', '(Unknown Source)'),
                      good.replace('UiTestDeadline.java:', 'Private.java:'),
                      good.replace('\n\tat ', '\n\n\tat '), good.replace('\n\tat ', '\n at '),
                      good + ' suffix', good.replace('\n', '\n\tat other.First.run(First.java:1)\n', 1)))

    def test_nested_or_later_helper_cannot_supply_root_match(self):
        self.unknown(prefix + self.trace() for prefix in (
            'java.lang.AssertionError: ordinary\n\tat fixture.Test.run(Test.kt:1)\nCaused by: ',
            'CustomError: ordinary\n\tat fixture.Test.run(Test.kt:1)\n', 'arbitrary first line\n'))

    def test_flattened_multiple_errors_and_free_text_veto_helper_hint(self):
        self.unknown(self.trace() + tail for tail in (
            '\njava.lang.AssertionError: second\n\tat fixture.Test.run(Test.kt:1)',
            '\nCustomError: second\n\tat fixture.Test.run(Test.kt:1)',
            '\nsecond paragraph of a multiline message',
            '\n' + self.trace('UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS', 'assertHealthy', 15),
            '\n\n' + self.trace('UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS', 'assertHealthy', 15)))

    def test_legal_cause_and_suppressed_tail_only_preserve_original_hint(self):
        tail = ('\n\tat fixture.Test.run(Test.kt:1)\n'
                '\tSuppressed: private.CustomError: SYNTHETIC_SECRET_A\n'
                '\t\tat private.Worker.run(Worker.java:2)\n\t\t... 2 more\n'
                'Caused by: private.BusinessError: SYNTHETIC_SECRET_B\n'
                '\tat private.Worker.run(Worker.java:3)\n\t... 1 more\n')
        value = self.failure(self.trace() + tail)
        self.assertEqual(value['cases'][0]['failure_hint'], 'HELPER_DEADLINE')
        for secret in ('SYNTHETIC_SECRET', 'private.', 'Worker.java', 'BusinessError'):
            self.assertNotIn(secret, json.dumps(value))

    def test_multiple_failure_headers_are_type_only_hints_with_bounded_counts(self):
        for namespace in ('org.junit.runners.model', 'org.junit.internal.runners.model'):
            for count in (2, 9, 10, 59, 60, 64):
                trace = (f'{namespace}.MultipleFailureException: There were {count} errors:\n'
                         '  arbitrary.PrivateError(SYNTHETIC_SECRET)\n' + self.trace())
                value = self.failure(trace)
                self.assertEqual(value['cases'][0]['failure_hint'], 'MULTIPLE_FAILURES')
                self.assertNotIn('SYNTHETIC_SECRET', json.dumps(value))

    def test_multiple_failure_wrong_count_class_prefix_suffix_and_unicode_are_unknown(self):
        header = 'org.junit.runners.model.MultipleFailureException: There were 2 errors:'
        bad = [header.replace('2', count) for count in ('0', '1', '65', '9999', '-2', '02', '2.0', '\u0662', '\uff12')]
        bad += [' ' + header, 'Caused by: ' + header, header + ' suffix',
                header.replace('org.junit', 'private.junit'), header.replace('errors:', 'error:'),
                header.replace('There were', 'There was')]
        self.unknown(bad)

    def test_unicode_and_newlines_cannot_complete_helper_prefix(self):
        good = self.trace()
        for trace in (good.replace('UI_TEST', 'UI_\u200bTEST'), good.replace('UI_TEST', '\uff35I_TEST'),
                      good.replace('AssertionError', 'Asserti\u00f3nError'), good.replace('java:102', 'java:\u0663\u0660'),
                      good.replace('EXCEEDED', 'EXCEEDED\u2028'), good.replace('\n\tat', '\n\u200b\tat'),
                      good.replace('EXCEEDED', 'EXCEEDED\nextra')):
            self.assertEqual(parser._failure_hint(trace), 'UNKNOWN')

    def test_stream_text_never_supplies_failure_hint(self):
        raw = partial_bundle(EXPECTED[0], 1) + partial_bundle(EXPECTED[0], -2, stream=self.trace())
        value = parser.parse_partial_output(raw, EXPECTED)
        self.assertEqual(value['cases'][0]['failure_hint'], 'UNKNOWN')
        self.assertEqual(value['cases'][0]['state'], 'failed')

    def test_skip_or_invalid_protocol_cannot_publish_helper_hint(self):
        value = self.failure(self.trace(), code=-4)
        self.assertEqual(value['cases'][0]['state'], 'skipped')
        self.assertEqual(value['cases'][0]['failure_hint'], 'NOT_APPLICABLE')
        raw = partial_bundle(EXPECTED[0], 1) + partial_bundle(EXPECTED[0], -2, stack=self.trace())
        value = parser.parse_partial_output(raw + 'INSTRUMENTATION_STATUS_CODE: 0\n', EXPECTED)
        self.assertEqual(value['protocol_state'], 'invalid')
        self.assertTrue(all(c['state'] == 'unknown' and c['execution_ordinal'] is None and
                            c['failure_hint'] == 'NOT_APPLICABLE' for c in value['cases']))

    def test_complete_run_states_ordinals_and_strict_gate_are_unaffected(self):
        for trace in (self.trace(), self.trace() + '\nmalformed tail', 'ordinary assertion'):
            raw = ''
            for ordinal, case in enumerate(reversed(EXPECTED), 1):
                raw += partial_bundle(case, 1, ordinal)
                raw += partial_bundle(case, -2 if ordinal == 7 else 0, ordinal,
                                      stack=trace if ordinal == 7 else None)
            raw += 'INSTRUMENTATION_CODE: -1\n'
            value = parser.parse_partial_output(raw, EXPECTED)
            evidence.checked_json('instrumentation.json', value)
            self.assertEqual(value['protocol_state'], 'complete')
            self.assertEqual([c['execution_ordinal'] for c in value['cases']], list(range(19, 0, -1)))
            self.assertEqual([c['state'] for c in value['cases']], ['passed'] * 12 + ['failed'] + ['passed'] * 6)
            with self.assertRaises(ValueError): parser.parse_output(raw, EXPECTED)

    def test_schema_rejects_nonfixed_hints_and_wrong_state_hint_combinations(self):
        base = self.failure(self.trace())
        for hint in ('SYNTHETIC_SECRET', 'NOT_APPLICABLE', '', None, True, 1, [], {}):
            value = copy.deepcopy(base); value['cases'][0]['failure_hint'] = hint
            with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)
        value = copy.deepcopy(base); del value['cases'][0]['failure_hint']
        with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)
        for state in ('passed', 'skipped', 'started', 'unknown'):
            value = copy.deepcopy(base); value['cases'][0]['state'] = state
            if state == 'unknown': value['cases'][0]['execution_ordinal'] = None
            with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json', value)


BASELINE_FUNCTION_AST_PINS = {'parse_output': '91c01a6cdb22cb94d5655a2056e14ba110f67c4394cce8b1e692982003518119', 'junit_xml': '20509ade67ceb24e7c9ab3fda2728ad80a4cbc32db48748cc31d3054c4d61a0b', '_failure_hint': 'b192b18c98e7e41f4404754217cddc1fa0e8bc3fac4380b183a8d0f0b3d0f457'}
SITE_SOURCE_FILE_PINS = {'app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/DataPageIsolatedUiTest.kt': 'baa039edcffd53f77ae616ff05b11c7d2175738feb078f9dbde07e2bd1ca362a', 'app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/IsolatedUiFixture.kt': '804a9a25b8c4d35fb5b93420ff4ac961691f923208cb61f5e69f5ee5059aaa39', 'app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/IsolatedUiProgress.kt': 'ccc6b325251fc5f8b433f540d0875733879f8dd608b04920bb48bf13e5fc747f', 'app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/RefundIsolatedUiTest.kt': 'efb40f0ecbd54dfeafb36fc57bdbf93ef185d8e1ef6d0471c2689d68f16214fe', 'app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/UiTestDeadline.java': '2b10b85f54f9af3b74ba3a172790f121cfda1fbdea4ed5e4f8a64fa68a88373f', 'app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/UiTestFailureRule.java': '477d223400afee6963d279c7393b4c0109e819d48ae6dfcd9d6e6f0992b495bd'}

# Complete synthetic DEX call chains and malicious protocol fixtures, never device results.
class FailureSiteTests(unittest.TestCase):
    @staticmethod
    def stack(frames, hint='HELPER_DEADLINE'):
        header, leaf = next(key for key, value in parser._HELPER_FAILURE_PREFIXES.items() if value == hint)
        return header + '\n' + leaf + ''.join('\n\tat ' + f for f in frames)

    def known(self):
        return list(parser._FAILURE_SITE_PATHS.items())

    def parsed(self, identity, stack, code=-2, stream=None):
        case = dict(zip(('class', 'method'), identity))
        raw = partial_bundle(case, 1) + partial_bundle(case, code, stack=stack, stream=stream)
        value = parser.parse_partial_output(raw, EXPECTED)
        evidence.checked_json('instrumentation.json', value)
        return next(c for c in value['cases'] if (c['class'], c['method']) == identity), value

    def test_all_exact_ordered_dex_paths_and_get_failure_types(self):
        self.assertEqual(len(self.known()), 441)
        self.assertEqual(len(parser._SITE_DEX_BRIDGES), 14)
        identities = set()
        for (identity, frames), site in self.known():
            identities.add(identity)
            for hint in parser._SITE_GET_HINTS:
                stack = self.stack(frames, hint)
                self.assertEqual(parser._failure_site(stack, identity, hint), site)
                for code in (-1, -2):
                    case, value = self.parsed(identity, stack, code)
                    self.assertEqual((case['failure_phase'], case['failure_wait']), site)
                    self.assertEqual(case['failure_hint'], hint)
        self.assertEqual(identities, set(parser.PARTIAL_EXPECTED_CASES))

    def test_refund_repeated_touch_bounds_require_complete_new_dex_chain(self):
        for index, line in ((14, 135), (18, 218)):
            identity = parser.PARTIAL_EXPECTED_CASES[index-1]
            wanted = (f'BODY_C{index:02}_L{line:03}', 'MAIN')
            paths = [frames for (case, frames), site in self.known()
                     if case == identity and site == wanted]
            self.assertEqual(len(paths), 1)
            frames = paths[0]
            bounds = 'net.ankio.auto.isolated.IsolatedUiFixture.screenBounds(IsolatedUiFixture.kt:174)'
            self.assertEqual(frames[-2], bounds)
            self.assertEqual(parser._failure_site(self.stack(frames), identity,
                                                 'HELPER_DEADLINE'), wanted)
            # The same-line onMain-only lookup is a genuine shorter route, but
            # accepting it would also accept a deleted screenBounds frame.
            self.assertEqual(parser._failure_site(self.stack(frames[:-2]+frames[-1:]),
                                                 identity, 'HELPER_DEADLINE'),
                             ('UNKNOWN', 'UNKNOWN'))

    def test_exact_c05_stages_and_shared_lifecycle(self):
        identity = parser.PARTIAL_EXPECTED_CASES[4]
        pairs = parser._FAILURE_SITE_PAIRS[identity]
        want = {('SWIPE_SHOW','MAIN'),('SWIPE_INITIAL_ROWS','POLL_MAIN'),
                ('SWIPE_FIRST','MAIN'),('SWIPE_REQUEST_OBSERVED','POLL_MAIN'),
                ('SWIPE_SECOND','MAIN'),('SWIPE_SECOND','POLL_MAIN'),('BODY_C05_L171','MAIN'),
                ('SWIPE_FINAL_ROWS','POLL_MAIN'),
                ('SWIPE_FINAL_ERROR','MAIN'),('SETUP_RESET','MAIN'),('SETUP_IDLE','IDLE'),
                ('TEARDOWN_HOST_FINISH','MAIN'),('TEARDOWN_HOST_DESTROYED','POLL_MAIN'),
                ('TEARDOWN_REQUESTS','POLL_MAIN'),('TEARDOWN_DATABASE','CLEANUP')}
        self.assertEqual(pairs, want)
        for other in parser.PARTIAL_EXPECTED_CASES:
            self.assertTrue({p for p in want if p[0].startswith(('SETUP_', 'TEARDOWN_'))} <= parser._FAILURE_SITE_PAIRS[other])

    def test_every_path_rejects_each_missing_duplicated_and_reordered_frame(self):
        for (identity, frames), site in self.known():
            for i in range(len(frames)):
                variants = [frames[:i] + frames[i+1:], frames[:i] + (frames[i],) + frames[i:]]
                if i+1 < len(frames) and frames[i] != frames[i+1]:
                    variants.append(frames[:i] + (frames[i+1],frames[i]) + frames[i+2:])
                for bad in variants:
                    # Any abbreviated path stays UNKNOWN, even if its frames
                    # could independently describe a genuine shorter call route.
                    self.assertEqual(parser._failure_site(self.stack(bad), identity, 'HELPER_DEADLINE'), ('UNKNOWN','UNKNOWN'))

    def test_no_bridge_free_jvm_path_and_no_arbitrary_bridge_variants(self):
        bridge_frames = {f for pair in parser._SITE_DEX_BRIDGES.values() for f in pair}
        for (identity, frames), site in self.known():
            shortened = tuple(f for f in frames if f not in bridge_frames)
            self.assertEqual(parser._failure_site(self.stack(shortened), identity, 'HELPER_DEADLINE'), ('UNKNOWN','UNKNOWN'))
        for method, pair in parser._SITE_DEX_BRIDGES.items():
            (identity, frames), _ = next(x for x in self.known() if pair[0] in x[0][1])
            i = frames.index(pair[0])
            for bad in (pair[0].replace('(', 'X(',1), pair[0].replace('.kt)', '.kt:0)'),
                        pair[0].replace('.kt)', '.kt:-1)'), pair[0].replace('.kt)', '.kt:1)'),
                        pair[0].split('(')[0]+'(Unknown Source)', pair[1].replace(':0)', ':1)'),
                        pair[1].replace('D8$$SyntheticClass', 'Unknown Source')):
                modified = frames[:i] + (bad,) + frames[i+1:]
                self.assertEqual(parser._failure_site(self.stack(modified), identity, 'HELPER_DEADLINE'), ('UNKNOWN','UNKNOWN'))

    def test_every_real_frame_rejects_file_line_class_and_method_drift(self):
        for (identity, frames), _ in self.known():
            for i, frame in enumerate(frames):
                for bad in (frame.replace('net.ankio.auto.isolated.', 'private.SYNTHETIC_SECRET.', 1),
                            frame.split('(')[0]+'(Unknown Source)',
                            frame.replace('(', 'Changed(', 1),
                            frame.rsplit('(',1)[0]+'(Changed.kt:999999)'):
                    modified = frames[:i] + (bad,) + frames[i+1:]
                    self.assertEqual(parser._failure_site(self.stack(modified), identity, 'HELPER_DEADLINE'), ('UNKNOWN','UNKNOWN'))

    def test_cross_case_and_conflicting_app_tail_are_unknown(self):
        for (identity, frames), site in self.known():
            if site[0].startswith(('SETUP_', 'TEARDOWN_')):
                continue
            other = next(c for c in parser.PARTIAL_EXPECTED_CASES if c != identity)
            self.assertEqual(parser._failure_site(self.stack(frames), other, 'HELPER_DEADLINE'), ('UNKNOWN','UNKNOWN'))
            for extra in (frames[-1], 'net.ankio.auto.isolated.IsolatedUiFixture.setUpIsolatedUi(IsolatedUiFixture.kt:50)',
                          'private.Worker.run(Worker.java:1)'):
                self.assertEqual(parser._failure_site(self.stack(frames+(extra,)), identity, 'HELPER_DEADLINE'), ('UNKNOWN','UNKNOWN'))

    def test_nested_causes_suppressed_stream_and_flattened_errors_never_supply_sites(self):
        (identity, frames), site = self.known()[0]
        good = self.stack(frames)
        for marker in ('\nCaused by: private.Error: SYNTHETIC_SECRET\n',
                       '\n\tSuppressed: private.Error: SYNTHETIC_SECRET\n'):
            nested = marker + '\n'.join('\t' + line if marker.startswith('\n\tSuppressed:') and line.startswith('\tat ') else line for line in good.split('\n')[1:])
            missing = self.stack(frames[:2]) + nested
            case, _ = self.parsed(identity, missing)
            self.assertEqual((case['failure_phase'],case['failure_wait']), ('UNKNOWN','UNKNOWN'))
            case, value = self.parsed(identity, good+nested)
            self.assertEqual((case['failure_phase'],case['failure_wait']), site)
            self.assertNotIn('SYNTHETIC_SECRET', json.dumps(value))
        for stack in (good+'\n'+good, 'java.lang.AssertionError: ordinary\n'+good,
                      good+'\nSYNTHETIC_SECRET unstructured tail'):
            case, value = self.parsed(identity, stack)
            self.assertEqual((case['failure_phase'],case['failure_wait']), ('UNKNOWN','UNKNOWN'))
        case, value = self.parsed(identity, None, stream=good)
        self.assertEqual((case['failure_phase'],case['failure_wait']), ('UNKNOWN','UNKNOWN'))
        self.assertNotIn('UiTestDeadline.java', json.dumps(value))

    def test_unheaded_misindented_repeated_and_arbitrary_tail_frames_are_unknown(self):
        (identity,frames),_ = next(x for x in self.known() if x[1] == ('SWIPE_SECOND','POLL_MAIN'))
        good=self.stack(frames)
        fake='org.junit.PRIVATE_CANARY.fake(Unknown Source)'
        other='net.ankio.auto.isolated.RefundIsolatedUiTest.fake(RefundIsolatedUiTest.kt:1)'
        tails = ('\n\tat '+fake, '\n\tat '+fake+'\n\tat '+fake,
                 '\n\t\tat '+other, '\n\t... 1 more',
                 '\n\tSuppressed: private.Error\n\tat '+other,
                 '\n\t\tSuppressed: private.Error\n\t\t\tat '+other,
                 '\nCaused by: private.Error\n\t\tat '+other,
                 '\n\tSuppressed: private.Error\n\t\t... 1 more\n\t\tat '+other,
                 '\n\tSuppressed: private.Error\n\t\t... 1 more\n\t\t... 1 more',
                 '\n\tat java.lang.reflect.Method.invoke(Native Method)')
        for tail in tails:
            case,value=self.parsed(identity,good+tail)
            self.assertEqual((case['failure_phase'],case['failure_wait']),('UNKNOWN','UNKNOWN'))
            self.assertNotIn('PRIVATE_CANARY',json.dumps(value))
        legal = ('\n\tSuppressed: private.Error\n\t\tat '+other+'\n\t\t... 1 more',
                 '\nCaused by: private.Error\n\tat '+other+'\n\t... 1 more',
                 '\n\tSuppressed: private.Error\n\t\tat '+other+
                 '\n\t\tSuppressed: private.Inner\n\t\t\tat '+other+
                 '\n\tSuppressed: private.Other\n\t\tat '+other)
        for tail in legal:
            self.assertEqual(parser._failure_site(good+tail,identity,'HELPER_DEADLINE'),('SWIPE_SECOND','POLL_MAIN'))

    def test_nested_elisions_are_bounded_by_the_actual_enclosing_trace(self):
        (identity,frames),site=self.known()[0];good=self.stack(frames)
        count=len(frames)+1
        for header,tabs in (('Caused by: Error','\t'),('\tSuppressed: Error','\t\t')):
            for n,expected in ((count,site),(count+1,('UNKNOWN','UNKNOWN'))):
                trace=good+'\n'+header+'\n'+tabs+f'... {n} more'
                self.assertEqual(parser._failure_site(trace,identity,'HELPER_DEADLINE'),expected)
        # A second cause is enclosed by the first cause, not permanently by root.
        first='\nCaused by: Error\n\tat private.Frame.run(Frame.java:1)\n\t... '+str(count)+' more'
        for n,expected in ((count+1,site),(count+2,('UNKNOWN','UNKNOWN'))):
            trace=good+first+'\nCaused by: Error\n\t... '+str(n)+' more'
            self.assertEqual(parser._failure_site(trace,identity,'HELPER_DEADLINE'),expected)
        suppressed='\n\tSuppressed: Error\n\t\tat private.Frame.run(Frame.java:1)\n\t\t... '+str(count)+' more'
        for n,expected in ((count+1,site),(count+2,('UNKNOWN','UNKNOWN'))):
            trace=good+suppressed+'\n\t\tSuppressed: Error\n\t\t\t... '+str(n)+' more'
            self.assertEqual(parser._failure_site(trace,identity,'HELPER_DEADLINE'),expected)
        # Empty secondary stacks are legitimate; their nested elision cannot be 1.
        self.assertEqual(parser._failure_site(good+'\nCaused by: Empty',identity,'HELPER_DEADLINE'),site)
        self.assertEqual(parser._failure_site(good+'\nCaused by: Empty\nCaused by: Error\n\t... 1 more',identity,'HELPER_DEADLINE'),('UNKNOWN','UNKNOWN'))

    def test_nonfailed_unknown_hint_and_guard_do_not_claim_call_sites(self):
        (identity, frames), _ = self.known()[0]
        for state in ('passed','skipped','started','unknown'):
            self.assertTrue(parser.failure_site_allowed(identity,state,'NOT_APPLICABLE','NOT_APPLICABLE','NOT_APPLICABLE'))
            self.assertFalse(parser.failure_site_allowed(identity,state,'NOT_APPLICABLE','SETUP_RESET','MAIN'))
        for hint in ('UNKNOWN','HELPER_PRIOR_GUARD','MULTIPLE_FAILURES'):
            self.assertEqual(parser._failure_site(self.stack(frames),identity,hint),('UNKNOWN','UNKNOWN'))
        case, _ = self.parsed(identity,self.stack(frames),-4)
        self.assertEqual((case['failure_phase'],case['failure_wait']), ('NOT_APPLICABLE','NOT_APPLICABLE'))

    def test_terminated_bundle_only_and_invalid_clears_new_values(self):
        (identity, frames), _ = self.known()[0]
        case = dict(zip(('class','method'),identity)); good=self.stack(frames)
        start=partial_bundle(case,1); terminal=partial_bundle(case,-2,stack=good)
        for raw in (start+terminal.rsplit('INSTRUMENTATION_STATUS_CODE:',1)[0], start):
            value=parser.parse_partial_output(raw,EXPECTED)
            self.assertEqual(value['protocol_state'],'incomplete')
            self.assertTrue(all(c['failure_phase']==c['failure_wait']=='NOT_APPLICABLE' for c in value['cases']))
        for raw in (start+terminal+'INSTRUMENTATION_STATUS_CODE: 0\n', start+terminal[:-1],
                    start+terminal+terminal, terminal, start+terminal.replace('numtests=19','numtests=18')):
            value=parser.parse_partial_output(raw,EXPECTED)
            self.assertEqual(value['protocol_state'],'invalid')
            self.assertTrue(all(c['failure_phase']==c['failure_wait']=='NOT_APPLICABLE' for c in value['cases']))

    def test_site_byte_and_frame_budgets_are_stricter_than_protocol_budgets(self):
        (identity,frames),site=self.known()[0];good=self.stack(frames)
        def padded(target, char='A'):
            text=good
            while len(text.encode())+32 < target:
                left=target-len(text.encode())-len('\n\tSuppressed: X'.encode())
                text+='\n\tSuppressed: X'+char*min(8000,left//len(char.encode()))
            if len(text.encode())<target:
                text+='A'*(target-len(text.encode()))
            return text
        for n in (32767,32768):
            text=padded(n)
            self.assertEqual(len(text.encode()),n)
            self.assertEqual(parser._failure_site(text,identity,'HELPER_DEADLINE'),site)
        for n in (32769,65536,65537):
            text=padded(n)
            self.assertEqual(parser._failure_site(text,identity,'HELPER_DEADLINE'),('UNKNOWN','UNKNOWN'))
            case,_=self.parsed(identity,text)
            self.assertEqual(case['failure_hint'],'HELPER_DEADLINE')
            self.assertEqual(case['failure_phase'],'UNKNOWN')
        text=padded(32769,'文')
        self.assertLess(len(text),32769)
        self.assertEqual(parser._failure_site(text,identity,'HELPER_DEADLINE'),('UNKNOWN','UNKNOWN'))
        tail=('org.junit.runners.ParentRunner.run(ParentRunner.java:1)',)*128
        self.assertEqual(parser._failure_site(self.stack(frames+tail),identity,'HELPER_DEADLINE'),('UNKNOWN','UNKNOWN'))

    def test_schema_rejects_missing_extra_dynamic_wrong_case_hint_and_wait(self):
        (identity,frames),site=next(x for x in self.known() if x[1][0].startswith('BODY_'))
        case,base=self.parsed(identity,self.stack(frames));index=base['cases'].index(case)
        for field in ('failure_phase','failure_wait'):
            for bad in ('PRIVATE_CANARY',None,True,[],{},'',0,'NOT_APPLICABLE'):
                value=copy.deepcopy(base);value['cases'][index][field]=bad
                with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json',value)
            value=copy.deepcopy(base);del value['cases'][index][field]
            with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json',value)
        for field,bad in [('failure_wait','CLEANUP'),('failure_hint','HELPER_PRIOR_GUARD'),('failure_hint','UNKNOWN'),
                          ('failure_phase','BODY_C19_L244'),('raw_stack','PRIVATE_CANARY')]:
            value=copy.deepcopy(base);value['cases'][index][field]=bad
            with self.assertRaises(ValueError): evidence.checked_json('instrumentation.json',value)

    def test_success_junit_and_original_hints_are_unchanged(self):
        import ast,hashlib
        tree=ast.parse(Path(parser.__file__).read_text())
        pins=BASELINE_FUNCTION_AST_PINS
        for node in tree.body:
            if isinstance(node,ast.FunctionDef) and node.name in pins:
                self.assertEqual(hashlib.sha256(ast.dump(node).encode()).hexdigest(),pins[node.name])
        passed=partial_run(); cases=parser.parse_output(passed,EXPECTED)
        self.assertEqual(len(cases),19)
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'TEST-isolated-ui.xml';p.write_text(parser.junit_xml(cases))
            self.assertEqual(evidence.checked_junit(p),parser.junit_xml(cases))
        (identity,frames),_=self.known()[0];good=self.stack(frames)
        for code in (-1,-2,-3,-4):
            raw=partial_run(codes=[code]+[0]*18)
            with self.assertRaises(ValueError): parser.parse_output(raw,EXPECTED)
        self.assertNotIn('failure_phase',parser.junit_xml(cases))

    def test_source_mapping_remains_frozen(self):
        import hashlib,zipfile
        root=Path(__file__).resolve().parents[1]
        lock=json.loads((root/'runtime-lock.json').read_text())
        self.assertEqual(lock['source']['sha256'],parser.SITE_SOURCE_SHA256)
        self.assertEqual(hashlib.sha256((root/'source.zip').read_bytes()).hexdigest(),parser.SITE_SOURCE_SHA256)
        with zipfile.ZipFile(root/'source.zip') as z:
            for name,digest in SITE_SOURCE_FILE_PINS.items():
                self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),digest)
        self.assertEqual(len({x for x in parser._SITE_METHODS}),len(parser._SITE_METHODS))
        self.assertLess(len(Path(parser.__file__).read_bytes()),128*1024)


if __name__ == '__main__':
    unittest.main()
