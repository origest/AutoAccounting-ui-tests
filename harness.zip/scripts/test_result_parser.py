import json
from pathlib import Path
import unittest
from result_parser import parse_output

EXPECTED = json.loads((Path(__file__).resolve().parents[1] / 'expected-tests.json').read_text())


def output(cases=EXPECTED):
    lines = []
    for case in cases:
        for code in (1, 0):
            lines += [f"INSTRUMENTATION_STATUS: class={case['class']}",
                      f"INSTRUMENTATION_STATUS: test={case['method']}",
                      'INSTRUMENTATION_STATUS: numtests=19',
                      f'INSTRUMENTATION_STATUS_CODE: {code}']
    return '\n'.join(lines) + '\nINSTRUMENTATION_CODE: -1\n'


class ParserTests(unittest.TestCase):
    def test_all_19(self):
        self.assertEqual(len(parse_output(output(), EXPECTED)), 19)

    def test_rejects_missing(self):
        with self.assertRaises(ValueError):
            parse_output(output(EXPECTED[:-1]), EXPECTED)

    def test_rejects_duplicate(self):
        with self.assertRaises(ValueError):
            parse_output(output(EXPECTED[:-1] + EXPECTED[:1]), EXPECTED)

    def test_rejects_failed_skipped_and_incomplete(self):
        for code in (-1, -2, -3, -4):
            with self.subTest(code=code), self.assertRaises(ValueError):
                parse_output(output().replace('STATUS_CODE: 0', f'STATUS_CODE: {code}', 1), EXPECTED)
        with self.assertRaises(ValueError):
            parse_output(output().replace('INSTRUMENTATION_CODE: -1', ''), EXPECTED)

    def test_rejects_wrong_count(self):
        with self.assertRaises(ValueError):
            parse_output(output().replace('numtests=19', 'numtests=18'), EXPECTED)

    def test_rejects_reordered_terminal_events(self):
        with self.assertRaises(ValueError):
            parse_output(output().replace('STATUS_CODE: 1', 'STATUS_CODE: 0', 1), EXPECTED)

    def test_rejects_extra_summary_failure(self):
        with self.assertRaises(ValueError):
            parse_output(output() + '\nINSTRUMENTATION_FAILED: crashed\n', EXPECTED)

    def test_rejects_terminal_before_start(self):
        wrong=output().replace('STATUS_CODE: 1','STATUS_CODE: X').replace('STATUS_CODE: 0','STATUS_CODE: 1').replace('STATUS_CODE: X','STATUS_CODE: 0')
        with self.assertRaises(ValueError): parse_output(wrong,EXPECTED)

    def test_rejects_premature_and_repeated_final(self):
        for wrong in ['INSTRUMENTATION_CODE: -1\n'+output(), output()+'INSTRUMENTATION_CODE: -1\n']:
            with self.subTest(wrong=wrong[:40]), self.assertRaises(ValueError): parse_output(wrong,EXPECTED)

    def test_rejects_tail_bundle(self):
        with self.assertRaises(ValueError):
            parse_output(output()+'INSTRUMENTATION_STATUS: class=unfinished\n',EXPECTED)

    def test_rejects_overlap(self):
        first=output().split('INSTRUMENTATION_STATUS_CODE: 1',1)[0]+'INSTRUMENTATION_STATUS_CODE: 1\n'
        with self.assertRaises(ValueError): parse_output(first+output(),EXPECTED)

    def test_rejects_malformed_protocol_and_abort(self):
        for tail in ['INSTRUMENTATION_STATUS_CODE: broken','INSTRUMENTATION_CODE: broken',
                     'INSTRUMENTATION_STATUS: broken','INSTRUMENTATION_ABORTED: error',
                     'INSTRUMENTATION_RESULT: shortMsg=crash']:
            with self.subTest(tail=tail),self.assertRaises(ValueError): parse_output(output()+tail,EXPECTED)


# These fixtures are synthetic protocol only, not real device test outcomes.
import os
import stat
import subprocess
import sys
import tempfile
import time
from unittest import mock
from result_parser import (parse_partial_output, read_partial_output, PARTIAL_EXPECTED_CASES,
                           MAX_PARTIAL_BYTES, MAX_PARTIAL_LINE_BYTES, MAX_PARTIAL_LINES)


def partial_bundle(case, code, number=1, *, stack=None, stream=None, extra=''):
    if stream is None:
        stream = '.' if code == 0 else ''
    lines = [f"INSTRUMENTATION_STATUS: class={case['class']}",
             f'INSTRUMENTATION_STATUS: current={number}',
             'INSTRUMENTATION_STATUS: id=AndroidJUnitRunner',
             'INSTRUMENTATION_STATUS: numtests=19']
    if stack is not None:
        lines.append('INSTRUMENTATION_STATUS: stack=' + stack)
    lines += ['INSTRUMENTATION_STATUS: stream=' + stream,
              f"INSTRUMENTATION_STATUS: test={case['method']}",
              f'INSTRUMENTATION_STATUS_CODE: {code}']
    return '\n'.join(lines) + '\n' + extra


def partial_run(cases=EXPECTED, codes=None, final=True, result=True):
    codes = codes or [0] * len(cases)
    text = ''
    last_class = None
    for number, (case, code) in enumerate(zip(cases, codes), 1):
        stream = '\n' + case['class'] + ':' if case['class'] != last_class else ''
        text += partial_bundle(case, 1, number, stream=stream)
        text += partial_bundle(case, code, number)
        last_class = case['class']
    if final:
        if result:
            text += ('INSTRUMENTATION_RESULT: stream=\nTime: 1.23\n\n'
                     + ('FAILURES!!!\nTests run: 19, Failures: 1\n' if any(c in (-1, -2) for c in codes)
                        else 'OK (19 tests)\n') + '\n')
        text += 'INSTRUMENTATION_CODE: -1\n'
    return text


class PartialParserTests(unittest.TestCase):
    def checked(self, raw):
        value = parse_partial_output(raw, EXPECTED)
        self.assertEqual(set(value), {'cases', 'protocol_state'})
        self.assertEqual(len(value['cases']), 19)
        self.assertEqual([(x['class'], x['method']) for x in value['cases']], list(PARTIAL_EXPECTED_CASES))
        for case in value['cases']:
            self.assertEqual(set(case), {'class', 'method', 'state'})
            self.assertIn(case['state'], {'passed', 'failed', 'skipped', 'started', 'unknown'})
        self.assertIn(value['protocol_state'], {'complete', 'incomplete', 'invalid'})
        return value

    def invalid(self, raw):
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'invalid')
        self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})
        return value

    def test_empty_has_no_observation(self):
        for raw in ('', b''):
            value = self.checked(raw)
            self.assertEqual(value['protocol_state'], 'incomplete')
            self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})

    def test_start_pass_and_unknown_are_distinct(self):
        raw = partial_run(EXPECTED[:1], final=False) + partial_bundle(EXPECTED[1], 1, 2)
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual([x['state'] for x in value['cases']], ['passed', 'started'] + ['unknown'] * 17)

    def test_full_complete_is_not_an_alternate_pass_gate(self):
        raw = partial_run()
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'complete')
        self.assertEqual({x['state'] for x in value['cases']}, {'passed'})
        self.assertEqual(len(parse_output(raw, EXPECTED)), 19)
        mixed = partial_run(codes=[-2, -3, -4, -1] + [0] * 15)
        value = self.checked(mixed)
        self.assertEqual(value['protocol_state'], 'complete')
        self.assertEqual([x['state'] for x in value['cases'][:4]], ['failed', 'skipped', 'skipped', 'failed'])
        with self.assertRaises(ValueError):
            parse_output(mixed, EXPECTED)

    def test_all_terminal_without_final_still_incomplete(self):
        value = self.checked(partial_run(final=False))
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual({x['state'] for x in value['cases']}, {'passed'})

    def test_complete_without_result_prose(self):
        self.assertEqual(self.checked(partial_run(result=False))['protocol_state'], 'complete')

    def test_valid_order_is_observed_not_inferred(self):
        value = self.checked(partial_run(list(reversed(EXPECTED))))
        self.assertEqual(value['protocol_state'], 'complete')
        self.assertEqual({x['state'] for x in value['cases']}, {'passed'})

    def test_minimal_sorted_bundles(self):
        raw = ''
        for code in (1, 0):
            raw += (f"INSTRUMENTATION_STATUS: class={EXPECTED[0]['class']}\n"
                    'INSTRUMENTATION_STATUS: numtests=19\n'
                    f"INSTRUMENTATION_STATUS: test={EXPECTED[0]['method']}\n"
                    f'INSTRUMENTATION_STATUS_CODE: {code}\n')
        self.assertEqual(self.checked(raw)['cases'][0]['state'], 'passed')

    def test_failure_trace_is_never_exported(self):
        secret = 'https://private.invalid/a?token=SECRET /private/file SECRET_ENV'
        trace = 'java.lang.AssertionError: ' + secret + '\n\tat fixture.Test.body(Test.kt:1)'
        raw = partial_bundle(EXPECTED[0], 1) + partial_bundle(EXPECTED[0], -2, stack=trace,
            stream='\nError in ' + EXPECTED[0]['method'] + ':\n' + trace)
        value = self.checked(raw)
        self.assertEqual(value['cases'][0]['state'], 'failed')
        self.assertNotIn('SECRET', json.dumps(value))
        self.assertNotIn('private', json.dumps(value))

    def test_clean_partial_bundle_does_not_count_as_start(self):
        raw = partial_run(EXPECTED[:1], final=False)
        raw += f"INSTRUMENTATION_STATUS: class={EXPECTED[1]['class']}\n"
        value = self.checked(raw)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual([x['state'] for x in value['cases'][:2]], ['passed', 'unknown'])

    def test_unknown_identity_never_appears_in_output(self):
        for key in ('class', 'method'):
            bad = dict(EXPECTED[0]); bad[key] = 'SECRET_UNAPPROVED'
            value = self.invalid(partial_bundle(bad, 1))
            self.assertNotIn('SECRET_UNAPPROVED', json.dumps(value))
        other = next(x for x in EXPECTED if x['class'] != EXPECTED[0]['class'])
        bad = dict(EXPECTED[0], method=other['method'])
        self.invalid(partial_bundle(bad, 1))

    def test_invalid_expected_never_becomes_an_allowlist(self):
        variants = [None, tuple(EXPECTED), EXPECTED[:-1], EXPECTED[:-1] + EXPECTED[:1],
                    [dict(x, extra='SECRET') for x in EXPECTED],
                    [dict(x, method='SECRET') for x in EXPECTED]]
        for expected in variants:
            with self.subTest(expected_type=type(expected).__name__):
                value = parse_partial_output(partial_run(), expected)
                self.assertEqual(value['protocol_state'], 'invalid')
                self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})
                self.assertNotIn('SECRET', json.dumps(value))

    def test_duplicate_fields_and_wrong_order(self):
        raw = partial_bundle(EXPECTED[0], 1)
        first = raw.splitlines()[0] + '\n'
        self.invalid(first + raw)
        self.invalid(raw.replace('INSTRUMENTATION_STATUS: id=AndroidJUnitRunner\n', '')
                     .replace('INSTRUMENTATION_STATUS_CODE: 1',
                              'INSTRUMENTATION_STATUS: id=AndroidJUnitRunner\nINSTRUMENTATION_STATUS_CODE: 1'))

    def test_overlap_terminal_without_start_and_identity_mismatch(self):
        start = partial_bundle(EXPECTED[0], 1)
        for raw in (partial_bundle(EXPECTED[0], 0), start + start,
                    start + partial_bundle(EXPECTED[1], 1, 2),
                    start + partial_bundle(EXPECTED[1], 0),
                    partial_run(EXPECTED[:1], final=False) + start):
            with self.subTest(raw_len=len(raw)):
                self.invalid(raw)

    def test_wrong_counts_current_id_and_unknown_fields(self):
        raw = partial_bundle(EXPECTED[0], 1)
        for wrong in ('numtests=18', 'numtests=019', 'numtests=999999999999999999',
                      'current=0', 'current=2', 'current=20', 'current=01', 'id=OtherRunner'):
            key = wrong.split('=')[0]
            valid = {'numtests': '19', 'current': '1', 'id': 'AndroidJUnitRunner'}[key]
            with self.subTest(wrong=wrong):
                self.invalid(raw.replace(key + '=' + valid, wrong))
        self.invalid(raw.replace('INSTRUMENTATION_STATUS: id=', 'INSTRUMENTATION_STATUS: unknown='))
        self.invalid(raw + partial_bundle(EXPECTED[0], 0, 2))

    def test_invalid_terminal_and_malformed_protocol(self):
        raw = partial_bundle(EXPECTED[0], 1)
        for code in ('2', '-5', '-999', '00', '+1', '1 ', 'broken', ''):
            self.invalid(raw.replace('STATUS_CODE: 1', 'STATUS_CODE: ' + code))
        for tail in ('INSTRUMENTATION_STATUS: broken\n', 'INSTRUMENTATION_CODE: broken\n',
                     'INSTRUMENTATION_ABORTED: SECRET\n', 'INSTRUMENTATION_FAILED: SECRET\n',
                     'INSTRUMENTATION_RESULT: shortMsg=SECRET\n', 'adb: SECRET\n'):
            self.invalid(raw + tail)

    def test_final_must_be_exact_and_last_and_after_all_cases(self):
        for raw in ('INSTRUMENTATION_CODE: -1\n',
                    partial_run(EXPECTED[:1]),
                    partial_run() + 'INSTRUMENTATION_CODE: -1\n',
                    partial_run() + partial_bundle(EXPECTED[0], 1),
                    partial_run().replace('INSTRUMENTATION_CODE: -1', 'INSTRUMENTATION_CODE: 0'),
                    partial_run() + 'unexpected tail\n',
                    partial_run().replace('INSTRUMENTATION_RESULT: stream=', 'INSTRUMENTATION_RESULT: unknown=')):
            self.invalid(raw)

    def test_stream_and_stack_cannot_turn_failure_into_pass(self):
        start = partial_bundle(EXPECTED[0], 1)
        self.invalid(partial_bundle(EXPECTED[0], 1, stack='java.lang.Error'))
        self.invalid(start + partial_bundle(EXPECTED[0], 0, stack='java.lang.Error'))
        self.invalid(start + partial_bundle(EXPECTED[0], 0, stream='SECRET error'))
        self.invalid(start + partial_bundle(EXPECTED[0], -3, stack='java.lang.Error'))
        self.invalid(partial_bundle(EXPECTED[0], 1, stream='SECRET not a class header'))

    def test_protocol_injection_rejected(self):
        start = partial_bundle(EXPECTED[0], 1)
        for injected in ('java.lang.Error\nINSTRUMENTATION_STATUS_CODE: 0',
                         'java.lang.Error\nINSTRUMENTATION_STATUS: class=' + EXPECTED[1]['class'],
                         'java.lang.Error\nINSTRUMENTATION_STATUS: test=' + EXPECTED[1]['method'],
                         'java.lang.Error\n INSTRUMENTATION_STATUS_CODE: 0',
                         'java.lang.Error INSTRUMENTATION_CODE: -1'):
            self.invalid(start + partial_bundle(EXPECTED[0], -2, stack=injected))
        self.invalid(partial_bundle(EXPECTED[0], 1, stream='\nINSTRUMENTATION_STATUS_CODE: 0'))
        self.invalid(partial_run() + '\nINSTRUMENTATION_STATUS_CODE: 0\n')
        self.invalid(' SECRET INSTRUMENTATION_STATUS_CODE: 0\n' + partial_run())

    def test_contradictory_failure_footer_invalidates_prior_passes(self):
        raw = partial_run()
        for bad in ('FAILURES!!!', 'arbitrary SECRET text', 'OK (18 tests)'):
            self.invalid(raw.replace('OK (19 tests)', bad))
            self.invalid(raw.replace('INSTRUMENTATION_RESULT: stream=', 'INSTRUMENTATION_RESULT: stream=' + bad))
        mixed = partial_run(codes=[-2] + [0] * 18)
        self.assertEqual(self.checked(mixed)['cases'][0]['state'], 'failed')
        self.invalid(mixed.replace('FAILURES!!!\nTests run: 19, Failures: 1', 'OK (19 tests)'))

    def test_utf8_control_characters_and_line_endings(self):
        good = partial_run().replace('\n', '\r\n').encode('utf-8')
        self.assertEqual(self.checked(good)['protocol_state'], 'complete')
        for bad in (b'\xff\n', b'\xc3\n', '\ud800\n', '\0\n', '\x1b[31m\n', '\x7f\n',
                    '\x85\n', '\u2028\n', '\u2029\n', '\u202e\n', '\u200b\n',
                    partial_run().replace('\n', '\r', 1)):
            with self.subTest(kind=type(bad).__name__):
                self.invalid(bad)

    def test_truncated_line_is_invalid_not_pass(self):
        for raw in (partial_bundle(EXPECTED[0], 1).rstrip('\n'), partial_run().rstrip('\n'),
                    partial_run(EXPECTED[:1], final=False) + 'INSTRUMENTATION_STAT',
                    partial_run(EXPECTED[:1], final=False) + 'INSTRUMENTATION_STATUS_CODE:\n'):
            self.invalid(raw)

    def test_bounds_and_unexpected_input_types(self):
        for raw in (b'x' * (MAX_PARTIAL_BYTES + 1), 'x' * (MAX_PARTIAL_BYTES + 1),
                    '界' * (MAX_PARTIAL_BYTES // 3 + 1),
                    'x' * (MAX_PARTIAL_LINE_BYTES + 1) + '\n',
                    '\n' * (MAX_PARTIAL_LINES + 1), None, bytearray(b''), {}, 3):
            self.invalid(raw)

    def test_no_repeated_class_header_on_same_class(self):
        raw = partial_run(EXPECTED[:1], final=False)
        same = next(x for x in EXPECTED[1:] if x['class'] == EXPECTED[0]['class'])
        self.invalid(raw + partial_bundle(same, 1, 2, stream='\n' + same['class'] + ':'))


class PartialReaderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='partial-parser-tests-')
        self.root = Path(self.temp.name)
        self.path = self.root / 'owned.txt'
        self.path.write_text(partial_run(EXPECTED[:1], final=False))

    def tearDown(self):
        self.temp.cleanup()

    def invalid_path(self, path):
        value = read_partial_output(path, EXPECTED)
        self.assertEqual(value['protocol_state'], 'invalid')
        self.assertEqual({x['state'] for x in value['cases']}, {'unknown'})
        return value

    def test_reads_owned_stable_partial(self):
        value = read_partial_output(self.path, EXPECTED)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual(value['cases'][0]['state'], 'passed')

    def test_rejects_missing_directory_symlink_and_hardlink(self):
        self.invalid_path(self.root / 'missing')
        self.invalid_path(self.root)
        link = self.root / 'link'; link.symlink_to(self.path)
        self.invalid_path(link)
        hard = self.root / 'hard'; os.link(self.path, hard)
        self.invalid_path(self.path)
        self.invalid_path(hard)

    def test_fifo_returns_without_waiting(self):
        fifo = self.root / 'fifo'; os.mkfifo(fifo)
        started = time.monotonic()
        self.invalid_path(fifo)
        self.assertLess(time.monotonic() - started, 1)

    def test_rejects_oversize_before_read(self):
        with self.path.open('wb') as out:
            out.truncate(MAX_PARTIAL_BYTES + 1)
        with mock.patch('os.read', side_effect=AssertionError('must not read oversize')):
            self.invalid_path(self.path)

    def test_rejects_wrong_owner_and_unstable_stat(self):
        real = os.fstat
        def wrong_owner(fd):
            original = real(fd)
            copied = mock.Mock(wraps=original)
            copied.st_mode = original.st_mode; copied.st_uid = os.getuid() + 1
            return copied
        with mock.patch('os.fstat', side_effect=wrong_owner):
            self.invalid_path(self.path)
        calls = 0
        def unstable(fd):
            nonlocal calls
            original = real(fd); calls += 1
            if calls == 2:
                values = {k: getattr(original, k) for k in ('st_dev', 'st_ino', 'st_mode', 'st_uid',
                           'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}
                values['st_mtime_ns'] += 1
                return type('ChangedStat', (), values)()
            return original
        with mock.patch('os.fstat', side_effect=unstable):
            self.invalid_path(self.path)

    def test_read_errors_and_invalid_encoding_are_redacted(self):
        with mock.patch('os.read', side_effect=OSError('SECRET /private/token')):
            self.assertNotIn('SECRET', json.dumps(self.invalid_path(self.path)))
        self.path.write_bytes(b'\xff\n')
        self.invalid_path(self.path)

    def test_extra_bytes_after_initial_stat_are_invalid(self):
        real = os.read
        first = True
        def growing(fd, length):
            nonlocal first
            if first:
                first = False
                with self.path.open('ab') as output:
                    output.write(b'\n')
            return real(fd, length)
        with mock.patch('os.read', side_effect=growing):
            self.invalid_path(self.path)

    def test_short_subprocess_timeout_preserves_partial_file_only(self):
        raw = partial_run(EXPECTED[:1], final=False) + partial_bundle(EXPECTED[1], 1, 2)
        code = 'import sys,time;sys.stdout.write(' + repr(raw) + ');sys.stdout.flush();time.sleep(10)'
        with self.path.open('wb') as output:
            with self.assertRaises(subprocess.TimeoutExpired) as caught:
                subprocess.run([sys.executable, '-c', code], stdout=output, stderr=subprocess.STDOUT,
                               timeout=0.2, check=False)
        self.assertIsNone(caught.exception.stdout)
        value = read_partial_output(self.path, EXPECTED)
        self.assertEqual(value['protocol_state'], 'incomplete')
        self.assertEqual([x['state'] for x in value['cases'][:2]], ['passed', 'started'])
        with self.assertRaises(ValueError):
            parse_output(self.path.read_text(), EXPECTED)


if __name__ == '__main__':
    unittest.main()
