import json
from pathlib import Path
import unittest
from result_parser import parse_output

EXPECTED = json.loads((Path(__file__).resolve().parents[1] / 'expected-tests.json').read_text())


def output(cases=EXPECTED):
    lines = []
    for case in cases:
        for code in (1, 0):
            lines += [f"INSTRUMENTATION_STATUS: class={case['class']}",
                      f"INSTRUMENTATION_STATUS: test={case['method']}",
                      'INSTRUMENTATION_STATUS: numtests=19',
                      f'INSTRUMENTATION_STATUS_CODE: {code}']
    return '\n'.join(lines) + '\nINSTRUMENTATION_CODE: -1\n'


class ParserTests(unittest.TestCase):
    def test_all_19(self):
        self.assertEqual(len(parse_output(output(), EXPECTED)), 19)

    def test_rejects_missing(self):
        with self.assertRaises(ValueError):
            parse_output(output(EXPECTED[:-1]), EXPECTED)

    def test_rejects_duplicate(self):
        with self.assertRaises(ValueError):
            parse_output(output(EXPECTED[:-1] + EXPECTED[:1]), EXPECTED)

    def test_rejects_failed_skipped_and_incomplete(self):
        for code in (-1, -2, -3, -4):
            with self.subTest(code=code), self.assertRaises(ValueError):
                parse_output(output().replace('STATUS_CODE: 0', f'STATUS_CODE: {code}', 1), EXPECTED)
        with self.assertRaises(ValueError):
            parse_output(output().replace('INSTRUMENTATION_CODE: -1', ''), EXPECTED)

    def test_rejects_wrong_count(self):
        with self.assertRaises(ValueError):
            parse_output(output().replace('numtests=19', 'numtests=18'), EXPECTED)

    def test_rejects_reordered_terminal_events(self):
        with self.assertRaises(ValueError):
            parse_output(output().replace('STATUS_CODE: 1', 'STATUS_CODE: 0', 1), EXPECTED)

    def test_rejects_extra_summary_failure(self):
        with self.assertRaises(ValueError):
            parse_output(output() + '\nINSTRUMENTATION_FAILED: crashed\n', EXPECTED)

    def test_rejects_terminal_before_start(self):
        wrong=output().replace('STATUS_CODE: 1','STATUS_CODE: X').replace('STATUS_CODE: 0','STATUS_CODE: 1').replace('STATUS_CODE: X','STATUS_CODE: 0')
        with self.assertRaises(ValueError): parse_output(wrong,EXPECTED)

    def test_rejects_premature_and_repeated_final(self):
        for wrong in ['INSTRUMENTATION_CODE: -1\n'+output(), output()+'INSTRUMENTATION_CODE: -1\n']:
            with self.subTest(wrong=wrong[:40]), self.assertRaises(ValueError): parse_output(wrong,EXPECTED)

    def test_rejects_tail_bundle(self):
        with self.assertRaises(ValueError):
            parse_output(output()+'INSTRUMENTATION_STATUS: class=unfinished\n',EXPECTED)

    def test_rejects_overlap(self):
        first=output().split('INSTRUMENTATION_STATUS_CODE: 1',1)[0]+'INSTRUMENTATION_STATUS_CODE: 1\n'
        with self.assertRaises(ValueError): parse_output(first+output(),EXPECTED)

    def test_rejects_malformed_protocol_and_abort(self):
        for tail in ['INSTRUMENTATION_STATUS_CODE: broken','INSTRUMENTATION_CODE: broken',
                     'INSTRUMENTATION_STATUS: broken','INSTRUMENTATION_ABORTED: error',
                     'INSTRUMENTATION_RESULT: shortMsg=crash']:
            with self.subTest(tail=tail),self.assertRaises(ValueError): parse_output(output()+tail,EXPECTED)


if __name__ == '__main__':
    unittest.main()
