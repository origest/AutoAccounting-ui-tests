import json
import os
from pathlib import Path
import tempfile
import unittest
from safe_scratch import create, reclaim, validate, MIN_FREE


class ScratchTests(unittest.TestCase):
    def test_gate_unchanged(self):
        self.assertEqual(MIN_FREE, 8804682957)

    def test_never_adopts_existing(self):
        with tempfile.TemporaryDirectory() as temp:
            create(temp, {'run': 'one'})
            with self.assertRaises(FileExistsError):
                create(temp, {'run': 'one'})

    def test_reclaims_only_owned_build_and_preserves_evidence(self):
        with tempfile.TemporaryDirectory() as temp:
            root = create(temp, {'run': 'one'})
            (root/'build').mkdir()
            (root/'build'/'file').write_text('build')
            (root/'apks').mkdir()
            (root/'apks'/'target.apk').write_text('retained')
            reclaim(root, {'run': 'one'}, ('build',))
            self.assertFalse((root/'build').exists())
            self.assertEqual((root/'apks'/'target.apk').read_text(), 'retained')

    def test_rejects_wrong_run_and_nonallowlisted_path(self):
        with tempfile.TemporaryDirectory() as temp:
            root = create(temp, {'run': 'one'})
            with self.assertRaises(ValueError):
                validate(root, {'run': 'two'})
            with self.assertRaises(ValueError):
                reclaim(root, {'run': 'one'}, ('../',))

    def test_does_not_follow_cleanup_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root = create(temp, {'run': 'one'})
            other = Path(temp)/'other'; other.mkdir()
            (other/'keep').write_text('retained')
            (root/'build').symlink_to(other, target_is_directory=True)
            with self.assertRaises(ValueError):
                reclaim(root, {'run': 'one'}, ('build',))
            self.assertEqual((other/'keep').read_text(), 'retained')


if __name__ == '__main__':
    unittest.main()
