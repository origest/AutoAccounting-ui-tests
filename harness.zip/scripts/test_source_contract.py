import unittest
from source_contract import check_wrapper,EXPECTED_URL,EXPECTED_HASH


class SourceContractTests(unittest.TestCase):
    def text(self): return 'distributionUrl='+EXPECTED_URL+'\ndistributionSha256Sum='+EXPECTED_HASH+'\n'
    def test_exact_wrapper(self): check_wrapper(self.text())
    def test_rejects_comment_fake_or_duplicate_or_alternate(self):
        for bad in ['#'+self.text().replace('\n','\n#'),self.text()+'distributionUrl='+EXPECTED_URL,
                    self.text().replace('gradle-8.11.1','gradle-8.12')]:
            with self.subTest(bad=bad[:30]),self.assertRaises(ValueError): check_wrapper(bad)

    def test_rejects_escaped_and_whitespace_keys(self):
        for key in (r'distribution\u0055rl','distribution Url',r'distribution\Url','distributionUrl:'):
            with self.subTest(key=key),self.assertRaises(ValueError):
                check_wrapper(self.text()+key+'=https\\://example.invalid/other.zip\n')


if __name__=='__main__': unittest.main()
