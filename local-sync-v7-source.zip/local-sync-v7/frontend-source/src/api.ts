declare global {
  interface Window {
    __localLedgerResolve?: (id: string, envelopeJson: string) => void;
    LocalLedger?: {
      request(id: string, path: string): void;
      openSettings(): void;
    };
  }
}

/** Only the bundled Android origin may invoke the native bridge. */
export const isLocalMode = window.location.origin === "https://appassets.androidplatform.net";
export function openLocalSettings() {
  if (!isLocalMode || typeof window.LocalLedger?.openSettings !== "function")
    throw new Error("本机接收设置暂不可用，请返回应用首页重试。");
  window.LocalLedger.openSettings();
}

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
type LocalEnvelope = { ok: boolean; data?: unknown; status?: number; message?: string };
const pendingLocal = new Map<string, {
  resolve: (value: unknown) => void;
  reject: (error: ApiError) => void;
  timer: ReturnType<typeof setTimeout>;
}>();
const localRequestPrefix = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
let localRequestSequence = 0;
if (isLocalMode) {
  window.__localLedgerResolve = (id, envelopeJson) => {
    const pending = pendingLocal.get(id);
    if (!pending) return; // Late, duplicate, or unknown native reply.
    pendingLocal.delete(id);
    clearTimeout(pending.timer);
    let envelope: LocalEnvelope;
    try { envelope = JSON.parse(envelopeJson); }
    catch { pending.reject(new ApiError(502, "本机数据返回异常，请保留应用数据并重试。")); return; }
    if (envelope?.ok !== true) {
      pending.reject(new ApiError(
        typeof envelope?.status === "number" ? envelope.status : 500,
        typeof envelope?.message === "string" ? envelope.message : "读取本机数据失败。",
      ));
    } else if (!Object.prototype.hasOwnProperty.call(envelope, "data")) {
      pending.reject(new ApiError(502, "本机数据返回不完整，请保留应用数据并重试。"));
    } else pending.resolve(envelope.data);
  };
}
function requestLocal<T>(path: string): Promise<T> {
  if (pendingLocal.size >= 32)
    return Promise.reject(new ApiError(429, "本机读取任务过多，请稍后重试。"));
  return new Promise<T>((resolve, reject) => {
    const id = `${localRequestPrefix}-${++localRequestSequence}`;
    const timer = setTimeout(() => {
      if (!pendingLocal.delete(id)) return;
      reject(new ApiError(504, "读取本机数据超时，请重试；不会改用云端连接。"));
    }, 30_000);
    // Install before invoking native: even an immediate reply must find this request.
    pendingLocal.set(id, { resolve: value => resolve(value as T), reject, timer });
    try { window.LocalLedger!.request(id, path); }
    catch {
      if (pendingLocal.delete(id)) {
        clearTimeout(timer);
        reject(new ApiError(502, "本机数据接口调用失败，请重试。"));
      }
    }
  });
}
export async function api<T = any>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  if (isLocalMode) {
    const method = (options.method || "GET").toUpperCase();
    if (method !== "GET" || options.body != null)
      throw new ApiError(405, "本机看板目前只读，不会执行在线写入。");
    const url = new URL(path, window.location.origin);
    if (url.origin !== window.location.origin || !/^\/api\/(session|sources|meta|summary|bills(?:\/[^/]+)?)$/.test(url.pathname))
      throw new ApiError(404, "本机看板不支持此操作。");
    if (typeof window.LocalLedger?.request !== "function")
      throw new ApiError(503, "本机数据接口不可用。请返回应用首页后重新进入，不会改用云端连接。");
    return requestLocal<T>(url.pathname + url.search);
  }
  const headers = new Headers(options.headers);
  headers.set("X-Requested-With", "bill-dashboard");
  if (options.body && !(options.body instanceof FormData))
    headers.set("Content-Type", "application/json");
  const response = await fetch(path, {
    ...options,
    headers,
    credentials: "same-origin",
  });
  if (!response.ok) {
    let message = `请求失败 (${response.status})`;
    try {
      const body = await response.json();
      message =
        typeof body.detail === "string"
          ? body.detail
          : body.detail
              ?.map((e: any) => `${e.loc?.slice(1).join(".")}: ${e.msg}`)
              .join("；") || message;
    } catch {
      /* Keep HTTP status. */
    }
    if (response.status === 401 && !path.endsWith("/login"))
      window.dispatchEvent(new Event("session-expired"));
    throw new ApiError(response.status, message);
  }
  return response.json();
}
export const post = (body?: unknown): RequestInit => ({
  method: "POST",
  body: body === undefined ? undefined : JSON.stringify(body),
});
export function money(value: string | number, currency = "CNY") {
  // Native summary values are exact decimal strings. Do not round them through IEEE754.
  if (isLocalMode && /^-?\d+(\.\d+)?$/.test(String(value))) {
    const input=String(value), negative=input.startsWith("-"), [whole,fraction=""]=input.replace(/^-/, "").split(".");
    let digits=(whole+(fraction+"00").slice(0,2)).replace(/^0+(?=\d)/, "");
    if ((fraction[2] || "0") >= "5") {
      let carry=1;const parts=digits.split("");
      for(let i=parts.length-1;i>=0&&carry;i--){const n=Number(parts[i])+carry;parts[i]=String(n%10);carry=Math.floor(n/10);}
      digits=(carry?"1":"")+parts.join("");
    }
    digits=digits.padStart(3,"0");const integer=digits.slice(0,-2).replace(/\B(?=(\d{3})+(?!\d))/g,",");
    const symbol=new Intl.NumberFormat("zh-CN",{style:"currency",currency}).formatToParts(0).find(p=>p.type==="currency")?.value || currency;
    return (negative&&/[1-9]/.test(digits)?"-":"")+symbol+integer+"."+digits.slice(-2);
  }
  return new Intl.NumberFormat("zh-CN", {
    style: "currency",
    currency,
    maximumFractionDigits: 2,
  }).format(Number(value));
}
export function dateTime(value: number | string | null) {
  if (!value) return "尚未接收";
  return new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    dateStyle: "medium",
    timeStyle: "short",
  }).format(
    new Date(
      typeof value === "string" && !/[Z+]/.test(value) ? `${value}Z` : value,
    ),
  );
}
export const types: Record<string, string> = {
  Expend: "支出",
  Income: "收入",
  Transfer: "转账",
  IncomeRefund: "退款",
  ExpendReimbursement: "待报销支出",
  IncomeReimbursement: "报销到账",
  ExpendLending: "借出",
  IncomeLending: "借入",
  ExpendRepayment: "还款",
  IncomeRepayment: "收款",
};
export const states: Record<string, string> = {
  Synced: "已同步",
  Edited: "已编辑",
  Wait2Edit: "待编辑",
};
export type Source = {
  id: string;
  name: string;
  kind: string;
  active: boolean;
  bill_count: number;
  last_received_at: string | null;
};
export type Bill = {
  snapshot_id?: string;
  id: string;
  external_id: string;
  source_name: string;
  type: string;
  state: string;
  money: string;
  fee: string;
  currency: string;
  time: number;
  category: string;
  book_name: string;
  shop_name: string;
  shop_item: string;
  account_from: string;
  account_to: string;
  remark: string;
  tags: string;
  flag: number;
  raw?: Record<string, unknown>;
  last_received_at: string;
};
export type Summary = {
  chart_safe?: boolean;
  income: string;
  expense: string;
  balance: string;
  refund: string;
  count: number;
  pending: number;
  excluded: number;
  categories: { name: string; value: string }[];
  daily: { date: string; income: string; expense: string }[];
};

export async function copyText(value: string) {
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(value);
      return;
    }
  } catch {
    /* Some Android WebViews do not grant the Clipboard API. */
  }
  const input = document.createElement("textarea");
  input.value = value;
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  try {
    if (!document.execCommand("copy")) throw new Error("请手动选择并复制令牌");
  } finally {
    input.remove();
  }
}

