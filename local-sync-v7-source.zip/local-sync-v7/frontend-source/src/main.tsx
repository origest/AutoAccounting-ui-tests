import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowRight,
  BarChart3,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Copy,
  Database,
  Download,
  FileUp,
  LayoutDashboard,
  ListFilter,
  LogOut,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Wallet,
  X,
} from "lucide-react";
import {
  api,
  isLocalMode,
  openLocalSettings,
  post,
  money,
  dateTime,
  states,
  types,
  copyText,
  type Bill,
  type Source,
  type Summary,
} from "./api";
import Chart from "./Charts";
import "./styles.css";

type Page = "overview" | "bills" | "sources" | "import";
const pages = [
  ["overview", "总览", LayoutDashboard],
  ["bills", "账单明细", ListFilter],
  ["sources", "数据来源", Database],
  ["import", "导入账单", FileUp],
] as const;
const today = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Asia/Shanghai",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
}).format(new Date());
const initialFilter = {
  start: `${today.slice(0, 7)}-01`,
  end: today,
  currency: "CNY",
  source_id: "",
  state: "",
  type: "",
  book: "",
  category: "",
  q: "",
};
function Logo() {
  return (
    <div className="brand">
      <span className="brand-icon">
        <BarChart3 size={24} />
      </span>
      <span>
        账迹<small>BILL DASHBOARD</small>
      </span>
    </div>
  );
}
function ErrorBox({ message }: { message: string }) {
  return message ? (
    <div className="error" role="alert">
      {message}
    </div>
  ) : null;
}
function Empty({
  title = "还没有账单",
  children,
}: {
  title?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="empty">
      <Wallet size={34} />
      <h3>{title}</h3>
      <p>{children || "调整筛选条件，或接入一个数据源后再来看看。"}</p>
    </div>
  );
}
function Modal({
  title,
  children,
  close,
}: {
  title: string;
  children: React.ReactNode;
  close: () => void;
}) {
  const panel = React.useRef<HTMLElement>(null);
  const closeRef = React.useRef(close);
  closeRef.current = close;
  useEffect(() => {
    const old = document.activeElement as HTMLElement | null;
    panel.current?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key === "Tab") {
        const items = panel.current?.querySelectorAll<HTMLElement>(
          "button, input, select, textarea, a[href]",
        );
        if (!items?.length) return;
        const first = items[0],
          last = items[items.length - 1];
        if (
          event.shiftKey &&
          (document.activeElement === first ||
            document.activeElement === panel.current)
        ) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.removeEventListener("keydown", key);
      old?.focus();
    };
  }, []);
  return (
    <div
      className="modal-overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <section
        ref={panel}
        tabIndex={-1}
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <header>
          <h2>{title}</h2>
          <button className="icon-button" onClick={close} aria-label="关闭">
            <X size={20} />
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}
function LocalSources({ sources }: { sources: Source[] }) {
  const [error, setError] = useState("");
  return <section className="panel local-source-panel">
    <div className="panel-heading"><div><h2>同一手机，本机接收</h2><p>账单通过 Android 应用间接口保存到本机，不经过服务器。</p></div></div>
    <ErrorBox message={error} />
    <div className="local-source-content">
      {sources.length ? sources.map((source) => <div className="local-source-item" key={source.id}>
        <h3>{source.name}</h3>
        <p>接收授权：{source.active ? "已开启" : "未开启"} · 已保存 {source.bill_count} 笔</p>
        <p className="muted">最近接收：{dateTime(source.last_received_at)}</p>
      </div>) : <p>还没有接收记录。请先在本机接收设置中授权自动记账。</p>}
      <button className="primary" onClick={() => { try { openLocalSettings(); setError(""); } catch (e) { setError((e as Error).message); } }}><ShieldCheck size={17} />打开本机接收设置</button>
      <p className="muted">自动记账需要支持“账迹（本机）”的版本。此处展示同步副本，修改请在自动记账中完成。</p>
      <p className="muted">完整离线副本从接收设置发起，需在自动记账明确授权，完成后更新看板。旧补传归档单独保存，不与副本混合。显示的是最后接收副本，不保证来源实时最新；撤销只停止后续传输，已收及在途副本可能保留。</p>
    </div>
  </section>;
}

function Login({ onLogin }: { onLogin: () => void }) {
  const [password, setPassword] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api("/api/login", post({ password }));
      onLogin();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="login">
      <div className="login-story">
        <Logo />
        <div>
          <span className="eyebrow">YOUR MONEY, IN PERSPECTIVE</span>
          <h1>
            每一笔生活，
            <br />
            都有迹可循。
          </h1>
          <p>
            把分散的账单汇集到一起。
            <br />
            看清收支的变化，让财务记录更有条理。
          </p>
          <div className="story-lines">
            <span />
            <span />
            <span />
            <span />
            <span />
            <span />
            <span />
          </div>
        </div>
        <small>AutoAccounting 自动同步 · 标准 CSV 导入</small>
      </div>
      <div className="login-form">
        <form onSubmit={submit}>
          <span className="tag">
            <ShieldCheck size={15} /> 私人账单空间
          </span>
          <h2>欢迎回到账迹</h2>
          <p className="muted">使用部署时设置的管理员密码登录。</p>
          <label>
            管理员密码
            <input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="输入密码"
            />
          </label>
          <ErrorBox message={error} />
          <button className="primary wide" disabled={busy}>
            {busy ? "正在登录…" : "进入我的看板"}
            <ArrowRight size={18} />
          </button>
          <p className="login-note">账单仅保存在你部署的服务中。</p>
        </form>
      </div>
    </div>
  );
}
function App() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [page, setPage] = useState<Page>("overview"),
    [filter, setFilter] = useState(initialFilter);
  const detailRequest=React.useRef(0);
  const [localDataset,setLocalDataset]=useState<"copy"|"archive">("copy");
  const [localMetaReady,setLocalMetaReady]=useState(false);
  const [sources, setSources] = useState<Source[]>([]),
    [meta, setMeta] = useState<{
      currencies: string[];
      books: string[];
      categories: string[];
      dataset?: "copy"|"archive";
      snapshot_id?: string|null;
      captured_at?: string|null;
      last_synced_at?: string|null;
    }>({ currencies: ["CNY"], books: [], categories: [] });
  const [summary, setSummary] = useState<Summary | null>(null),
    [bills, setBills] = useState<Bill[]>([]),
    [total, setTotal] = useState(0),
    [pageNumber, setPageNumber] = useState(1);
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [refresh, setRefresh] = useState(0),
    [detail, setDetail] = useState<Bill | null>(null);
  const [appliedSearch, setAppliedSearch] = useState("");
  const query = useMemo(() => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...filter, q: appliedSearch }))
      if (v) p.set(k, v);
    if(isLocalMode){p.set("dataset",localDataset);if(localDataset==="copy"&&meta.snapshot_id)p.set("snapshot_id",meta.snapshot_id);}
    return p.toString();
  }, [filter, appliedSearch,localDataset,meta.snapshot_id]);
  useEffect(() => {
    const timeout = setTimeout(() => setAppliedSearch(filter.q), 250);
    return () => clearTimeout(timeout);
  }, [filter.q]);
  useEffect(() => {
    api("/api/session")
      .then(() => setAuthenticated(true))
      .catch((e) => {
        setError((e as Error).message);
        setAuthenticated(false);
      });
    const expire = () => setAuthenticated(false);
    window.addEventListener("session-expired", expire);
    return () => window.removeEventListener("session-expired", expire);
  }, []);
  useEffect(() => {
    if (!authenticated) return;
    let cancelled = false;
    if(isLocalMode){detailRequest.current++;setSummary(null);setLocalMetaReady(false);setBills([]);setDetail(null);setPageNumber(1);}
    const suffix=isLocalMode?`?dataset=${localDataset}`:"";
    api<typeof meta>(`/api/meta${suffix}`).then(async m=>{
      const pinned=isLocalMode&&m.snapshot_id?`${suffix}&snapshot_id=${encodeURIComponent(m.snapshot_id)}`:suffix;
      const sources=await api<Source[]>(`/api/sources${pinned}`);
      return {m,sources};
    }).then(({m,sources})=>{
      if(!cancelled){setSources(sources);setMeta(m);setLocalMetaReady(true);}
    }).catch(e=>{if(!cancelled){setError(e.message);setLocalMetaReady(false);}});
    return () => {
      cancelled = true;
    };
  }, [authenticated, refresh,localDataset]);
  useEffect(() => {
    if (!authenticated || !["overview", "bills"].includes(page)) return;
    if(isLocalMode&&(!localMetaReady||meta.dataset!==localDataset))return;
    if(isLocalMode&&localDataset==="copy"&&!meta.snapshot_id){setBills([]);setTotal(0);return;}
    let cancelled = false;
    if(isLocalMode)setSummary(null);
    setBusy(true);
    setError("");
    Promise.all([
      isLocalMode ? (localDataset!=="copy" ? Promise.resolve(null) : api<Summary>(`/api/summary?${query}`).catch(e=>{if(!cancelled)setError(`图表未生成：${e.message}；账单列表仍可查看。`);return null;})) : api<Summary>(`/api/summary?${query}`),
      api<{ items: Bill[]; total: number }>(
        `/api/bills?${query}&page=${page === "overview" ? 1 : pageNumber}&page_size=${page === "overview" ? 6 : 25}`,
      ),
    ])
      .then(([s, b]) => {
        if (!cancelled) {
          setSummary(s);
          setBills(b.items);
          setTotal(b.total);
        }
      })
      .catch((e) => {
        if (!cancelled) {
          setError(e.message);
          setSummary(null);
          setBills([]);
        }
      })
      .finally(() => {
        if (!cancelled) setBusy(false);
      });
    return () => {
      cancelled = true;
    };
  }, [authenticated, page, query, pageNumber, refresh,localMetaReady,localDataset,meta.dataset,meta.snapshot_id]);
  useEffect(() => {
    if (!isLocalMode) return;
    const resumed = () => {
      if (document.visibilityState === "visible") setRefresh((r) => r + 1);
    };
    document.addEventListener("visibilitychange", resumed);
    window.addEventListener("focus", resumed);
    window.addEventListener("local-ledger-resume", resumed);
    return () => {
      document.removeEventListener("visibilitychange", resumed);
      window.removeEventListener("focus", resumed);
      window.removeEventListener("local-ledger-resume", resumed);
    };
  }, []);
  function changeFilter(key: keyof typeof filter, value: string) {
    setFilter((f) => ({ ...f, [key]: value }));
    setPageNumber(1);
  }
  async function openBill(bill: Bill) {
    const request=++detailRequest.current;
    try {
      const suffix=isLocalMode?`?dataset=${localDataset}${bill.snapshot_id?`&snapshot_id=${encodeURIComponent(bill.snapshot_id)}`:""}`:"";
      const result=await api<Bill>(`/api/bills/${bill.id}${suffix}`);
      if(request===detailRequest.current)setDetail(result);
    } catch (e) {
      setError((e as Error).message);
    }
  }
  const chartOption = useMemo(
    () => ({
      color: ["#247a65", "#d29057"],
      tooltip: { trigger: "axis", renderMode: "richText" },
      legend: {
        right: 10,
        top: 2,
        icon: "circle",
        itemWidth: 8,
        textStyle: { color: "#7a8580" },
      },
      grid: { left: 55, right: 20, top: 45, bottom: 30 },
      xAxis: {
        type: "category",
        boundaryGap: false,
        data: summary?.daily.map((d) => d.date.slice(5)),
        axisLine: { lineStyle: { color: "#e8ece9" } },
        axisTick: { show: false },
        axisLabel: { color: "#83908a" },
      },
      yAxis: {
        type: "value",
        splitLine: { lineStyle: { color: "#eef1ee", type: "dashed" } },
        axisLabel: { color: "#83908a" },
      },
      series: [
        {
          name: "收入",
          type: "line",
          smooth: true,
          symbolSize: 6,
          areaStyle: { opacity: 0.08 },
          data: summary?.daily.map((d) => Number(d.income)),
        },
        {
          name: "净支出",
          type: "line",
          smooth: true,
          symbolSize: 6,
          data: summary?.daily.map((d) => Number(d.expense)),
        },
      ],
    }),
    [summary],
  );
  if (authenticated === null)
    return (
      <div className="loading-screen">
        <Logo />
        <p>正在连接你的账单空间…</p>
      </div>
    );
  if (!authenticated && isLocalMode)
    return <div className="loading-screen"><Logo /><ErrorBox message={error || "本机数据接口不可用。"} /><p>请返回应用首页后重新进入。不会回退到云端或要求登录。</p></div>;
  if (!authenticated)
    return (
      <Login
        onLogin={() => {
          setAuthenticated(true);
          setRefresh((r) => r + 1);
        }}
      />
    );
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Logo />
        <div className="workspace-label">{isLocalMode ? "本机财务空间" : "个人财务空间"}</div>
        <nav>
          {pages.filter(([id]) => !isLocalMode || id !== "import").map(([id, name, Icon]) => (
            <button
              key={id}
              className={page === id ? "active" : ""}
              onClick={() => {
                setPage(id);
                setError("");
                setPageNumber(1);
              }}
            >
              <Icon size={19} />
              <span>{name}</span>
              {page === id && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="private-note">
            <ShieldCheck size={18} />
            <div>
              你的数据，你来掌握<small>{isLocalMode ? "仅本机保存 · 不连接云端" : "独立部署 · 私人访问"}</small>
            </div>
          </div>
          {!isLocalMode && <button
            className="logout"
            onClick={async () => {
              try {
                await api("/api/logout", post());
                setAuthenticated(false);
              } catch (e) {
                setError((e as Error).message);
              }
            }}
          >
            <LogOut size={17} /> 退出登录
          </button>}
        </div>
      </aside>
      <main>
        <header className="topbar">
          <span>
            我的账单 <span className="slash">/</span>{" "}
            {pages.find((p) => p[0] === page)?.[1]}
          </span>
          <div>
            <span className="status-dot" /> {isLocalMode ? "本机离线看板" : "私人空间"}
            {!isLocalMode && <button
              className="avatar"
              aria-label="退出当前登录"
              title="退出登录"
              onClick={async () => {
                try {
                  await api("/api/logout", post());
                  setAuthenticated(false);
                } catch (e) {
                  setError((e as Error).message);
                }
              }}
            >
              我
            </button>}
          </div>
        </header>
        <div className="content">
          <div className="page-title">
            <div>
              <div className="eyebrow">
                {page === "overview"
                  ? "FINANCIAL OVERVIEW"
                  : page === "bills"
                    ? "ALL TRANSACTIONS"
                    : page === "sources"
                      ? "CONNECTED SOURCES"
                      : "IMPORT YOUR RECORDS"}
              </div>
              <h1>
                {
                  {
                    overview: "看清每一笔收支",
                    bills: "账单明细",
                    sources: isLocalMode ? "本机同步状态" : "连接你的账单",
                    import: "让记录汇集于此",
                  }[page]
                }
              </h1>
              <p className="muted">
                {
                  {
                    overview: "把日常的数字，变成清晰的生活轨迹。",
                    bills: "按时间、来源和分类，找到你关心的每一笔。",
                    sources: isLocalMode ? "查看接收授权和本机副本，不使用云端地址或令牌。" : "自动接收新账单，也让历史记录有处可归。",
                    import: "上传标准 CSV，预览确认后再写入账本。",
                  }[page]
                }
              </p>
            </div>
            <button
              className="secondary"
              onClick={() => setRefresh((r) => r + 1)}
              disabled={busy}
            >
              <RefreshCw size={16} className={busy ? "spin" : ""} />
              刷新数据
            </button>
          </div>
          <ErrorBox message={error} />
          {["overview", "bills"].includes(page) && (
            <>
              <div className="filters">
                <div className="date-range">
                  <label className="sr-only" htmlFor="start">
                    开始日期
                  </label>
                  <input
                    id="start"
                    aria-label="开始日期"
                    type="date"
                    value={filter.start}
                    onChange={(e) => changeFilter("start", e.target.value)}
                  />
                  <span>—</span>
                  <label className="sr-only" htmlFor="end">
                    结束日期
                  </label>
                  <input
                    id="end"
                    aria-label="结束日期"
                    type="date"
                    value={filter.end}
                    onChange={(e) => changeFilter("end", e.target.value)}
                  />
                </div>
                <select
                  aria-label="币种"
                  value={filter.currency}
                  onChange={(e) => changeFilter("currency", e.target.value)}
                >
                  {meta.currencies.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
                <select
                  aria-label="数据来源"
                  value={filter.source_id}
                  onChange={(e) => changeFilter("source_id", e.target.value)}
                >
                  <option value="">全部来源</option>
                  {sources.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
                <select
                  aria-label="账单状态"
                  value={filter.state}
                  onChange={(e) => changeFilter("state", e.target.value)}
                >
                  <option value="">全部状态</option>
                  {Object.entries(states).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
                <button
                  className="text-button"
                  onClick={() => {
                    setFilter(initialFilter);
                    setPageNumber(1);
                  }}
                >
                  重置
                </button>
              </div>
              {page === "overview" && (!isLocalMode || (localDataset==="copy" && !!meta.snapshot_id)) && (
                <>
                  <div className="kpi-grid">
                    {[
                      {
                        name: "总收入",
                        value: summary?.income,
                        icon: ArrowDownLeft,
                        style: "green",
                        note: "普通收入，不含借入与报销",
                      },
                      {
                        name: "净支出",
                        value: summary?.expense,
                        icon: ArrowUpRight,
                        style: "orange",
                        note: `已扣除退款 ${money(summary?.refund || 0, filter.currency)}`,
                      },
                      {
                        name: "本期结余",
                        value: summary?.balance,
                        icon: Wallet,
                        style: "dark",
                        note: isLocalMode ? "普通收入 − 净支出，不是资产余额" : "收入 − 净支出",
                      },
                      {
                        name: "账单记录",
                        value: summary?.count,
                        icon: ListFilter,
                        style: "blue",
                        note: `${summary?.pending || 0} 笔待确认 · ${summary?.excluded || 0} 笔不计统计`,
                      },
                    ].map((card, i) => (
                      <div className={`kpi ${card.style}`} key={card.name}>
                        <div>
                          <span>{card.name}</span>
                          <card.icon size={19} />
                        </div>
                        <strong>
                          {summary
                            ? i === 3
                              ? card.value
                              : money(card.value || 0, filter.currency)
                            : "—"}
                          {i === 3 && <small>笔</small>}
                        </strong>
                        <p>{card.note}</p>
                      </div>
                    ))}
                  </div>
                  <div className="chart-grid">
                    <section className="panel">
                      <div className="panel-heading">
                        <div>
                          <h2>收支趋势</h2>
                          <p>按交易日期汇总 · {filter.currency}</p>
                        </div>
                        <span className="subtle-pill">日视图</span>
                      </div>
                      {isLocalMode && summary?.chart_safe===false ? <Empty title="金额超出图表安全范围">金额按两位小数显示，账单列表仍可查看；未绘制可能失真的图形。</Empty> : summary?.daily.length ? (
                        <Chart
                          option={chartOption}
                          label="每天收入与净支出趋势"
                        />
                      ) : (
                        <Empty title="等待第一笔收支">
                          接入数据后，收支变化会在这里呈现。
                        </Empty>
                      )}
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <div>
                          <h2>支出去向</h2>
                          <p>普通支出分类 · 退款前</p>
                        </div>
                        <span className="subtle-pill">TOP 6</span>
                      </div>
                      {isLocalMode && summary?.chart_safe===false ? <Empty title="金额超出图表安全范围" /> : summary?.categories.length ? (
                        <div className="category-list">
                          {summary.categories.slice(0, 6).map((c, i) => (
                            <div key={c.name}>
                              <div>
                                <span>
                                  <b>{String(i + 1).padStart(2, "0")}</b>
                                  {c.name}
                                </span>
                                <strong>
                                  {money(c.value, filter.currency)}
                                </strong>
                              </div>
                              <div className="bar-track">
                                <i
                                  style={{
                                    width: `${(Number(c.value) / Math.max(...summary.categories.map((c) => Number(c.value)), 1)) * 100}%`,
                                    opacity: 1 - i * 0.1,
                                  }}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <Empty title="暂无支出分类" />
                      )}
                    </section>
                  </div>
                </>
              )}
              {isLocalMode && <div role="status" className="error-banner">{localDataset==="copy" ? "这是最后成功同步的离线副本，不会实时查询自动记账。离线、同步失败或撤销后，记录可能不是最新；已接收及在途副本仍可能保留。" : "旧逐条接收归档：可能含过时或重复记录，不是当前快照，不与离线副本合并。"} {localDataset==="copy" ? "统计仅基于此份副本：默认全部捕获（含待确认），只计主单；退款按退款日冲减，分类为退款前毛支出；图形为近似显示，金额标签保留小数精度并四舍五入到两位。不推算资产余额，不跨币种合计。" : "旧归档不提供金额汇总及图表。"}
                <p>最后成功同步：{dateTime(meta.last_synced_at || null)} · 捕获时间：{dateTime(meta.captured_at || null)}</p>
                <button onClick={()=>{setSummary(null);setLocalMetaReady(false);setLocalDataset(d=>d==="copy"?"archive":"copy");setPageNumber(1);setDetail(null);}}>{localDataset==="copy"?"单独查看旧接收归档":"返回离线副本"}</button>
                {localDataset==="copy"&&!meta.snapshot_id&&<p>尚无已完成的离线副本，请在本机接收设置发起同步。不会显示旧归档代替。</p>}</div>}
              <section className="panel bills-panel">
                <div className="panel-heading">
                  <div>
                    <h2>
                      {page === "overview" ? "最近账单" : "全部记录"}
                      <span className="count">{total}</span>
                    </h2>
                    <p>{isLocalMode ? "显示固定离线副本主账单，非实时总账；长文本以…省略，点开查看完整详情" : "保留来源状态，让每一笔都有出处"}</p>
                  </div>
                  {page === "overview" ? (
                    <button
                      className="text-button"
                      onClick={() => setPage("bills")}
                    >
                      查看全部
                      <ArrowRight size={15} />
                    </button>
                  ) : !isLocalMode ? (
                    <button
                      className="secondary"
                      onClick={() => {
                        window.location.href = `/api/bills/export.csv?${query}`;
                      }}
                    >
                      <Download size={15} />
                      导出 CSV
                    </button>
                  ) : null}
                </div>
                {page === "bills" && (
                  <div className="table-filters">
                    <div className="search">
                      <Search size={17} />
                      <input
                        aria-label="搜索账单"
                        placeholder="搜索商户、备注、标签…"
                        value={filter.q}
                        onChange={(e) => changeFilter("q", e.target.value)}
                      />
                    </div>
                    <select
                      aria-label="账单类型"
                      value={filter.type}
                      onChange={(e) => changeFilter("type", e.target.value)}
                    >
                      <option value="">全部类型</option>
                      {Object.entries(types).map(([k, v]) => (
                        <option value={k} key={k}>
                          {v}
                        </option>
                      ))}
                    </select>
                    <select
                      aria-label="账本"
                      value={filter.book}
                      onChange={(e) => changeFilter("book", e.target.value)}
                    >
                      <option value="">全部账本</option>
                      {meta.books.map((b) => (
                        <option key={b}>{b}</option>
                      ))}
                    </select>
                    <select
                      aria-label="分类"
                      value={filter.category}
                      onChange={(e) => changeFilter("category", e.target.value)}
                    >
                      <option value="">全部分类</option>
                      {meta.categories.map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                )}
                {busy ? (
                  <div className="loading-inline">正在读取账单…</div>
                ) : bills.length ? (
                  <div className="table-scroll">
                    <table>
                      <thead>
                        <tr>
                          <th>交易信息</th>
                          <th>分类 / 账本</th>
                          <th>来源</th>
                          <th>状态</th>
                          <th className="align-right">金额</th>
                        </tr>
                      </thead>
                      <tbody>
                        {bills.map((b) => (
                          <tr key={b.id}>
                            <td>
                              <button
                                className="bill-link"
                                onClick={() => openBill(b)}
                              >
                                <span
                                  className={`transaction-icon ${b.type.startsWith("Income") ? "income" : ""}`}
                                >
                                  {b.type.startsWith("Income") ? (
                                    <ArrowDownLeft size={18} />
                                  ) : (
                                    <ArrowUpRight size={18} />
                                  )}
                                </span>
                                <span>
                                  <strong>
                                    {b.shop_name ||
                                      b.shop_item ||
                                      types[b.type]}
                                  </strong>
                                  <small>{dateTime(b.time)}</small>
                                </span>
                              </button>
                            </td>
                            <td>
                              <strong>{b.category || "未分类"}</strong>
                              <small>{b.book_name}</small>
                            </td>
                            <td>{b.source_name}</td>
                            <td>
                              <span
                                className={`badge ${b.state === "Wait2Edit" ? "waiting" : ""}`}
                              >
                                {states[b.state]}
                              </span>
                              {Boolean(b.flag & 1) && <small>不计统计</small>}
                            </td>
                            <td
                              className={`align-right amount ${b.type.startsWith("Income") ? "income-text" : ""}`}
                            >
                              {money(b.money, b.currency)}
                              <small>{types[b.type]}</small>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <Empty>
                    {isLocalMode ? (
                      "当前筛选范围内没有本机账单。请调整日期，或在“数据来源”中检查本机接收设置。"
                    ) : sources.length ? (
                      "当前筛选范围内没有账单。你可以调整日期，或在手机端点击“立即导出”。"
                    ) : (
                      <>
                        <span>
                          连接 AutoAccounting 或导入 CSV，开始整理收支。
                        </span>
                        <button
                          className="primary"
                          onClick={() => setPage("sources")}
                        >
                          <Plus size={16} />
                          添加数据来源
                        </button>
                      </>
                    )}
                  </Empty>
                )}
                {page === "bills" && total > 0 && (
                  <div className="pagination">
                    <span>
                      共 {total} 笔 · 第 {pageNumber} /{" "}
                      {Math.max(1, Math.ceil(total / 25))} 页
                    </span>
                    <div>
                      <button
                        className="icon-button"
                        aria-label="上一页"
                        disabled={pageNumber === 1 || busy}
                        onClick={() => setPageNumber((n) => n - 1)}
                      >
                        <ChevronLeft size={18} />
                      </button>
                      <button
                        className="icon-button"
                        aria-label="下一页"
                        disabled={pageNumber * 25 >= total || busy}
                        onClick={() => setPageNumber((n) => n + 1)}
                      >
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </div>
                )}
              </section>
              <p className="footnote">
                <CircleHelp size={15} />{" "}
                按上海时区汇总；当前币种独立统计。普通收入和支出不包含转账、借还款、报销；待编辑账单可通过状态筛选排除。
              </p>
            </>
          )}
          {page === "sources" && (isLocalMode ? <LocalSources sources={sources} /> :
            <Sources
              sources={sources}
              reload={() => setRefresh((r) => r + 1)}
            />
          )}
          {page === "import" && !isLocalMode && (
            <Imports
              sources={sources}
              reload={() => setRefresh((r) => r + 1)}
              goSources={() => setPage("sources")}
            />
          )}
        </div>
        <footer>
          账迹 <span>让每一笔记录，都有意义。</span>
          <small>Bill Dashboard · v0.1</small>
        </footer>
      </main>
      {detail && (
        <Modal title="账单详情" close={() => setDetail(null)}>
          <div className="detail-amount">
            {money(detail.money, detail.currency)}
            <span>{types[detail.type]}</span>
          </div>
          <dl className="detail-grid">
            {Object.entries({
              商户: detail.shop_name || "—",
              商品: detail.shop_item || "—",
              交易时间: dateTime(detail.time),
              来源: detail.source_name,
              "原始 ID": detail.external_id,
              状态: states[detail.state],
              分类: detail.category || "未分类",
              账本: detail.book_name,
              "转出 / 所属账户": detail.account_from || "—",
              转入账户: detail.account_to || "—",
              "手续费 / 优惠": detail.fee,
              标签: detail.tags || "—",
              备注: detail.remark || "—",
              最近接收: dateTime(detail.last_received_at),
            }).map(([k, v]) => (
              <div key={k}>
                <dt>{k}</dt>
                <dd>{v}</dd>
              </div>
            ))}
          </dl>
          <details>
            <summary>查看来源原始字段</summary>
            <pre>{JSON.stringify(detail.raw, null, 2)}</pre>
          </details>
        </Modal>
      )}
    </div>
  );
}

function Sources({
  sources,
  reload,
}: {
  sources: Source[];
  reload: () => void;
}) {
  const [creating, setCreating] = useState(false),
    [name, setName] = useState(""),
    [kind, setKind] = useState("autoaccounting"),
    [token, setToken] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [copied, setCopied] = useState(false);
  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const result = await api("/api/sources", post({ name, kind }));
      setCreating(false);
      setName("");
      if (result.token) {
        setToken(result.token);
        setCopied(false);
      }
      reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function toggle(s: Source) {
    setError("");
    setBusy(true);
    try {
      await api(`/api/sources/${s.id}`, {
        method: "PATCH",
        body: JSON.stringify({ active: !s.active }),
      });
      reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function rotate(s: Source) {
    if (!confirm(`更换“${s.name}”的令牌后，旧令牌立即失效。继续吗？`)) return;
    setError("");
    setBusy(true);
    try {
      const r = await api(`/api/sources/${s.id}/rotate-token`, post());
      setToken(r.token);
      setCopied(false);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const endpoint = `${window.location.origin}/autoaccounting/v1/bills`;
  return (
    <>
      <ErrorBox message={error} />
      <div className="connection-banner">
        <div className="connection-icon">
          <Database size={28} />
        </div>
        <div>
          <h2>一个看板，汇集不同来源</h2>
          <p>每台手机使用独立的数据源。重复收到的同一账单会自动更新。</p>
        </div>
        <button className="primary" onClick={() => setCreating(true)}>
          <Plus size={17} />
          添加来源
        </button>
      </div>
      <div className="source-grid">
        {sources.map((s) => (
          <section className="panel source-card" key={s.id}>
            <div className="source-title">
              <span className="source-logo">
                {s.kind === "autoaccounting" ? (
                  <RefreshCw size={23} />
                ) : (
                  <FileUp size={23} />
                )}
              </span>
              <span className={`badge ${!s.active ? "waiting" : ""}`}>
                {s.active ? "已启用" : "已停用"}
              </span>
            </div>
            <h2>{s.name}</h2>
            <p className="muted">
              {s.kind === "autoaccounting"
                ? "AutoAccounting · 自动同步"
                : "标准 CSV · 文件导入"}
            </p>
            <div className="source-stats">
              <div>
                <small>累计账单</small>
                <strong>
                  {s.bill_count}
                  <span>笔</span>
                </strong>
              </div>
              <div>
                <small>最近接收</small>
                <strong className="last-time">
                  {dateTime(s.last_received_at)}
                </strong>
              </div>
            </div>
            <div className="source-actions">
              {s.kind === "autoaccounting" && (
                <button
                  className="text-button"
                  disabled={busy}
                  onClick={() => rotate(s)}
                >
                  更换令牌
                </button>
              )}
              <button
                className="text-button"
                disabled={busy}
                onClick={() => toggle(s)}
              >
                {s.active ? "停用接收" : "启用接收"}
              </button>
            </div>
          </section>
        ))}
      </div>
      {!sources.length && (
        <section className="panel">
          <Empty title="从连接第一个来源开始">
            点击“添加来源”，选择 AutoAccounting 或标准 CSV。
          </Empty>
        </section>
      )}
      <section className="panel guide">
        <h2>连接 AutoAccounting</h2>
        <ol>
          <li>创建一个 AutoAccounting 数据源，保存仅显示一次的令牌。</li>
          <li>在手机的“数据管理 → 账单导出”中启用“同步账单到 NAS”。</li>
          <li>
            填写接收地址 <code>{endpoint}</code>，粘贴令牌本身，无需加 Bearer
            前缀。
          </li>
          <li>点击“立即导出”，然后刷新此页面检查最近接收时间。</li>
        </ol>
        <p className="notice">
          手机要求可访问且证书有效的 HTTPS
          地址。当前客户端主要推送今天和昨天的账单，不会通知删除，也不会自动补齐全部历史记录。
        </p>
      </section>
      {creating && (
        <Modal title="添加数据来源" close={() => setCreating(false)}>
          <form onSubmit={create}>
            <label>
              来源名称
              <input
                required
                maxLength={100}
                placeholder="例如：我的手机、历史账本"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </label>
            <label>
              接入方式
              <select value={kind} onChange={(e) => setKind(e.target.value)}>
                <option value="autoaccounting">AutoAccounting 自动同步</option>
                <option value="csv">标准 CSV 文件导入</option>
              </select>
            </label>
            <ErrorBox message={error} />
            <button className="primary wide" disabled={busy}>
              创建来源
            </button>
          </form>
        </Modal>
      )}
      {token && (
        <Modal title="保存你的同步令牌" close={() => setToken("")}>
          <p className="muted">
            令牌只显示这一次。请将它保存到 AutoAccounting 的“NAS 令牌”中。
          </p>
          <div className="token-value">{token}</div>
          <ErrorBox message={error} />
          <button
            className="secondary wide"
            onClick={async () => {
              try {
                await copyText(token);
                setCopied(true);
              } catch {
                setError("无法使用剪贴板，请手动选中并复制令牌");
              }
            }}
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}{" "}
            {copied ? "已复制" : "复制令牌"}
          </button>
          <p className="muted">接收地址</p>
          <code className="endpoint">{endpoint}</code>
          <button className="primary wide" onClick={() => setToken("")}>
            我已保存
          </button>
        </Modal>
      )}
    </>
  );
}
function Imports({
  sources,
  reload,
  goSources,
}: {
  sources: Source[];
  reload: () => void;
  goSources: () => void;
}) {
  const available = sources.filter((s) => s.kind === "csv" && s.active);
  const [source, setSource] = useState(""),
    [file, setFile] = useState<File | null>(null),
    [preview, setPreview] = useState<any>(null),
    [result, setResult] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function upload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true);
    setError("");
    setPreview(null);
    setResult(null);
    const data = new FormData();
    data.append("file", file);
    try {
      setPreview(
        await api(
          `/api/imports/preview?source_id=${encodeURIComponent(source || available[0]?.id || "")}`,
          { method: "POST", body: data },
        ),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function commit() {
    setBusy(true);
    setError("");
    try {
      setResult(await api(`/api/imports/${preview.batch_id}/commit`, post()));
      reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <ErrorBox message={error} />
      <div className="import-grid">
        <section className="panel import-panel">
          <span className="tag">01 / 上传文件</span>
          <h2>导入历史账单</h2>
          <p className="muted">支持 UTF-8 CSV，最多 2 MB / 10000 行。</p>
          {available.length ? (
            <form onSubmit={upload}>
              <label>
                导入到哪个数据源
                <select
                  value={source || available[0]?.id}
                  onChange={(e) => {
                    setSource(e.target.value);
                    setPreview(null);
                    setResult(null);
                  }}
                >
                  {available.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="upload-zone">
                <FileUp size={32} />
                <strong>{file ? file.name : "选择 CSV 文件"}</strong>
                <span>先预览，再确认导入</span>
                <input
                  aria-label="选择 CSV 文件"
                  type="file"
                  accept=".csv,text/csv"
                  required
                  onChange={(e) => {
                    setFile(e.target.files?.[0] || null);
                    setPreview(null);
                    setResult(null);
                  }}
                />
              </label>
              <button className="primary wide" disabled={busy || !file}>
                {busy ? "处理中…" : "校验并预览"}
                <ArrowRight size={17} />
              </button>
            </form>
          ) : (
            <Empty title="先创建一个 CSV 数据源">
              <button className="primary" onClick={goSources}>
                前往数据来源
              </button>
            </Empty>
          )}
        </section>
        <section className="panel guide">
          <h2>准备你的 CSV</h2>
          <p className="muted">
            当前支持统一模板。其他记账软件的导出文件，请先将字段转换为模板格式。
          </p>
          <a className="secondary" href="/api/imports/template.csv">
            <Download size={16} />
            下载示例模板
          </a>
          <ul>
            <li>必填：id、type、money、time。</li>
            <li>id 是来源中的稳定数字编号，重复导入相同 id 会更新该账单。</li>
            <li>
              type 示例：Expend（支出）、Income（收入）、Transfer（转账）。
            </li>
            <li>
              time 支持毫秒时间戳或 ISO 日期时间；未带时区时按上海时间解析。
            </li>
            <li>金额使用小数，币种使用 CNY 等三字母代码。</li>
            <li>整批校验通过才允许导入；同一文件内不能有重复 id。</li>
          </ul>
        </section>
      </div>
      {preview && (
        <section className="panel import-preview">
          <div className="panel-heading">
            <div>
              <span className="tag">02 / 确认导入</span>
              <h2>共 {preview.total} 条记录</h2>
            </div>
            {!result && preview.batch_id && (
              <button className="primary" disabled={busy} onClick={commit}>
                {busy ? "正在保存…" : "确认导入"}
              </button>
            )}
          </div>
          {preview.error_count > 0 ? (
            <div className="error">
              发现 {preview.error_count} 行错误，本批未导入。
              {preview.errors.map((e: any) => (
                <p key={e.row}>
                  第 {e.row} 行：{e.message}
                </p>
              ))}
            </div>
          ) : (
            <>
              <p className="muted">
                预览前 5 条。已有账单将按数据源和原始 id 更新，不重复累加。
              </p>
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>原始 ID</th>
                      <th>类型</th>
                      <th>商户</th>
                      <th>分类</th>
                      <th>金额</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.sample.map((r: any) => (
                      <tr key={r.id}>
                        <td>{r.id}</td>
                        <td>{types[r.type]}</td>
                        <td>{r.shopName || "—"}</td>
                        <td>{r.cateName || "未分类"}</td>
                        <td>{r.money}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
          {result && (
            <div className="success" role="status">
              <Check size={20} />
              导入完成：新增 {result.inserted} 笔，更新 {result.updated}{" "}
              笔，未变化 {result.unchanged} 笔。
            </div>
          )}
        </section>
      )}
    </>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);

