import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig(({ mode }) => ({
  // Preserve root-relative URLs for the online server history fallback.
  base: mode === "android" ? "./" : "/",
  plugins: [react()],
  server: { proxy: { "/api": "http://127.0.0.1:8000" } },
  build: {
    target: mode === "android" ? "chrome74" : undefined,
    modulePreload: mode === "android" ? { polyfill: false } : undefined,
    rollupOptions: { output: { manualChunks: { charts: ["echarts"] } } },
  },
}));
