# Isolated receiver instrumentation scaffold

NOT RUN on device. Production `app/src/main` copied unchanged with `production-copy-sha256.json`; bundled built frontend copied into assets. No production edits. This QA package has the same ID as the receiver: only install on a **blank disposable emulator**, never overwrite a user installation. No release/publication authorized.

Runner is dependency-free `android.app.Instrumentation` subclass `io.github.origest.billdashboard.ReceiverQaRunner` (not JUnit's runner). It reports `qa_status=PASS/FAIL` and exits; inspect this value rather than assuming adb exit code is a pass. A durable synthetic-only ownership marker is required: first claim refuses any existing database/sidecar, private files, receiver pairing or snapshot session; subsequent invocations must match the original qa_run. Resets occur only after that gate. Every invocation requires `allowBlankEmulator=YES`, `qa_run=<UUID>` and device `ro.kernel.qemu=1`.

`case=core allow_synthetic_reset=true`: explicitly resets only disposable receiver QA DB, seeds two authorized synthetic copies through private store, verifies old pinned/new summaries and reopen, unpinned summary rejection, real ContentResolver rejection of receiver UID, and native WebView React DOM rendering of net expense 1.30 plus a nonzero-size chart canvas/network block. This is not proof of successful sender admission or real user approval UI.

`case=pair allow_pair=true`: pins actual installed synthetic net.ankio.auto certificate using test-only setup. No UID spoof and no production trust bypass. Does NOT test visible authorization UI. Execute after core and before source harness transfer, with `allow_synthetic_reset=true` to remove the core fixture source binding before testing a different source generation. This explicit reset is disposable QA setup, not a production migration.

`case=received [snapshot_id=...] [source_id=...] [expected_expense=0.3]`: verifies actual selected receiver copy after source harness sends over real Binder. This case does not reset, pair, fabricate or complete a copy. Source fixture expected Expend 0.1 + 0.2 and Income 100. Source runner is separate and owns transmission; the receiver runner cannot masquerade as source UID.

Compile serially with source worker using shared toolchain/cache: `:app:assembleDebug :app:assembleDebugAndroidTest`. No Gradle launched by this README. Instrumentation component after compile should be verified in test APK manifest; expected `io.github.origest.billdashboard.test/io.github.origest.billdashboard.ReceiverQaRunner`.

Not implemented here: native pairing dialog automation, chart pixel/numerical rendering assertions, automatic scheduler/end-to-end source generation changes, revocation races, capacity stress, process-death orchestration, source signature substitution. See ../v7-plan/receiver_plan.md. DOM render only is not chart correctness. Compile success is not device test success.

## Additional executable cases (device NOT RUN)

All retain the persisted synthetic ownership gate. `qa_status=PASS` plus matching `qa_run` and `case` are required; outputs also include `active_snapshot_id`, `manifest_count`, `row_count`, `complete_count`.

- `evidence`: save stable full-ledger-table SHA-256 and selected pointer in QA preferences, output `ledger_sha256`.
- `assert-unchanged [require_wrong_signer=true]`: compare every ledger table and pointer to saved baseline. Optional flag verifies installed source certificate differs from retained receiver pin and that LocalTrust denies its actual UID. Actual failed source Binder call must be executed by the source harness between evidence and this assertion; this is not a substitute for that call.
- `interrupt-prepare`: stage first of two rows and persist QA checkpoint; outputs `checkpoint=PARTIAL_STAGED` and `snapshot_id`. Run after core and before pair reset because this uses the core fixture source generation.
- `interrupt-resume`: after external force-stop/restart, verify previous pointer has not changed, retry the identical first page, add second page, complete and assert selected. Outputs `checkpoint=RESUMED_COMPLETE`. This tests **staging reopen at deterministic completed-operation checkpoints**, not a crash or a kill inside a SQLite transaction/real Worker.
- `capacity-bytes allow_synthetic_reset=true`: LAST PHASE, explicitly reset owned synthetic DB, stream 128 rows each exactly 256 KiB into each of four 32 MiB snapshots (128 MiB actual payload). Complete archival manifests without selecting them. Assert measured UTF-8 payload bytes, reject a fifth positive-byte manifest, verify unchanged whole-ledger fingerprint. Outputs `actual_payload_bytes=134217728` and `elapsed_ms`. This tests device store capacity, not Binder packet throughput; does not claim a memory bound from elapsed time.
- `capacity-manifests allow_synthetic_reset=true`: LAST PHASE, reset again, stage 1000 empty manifests, reject the next and assert fingerprint unchanged. This intentionally does not fake completed/selected states.

Run capacity only after all positive, source checkpoint/resume and wrong-signer assertions; it destroys only this explicitly marked QA fixture database. The reset is never a production retention policy. No mid-write transactional crash injection or race proof is implemented.

Core success also emits `webview_data_rendered=true` only after the actual rendered expense KPI contains 1.30 and at least one canvas has positive width and height. This rejects a mere loading skeleton, but still does not prove pixel-level chart accuracy.
