package io.github.origest.billdashboard;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.webkit.WebView;
import org.json.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Isolated disposable-device instrumentation, not shipped in production. No UID spoofing. */
public final class ReceiverQaRunner extends Instrumentation {
 private Bundle args; private Context context;
 @Override public void onCreate(Bundle arguments){super.onCreate(arguments);args=arguments==null?new Bundle():arguments;start();}
 @Override public void onStart(){
  Bundle result=new Bundle();context=getTargetContext();String name=args.getString("case","core");
  try{
   require("YES".equals(args.getString("allowBlankEmulator")),"Blank emulator gate missing");
   UUID.fromString(args.getString("qa_run",""));
   java.lang.Process probe=new ProcessBuilder("getprop","ro.kernel.qemu").start();
   String qemu=new java.io.BufferedReader(new java.io.InputStreamReader(probe.getInputStream())).readLine();
   require(probe.waitFor()==0&&"1".equals(qemu),"Requires disposable emulator");
   requireSyntheticOwnership();
   if("core".equals(name)){require("true".equals(args.getString("allow_synthetic_reset")),"Blank QA device reset must be explicit");context.deleteDatabase("local-ledger.db");fixedCopyAndReopen();deniedRealReceiverUid();webViewLoads();result.putBoolean("webview_data_rendered",true);}
   else if("pair".equals(name)){require("true".equals(args.getString("allow_pair")),"Explicit QA pairing required");if("true".equals(args.getString("allow_synthetic_reset")))context.deleteDatabase("local-ledger.db");require(LocalTrust.pair(context,LocalTrust.certificate(context)),"Pair failed");}
   else if("received".equals(name))receivedCopy();
   else ReceiverQaScenarios.run(context,name,args,result);
   result.putString("qa_status","PASS");result.putString("qa_run",args.getString("qa_run"));result.putString("case",name);finish(Activity.RESULT_OK,result);
  }catch(Throwable e){result.putString("qa_status","FAIL");result.putString("case",name);result.putString("failure",e.getClass().getSimpleName()+": "+e.getMessage());finish(Activity.RESULT_CANCELED,result);}
 }
 private void requireSyntheticOwnership(){
  android.content.SharedPreferences marker=context.getSharedPreferences("receiver-qa-ownership",Context.MODE_PRIVATE);
  String run=args.getString("qa_run","");
  if(marker.contains("qa_run")){
   require(run.equals(marker.getString("qa_run",""))&&marker.getBoolean("synthetic_only",false),"QA fixture ownership mismatch");
   return;
  }
  // First claim must be genuinely blank, not merely caller-described as blank.
  require(marker.getAll().isEmpty(),"Malformed ownership marker");
  require(context.databaseList().length==0,"Existing database: refuse first QA ownership claim");
  java.io.File databases=context.getDatabasePath("local-ledger.db").getParentFile();
  java.io.File[] files=databases==null?null:databases.listFiles();
  require(files==null||files.length==0,"Existing database sidecar or copy: refuse reset");
  require(context.getSharedPreferences("local-receiver",Context.MODE_PRIVATE).getAll().isEmpty(),"Existing receiver pairing");
  require(context.getSharedPreferences("local-snapshot-sessions",Context.MODE_PRIVATE).getAll().isEmpty(),"Existing snapshot sessions");
  java.io.File[] privateFiles=context.getFilesDir().listFiles();
  require(privateFiles==null||privateFiles.length==0,"Existing private files: refuse first QA claim");
  require(marker.edit().putString("qa_run",run).putBoolean("synthetic_only",true).commit(),"Cannot persist synthetic ownership");
 }
 private static void require(boolean value,String error){if(!value)throw new AssertionError(error);}
 private LocalSnapshotStore.Row row(long id,String money){return new LocalSnapshotStore.Row(id,"{\"id\":"+id+",\"type\":\"Expend\",\"money\":"+money+",\"time\":"+System.currentTimeMillis()+",\"groupId\":-1,\"state\":\"Edited\",\"currency\":\"CNY\",\"cateName\":\"QA synthetic\"}");}
 private String select(long seq,String money)throws Exception{
  try(LocalLedger ledger=new LocalLedger(context)){
   LocalSnapshotStore store=new LocalSnapshotStore(ledger);List<LocalSnapshotStore.Row> rows=Arrays.asList(row(1,money),row(2,"0.2"));long bytes=0;for(LocalSnapshotStore.Row r:rows)bytes+=r.payload.getBytes(StandardCharsets.UTF_8).length;
   String source="12345678-1234-1234-1234-123456789abc",id=UUID.randomUUID().toString();LocalSnapshotStore.Manifest m=new LocalSnapshotStore.Manifest(source,id,seq,System.currentTimeMillis(),2,bytes,LocalSnapshotStore.digest(rows));
   LocalSnapshotStore.CopyAuthorization a=new LocalSnapshotStore.CopyAuthorization("offline-copy-v1",source,id,m.digest,UUID.randomUUID().toString(),UUID.randomUUID().toString(),UUID.randomUUID().toString());store.beginAuthorizedCopy(m,a);store.page(id,rows);require("selected".equals(store.completeAuthorizedCopy(id,a)),"copy not selected");return id;
  }
 }
 private JSONObject summary(String id)throws Exception{JSONObject e=new JSONObject(new LocalReadApi(context).request("/api/summary?snapshot_id="+id));require(e.getBoolean("ok"),"summary failed");return e.getJSONObject("data");}
 private void fixedCopyAndReopen()throws Exception{
  String old=select(1,"0.1"),current=select(2,"1.1");
  require("0.3".equals(summary(old).getString("expense")),"pinned old total changed");require("1.3".equals(summary(current).getString("expense")),"new total wrong");
  try(LocalLedger ledger=new LocalLedger(context)){require(current.equals(new LocalSnapshotStore(ledger).activeSnapshotId()),"reopen lost pointer");}
  require(new JSONObject(new LocalReadApi(context).request("/api/summary")).getInt("status")==409,"unpinned summary admitted");
 }
 private void deniedRealReceiverUid(){
  boolean denied=false;try{context.getContentResolver().call(Uri.parse("content://io.github.origest.billdashboard.localsync"),"snapshot-begin-v2",null,new Bundle());}catch(SecurityException expected){denied=true;}
  require(denied,"receiver UID must not impersonate net.ankio.auto");
 }
 private void receivedCopy()throws Exception{
  try(LocalLedger ledger=new LocalLedger(context)){
   LocalSnapshotStore.Manifest m=new LocalSnapshotStore(ledger).selectedCopyManifest(null);require(m!=null,"no received selected copy");String expected=args.getString("snapshot_id");if(expected!=null)require(expected.equals(m.snapshotId),"snapshot mismatch");String source=args.getString("source_id");if(source!=null)require(source.equals(m.sourceId),"source mismatch");
   JSONObject envelope=new JSONObject(new LocalReadApi(context).request("/api/summary?snapshot_id="+m.snapshotId+"&start="+Uri.encode(args.getString("start","2023-11-01"))+"&end="+Uri.encode(args.getString("end","2023-11-30"))));require(envelope.getBoolean("ok"),"received summary failed");JSONObject s=envelope.getJSONObject("data");String expense=args.getString("expected_expense");if(expense!=null)require(expense.equals(s.getString("expense")),"received total mismatch");
  }
 }
 private WebView findWeb(View v){if(v instanceof WebView)return (WebView)v;if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++){WebView w=findWeb(g.getChildAt(i));if(w!=null)return w;}}return null;}
 private void webViewLoads()throws Exception{
  Activity a=startActivitySync(new Intent(context,LocalDashboardActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  try{
   final WebView[] holder=new WebView[1];runOnMainSync(()->holder[0]=findWeb(a.getWindow().getDecorView()));require(holder[0]!=null,"missing WebView");
   long deadline=SystemClock.elapsedRealtime()+30000;boolean ready=false;
   while(SystemClock.elapsedRealtime()<deadline){CountDownLatch done=new CountDownLatch(1);String[] value=new String[1];runOnMainSync(()->holder[0].evaluateJavascript("JSON.stringify({origin:location.origin,body:document.body.innerText,root:!!document.getElementById('root'),canvas:Array.from(document.querySelectorAll('canvas')).some(c=>c.width>0&&c.height>0),expense:Array.from(document.querySelectorAll('.kpi')).some(c=>c.innerText.indexOf('净支出')>=0&&c.innerText.indexOf('1.30')>=0)})",v->{value[0]=v;done.countDown();}));require(done.await(3,TimeUnit.SECONDS),"JS callback timeout");
    if(value[0]!=null&&!"null".equals(value[0])){String decoded=new JSONArray("["+value[0]+"]").getString(0);JSONObject dom=new JSONObject(decoded);if(dom.optBoolean("root")&&dom.optString("body").contains("1.30")&&dom.optBoolean("expense")&&dom.optBoolean("canvas")){require("https://appassets.androidplatform.net".equals(dom.getString("origin")),"wrong origin");ready=true;break;}}
    Thread.sleep(200);
   }
   require(ready,"bundled React expense 1.30 and nonzero chart canvas did not render within 30 seconds");
   runOnMainSync(()->require(holder[0].getSettings().getBlockNetworkLoads(),"network block disabled"));
  }finally{runOnMainSync(a::finish);}
 }
}
