package io.github.origest.billdashboard;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Only invoked after runner's persisted synthetic ownership gate. */
final class ReceiverQaScenarios {
 static final String SOURCE="12345678-1234-1234-1234-123456789abc";
 static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);}
 static String hex(byte[] a){StringBuilder b=new StringBuilder();for(byte x:a)b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();}
 static void frame(MessageDigest d,byte[] a){d.update(ByteBuffer.allocate(4).putInt(a.length).array());d.update(a);}
 static String fingerprint(LocalLedger ledger)throws Exception{
  MessageDigest d=MessageDigest.getInstance("SHA-256");SQLiteDatabase db=ledger.getReadableDatabase();db.beginTransaction();
  try(Cursor names=db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name!='android_metadata' ORDER BY name",null)){
   while(names.moveToNext()){String name=names.getString(0);check(name.matches("[a-zA-Z0-9_]+"),"unexpected table name");frame(d,name.getBytes(StandardCharsets.UTF_8));
    try(Cursor schema=db.rawQuery("PRAGMA table_info("+name+")",null)){StringBuilder order=new StringBuilder();while(schema.moveToNext()){if(order.length()>0)order.append(',');order.append(schema.getInt(0)+1);}try(Cursor rows=db.rawQuery("SELECT * FROM "+name+" ORDER BY "+order,null)){while(rows.moveToNext()){d.update((byte)126);for(int i=0;i<rows.getColumnCount();i++){d.update((byte)rows.getType(i));if(rows.isNull(i))continue;frame(d,rows.getType(i)==Cursor.FIELD_TYPE_BLOB?rows.getBlob(i):rows.getString(i).getBytes(StandardCharsets.UTF_8));}}}}
   }db.setTransactionSuccessful();return hex(d.digest());
  }finally{db.endTransaction();}
 }
 static long scalar(LocalLedger db,String sql){try(Cursor c=db.getReadableDatabase().rawQuery(sql,null)){check(c.moveToFirst(),"missing scalar");return c.getLong(0);}}
 static void run(Context c,String name,Bundle args,Bundle out)throws Exception{
  SharedPreferences p=c.getSharedPreferences("receiver-qa-evidence",0);
  if(name.startsWith("capacity-")){check("true".equals(args.getString("allow_synthetic_reset")),"capacity reset must be explicit");c.deleteDatabase("local-ledger.db");}
  try(LocalLedger db=new LocalLedger(c)){
   LocalSnapshotStore store=new LocalSnapshotStore(db);
   if("evidence".equals(name)){
    String fp=fingerprint(db),active=store.activeSnapshotId();check(p.edit().putString("fingerprint",fp).putString("active",active==null?"":active).commit(),"evidence persistence failed");out.putString("ledger_sha256",fp);
   }else if("assert-unchanged".equals(name)){
    check(p.contains("fingerprint"),"missing baseline");check(p.getString("fingerprint","").equals(fingerprint(db)),"ledger changed after denial");String active=store.activeSnapshotId();check(p.getString("active","").equals(active==null?"":active),"selected pointer changed");
    if("true".equals(args.getString("require_wrong_signer"))){String pin=c.getSharedPreferences("local-receiver",0).getString("certificate","");check(!pin.isEmpty()&&!pin.equals(LocalTrust.certificate(c)),"source signer did not change");int uid=c.getPackageManager().getApplicationInfo(LocalTrust.SENDER,0).uid;check(!LocalTrust.permitted(c,uid),"wrong signer permitted");out.putString("wrong_signer","DENIED_BY_TRUST");}
    out.putString("ledger_sha256",fingerprint(db));
   }else if("interrupt-prepare".equals(name)){
    String id=UUID.randomUUID().toString();List<LocalSnapshotStore.Row> rows=small();LocalSnapshotStore.Manifest m=smallManifest(id,rows);LocalSnapshotStore.CopyAuthorization auth=auth(id,m.digest,p,true);store.beginAuthorizedCopy(m,auth);store.page(id,Collections.singletonList(rows.get(0)));String active=store.activeSnapshotId();check(p.edit().putString("partial_id",id).putString("partial_before",active==null?"":active).commit(),"checkpoint persistence failed");out.putString("checkpoint","PARTIAL_STAGED");out.putString("snapshot_id",id);
   }else if("interrupt-resume".equals(name)){
    String id=p.getString("partial_id","");check(!id.isEmpty(),"missing partial checkpoint");String active=store.activeSnapshotId();check(p.getString("partial_before","").equals(active==null?"":active),"partial copy selected early");List<LocalSnapshotStore.Row> rows=small();LocalSnapshotStore.Manifest m=smallManifest(id,rows);LocalSnapshotStore.CopyAuthorization auth=auth(id,m.digest,p,false);store.beginAuthorizedCopy(m,auth);store.page(id,Collections.singletonList(rows.get(0)));store.page(id,Collections.singletonList(rows.get(1)));check("selected".equals(store.completeAuthorizedCopy(id,auth)),"resume did not select");check(id.equals(store.activeSnapshotId()),"pointer missing after resume");out.putString("checkpoint","RESUMED_COMPLETE");
   }else if("capacity-bytes".equals(name)){
    long started=android.os.SystemClock.elapsedRealtime();String digest=largeDigest();
    for(int n=0;n<4;n++){String id=UUID.randomUUID().toString();store.begin(new LocalSnapshotStore.Manifest(SOURCE,id,n,0,128,LocalSnapshotStore.MAX_BYTES,digest));for(int i=1;i<=128;i++)store.page(id,Collections.singletonList(large(i)));store.complete(id);}
    check(scalar(db,"SELECT SUM(length(CAST(payload AS BLOB))) FROM local_snapshot_rows")==LocalSnapshotStore.MAX_DECLARED_BYTES,"actual payload capacity not filled");String before=fingerprint(db);boolean refused=false;try{store.begin(new LocalSnapshotStore.Manifest(SOURCE,UUID.randomUUID().toString(),4,0,1,1,digest));}catch(IllegalArgumentException|IllegalStateException expected){refused=true;}check(refused,"over-cap accepted");check(before.equals(fingerprint(db)),"capacity rejection modified archive");out.putLong("actual_payload_bytes",LocalSnapshotStore.MAX_DECLARED_BYTES);out.putLong("elapsed_ms",android.os.SystemClock.elapsedRealtime()-started);
   }else if("capacity-manifests".equals(name)){
    String empty=LocalSnapshotStore.digest(Collections.emptyList());for(int i=0;i<1000;i++)store.begin(new LocalSnapshotStore.Manifest(SOURCE,UUID.randomUUID().toString(),i,0,0,0,empty));String before=fingerprint(db);boolean refused=false;try{store.begin(new LocalSnapshotStore.Manifest(SOURCE,UUID.randomUUID().toString(),1000,0,0,0,empty));}catch(IllegalArgumentException|IllegalStateException expected){refused=true;}check(refused&&before.equals(fingerprint(db)),"manifest cap failed or archive changed");out.putLong("manifest_count",1000);
   }else throw new IllegalArgumentException("unknown scenario");
   out.putString("active_snapshot_id",store.activeSnapshotId());out.putLong("manifest_count",scalar(db,"SELECT COUNT(*) FROM local_snapshot_manifests"));out.putLong("row_count",scalar(db,"SELECT COUNT(*) FROM local_snapshot_rows"));out.putLong("complete_count",scalar(db,"SELECT COUNT(*) FROM local_snapshot_manifests WHERE complete=1"));
  }
 }
 static List<LocalSnapshotStore.Row> small(){return Arrays.asList(new LocalSnapshotStore.Row(1,"{\"id\":1,\"type\":\"Expend\",\"money\":0.1,\"time\":1700000000001,\"groupId\":-1,\"currency\":\"CNY\"}"),new LocalSnapshotStore.Row(2,"{\"id\":2,\"type\":\"Expend\",\"money\":0.2,\"time\":1700000000002,\"groupId\":-1,\"currency\":\"CNY\"}"));}
 static LocalSnapshotStore.Manifest smallManifest(String id,List<LocalSnapshotStore.Row> rows){long size=0;for(LocalSnapshotStore.Row row:rows)size+=row.payload.getBytes(StandardCharsets.UTF_8).length;return new LocalSnapshotStore.Manifest(SOURCE,id,10000,1700000000000L,rows.size(),size,LocalSnapshotStore.digest(rows));}
 static LocalSnapshotStore.CopyAuthorization auth(String id,String digest,SharedPreferences p,boolean create){if(create)check(p.edit().putString("grant",UUID.randomUUID().toString()).putString("revoke",UUID.randomUUID().toString()).putString("epoch",UUID.randomUUID().toString()).commit(),"persist auth");return new LocalSnapshotStore.CopyAuthorization("offline-copy-v1",SOURCE,id,digest,p.getString("grant",""),p.getString("revoke",""),p.getString("epoch",""));}
 static LocalSnapshotStore.Row large(int id){String prefix="{\"id\":"+id+",\"remark\":\"",suffix="\"}";char[] padding=new char[LocalSnapshotStore.MAX_ROW_BYTES-prefix.length()-suffix.length()];Arrays.fill(padding,'x');return new LocalSnapshotStore.Row(id,prefix+new String(padding)+suffix);}
 static String largeDigest()throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");for(int i=1;i<=128;i++){LocalSnapshotStore.Row r=large(i);frame(d,Long.toString(r.id).getBytes(StandardCharsets.US_ASCII));frame(d,r.payload.getBytes(StandardCharsets.UTF_8));}return hex(d.digest());}
}
