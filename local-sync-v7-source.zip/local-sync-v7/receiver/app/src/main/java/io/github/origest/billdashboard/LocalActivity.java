package io.github.origest.billdashboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Offline, native read-only ledger. Never opens the online WebView or sends HTTP. */
public final class LocalActivity extends Activity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ExecutorService authorizationWorker=Executors.newSingleThreadExecutor();
    private LinearLayout column; private TextView status; private int offset; private boolean loading;
    @Override public void onCreate(Bundle state){super.onCreate(state);render();}
    private void render(){
        ScrollView scroll=new ScrollView(this); column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setPadding(32,48,32,32);scroll.addView(column);setContentView(scroll);
        label("账迹 · 本机账本",26); label("仅保存在这台手机，不连接云端。这里只读展示同步副本，自动记账仍是账单来源。",14);
        Button pairing=new Button(this);pairing.setText("接收授权设置");column.addView(pairing);pairing.setOnClickListener(v->pair());
        Button refresh=new Button(this);refresh.setText("刷新");column.addView(refresh);refresh.setOnClickListener(v->{if(!loading){offset=0;render();}});
        Button history=new Button(this);history.setText("从自动记账补传历史账单");column.addView(history);
        history.setOnClickListener(v->{
            try{android.content.Intent intent=new android.content.Intent();intent.setComponent(new android.content.ComponentName("net.ankio.auto","net.ankio.auto.ui.activity.DashboardHistoryActivity"));startActivity(intent);}
            catch(android.content.ActivityNotFoundException e){new AlertDialog.Builder(this).setMessage("当前自动记账没有历史补传界面，需要兼容候选版本。不会清数据或替换现有安装。").setPositiveButton("关闭",null).show();}
        });
        Button snapshots=new Button(this);snapshots.setText("同步完整离线副本到看板");column.addView(snapshots);snapshots.setOnClickListener(v->{
            try{android.content.Intent i=new android.content.Intent();i.setComponent(new android.content.ComponentName("net.ankio.auto","net.ankio.auto.ui.activity.DashboardSnapshotActivity"));startActivity(i);}
            catch(android.content.ActivityNotFoundException e){new AlertDialog.Builder(this).setMessage("当前源应用不支持完整快照。不会替换安装或清除数据。").setPositiveButton("关闭",null).show();}
        });
        Button review=new Button(this);review.setText("查看已接收副本与旧暂存");column.addView(review);review.setOnClickListener(v->startActivity(new android.content.Intent(this,LocalSnapshotReviewActivity.class)));
        label("完整离线副本需在源应用明确授权，完成后更新看板；旧补传归档单独保留，不混合统计。撤销只停止后续传输，已收及在途副本可能仍会完成。",14);
        status=label("正在读取本机账本…",14);load();
    }
    private TextView label(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setPadding(0,12,0,12);column.addView(t);return t;}
    private void load(){
        if(loading)return;loading=true;final int start=offset;
        worker.execute(()->{
            try(LocalLedger db=new LocalLedger(this)) {
                List<JSONObject> rows=db.page(start);long count=db.count();
                runOnUiThread(()->{
                    if(isFinishing()||isDestroyed())return;
                    loading=false;status.setText("历史接收归档共 "+count+" 条主记录。这里不是当前离线副本看板，也不提供金额汇总。");
                    if(start==0)label("历史接收副本可能含已归组或删除的旧记录，不能作为当前总账；金额汇总已暂停。",16);
                    SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault());
                    for(JSONObject b:rows){TextView t=label(fmt.format(new Date(b.optLong("time")))+"  "+b.optString("type")+"  "+b.optString("money")+"\n"+b.optString("shopName")+" · "+b.optString("cateName"),16);t.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("本机账单详情").setMessage(b.toString()).setPositiveButton("关闭",null).show());}
                    offset=start+rows.size();if(offset<count){Button more=new Button(this);more.setText("加载后 100 条");column.addView(more);more.setOnClickListener(v->{if(!loading){more.setVisibility(View.GONE);load();}});}
                });
            }catch(Exception e){runOnUiThread(()->{if(!isDestroyed()){loading=false;status.setText("读取失败。请保留应用数据，稍后重试。");}});}
        });
    }
    private void pair(){
        String existing=getSharedPreferences("local-receiver",MODE_PRIVATE).getString("certificate","");
        if(!existing.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("本机接收已授权").setMessage("授权固定为你确认时安装的自动记账签名。关闭接收会阻止后续传输，不会删除已收到的账单；已经在途的副本仍可能完成并更新看板。")
                .setPositiveButton("保留授权",null).setNegativeButton("关闭接收",(d,w)->savePairing(null)).show();return;
        }
        try{
            String cert=LocalTrust.certificate(this);
            new AlertDialog.Builder(this).setTitle("允许自动记账同步到本机？")
                .setMessage("允许当前安装的 net.ankio.auto 将账单写入账迹，包括金额、类别、资产、备注。不会上传到服务器。请确认自动记账来自你信任的安装包。\n签名 SHA-256：\n"+cert+"\n换签名后必须关闭并重新授权。")
                .setNegativeButton("取消",null).setPositiveButton("允许本机接收",(d,w)->savePairing(cert)).show();
        }catch(Exception e){new AlertDialog.Builder(this).setMessage("没有找到可验证签名的自动记账。请先安装支持账迹适配器的版本。").setPositiveButton("关闭",null).show();}
    }
    private void savePairing(String cert){
        authorizationWorker.execute(()->{
            boolean saved;try{saved=cert==null?LocalTrust.revoke(this):LocalTrust.pair(this,cert);}catch(Exception e){saved=false;}
            final boolean ok=saved;runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())Toast.makeText(this,ok?(cert==null?"已关闭后续接收；已有及在途副本保留":"已保存本机接收授权"):"授权变更未能确认，请保留数据并重试",Toast.LENGTH_LONG).show();});
        });
    }
    @Override protected void onDestroy(){worker.shutdown();authorizationWorker.shutdown();super.onDestroy();}
}
