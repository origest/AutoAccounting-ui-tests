package io.github.origest.billdashboard;

import org.json.JSONException;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.util.List;
import java.util.Arrays;
import java.util.UUID;

/** Strict, bounded envelope; amounts never use a floating-point accumulator. */
final class LocalBill {
    static final int MAX_BYTES = 256 * 1024;
    final String source, id, json, type, money, currency;
    final long time, groupId, flag, revision;
    static final List<String> TYPES = Arrays.asList("Expend", "Income", "Transfer", "IncomeRefund", "IncomeReimbursement", "ExpendReimbursement", "IncomeLending", "ExpendLending", "IncomeRepayment", "ExpendRepayment");
    LocalBill(String sourceId, String payload) throws JSONException {
        if (sourceId == null || !UUID.fromString(sourceId).toString().equals(sourceId)) throw new IllegalArgumentException("Invalid source");
        if (payload == null || payload.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > MAX_BYTES) throw new IllegalArgumentException("Payload too large");
        JSONObject b = new JSONObject(payload);
        id = integer(b, "id", 1, Long.MAX_VALUE);
        revision = Long.parseLong(integer(b, "categoryRevision", 0, Long.MAX_VALUE - 1));
        type = b.getString("type");
        if (!TYPES.contains(type)) throw new IllegalArgumentException("Unsupported type");
        money = decimal(b.get("money").toString(), false);
        if (b.has("fee")) decimal(b.get("fee").toString(), true);
        time = Long.parseLong(integer(b, "time", 0, 4102444800000L));
        groupId = b.has("groupId") ? Long.parseLong(integer(b, "groupId", -1, Long.MAX_VALUE)) : -1;
        flag = b.has("flag") ? Long.parseLong(integer(b, "flag", 0, Long.MAX_VALUE)) : 0;
        String cur = b.optString("currency", "CNY");
        if (cur.startsWith("{")) cur = new JSONObject(cur).optString("code", "CNY");
        if (cur.isEmpty()) cur = "CNY";
        if (!cur.matches("[A-Z]{3}")) throw new IllegalArgumentException("Invalid currency");
        currency = cur; source = sourceId; json = b.toString();
    }
    static String integer(JSONObject b, String key, long min, long max) throws JSONException {
        String v = b.get(key).toString();
        if (!v.matches("-?[0-9]{1,19}")) throw new IllegalArgumentException("Invalid integer");
        long n = Long.parseLong(v);
        if (n < min || n > max) throw new IllegalArgumentException("Integer range");
        return Long.toString(n);
    }
    static String decimal(String value, boolean signed) {
        if (!value.matches("-?[0-9]{1,14}(\\.[0-9]{1,6})?")) throw new IllegalArgumentException("Invalid amount");
        BigDecimal n = new BigDecimal(value);
        if (!signed && n.signum() < 0) throw new IllegalArgumentException("Negative amount");
        return n.toPlainString();
    }
}
