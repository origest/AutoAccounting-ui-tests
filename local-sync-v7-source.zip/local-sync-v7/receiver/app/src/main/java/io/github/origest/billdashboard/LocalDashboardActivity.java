package io.github.origest.billdashboard;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import java.util.concurrent.*;

/** Bundled React dashboard with a strictly read-only private-database bridge. Never loads a server. */
public final class LocalDashboardActivity extends Activity {
    static final String ORIGIN="https://appassets.androidplatform.net";
    private WebView web;
    private final ThreadPoolExecutor reader=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(32));
    static boolean ownOrigin(Uri uri){return "https".equals(uri.getScheme())&&"appassets.androidplatform.net".equals(uri.getHost())&&(uri.getPort()==-1||uri.getPort()==443)&&uri.getUserInfo()==null;}
    static boolean assetPath(String path){return path!=null&&!path.contains("..")&&!path.contains("\\")&&(path.equals("/index.html")||path.matches("/assets/[A-Za-z0-9_.-]+"));}
    @Override @SuppressWarnings("SetJavaScriptEnabled") public void onCreate(Bundle state){
        super.onCreate(state);
        try{getAssets().open("dashboard/index.html").close();}catch(Exception e){TextView t=new TextView(this);t.setText("本机前端资源未打包，请使用完整构建。不会连接云端作为替代。");setContentView(t);return;}
        web=new WebView(this);setContentView(web);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);
        s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setBlockNetworkLoads(true);s.setBlockNetworkImage(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setGeolocationEnabled(false);
        web.addJavascriptInterface(new Bridge(),"LocalLedger");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){return !req.isForMainFrame()||!ownOrigin(req.getUrl())||!"/index.html".equals(req.getUrl().getPath());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){Uri uri=Uri.parse(url);return !ownOrigin(uri)||!"/index.html".equals(uri.getPath());}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){return resource(req.getUrl(),req.getMethod());}
        });
        web.setDownloadListener((a,b,c,d,e)->{});
        web.loadUrl(ORIGIN+"/index.html");
    }
    WebResourceResponse resource(Uri uri,String method){
        if(!"GET".equals(method)||!ownOrigin(uri)||!assetPath(uri.getPath())||uri.getQuery()!=null)return denied();
        try{
            String path=uri.getPath();String mime=path.endsWith(".html")?"text/html":path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":path.endsWith(".svg")?"image/svg+xml":"application/octet-stream";
            Map<String,String> headers=new HashMap<>();headers.put("Content-Security-Policy","default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'");headers.put("X-Content-Type-Options","nosniff");headers.put("Cache-Control","no-store");
            return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,getAssets().open("dashboard"+path));
        }catch(Exception e){return denied();}
    }
    private static WebResourceResponse denied(){return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",new HashMap<>(),new ByteArrayInputStream("本机模式禁止此请求".getBytes(StandardCharsets.UTF_8)));}
    public final class Bridge {
        @JavascriptInterface public void request(String id,String path){
            if(id==null||!id.matches("[A-Za-z0-9_-]{1,64}"))return;
            try{reader.execute(()->reply(id,new LocalReadApi(getApplicationContext()).request(path)));}
            catch(RejectedExecutionException e){reply(id,"{\"ok\":false,\"status\":429,\"message\":\"本机读取繁忙，请稍后重试\"}");}
        }
        @JavascriptInterface public void openSettings(){runOnUiThread(()->startActivity(new Intent(LocalDashboardActivity.this,LocalActivity.class)));}
    }
    private void reply(String id,String envelope){runOnUiThread(()->{if(web!=null&&!isFinishing()&&!isDestroyed())web.evaluateJavascript("window.__localLedgerResolve && window.__localLedgerResolve("+JSONObject.quote(id)+","+JSONObject.quote(envelope)+")",null);});}
    @Override protected void onResume(){super.onResume();if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('local-ledger-resume'))",null);}
    @Override protected void onDestroy(){reader.shutdownNow();if(web!=null){web.removeJavascriptInterface("LocalLedger");web.destroy();web=null;}super.onDestroy();}
}
