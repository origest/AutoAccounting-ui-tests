package io.github.origest.billdashboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

final class LocalLedger extends SQLiteOpenHelper {
    LocalLedger(Context context) { super(context, "local-ledger.db", null, 6); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE bills(source TEXT NOT NULL, external_id TEXT NOT NULL, payload TEXT NOT NULL, type TEXT NOT NULL, money TEXT NOT NULL, currency TEXT NOT NULL, time INTEGER NOT NULL, group_id INTEGER NOT NULL, flag INTEGER NOT NULL, revision INTEGER NOT NULL, received_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(source,external_id))");
        db.execSQL("CREATE TABLE source_binding(slot INTEGER PRIMARY KEY CHECK(slot=1), source TEXT NOT NULL)");
        db.execSQL("CREATE INDEX bills_time ON bills(time DESC)");
        LocalSnapshotStore.createSchema(db);
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion<2){
            db.execSQL("ALTER TABLE bills ADD COLUMN revision INTEGER NOT NULL DEFAULT -1");
            db.execSQL("CREATE TABLE source_binding(slot INTEGER PRIMARY KEY CHECK(slot=1), source TEXT NOT NULL)");
            db.execSQL("INSERT INTO source_binding(slot,source) VALUES(1,'legacy-unversioned')");
        }
        if(oldVersion<3)db.execSQL("ALTER TABLE bills ADD COLUMN received_at INTEGER NOT NULL DEFAULT 0");
        if(oldVersion<4)LocalSnapshotStore.createSchema(db);
        else {
            if(oldVersion<5)LocalSnapshotStore.migrateProgress(db);
            if(oldVersion<6)LocalSnapshotStore.createCopySchema(db);
        }
    }
    synchronized String receive(LocalBill bill) {
        SQLiteDatabase db = getWritableDatabase();
        String status = "inserted";
        db.beginTransaction();
        try {
            String bound=null;
            try(Cursor c=db.rawQuery("SELECT source FROM source_binding WHERE slot=1",null)){if(c.moveToFirst())bound=c.getString(0);}
            if(bound==null){ContentValues binding=new ContentValues();binding.put("slot",1);binding.put("source",bill.source);db.insertOrThrow("source_binding",null,binding);}
            else if(!bound.equals(bill.source)) return "source_changed";
            try (Cursor c = db.rawQuery("SELECT payload,revision FROM bills WHERE source=? AND external_id=?", new String[]{bill.source, bill.id})) {
                if (c.moveToFirst()) {
                    status=LocalSyncDecision.compare(bill.revision,c.getLong(1),bill.json,c.getString(0));
                }
            }
            if (status.equals("inserted") || status.equals("updated")) {
                ContentValues v = new ContentValues();
                v.put("source",bill.source); v.put("external_id",bill.id); v.put("payload",bill.json);
                v.put("type",bill.type); v.put("money",bill.money); v.put("currency",bill.currency);
                v.put("time",bill.time); v.put("group_id",bill.groupId); v.put("flag",bill.flag); v.put("revision",bill.revision); v.put("received_at",System.currentTimeMillis());
                if (db.insertWithOnConflict("bills",null,v,SQLiteDatabase.CONFLICT_REPLACE) == -1) throw new IllegalStateException("Write failed");
            }
            if(status.equals("unchanged")){ContentValues receipt=new ContentValues();receipt.put("received_at",System.currentTimeMillis());db.update("bills",receipt,"source=? AND external_id=?",new String[]{bill.source,bill.id});}
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        // ACK only after transaction commit, never on merely receiving the IPC call.
        return status;
    }
    List<JSONObject> page(int offset) {
        List<JSONObject> rows = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT payload FROM bills WHERE group_id=-1 ORDER BY time DESC,source,external_id LIMIT 100 OFFSET ?",new String[]{Integer.toString(offset)})) {
            while(c.moveToNext()) { try { rows.add(new JSONObject(c.getString(0))); } catch(Exception e) { throw new IllegalStateException("Corrupt local record"); } }
        }
        return rows;
    }
    long count() { try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM bills WHERE group_id=-1",null)){c.moveToFirst();return c.getLong(0);} }
    Map<String,BigDecimal[]> totals() {
        Map<String,BigDecimal[]> result=new TreeMap<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT currency,type,money FROM bills WHERE group_id=-1 AND (flag & 1)=0",null)) {
            while(c.moveToNext()) {
                BigDecimal[] v=result.computeIfAbsent(c.getString(0),key->new BigDecimal[]{BigDecimal.ZERO,BigDecimal.ZERO});
                BigDecimal n=new BigDecimal(c.getString(2));
                switch(c.getString(1)) {case "Income":v[0]=v[0].add(n);break;case "Expend":v[1]=v[1].add(n);break;case "IncomeRefund":v[1]=v[1].subtract(n);break;default:break;}
            }
        }
        return result;
    }
}
