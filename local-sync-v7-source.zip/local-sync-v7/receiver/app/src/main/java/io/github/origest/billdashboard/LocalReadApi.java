package io.github.origest.billdashboard;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

/** Read-only adapter for the existing React dashboard API. No socket, HTTP client, or writes. */
final class LocalReadApi {
    private final Context context;
    private static final ZoneId ZONE=ZoneId.of("Asia/Shanghai");
    LocalReadApi(Context context){this.context=context;}
    String request(String path){
        try {
            if(path==null||path.length()>8192||!path.startsWith("/api/"))throw new ApiFailure(400,"无效本机请求");
            Uri uri=Uri.parse("https://local.invalid"+path);
            if(!"local.invalid".equals(uri.getAuthority())||uri.getFragment()!=null)throw new ApiFailure(400,"无效本机请求");
            Object result;
            try(LocalLedger db=new LocalLedger(context)) {
                switch(uri.getPath()) {
                    case "/api/session":result=new JSONObject().put("authenticated",true).put("mode","local");break;
                    case "/api/sources":result=isArchive(uri)?sources(db):copySources(db,uri);break;
                    case "/api/meta":result=isArchive(uri)?meta(db).put("dataset","archive"):copyMeta(db,uri);break;
                    case "/api/bills":result=isArchive(uri)?bills(db,uri):copyBills(db,uri);break;
                    case "/api/summary":result=copySummary(db,uri);break;
                    default:
                        if(uri.getPath().matches("/api/bills/[0-9a-f-]{36}:[0-9]{1,19}"))result=isArchive(uri)?detail(db,uri.getLastPathSegment()):copyDetail(db,uri);
                        else throw new ApiFailure(404,"本机模式不支持此接口");
                }
            }
            return new JSONObject().put("ok",true).put("data",result).toString();
        }catch(ApiFailure e){return error(e.status,e.getMessage());}
        catch(IllegalArgumentException e){return error(422,"筛选参数无效");}
        catch(Exception e){return error(500,"本机账本读取失败，请保留数据并重试");}
    }
    private static String error(int status,String message){try{return new JSONObject().put("ok",false).put("status",status).put("message",message).toString();}catch(Exception e){throw new IllegalStateException(e);}}
    static final class ApiFailure extends Exception {final int status;ApiFailure(int s,String m){super(m);status=s;}}
    private static Object stamp(long value){return value>0?Instant.ofEpochMilli(value).toString():JSONObject.NULL;}
    private boolean active(){try{String pin=context.getSharedPreferences("local-receiver",0).getString("certificate","");return !pin.isEmpty()&&pin.equals(LocalTrust.certificate(context));}catch(Exception e){return false;}}
    private JSONArray sources(LocalLedger db)throws Exception{
        JSONArray out=new JSONArray();
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT source,COUNT(*),MAX(received_at) FROM bills GROUP BY source ORDER BY source",null)){
            while(c.moveToNext())out.put(new JSONObject().put("id",c.getString(0)).put("name","自动记账（本机）").put("kind","local").put("active",active()).put("bill_count",c.getLong(1)).put("last_received_at",stamp(c.getLong(2))));
        }return out;
    }
    private JSONObject meta(LocalLedger db)throws Exception{
        Set<String> currencies=new TreeSet<>(),books=new TreeSet<>(),categories=new TreeSet<>();currencies.add("CNY");
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT currency,payload FROM bills",null)){
            while(c.moveToNext()){if(Thread.currentThread().isInterrupted())throw new InterruptedException();currencies.add(c.getString(0));JSONObject b=new JSONObject(c.getString(1));if(!b.optString("bookName").isEmpty()&&b.optString("bookName").length()<=256&&books.size()<500)books.add(b.optString("bookName"));if(!b.optString("cateName").isEmpty()&&b.optString("cateName").length()<=256&&categories.size()<500)categories.add(b.optString("cateName"));}
        }return new JSONObject().put("currencies",new JSONArray(currencies)).put("books",new JSONArray(books)).put("categories",new JSONArray(categories)).put("filter_options_limited",true);
    }
    private JSONObject mapped(String source,String id,String currency,long received,JSONObject b,boolean raw)throws Exception{
        JSONObject out=new JSONObject().put("id",source+":"+id).put("source_id",source).put("external_id",id).put("source_name","自动记账（本机）").put("currency",currency).put("last_received_at",stamp(received));
        String[][] keys={{"type","type"},{"state","state"},{"money","money"},{"fee","fee"},{"category","cateName"},{"book_name","bookName"},{"shop_name","shopName"},{"shop_item","shopItem"},{"account_from","accountNameFrom"},{"account_to","accountNameTo"},{"remark","remark"},{"tags","tags"}};
        for(String[] pair:keys){String value=b.optString(pair[1],pair[0].equals("fee")?"0":"");
            if(!raw && !Arrays.asList("money","fee","type","state").contains(pair[0]) && value.length()>256){value=value.substring(0,256)+"…";out.put("preview_truncated",true);}out.put(pair[0],value);}
        out.put("time",b.getLong("time")).put("flag",b.optLong("flag")).put("group_id",b.optLong("groupId",-1));
        if(raw)out.put("raw",b);return out;
    }
    private JSONObject detail(LocalLedger db,String id)throws Exception{
        String[] parts=id.split(":",2);
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT payload,currency,received_at FROM bills WHERE source=? AND external_id=?",parts)){
            if(!c.moveToFirst())throw new ApiFailure(404,"本机账单不存在");return mapped(parts[0],parts[1],c.getString(1),c.getLong(2),new JSONObject(c.getString(0)),true);
        }
    }
    private static String param(Uri uri,String name,String fallback){String v=uri.getQueryParameter(name);return v==null||v.isEmpty()?fallback:v;}
    static final class Filter {
        final long start,end;final String currency,source,type,state,book,category,q;
        Filter(Uri uri){
            LocalDate today=LocalDate.now(ZONE),a=LocalDate.parse(param(uri,"start",today.withDayOfMonth(1).toString())),b=LocalDate.parse(param(uri,"end",today.toString()));
            if(b.isBefore(a)||ChronoUnit.DAYS.between(a,b)>366*5)throw new IllegalArgumentException();
            start=a.atStartOfDay(ZONE).toInstant().toEpochMilli();end=b.plusDays(1).atStartOfDay(ZONE).toInstant().toEpochMilli();
            currency=param(uri,"currency","CNY");if(!currency.matches("[A-Z]{3}"))throw new IllegalArgumentException();
            source=param(uri,"source_id","");type=param(uri,"type","");state=param(uri,"state","");book=param(uri,"book","");category=param(uri,"category","");q=param(uri,"q","").trim().toLowerCase(Locale.ROOT);if(q.length()>200)throw new IllegalArgumentException();
        }
        boolean matches(JSONObject b){
            if(!state.isEmpty()&&!state.equals(b.optString("state")))return false;
            if(!book.isEmpty()&&!book.equals(b.optString("bookName")))return false;
            if(!category.isEmpty()&&!category.equals(b.optString("cateName")))return false;
            if(!q.isEmpty()){
                for(String key:new String[]{"shopName","shopItem","remark","cateName","tags"})if(b.optString(key).toLowerCase(Locale.ROOT).contains(q))return true;
                return false;
            }return true;
        }
        Cursor cursor(LocalLedger db){
            String sql="SELECT source,external_id,currency,received_at,payload FROM bills WHERE group_id=-1 AND time>=? AND time<? AND currency=?";
            List<String> args=new ArrayList<>(Arrays.asList(Long.toString(start),Long.toString(end),currency));
            if(!source.isEmpty()){sql+=" AND source=?";args.add(source);}if(!type.isEmpty()){sql+=" AND type=?";args.add(type);}
            return db.getReadableDatabase().rawQuery(sql+" ORDER BY time DESC,source,external_id",args.toArray(new String[0]));
        }
    }
    private JSONObject bills(LocalLedger db,Uri uri)throws Exception{
        Filter f=new Filter(uri);int page=Integer.parseInt(param(uri,"page","1")),size=Integer.parseInt(param(uri,"page_size","25"));if(page<1||size<1||size>100)throw new IllegalArgumentException();
        long lower=(long)(page-1)*size,total=0;JSONArray items=new JSONArray();
        try(Cursor c=f.cursor(db)){while(c.moveToNext()){if(Thread.currentThread().isInterrupted())throw new InterruptedException();JSONObject b=new JSONObject(c.getString(4));if(!f.matches(b))continue;if(total>=lower&&items.length()<size)items.put(mapped(c.getString(0),c.getString(1),c.getString(2),c.getLong(3),b,false));total++;}}
        return new JSONObject().put("items",items).put("total",total).put("page",page).put("page_size",size);
    }
    private static boolean isArchive(Uri uri) {
        String value=param(uri,"dataset","copy");
        if(!value.equals("copy")&&!value.equals("archive"))throw new IllegalArgumentException();
        return value.equals("archive");
    }
    private LocalSnapshotStore.Manifest copyManifest(LocalSnapshotStore store,Uri uri) {
        String id=param(uri,"snapshot_id","");
        if(!id.isEmpty()&&!UUID.fromString(id).toString().equals(id))throw new IllegalArgumentException();
        return store.selectedCopyManifest(id.isEmpty()?null:id);
    }
    private static String currency(JSONObject b)throws Exception {
        String value=b.optString("currency","CNY").trim();if(value.isEmpty())value="CNY";
        if(value.startsWith("{"))value=new JSONObject(value).getString("code");
        value=value.trim().toUpperCase(Locale.ROOT);
        if(!value.matches("[A-Z]{3}"))throw new IllegalArgumentException();return value;
    }
    private JSONObject copyInfo(LocalSnapshotStore store,LocalSnapshotStore.Manifest m)throws Exception {
        return new JSONObject().put("dataset","copy").put("snapshot_id",m==null?JSONObject.NULL:m.snapshotId)
            .put("captured_at",m==null?JSONObject.NULL:stamp(m.capturedAt))
            .put("last_synced_at",m==null?JSONObject.NULL:stamp(store.copySelectedAt(m.snapshotId)))
            .put("offline",true).put("summary_enabled",m!=null).put("freshness","offline_copy_not_live");
    }
    private JSONArray copySources(LocalLedger db,Uri uri)throws Exception {
        LocalSnapshotStore store=new LocalSnapshotStore(db);LocalSnapshotStore.Manifest m=copyManifest(store,uri);
        JSONArray out=new JSONArray();if(m!=null)out.put(new JSONObject().put("id",m.sourceId).put("name","自动记账（离线副本）")
            .put("kind","local-copy").put("active",active()).put("bill_count",m.totalRows)
            .put("last_received_at",stamp(store.copySelectedAt(m.snapshotId))));return out;
    }
    private JSONObject copyMeta(LocalLedger db,Uri uri)throws Exception {
        LocalSnapshotStore store=new LocalSnapshotStore(db);LocalSnapshotStore.Manifest m=copyManifest(store,uri);
        Set<String> currencies=new TreeSet<>(),books=new TreeSet<>(),categories=new TreeSet<>();currencies.add("CNY");
        if(m!=null)try(Cursor c=db.getReadableDatabase().rawQuery("SELECT payload FROM local_snapshot_rows WHERE snapshot_id=? ORDER BY bill_id",new String[]{m.snapshotId})) {
            while(c.moveToNext()){if(Thread.currentThread().isInterrupted())throw new InterruptedException();JSONObject b=new JSONObject(c.getString(0));currencies.add(currency(b));if(!b.optString("bookName").isEmpty()&&b.optString("bookName").length()<=256&&books.size()<500)books.add(b.optString("bookName"));if(!b.optString("cateName").isEmpty()&&b.optString("cateName").length()<=256&&categories.size()<500)categories.add(b.optString("cateName"));}
        }
        return copyInfo(store,m).put("currencies",new JSONArray(currencies)).put("books",new JSONArray(books)).put("categories",new JSONArray(categories)).put("filter_options_limited",true);
    }
    private JSONObject copyBills(LocalLedger db,Uri uri)throws Exception {
        Filter f=new Filter(uri);int page=Integer.parseInt(param(uri,"page","1")),size=Integer.parseInt(param(uri,"page_size","25"));
        if(page<1||size<1||size>100)throw new IllegalArgumentException();
        LocalSnapshotStore store=new LocalSnapshotStore(db);LocalSnapshotStore.Manifest m=copyManifest(store,uri);
        if(page>1&&param(uri,"snapshot_id","").isEmpty())throw new ApiFailure(409,"分页需要固定快照，请刷新后重试");
        long total=0,lower=(long)(page-1)*size;JSONArray items=new JSONArray();
        // Immutable snapshot ID is fixed for this request and every subsequent page/detail.
        if(m!=null)try(Cursor c=db.getReadableDatabase().rawQuery("SELECT bill_id,payload FROM local_snapshot_rows WHERE snapshot_id=? ORDER BY bill_id DESC",new String[]{m.snapshotId})) {
            while(c.moveToNext()) {
                if(Thread.currentThread().isInterrupted())throw new InterruptedException();JSONObject b=new JSONObject(c.getString(1));
                String cur=currency(b);long time=b.getLong("time");
                if(b.optLong("groupId",-1)!=-1||time<f.start||time>=f.end||!cur.equals(f.currency)||
                    (!f.source.isEmpty()&&!f.source.equals(m.sourceId))||(!f.type.isEmpty()&&!f.type.equals(b.optString("type")))||!f.matches(b))continue;
                if(total>=lower&&items.length()<size)items.put(mapped(m.sourceId,c.getString(0),cur,store.copySelectedAt(m.snapshotId),b,false).put("snapshot_id",m.snapshotId));total++;
            }
        }
        if(items.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8).length>512*1024)throw new ApiFailure(422,"本页文字过多，请缩小分页范围");
        return copyInfo(store,m).put("items",items).put("total",total).put("page",page).put("page_size",size);
    }
    /** Only a pinned, complete selected copy is a coherent chart input. Archive has no totals. */
    private JSONObject copySummary(LocalLedger db,Uri uri)throws Exception {
        if(isArchive(uri)||param(uri,"snapshot_id","").isEmpty())throw new ApiFailure(409,"图表需要固定的完整离线副本，不支持旧接收归档");
        LocalSnapshotStore store=new LocalSnapshotStore(db);LocalSnapshotStore.Manifest m=copyManifest(store,uri);
        if(m==null)throw new ApiFailure(409,"尚无完整离线副本");
        Filter f=new Filter(uri);BigDecimal income=BigDecimal.ZERO,expense=BigDecimal.ZERO,refund=BigDecimal.ZERO;
        Map<String,BigDecimal[]> daily=new TreeMap<>();Map<String,BigDecimal> categories=new TreeMap<>();long count=0,pending=0,excluded=0,special=0;
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT payload FROM local_snapshot_rows WHERE snapshot_id=? ORDER BY bill_id",new String[]{m.snapshotId})){
            while(c.moveToNext()){
                if(Thread.currentThread().isInterrupted())throw new InterruptedException();String raw=c.getString(0);JSONObject bill=new JSONObject(raw);long time=bill.getLong("time");String type=bill.getString("type");
                if(bill.optLong("groupId",-1)!=-1||time<f.start||time>=f.end||!currency(bill).equals(f.currency)||(!f.source.isEmpty()&&!f.source.equals(m.sourceId))||(!f.type.isEmpty()&&!f.type.equals(type))||!f.matches(bill))continue;
                count++;if("Wait2Edit".equals(bill.optString("state"))||!bill.optString("pendingCategory").isEmpty())pending++;
                if((bill.optLong("flag")&1)!=0){excluded++;continue;}
                BigDecimal amount=exactMoney(raw);
                String day=Instant.ofEpochMilli(time).atZone(ZONE).toLocalDate().toString();BigDecimal[] point=daily.computeIfAbsent(day,key->new BigDecimal[]{BigDecimal.ZERO,BigDecimal.ZERO});
                switch(type){
                    case "Income":income=income.add(amount);point[0]=point[0].add(amount);break;
                    case "Expend":expense=expense.add(amount);point[1]=point[1].add(amount);String category=bill.optString("cateName");if(category.isEmpty())category="未分类";if(category.length()>256)throw new ApiFailure(422,"分类名称过长，无法安全绘制图表");categories.put(category,categories.getOrDefault(category,BigDecimal.ZERO).add(amount));break;
                    case "IncomeRefund":refund=refund.add(amount);point[1]=point[1].subtract(amount);break;
                    case "Transfer":case "ExpendReimbursement":case "IncomeReimbursement":case "ExpendLending":case "IncomeLending":case "ExpendRepayment":case "IncomeRepayment":special++;break;
                    default:throw new ApiFailure(422,"未知交易类型，未生成不完整统计");
                }
            }
        }
        JSONArray days=new JSONArray(),cats=new JSONArray();for(Map.Entry<String,BigDecimal[]> entry:daily.entrySet())days.put(new JSONObject().put("date",entry.getKey()).put("income",entry.getValue()[0].toPlainString()).put("expense",entry.getValue()[1].toPlainString()));
        List<Map.Entry<String,BigDecimal>> sorted=new ArrayList<>(categories.entrySet());sorted.sort((a,b)->{int amount=b.getValue().compareTo(a.getValue());return amount!=0?amount:a.getKey().compareTo(b.getKey());});
        for(Map.Entry<String,BigDecimal> entry:sorted)cats.put(new JSONObject().put("name",entry.getKey()).put("value",entry.getValue().toPlainString()));
        BigDecimal safeBound=new BigDecimal("90071992547409.91");boolean chartSafe=true;
        for(BigDecimal v:new BigDecimal[]{income,expense,refund,expense.subtract(refund),income.subtract(expense).add(refund)})if(v.abs().compareTo(safeBound)>0)chartSafe=false;
        for(BigDecimal[] point:daily.values())for(BigDecimal v:point)if(v.abs().compareTo(safeBound)>0)chartSafe=false;
        for(BigDecimal v:categories.values())if(v.abs().compareTo(safeBound)>0)chartSafe=false;
        JSONObject result=copyInfo(store,m).put("chart_safe",chartSafe).put("income",income.toPlainString()).put("expense",expense.subtract(refund).toPlainString()).put("gross_expense",expense.toPlainString()).put("refund",refund.toPlainString()).put("balance",income.subtract(expense).add(refund).toPlainString()).put("count",count).put("pending",pending).put("excluded",excluded).put("special",special).put("daily",days).put("categories",cats).put("timezone","Asia/Shanghai").put("semantics","money-only-gross-categories-v1").put("includes_pending",f.state.isEmpty()||f.state.equals("Wait2Edit"));
        if(result.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8).length>512*1024)throw new ApiFailure(422,"统计分类过多，请缩小筛选范围");return result;
    }
    /** JsonReader preserves a JSON number's decimal token instead of rounding through Double. */
    private static BigDecimal exactMoney(String raw)throws Exception {
        BigDecimal value=null;try(android.util.JsonReader reader=new android.util.JsonReader(new java.io.StringReader(raw))){
            reader.setLenient(false);reader.beginObject();while(reader.hasNext()){
                String name=reader.nextName();if(!name.equals("money")){reader.skipValue();continue;}
                if(value!=null)throw new IllegalArgumentException();android.util.JsonToken token=reader.peek();if(token!=android.util.JsonToken.NUMBER&&token!=android.util.JsonToken.STRING)throw new IllegalArgumentException();
                String number=reader.nextString();if(number.length()>64)throw new IllegalArgumentException();value=new BigDecimal(number);
                if(value.signum()<0||value.precision()>24||Math.abs((long)value.scale())>12)throw new IllegalArgumentException();
            }reader.endObject();if(reader.peek()!=android.util.JsonToken.END_DOCUMENT)throw new IllegalArgumentException();
        }if(value==null)throw new IllegalArgumentException();return value;
    }
    private JSONObject copyDetail(LocalLedger db,Uri uri)throws Exception {
        if(param(uri,"snapshot_id","").isEmpty())throw new ApiFailure(409,"详情需要固定快照，请刷新后重试");
        LocalSnapshotStore store=new LocalSnapshotStore(db);LocalSnapshotStore.Manifest m=copyManifest(store,uri);
        String[] parts=uri.getLastPathSegment().split(":",2);
        if(m==null||!m.sourceId.equals(parts[0]))throw new ApiFailure(404,"离线副本账单不存在");
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT payload FROM local_snapshot_rows WHERE snapshot_id=? AND bill_id=?",new String[]{m.snapshotId,parts[1]})) {
            if(!c.moveToFirst())throw new ApiFailure(404,"离线副本账单不存在");JSONObject b=new JSONObject(c.getString(0));
            return mapped(m.sourceId,parts[1],currency(b),store.copySelectedAt(m.snapshotId),b,true).put("snapshot_id",m.snapshotId);
        }
    }
}
