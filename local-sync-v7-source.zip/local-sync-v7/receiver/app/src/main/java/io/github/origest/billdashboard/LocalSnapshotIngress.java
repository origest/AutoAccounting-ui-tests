package io.github.origest.billdashboard;

import android.content.Context;
import android.content.ContentProviderClient;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.JSONObject;

/** Authenticated bounded copying. Legacy grants stage only; explicit copy contracts may select complete copies. */
final class LocalSnapshotIngress {
    interface LiveVerifier { boolean verify(String grantJson); }
    private static final int MAX_PACKET=384*1024;
    static Bundle receive(Context context,LocalLedger ledger,int uid,String method,Bundle extras,LiveVerifier verifier){
        Bundle result=new Bundle();result.putInt("protocol",2);result.putString("status","denied");
        try {
            if(extras==null||extras.getInt("protocol")!=2)return result;
            final String epoch;synchronized(LocalTrust.LOCK){if(!LocalTrust.permitted(context,uid))return result;epoch=LocalTrust.epoch(context);}
            String grant=extras.getString("grant_json");require(grant!=null&&grant.getBytes(StandardCharsets.UTF_8).length<=4096);
            JSONObject g=new JSONObject(grant);
            String contract=g.isNull("contract")?null:g.getString("contract");
            require(Objects.equals(contract,extras.getString("contract")));
            require(contract==null||"offline-copy-v1".equals(contract));
            JSONObject lease=g.getJSONObject("lease");String snapshot=lease.getString("snapshotId");
            String source=lease.getString("sourceId"),digest=lease.getString("digest");long sequence=lease.getLong("sequence");
            LocalSnapshotStore.CopyAuthorization copy=contract==null?null:new LocalSnapshotStore.CopyAuthorization(contract,source,snapshot,digest,g.getString("grantId"),g.getString("revokeEpoch"),epoch);
            require(verifier.verify(grant)); // No receiver lock across reverse Binder/DB checks.
            synchronized(LocalTrust.LOCK){
                require(LocalTrust.permitted(context,uid)&&epoch.equals(LocalTrust.epoch(context)));
            }
            // Admission is now in-flight. Do not hold the UI pairing/revocation lock
            // during SQLite writes or a complete snapshot hash. Revocation may happen
            // while an admitted copy finishes; the disclosed offline-copy contract retains it.
            {
                LocalSnapshotStore store=new LocalSnapshotStore(ledger);
                android.content.SharedPreferences sessions=context.getSharedPreferences("local-snapshot-sessions",Context.MODE_PRIVATE);
                if("snapshot-begin-v2".equals(method)){
                    String raw=extras.getString("manifest_json");require(raw!=null&&raw.getBytes(StandardCharsets.UTF_8).length<=4096);
                    JSONObject m=new JSONObject(raw);LocalSnapshotStore.Manifest manifest=new LocalSnapshotStore.Manifest(m.getString("sourceId"),m.getString("snapshotId"),m.getLong("sequence"),m.getLong("capturedAt"),m.getLong("totalRows"),m.getLong("totalBytes"),m.getString("digest"));
                    require(snapshot.equals(manifest.snapshotId)&&source.equals(manifest.sourceId)&&digest.equals(manifest.digest)&&sequence==manifest.sequence);
                    if(copy==null)store.begin(manifest);else store.beginAuthorizedCopy(manifest,copy);
                    require(sessions.edit().putString(snapshot+":grant",grant).putString(snapshot+":epoch",epoch).commit());
                    result.putString("status","staged");
                }else{
                    require(snapshot.equals(extras.getString("snapshot_id"))&&grant.equals(sessions.getString(snapshot+":grant",""))&&epoch.equals(sessions.getString(snapshot+":epoch","")));
                    if("snapshot-page-v2".equals(method)){
                        ArrayList<Bundle> incoming=extras.getParcelableArrayList("rows");require(incoming!=null&&incoming.size()<=100);
                        ArrayList<LocalSnapshotStore.Row> rows=new ArrayList<>();long size=0;
                        for(Bundle b:incoming){byte[] bytes=b.getByteArray("payload");require(bytes!=null&&bytes.length<=LocalSnapshotStore.MAX_ROW_BYTES);size+=bytes.length+32;require(size<=MAX_PACKET);
                            String payload=new String(bytes,StandardCharsets.UTF_8);require(Arrays.equals(bytes,payload.getBytes(StandardCharsets.UTF_8)));rows.add(new LocalSnapshotStore.Row(b.getLong("id"),payload));}
                        store.page(snapshot,rows);result.putString("status","accepted");
                    }else if("snapshot-complete-v2".equals(method)){
                        if(copy==null){store.complete(snapshot);result.putString("status","complete");}
                        else result.putString("status",store.completeAuthorizedCopy(snapshot,copy));
                    }
                    else return denied();
                }
            }
            // Revocation detected after copying stops subsequent sends. A completed authorized copy
            // may already be selected; denial is not a promise of rollback or remote erasure.
            require(verifier.verify(grant));synchronized(LocalTrust.LOCK){require(LocalTrust.permitted(context,uid)&&epoch.equals(LocalTrust.epoch(context)));}
            result.putString("source_id",source);result.putString("snapshot_id",snapshot);result.putString("digest",digest);return result;
        }catch(Exception ignored){return denied();}
    }
    private static Bundle denied(){Bundle b=new Bundle();b.putInt("protocol",2);b.putString("status","denied");return b;}
    private static void require(boolean ok){if(!ok)throw new IllegalStateException("SNAPSHOT_STAGE_REJECTED");}
    static boolean liveVerify(Context context,String grant){
        long identity=Binder.clearCallingIdentity();
        try {
            android.content.pm.ProviderInfo p=context.getPackageManager().resolveContentProvider("net.ankio.auto.localsnapshotgrant",0);
            if(p==null||!LocalTrust.SENDER.equals(p.packageName)||!LocalTrust.permitted(context,p.applicationInfo.uid))return false;
            String cert=LocalTrust.certificate(context);Bundle b=new Bundle();b.putString("grant_json",grant);
            try(ContentProviderClient client=context.getContentResolver().acquireContentProviderClient(Uri.parse("content://net.ankio.auto.localsnapshotgrant"))){
                if(client==null)return false;Bundle reply=client.call("verify-v1",null,b);
                return reply!=null&&reply.getInt("protocol")==1&&"valid".equals(reply.getString("status"))&&grant.equals(reply.getString("grant_json"))&&cert.equals(LocalTrust.certificate(context))&&LocalTrust.permitted(context,p.applicationInfo.uid);
            }
        }catch(Exception ignored){return false;}finally{Binder.restoreCallingIdentity(identity);}
    }
}
