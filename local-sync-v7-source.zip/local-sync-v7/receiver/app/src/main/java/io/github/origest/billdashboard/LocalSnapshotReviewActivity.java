package io.github.origest.billdashboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;
import java.util.concurrent.*;

/** Native local review only; nonexported, never accepts an approval from intent/JS/provider. */
public final class LocalSnapshotReviewActivity extends Activity {
    interface VerifierFactory { LocalSnapshotStore.AuthorizationVerifier create(Activity activity); }
    // Integration installs a factory at process initialization. Process death returns to fail-closed.
    private static volatile VerifierFactory verifierFactory;
    static void setVerifierFactory(VerifierFactory factory){verifierFactory=factory;}
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private LinearLayout column;private String selected;private int offset;private boolean busy;
    @Override public void onCreate(Bundle saved){super.onCreate(saved);if(saved!=null){selected=saved.getString("snapshot");offset=saved.getInt("offset");}if(selected==null)list();else review(selected);}
    @Override protected void onSaveInstanceState(Bundle out){out.putString("snapshot",selected);out.putInt("offset",offset);super.onSaveInstanceState(out);}
    private void screen(String title){ScrollView scroll=new ScrollView(this);column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setPadding(32,32,32,32);scroll.addView(column);setContentView(scroll);text(title,24);}
    private void text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,12,0,12);column.addView(t);}
    private void button(String title,Runnable action){Button b=new Button(this);b.setText(title);column.addView(b);b.setOnClickListener(v->{if(!busy)action.run();});}
    private interface Job {void run(LocalSnapshotStore store)throws Exception;}
    private void background(Job job){if(busy)return;busy=true;worker.execute(()->{try(LocalLedger ledger=new LocalLedger(getApplicationContext())){job.run(new LocalSnapshotStore(ledger));}catch(Exception e){ui(()->{busy=false;new AlertDialog.Builder(this).setTitle("未完成").setMessage("未能确认操作结果。请保留数据，刷新查看当前快照后再决定是否重试。错误："+safeCode(e)).setPositiveButton("关闭",null).show();});}});}
    private static String safeCode(Exception e){String m=e.getMessage();return m!=null&&m.matches("[A-Z_]{1,80}")?m:"LOCAL_SNAPSHOT_REVIEW_FAILED";}
    private void ui(Runnable r){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())r.run();});}
    private void list(){selected=null;screen("本机快照 · 待查看");text("只展示已完整校验的快照。按新版离线副本授权完成同步后会更新看板；旧暂存不会自动升级。历史副本和原始接收归档均保留，金额汇总仍暂停。",15);
        background(store->{List<LocalSnapshotStore.Manifest> rows=store.listComplete(offset,20);String active=store.activeSnapshotId();ui(()->{busy=false;
            if(rows.isEmpty())text("没有可查看的完整快照。未完成的暂存内容不会影响当前记录。",16);
            for(LocalSnapshotStore.Manifest m:rows)button((m.snapshotId.equals(active)?"当前 · ":"")+m.totalRows+" 条 · "+DateFormat.getDateTimeInstance().format(new Date(m.capturedAt))+" · 序列 "+m.sequence,()->review(m.snapshotId));
            if(offset>0)button("上一页",()->{offset=Math.max(0,offset-20);list();});if(rows.size()==20)button("下一页",()->{offset+=20;list();});button("刷新",this::list);
        });});
    }
    private void review(String id){selected=id;screen("快照核对");background(store->{LocalSnapshotStore.Review r=store.review(id);ui(()->{busy=false;
        text("来源："+r.manifest.sourceId+"\n快照："+id+"\n序列："+r.manifest.sequence+"\n捕获时间："+DateFormat.getDateTimeInstance().format(new Date(r.manifest.capturedAt))+"\n记录数："+r.manifest.totalRows+"\n原始数据字节："+r.manifest.totalBytes+"\n相较当前快照缺少："+r.absentRows+" 条",15);
        text("缺少仅表示未出现在此次捕获中，不等于用户删除。切换后旧快照仍保留。空快照也必须明确确认。当前不提供金额汇总。",15);
        button("查看此快照记录",()->details(r,false,0));button("查看缺少的记录",()->details(r,true,0));
        if(verifierFactory==null){
            text("此处仅供核对，不手动切换。新版已授权离线副本在完整同步后更新看板；旧暂存需要在自动记账创建新快照并重新明确授权。撤销不远程删除已接收副本。",15);
            Button blocked=new Button(this);blocked.setText("旧暂存不可直接切换为看板");blocked.setEnabled(false);column.addView(blocked);
        }else button("核对并切换为当前快照",()->confirm(r));
        button("返回快照列表",this::list);
    });});}
    private void details(LocalSnapshotStore.Review r,boolean absent,long after){screen(absent?"本次未出现的历史记录":"快照记录");background(store->{List<LocalSnapshotStore.Row> rows=absent?store.absentPage(r.manifest.snapshotId,r.activeId,after,20):store.pageRows(r.manifest.snapshotId,after,20);ui(()->{busy=false;
        if(rows.isEmpty())text("没有更多记录。",16);for(LocalSnapshotStore.Row row:rows){String preview=row.payload.length()>1500?row.payload.substring(0,1500)+"…（仅显示前1500字符，原文完整保留）":row.payload;text("ID "+row.id+"\n"+preview,14);}
        if(!rows.isEmpty())button("下一页",()->details(r,absent,rows.get(rows.size()-1).id));button("回到快照核对",()->review(r.manifest.snapshotId));
    });});}
    private void confirm(LocalSnapshotStore.Review r){
        VerifierFactory factory=verifierFactory;
        if(factory==null){new AlertDialog.Builder(this).setTitle("暂不能切换").setMessage("实时来源与授权校验尚未连接，保持当前快照不变。不会绕过校验。").setPositiveButton("关闭",null).show();return;}
        new AlertDialog.Builder(this).setTitle(r.manifest.totalRows==0?"确认切换为空快照？":"确认切换当前快照？")
            .setMessage("目标共 "+r.manifest.totalRows+" 条，相较当前缺少 "+r.absentRows+" 条。旧快照不会删除。确认后仍须通过实时来源及授权校验；核对期间当前快照若已变化，本次切换将拒绝。")
            .setNegativeButton("取消",null).setPositiveButton("确认切换",(d,w)->{
                // Fetch current integration only after this explicit user gesture. Never restore approval.
                VerifierFactory current=verifierFactory;
                if(current==null){confirm(r);return;}
                background(store->{LocalSnapshotStore.AuthorizationVerifier verifier=current.create(this);store.activateReviewed(r.manifest.snapshotId,r.activeId,verifier);ui(()->{busy=false;Toast.makeText(this,"已切换；旧快照仍保留",Toast.LENGTH_LONG).show();review(r.manifest.snapshotId);});});
            }).show();
    }
    @Override protected void onDestroy(){worker.shutdown();super.onDestroy();}
}
