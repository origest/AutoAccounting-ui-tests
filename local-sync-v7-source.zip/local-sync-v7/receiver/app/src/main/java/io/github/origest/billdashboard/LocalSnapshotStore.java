package io.github.origest.billdashboard;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.JSONObject;

/** Internal staging kernel only. No IPC entry, automatic activation or monetary aggregation. */
final class LocalSnapshotStore {
    static final int MAX_ROWS=20000, MAX_ROW_BYTES=256*1024, MAX_PAGE_BYTES=1024*1024;
    static final long MAX_BYTES=32L*1024*1024, MAX_DECLARED_BYTES=128L*1024*1024;
    static final int MAX_MANIFESTS=1000;
    private final LocalLedger ledger;
    LocalSnapshotStore(LocalLedger ledger){this.ledger=ledger;}
    static final class Manifest {
        final String sourceId,snapshotId,digest; final long sequence,capturedAt,totalRows,totalBytes;
        Manifest(String sourceId,String snapshotId,long sequence,long capturedAt,long totalRows,long totalBytes,String digest){
            uuid(sourceId);uuid(snapshotId);
            require(sequence>=0 && capturedAt>=0 && totalRows>=0 && totalRows<=MAX_ROWS && totalBytes>=0 && totalBytes<=MAX_BYTES,"MANIFEST_LIMIT");
            require(digest!=null&&digest.matches("[0-9a-f]{64}"),"DIGEST_FORMAT");
            this.sourceId=sourceId;this.snapshotId=snapshotId;this.sequence=sequence;this.capturedAt=capturedAt;this.totalRows=totalRows;this.totalBytes=totalBytes;this.digest=digest;
        }
    }
    static final class Row {
        final long id; final String payload;
        Row(long id,String payload){
            require(id>0 && payload!=null,"ROW_ID");
            require(bytes(payload).length<=MAX_ROW_BYTES,"ROW_LIMIT");
            try{JSONObject object=new JSONObject(payload);Object embedded=object.get("id");
                require((embedded instanceof Integer || embedded instanceof Long) && ((Number)embedded).longValue()==id,"ROW_PAYLOAD_ID");
            }catch(org.json.JSONException e){throw new IllegalArgumentException("ROW_JSON");}
            this.id=id;this.payload=payload;
        }
    }
    static void createSchema(SQLiteDatabase db){
        db.execSQL("CREATE TABLE local_snapshot_manifests(snapshot_id TEXT PRIMARY KEY NOT NULL, source TEXT NOT NULL, sequence INTEGER NOT NULL, captured_at INTEGER NOT NULL, total_rows INTEGER NOT NULL, total_bytes INTEGER NOT NULL, digest TEXT NOT NULL, complete INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE local_snapshot_rows(snapshot_id TEXT NOT NULL, bill_id INTEGER NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(snapshot_id,bill_id))");
        db.execSQL("CREATE TABLE local_snapshot_active(slot INTEGER PRIMARY KEY CHECK(slot=1), snapshot_id TEXT NOT NULL)");
        createProgressSchema(db);
        createCopySchema(db);
    }
    static final String COPY_CONTRACT="offline-copy-v1";
    /** Created by authenticated ingress after explicit copy-contract authorization, never by an approval flag. */
    static final class CopyAuthorization {
        final String contract,sourceId,snapshotId,digest,grantId,revokeEpoch,receiverEpoch;
        CopyAuthorization(String contract,String sourceId,String snapshotId,String digest,String grantId,String revokeEpoch,String receiverEpoch){
            require(COPY_CONTRACT.equals(contract),"COPY_CONTRACT_REQUIRED");uuid(sourceId);uuid(snapshotId);uuid(grantId);uuid(revokeEpoch);uuid(receiverEpoch);
            require(digest!=null&&digest.matches("[0-9a-f]{64}"),"DIGEST_FORMAT");
            this.contract=contract;this.sourceId=sourceId;this.snapshotId=snapshotId;this.digest=digest;this.grantId=grantId;this.revokeEpoch=revokeEpoch;this.receiverEpoch=receiverEpoch;
        }
    }
    /** v5 -> v6 is additive. Existing staging is intentionally NOT upgraded to a copy contract. */
    static void createCopySchema(SQLiteDatabase db){
        db.execSQL("CREATE TABLE local_snapshot_copy_contract(snapshot_id TEXT PRIMARY KEY NOT NULL, contract TEXT NOT NULL, source TEXT NOT NULL, digest TEXT NOT NULL, grant_id TEXT NOT NULL, revoke_epoch TEXT NOT NULL, receiver_epoch TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, selected_at INTEGER NOT NULL DEFAULT 0)");
    }
    void beginAuthorizedCopy(Manifest m,CopyAuthorization authorization){transaction(db->{
        validateAuthorization(m,authorization);
        Manifest existing=manifest(db,m.snapshotId);
        if(existing!=null){require(same(existing,m),"MANIFEST_CONFLICT");checkCopyContract(db,m,authorization);progress(db,m);checkSource(db,m.sourceId);return;}
        beginInTransaction(db,m);
        ContentValues v=new ContentValues();v.put("snapshot_id",m.snapshotId);v.put("contract",authorization.contract);v.put("source",authorization.sourceId);v.put("digest",authorization.digest);v.put("grant_id",authorization.grantId);v.put("revoke_epoch",authorization.revokeEpoch);v.put("receiver_epoch",authorization.receiverEpoch);
        db.insertOrThrow("local_snapshot_copy_contract",null,v);
    });}
    /** Complete receipt and select locally in one transaction. No source state is changed.
     * Ingress must validate the current send authorization; received copies are not remotely revoked. */
    String completeAuthorizedCopy(String snapshotId,CopyAuthorization authorization){uuid(snapshotId);transaction(db->{
        Manifest m=required(db,snapshotId);validateAuthorization(m,authorization);checkCopyContract(db,m,authorization);checkSource(db,m.sourceId);
        verify(db,m);
        String active=activeId(db);
        boolean completed;try(Cursor c=db.rawQuery("SELECT completed FROM local_snapshot_copy_contract WHERE snapshot_id=?",new String[]{snapshotId})){require(c.moveToFirst(),"COPY_CONTRACT_REQUIRED");completed=c.getInt(0)==1;}
        if(completed){require(snapshotId.equals(active),"COPY_ALREADY_COMPLETED_NOT_CURRENT");return;}
        if(active!=null){Manifest prior=required(db,active);require(prior.sourceId.equals(m.sourceId),"SOURCE_CHANGED");require(m.sequence>=prior.sequence,"STALE_SNAPSHOT");require(m.sequence!=prior.sequence||m.digest.equals(prior.digest),"SEQUENCE_CONFLICT");}
        try(Cursor c=db.rawQuery("SELECT source FROM source_binding WHERE slot=1",null)){if(!c.moveToFirst()){ContentValues b=new ContentValues();b.put("slot",1);b.put("source",m.sourceId);db.insertOrThrow("source_binding",null,b);}}
        ContentValues done=new ContentValues();done.put("complete",1);require(db.update("local_snapshot_manifests",done,"snapshot_id=?",new String[]{snapshotId})==1,"UNKNOWN_SNAPSHOT");
        ContentValues copy=new ContentValues();copy.put("completed",1);copy.put("selected_at",System.currentTimeMillis());require(db.update("local_snapshot_copy_contract",copy,"snapshot_id=?",new String[]{snapshotId})==1,"COPY_CONTRACT_REQUIRED");
        ContentValues pointer=new ContentValues();pointer.put("snapshot_id",snapshotId);
        if(active==null){pointer.put("slot",1);db.insertOrThrow("local_snapshot_active",null,pointer);}else require(db.update("local_snapshot_active",pointer,"slot=1",null)==1,"ACTIVE_POINTER_MISSING");
    });return "selected";}
    /** Pin reads to an actually selected offline copy, not arbitrary complete legacy staging. */
    Manifest selectedCopyManifest(String requestedSnapshotId){
        SQLiteDatabase db=ledger.getReadableDatabase();db.beginTransaction();try{
            String id=requestedSnapshotId==null?activeId(db):requestedSnapshotId;if(id==null)return null;uuid(id);
            try(Cursor c=db.rawQuery("SELECT contract,completed FROM local_snapshot_copy_contract WHERE snapshot_id=?",new String[]{id})){
                boolean selected=c.moveToFirst()&&COPY_CONTRACT.equals(c.getString(0))&&c.getInt(1)==1;
                if(!selected){require(requestedSnapshotId==null,"COPY_NOT_SELECTED");return null;}
            }
            require(isComplete(db,id),"SNAPSHOT_INCOMPLETE");return required(db,id);
        }finally{db.endTransaction();}
    }
    long copySelectedAt(String snapshotId){uuid(snapshotId);try(Cursor c=ledger.getReadableDatabase().rawQuery("SELECT selected_at FROM local_snapshot_copy_contract WHERE snapshot_id=? AND completed=1",new String[]{snapshotId})){return c.moveToFirst()?c.getLong(0):0L;}}
    private static void validateAuthorization(Manifest m,CopyAuthorization a){require(a!=null && COPY_CONTRACT.equals(a.contract)&&m.sourceId.equals(a.sourceId)&&m.snapshotId.equals(a.snapshotId)&&m.digest.equals(a.digest),"COPY_AUTHORIZATION_MISMATCH");}
    private static void checkCopyContract(SQLiteDatabase db,Manifest m,CopyAuthorization a){
        try(Cursor c=db.rawQuery("SELECT contract,source,digest,grant_id,revoke_epoch,receiver_epoch FROM local_snapshot_copy_contract WHERE snapshot_id=?",new String[]{m.snapshotId})){
            require(c.moveToFirst(),"COPY_CONTRACT_REQUIRED");
            require(a.contract.equals(c.getString(0))&&a.sourceId.equals(c.getString(1))&&a.digest.equals(c.getString(2))&&a.grantId.equals(c.getString(3))&&a.revokeEpoch.equals(c.getString(4))&&a.receiverEpoch.equals(c.getString(5)),"COPY_AUTHORIZATION_MISMATCH");
        }
    }
    private static void createProgressSchema(SQLiteDatabase db){
        db.execSQL("CREATE TABLE local_snapshot_progress(snapshot_id TEXT PRIMARY KEY NOT NULL, received_rows INTEGER NOT NULL CHECK(received_rows>=0), received_bytes INTEGER NOT NULL CHECK(received_bytes>=0))");
    }
    /** v4 -> v5 additive migration: scan historical rows once, never overwrite any archive. */
    static void migrateProgress(SQLiteDatabase db){
        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM local_snapshot_rows r WHERE NOT EXISTS(SELECT 1 FROM local_snapshot_manifests m WHERE m.snapshot_id=r.snapshot_id)",null)){c.moveToFirst();require(c.getLong(0)==0,"SNAPSHOT_ORPHAN_ROWS");}
        createProgressSchema(db);
        db.execSQL("INSERT INTO local_snapshot_progress(snapshot_id,received_rows,received_bytes) SELECT m.snapshot_id,COUNT(r.bill_id),COALESCE(SUM(length(CAST(r.payload AS BLOB))),0) FROM local_snapshot_manifests m LEFT JOIN local_snapshot_rows r ON r.snapshot_id=m.snapshot_id GROUP BY m.snapshot_id");
    }
    private static long[] progress(SQLiteDatabase db,Manifest m){
        try(Cursor c=db.rawQuery("SELECT received_rows,received_bytes FROM local_snapshot_progress WHERE snapshot_id=?",new String[]{m.snapshotId})){
            require(c.moveToFirst(),"SNAPSHOT_PROGRESS_MISSING");long count=c.getLong(0),size=c.getLong(1);
            require(c.getType(0)==Cursor.FIELD_TYPE_INTEGER && c.getType(1)==Cursor.FIELD_TYPE_INTEGER && count>=0 && count<=m.totalRows && size>=0 && size<=m.totalBytes,"SNAPSHOT_PROGRESS_INVALID");
            return new long[]{count,size};
        }
    }
    void begin(Manifest m){transaction(db->beginInTransaction(db,m));}
    private static void beginInTransaction(SQLiteDatabase db,Manifest m){
        checkSource(db,m.sourceId);
        Manifest old=manifest(db,m.snapshotId);
        if(old!=null){require(same(old,m),"MANIFEST_CONFLICT");progress(db,old);return;}
        try(Cursor c=db.rawQuery("SELECT COUNT(*),COALESCE(SUM(total_bytes),0) FROM local_snapshot_manifests",null)){c.moveToFirst();require(c.getLong(0)<MAX_MANIFESTS && c.getLong(1)<=MAX_DECLARED_BYTES-m.totalBytes,"ARCHIVE_CAPACITY_REACHED");}
        ContentValues v=new ContentValues();v.put("snapshot_id",m.snapshotId);v.put("source",m.sourceId);v.put("sequence",m.sequence);v.put("captured_at",m.capturedAt);v.put("total_rows",m.totalRows);v.put("total_bytes",m.totalBytes);v.put("digest",m.digest);
        db.insertOrThrow("local_snapshot_manifests",null,v);
        ContentValues counters=new ContentValues();counters.put("snapshot_id",m.snapshotId);counters.put("received_rows",0);counters.put("received_bytes",0);db.insertOrThrow("local_snapshot_progress",null,counters);
    }
    void page(String snapshotId,List<Row> rows){uuid(snapshotId);require(rows!=null&&rows.size()<=MAX_ROWS,"PAGE_LIMIT");
        // Defensive copy: callers cannot mutate the list while validation/transaction runs.
        List<Row> copy=new ArrayList<>(rows);long size=0;Set<Long> ids=new HashSet<>();
        for(Row r:copy){require(r!=null&&ids.add(r.id),"PAGE_DUPLICATE_ID");size+=8L+bytes(Long.toString(r.id)).length+bytes(r.payload).length;require(size<=MAX_PAGE_BYTES,"PAGE_LIMIT");}
        transaction(db->{Manifest m=required(db,snapshotId);checkSource(db,m.sourceId);
            boolean sealed=isComplete(db,snapshotId);long[] counters=progress(db,m);
            for(Row r:copy){String previous=null;try(Cursor c=db.rawQuery("SELECT payload FROM local_snapshot_rows WHERE snapshot_id=? AND bill_id=?",new String[]{snapshotId,Long.toString(r.id)})){if(c.moveToFirst())previous=c.getString(0);}
                if(previous!=null){require(previous.equals(r.payload),"ROW_CONFLICT");continue;}
                require(!sealed,"SNAPSHOT_SEALED");
                counters[0]++;counters[1]+=bytes(r.payload).length;require(counters[0]<=m.totalRows && counters[1]<=m.totalBytes,"STAGING_EXCEEDS_MANIFEST");
                ContentValues v=new ContentValues();v.put("snapshot_id",snapshotId);v.put("bill_id",r.id);v.put("payload",r.payload);db.insertOrThrow("local_snapshot_rows",null,v);
            }
            ContentValues updated=new ContentValues();updated.put("received_rows",counters[0]);updated.put("received_bytes",counters[1]);require(db.update("local_snapshot_progress",updated,"snapshot_id=?",new String[]{snapshotId})==1,"SNAPSHOT_PROGRESS_MISSING");
        });
    }
    void complete(String snapshotId){uuid(snapshotId);transaction(db->{Manifest m=required(db,snapshotId);checkSource(db,m.sourceId);verify(db,m);ContentValues v=new ContentValues();v.put("complete",1);db.update("local_snapshot_manifests",v,"snapshot_id=?",new String[]{snapshotId});});}
    /** Local user-reviewed entry point, deliberately not exposed to bridge/provider. */
    void activateApproved(String snapshotId){activateApproved(snapshotId,null,false);}
    private void activateApproved(String snapshotId,String reviewedActive,boolean checkReview){uuid(snapshotId);transaction(db->{
        Manifest m=required(db,snapshotId);checkSource(db,m.sourceId);require(isComplete(db,snapshotId),"SNAPSHOT_INCOMPLETE");verify(db,m);
        String active=activeId(db);if(checkReview)require(Objects.equals(active,reviewedActive),"REVIEW_CHANGED");if(active!=null){Manifest prior=required(db,active);require(prior.sourceId.equals(m.sourceId),"SOURCE_CHANGED");require(m.sequence>=prior.sequence,"STALE_SNAPSHOT");require(m.sequence!=prior.sequence||m.digest.equals(prior.digest),"SEQUENCE_CONFLICT");}
        // Bind before first activation. Raw receive-v1 remains a separate archive, same generation.
        try(Cursor c=db.rawQuery("SELECT source FROM source_binding WHERE slot=1",null)){if(!c.moveToFirst()){ContentValues b=new ContentValues();b.put("slot",1);b.put("source",m.sourceId);db.insertOrThrow("source_binding",null,b);}}
        ContentValues v=new ContentValues();v.put("snapshot_id",snapshotId);
        if(active==null){v.put("slot",1);db.insertOrThrow("local_snapshot_active",null,v);}else db.update("local_snapshot_active",v,"slot=1",null);
    });}
    /** The integration must hold a current source-generation/authorization lease for the callback.
     * No stored flag, JS value or remote approval bit substitutes for the native confirmation. */
    interface AuthorizationVerifier { void withVerifiedAuthorization(Manifest manifest,Runnable activation); }
    void activateReviewed(String snapshotId,String reviewedActive,AuthorizationVerifier verifier){
        require(verifier!=null,"LIVE_AUTHORIZATION_UNAVAILABLE");
        Manifest m=required(ledger.getReadableDatabase(),snapshotId);
        final Thread caller=Thread.currentThread();final boolean[] invoked={false};final boolean[] open={true};
        try{verifier.withVerifiedAuthorization(m,()->{
            require(open[0] && Thread.currentThread()==caller && !invoked[0],"AUTHORIZATION_CALLBACK_INVALID");
            invoked[0]=true;activateApproved(snapshotId,reviewedActive,true);
        });require(invoked[0],"LIVE_AUTHORIZATION_UNAVAILABLE");}finally{open[0]=false;}
    }
    static final class Review {
        final Manifest manifest;final String activeId;final long absentRows;
        Review(Manifest m,String active,long absent){manifest=m;activeId=active;absentRows=absent;}
    }
    Review review(String snapshotId){uuid(snapshotId);SQLiteDatabase db=ledger.getReadableDatabase();db.beginTransaction();try{
        Manifest m=required(db,snapshotId);require(isComplete(db,snapshotId),"SNAPSHOT_INCOMPLETE");String active=activeId(db);
        long count=0;if(active!=null)try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM local_snapshot_rows old WHERE old.snapshot_id=? AND NOT EXISTS(SELECT 1 FROM local_snapshot_rows next WHERE next.snapshot_id=? AND next.bill_id=old.bill_id)",new String[]{active,snapshotId})){c.moveToFirst();count=c.getLong(0);}
        return new Review(m,active,count);
    }finally{db.endTransaction();}}
    List<Manifest> listComplete(int offset,int limit){require(offset>=0&&limit>=1&&limit<=50,"PAGE_LIMIT");List<Manifest> result=new ArrayList<>();
        try(Cursor c=ledger.getReadableDatabase().rawQuery("SELECT source,snapshot_id,sequence,captured_at,total_rows,total_bytes,digest FROM local_snapshot_manifests WHERE complete=1 ORDER BY captured_at DESC,snapshot_id LIMIT ? OFFSET ?",new String[]{Integer.toString(limit),Integer.toString(offset)})){
            while(c.moveToNext())result.add(new Manifest(c.getString(0),c.getString(1),c.getLong(2),c.getLong(3),c.getLong(4),c.getLong(5),c.getString(6)));
        }return result;
    }
    List<Row> pageRows(String snapshotId,long after,int limit){uuid(snapshotId);require(after>=0&&limit>=1&&limit<=100,"PAGE_LIMIT");return boundedRows(ledger.getReadableDatabase(),snapshotId,null,after,limit);}
    List<Row> activePage(long after,int limit){require(after>=0&&limit>=1&&limit<=100,"PAGE_LIMIT");SQLiteDatabase db=ledger.getReadableDatabase();db.beginTransaction();try{String active=activeId(db);return active==null?Collections.emptyList():boundedRows(db,active,null,after,limit);}finally{db.endTransaction();}}
    List<Row> absentPage(String snapshotId,String reviewedActive,long after,int limit){uuid(snapshotId);require(after>=0&&limit>=1&&limit<=100,"PAGE_LIMIT");if(reviewedActive==null)return Collections.emptyList();uuid(reviewedActive);return boundedRows(ledger.getReadableDatabase(),reviewedActive,snapshotId,after,limit);}
    private static List<Row> boundedRows(SQLiteDatabase db,String snapshotId,String exclude,long after,int limit){
        String sql="SELECT old.bill_id,old.payload FROM local_snapshot_rows old WHERE old.snapshot_id=? AND old.bill_id>?";
        List<String> args=new ArrayList<>(Arrays.asList(snapshotId,Long.toString(after)));
        if(exclude!=null){sql+=" AND NOT EXISTS(SELECT 1 FROM local_snapshot_rows next WHERE next.snapshot_id=? AND next.bill_id=old.bill_id)";args.add(exclude);}
        sql+=" ORDER BY old.bill_id LIMIT ?";args.add(Integer.toString(limit));List<Row> rows=new ArrayList<>();long size=0;
        try(Cursor c=db.rawQuery(sql,args.toArray(new String[0]))){while(c.moveToNext()){Row r=new Row(c.getLong(0),c.getString(1));long framed=8+bytes(Long.toString(r.id)).length+bytes(r.payload).length;if(size+framed>MAX_PAGE_BYTES)break;rows.add(r);size+=framed;}}return rows;
    }
    String activeSnapshotId(){return activeId(ledger.getReadableDatabase());}
    List<Row> activeRows(){SQLiteDatabase db=ledger.getReadableDatabase();db.beginTransaction();try{String id=activeId(db);return id==null?Collections.emptyList():readRows(db,id);}finally{db.endTransaction();}}
    private static void checkSource(SQLiteDatabase db,String source){
        try(Cursor c=db.rawQuery("SELECT source FROM source_binding WHERE slot=1 UNION SELECT source FROM local_snapshot_manifests",null)){while(c.moveToNext())require(source.equals(c.getString(0)),"SOURCE_CHANGED");}
    }
    /** Bounded memory: each row is validated and hashed directly from the ordered cursor. */
    private static void verify(SQLiteDatabase db,Manifest m){
        try {
            MessageDigest hash=MessageDigest.getInstance("SHA-256");long total=0, count=0, previous=0;
            long[] counters=progress(db,m);
            try(Cursor c=db.rawQuery("SELECT bill_id,payload FROM local_snapshot_rows WHERE snapshot_id=? ORDER BY bill_id",new String[]{m.snapshotId})){
                while(c.moveToNext()){
                    require(++count<=m.totalRows && count<=MAX_ROWS,"SNAPSHOT_ROW_LIMIT");
                    Row row=new Row(c.getLong(0),c.getString(1));require(row.id>previous,"SNAPSHOT_ID_ORDER");previous=row.id;
                    byte[] payload=bytes(row.payload);total+=payload.length;require(total<=m.totalBytes && total<=MAX_BYTES,"SNAPSHOT_BYTE_LIMIT");
                    frame(hash,bytes(Long.toString(row.id)));frame(hash,payload);
                }
            }
            require(count==counters[0] && total==counters[1] && count==m.totalRows && total==m.totalBytes && hex(hash.digest()).equals(m.digest),"SNAPSHOT_VERIFICATION_FAILED");
        }catch(java.security.NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }
    private static void frame(MessageDigest hash,byte[] value){hash.update(ByteBuffer.allocate(4).putInt(value.length).array());hash.update(value);}
    private static String hex(byte[] hash){StringBuilder s=new StringBuilder();for(byte b:hash)s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
    static String digest(List<Row> input){try{MessageDigest md=MessageDigest.getInstance("SHA-256");List<Row> rows=new ArrayList<>(input);rows.sort(Comparator.comparingLong(r->r.id));long previous=0;for(Row r:rows){require(r.id>previous,"DUPLICATE_ID");previous=r.id;for(byte[] value:new byte[][]{bytes(Long.toString(r.id)),bytes(r.payload)}){md.update(ByteBuffer.allocate(4).putInt(value.length).array());md.update(value);}}StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}catch(java.security.NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
    private static List<Row> readRows(SQLiteDatabase db,String id){List<Row> rows=new ArrayList<>();try(Cursor c=db.rawQuery("SELECT bill_id,payload FROM local_snapshot_rows WHERE snapshot_id=? ORDER BY bill_id",new String[]{id})){while(c.moveToNext()){require(rows.size()<MAX_ROWS,"ROW_LIMIT");rows.add(new Row(c.getLong(0),c.getString(1)));}}return rows;}
    private static boolean isComplete(SQLiteDatabase db,String id){try(Cursor c=db.rawQuery("SELECT complete FROM local_snapshot_manifests WHERE snapshot_id=?",new String[]{id})){return c.moveToFirst()&&c.getInt(0)==1;}}
    private static String activeId(SQLiteDatabase db){try(Cursor c=db.rawQuery("SELECT snapshot_id FROM local_snapshot_active WHERE slot=1",null)){return c.moveToFirst()?c.getString(0):null;}}
    private static Manifest required(SQLiteDatabase db,String id){Manifest m=manifest(db,id);require(m!=null,"UNKNOWN_SNAPSHOT");return m;}
    private static Manifest manifest(SQLiteDatabase db,String id){try(Cursor c=db.rawQuery("SELECT source,snapshot_id,sequence,captured_at,total_rows,total_bytes,digest FROM local_snapshot_manifests WHERE snapshot_id=?",new String[]{id})){return c.moveToFirst()?new Manifest(c.getString(0),c.getString(1),c.getLong(2),c.getLong(3),c.getLong(4),c.getLong(5),c.getString(6)):null;}}
    private static boolean same(Manifest a,Manifest b){return a.sourceId.equals(b.sourceId)&&a.snapshotId.equals(b.snapshotId)&&a.sequence==b.sequence&&a.capturedAt==b.capturedAt&&a.totalRows==b.totalRows&&a.totalBytes==b.totalBytes&&a.digest.equals(b.digest);}
    private interface Write {void run(SQLiteDatabase db);}
    private void transaction(Write write){SQLiteDatabase db=ledger.getWritableDatabase();db.beginTransaction();try{write.run(db);db.setTransactionSuccessful();}finally{db.endTransaction();}}
    private static byte[] bytes(String s){return s.getBytes(StandardCharsets.UTF_8);}
    private static void uuid(String s){require(s!=null&&s.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")&&UUID.fromString(s).toString().equals(s),"UUID_FORMAT");}
    private static void require(boolean ok,String code){if(!ok)throw new IllegalStateException(code);}
}
