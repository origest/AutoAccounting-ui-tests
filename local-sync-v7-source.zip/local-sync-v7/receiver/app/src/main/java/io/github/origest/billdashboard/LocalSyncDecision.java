package io.github.origest.billdashboard;

/** Pure ordering rule shared by SQLite writes and host regression tests. */
final class LocalSyncDecision {
    static String compare(long incoming, long previous, String payload, String stored) {
        if (incoming < previous) return "stale";
        if (incoming > previous) return "updated";
        return payload.equals(stored) ? "unchanged" : "conflict";
    }
}
