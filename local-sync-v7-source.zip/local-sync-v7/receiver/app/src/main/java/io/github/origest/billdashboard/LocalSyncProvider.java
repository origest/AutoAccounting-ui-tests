package io.github.origest.billdashboard;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;

/** Write-only Binder IPC; no HTTP listener, no implicit broadcasts, no read API. */
public final class LocalSyncProvider extends ContentProvider {
    private LocalLedger ledger;
    @Override public boolean onCreate(){ ledger=new LocalLedger(getContext()); return true; }
    @Override public Bundle call(String method,String arg,Bundle extras) {
        Bundle result=new Bundle();
        if(!LocalTrust.permitted(getContext(),Binder.getCallingUid())) throw new SecurityException("Receiver not paired with caller");
        if(method!=null&&method.startsWith("snapshot-"))return LocalSnapshotIngress.receive(getContext(),ledger,Binder.getCallingUid(),method,extras,g->LocalSnapshotIngress.liveVerify(getContext(),g));
        if(!"receive-v1".equals(method) || extras==null || extras.getInt("protocol",0)!=1) {result.putString("status","invalid");return result;}
        try {
            LocalBill bill=new LocalBill(extras.getString("source_id"),extras.getString("bill_json"));
            result.putString("status",ledger.receive(bill)); result.putString("id",bill.id);result.putString("source_id",bill.source);result.putInt("protocol",1);result.putLong("revision",bill.revision);
        } catch(org.json.JSONException | IllegalArgumentException e) {result.putString("status","invalid");}
        catch(android.database.SQLException e) {result.putString("status","storage_error");}
        return result;
    }
    @Override public Cursor query(Uri u,String[] p,String s,String[] a,String o){throw new SecurityException("Read forbidden");}
    @Override public String getType(Uri u){return null;}
    @Override public Uri insert(Uri u,ContentValues v){throw new SecurityException("Use bounded call");}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new SecurityException("Update forbidden");}
    @Override public int delete(Uri u,String s,String[] a){throw new SecurityException("Delete forbidden");}
}
