package io.github.origest.billdashboard;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import java.security.MessageDigest;
import java.util.Arrays;

final class LocalTrust {
    static final Object LOCK=new Object();
    static String epoch(Context c){synchronized(LOCK){
        android.content.SharedPreferences p=c.getSharedPreferences("local-receiver",Context.MODE_PRIVATE);
        if(p.getString("certificate","").isEmpty())return "";
        String value=p.getString("epoch","");if(value.isEmpty()){value=java.util.UUID.randomUUID().toString();if(!p.edit().putString("epoch",value).commit())throw new IllegalStateException("AUTH_PERSIST_FAILED");}return value;
    }}
    static boolean pair(Context c,String cert){synchronized(LOCK){if(cert==null || !cert.matches("[0-9a-f]{64}"))return false;return c.getSharedPreferences("local-receiver",Context.MODE_PRIVATE).edit().putString("certificate",cert).putString("epoch",java.util.UUID.randomUUID().toString()).commit();}}
    static boolean revoke(Context c){synchronized(LOCK){return c.getSharedPreferences("local-receiver",Context.MODE_PRIVATE).edit().remove("certificate").putString("epoch",java.util.UUID.randomUUID().toString()).commit();}}

    static final String SENDER="net.ankio.auto";
    static String certificate(Context context) throws Exception {
        android.content.pm.PackageInfo info=context.getPackageManager().getPackageInfo(SENDER,PackageManager.GET_SIGNING_CERTIFICATES);
        Signature[] signatures=info.signingInfo.getApkContentsSigners();
        if(signatures==null || signatures.length!=1)throw new SecurityException("SINGLE_SIGNER_REQUIRED");
        String[] hashes=new String[signatures.length];
        for(int i=0;i<signatures.length;i++) {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(signatures[i].toByteArray());
            StringBuilder out=new StringBuilder(); for(byte b:digest) out.append(String.format(java.util.Locale.ROOT,"%02x",b & 255)); hashes[i]=out.toString();
        }
        Arrays.sort(hashes); return String.join(":",hashes);
    }
    static boolean permitted(Context context,int uid) {
        try {
            String[] packages=context.getPackageManager().getPackagesForUid(uid);
            if(packages==null || packages.length!=1 || !SENDER.equals(packages[0])) return false;
            String pin=context.getSharedPreferences("local-receiver",Context.MODE_PRIVATE).getString("certificate","");
            return pin.matches("[0-9a-f]{64}") && pin.equals(certificate(context));
        } catch(Exception ignored) { return false; }
    }
}
