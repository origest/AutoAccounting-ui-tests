package io.github.origest.billdashboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.net.URISyntaxException;

/** A same-origin HTTPS client. Financial records and credentials stay with your server. */
public class MainActivity extends Activity {
    private static final int PICK_FILE = 14;
    private WebView web;
    private LinearLayout root;
    private ProgressBar progress;
    private TextView error;
    private String origin;
    private ValueCallback<Uri[]> fileCallback;
    private SharedPreferences preferences;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("connection", MODE_PRIVATE);
        origin = preferences.getString("origin", "");
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 244));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
        if (origin.isEmpty()) showConnection(); else showDashboard();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private TextView text(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextSize(size); view.setTextColor(color);
        return view;
    }
    private void showConnection() {
        if (web != null) { web.destroy(); web = null; }
        root.removeAllViews();
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(dp(28), dp(24), dp(28), dp(24));
        root.addView(content, new LinearLayout.LayoutParams(-1, -1));
        content.addView(text("账迹", 36, Color.rgb(22, 60, 53)));
        TextView description = text("连接你的账单空间\n填写已部署的 HTTPS 服务地址，即可登录查看收支。", 15, Color.rgb(108, 125, 113));
        description.setPadding(0, dp(20), 0, dp(24)); content.addView(description);
        EditText address = new EditText(this);
        address.setSingleLine(true); address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setHint("https://bill.example.com"); address.setText(origin);
        address.setContentDescription("服务地址");
        content.addView(address, new LinearLayout.LayoutParams(-1, dp(60)));
        Button connect = new Button(this); connect.setText("连接服务"); content.addView(connect);
        connect.setOnClickListener(view -> {
            String value = address.getText().toString().trim();
            try {
                URI uri = new URI(value);
                if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getRawUserInfo() != null
                        || uri.getRawQuery() != null || uri.getRawFragment() != null
                        || !(uri.getPath().isEmpty() || uri.getPath().equals("/"))) {
                    throw new URISyntaxException(value, "Invalid server origin");
                }
                origin = "https://" + uri.getRawAuthority();
                preferences.edit().putString("origin", origin).apply();
                showDashboard();
            } catch (URISyntaxException e) { address.setError("请输入完整的 HTTPS 域名，可包含端口，不要填写接口路径"); }
        });
        TextView hint = text("服务地址由你部署的云端服务提供。账单保存在服务器中，应用需要联网使用。", 12, Color.rgb(125, 143, 126));
        hint.setPadding(0, dp(20), 0, 0); content.addView(hint);
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void showDashboard() {
        root.removeAllViews();
        LinearLayout toolbar = new LinearLayout(this); toolbar.setGravity(Gravity.CENTER_VERTICAL); toolbar.setPadding(dp(16), 0, dp(8), 0);
        TextView title = text("账迹", 18, Color.rgb(22, 60, 53)); toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1)); title.setGravity(Gravity.CENTER_VERTICAL);
        Button refresh = new Button(this); refresh.setText("刷新"); toolbar.addView(refresh);
        Button settings = new Button(this); settings.setText("连接设置"); toolbar.addView(settings);
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(52)));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        error = text("", 13, Color.rgb(163, 81, 60)); error.setPadding(dp(16), dp(12), dp(16), dp(12)); error.setVisibility(View.GONE); root.addView(error);
        web = new WebView(this); root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        WebSettings config = web.getSettings();
        config.setJavaScriptEnabled(true); config.setDomStorageEnabled(true);
        // Content URIs come from the system picker after explicit user selection.
        config.setAllowFileAccess(false); config.setAllowContentAccess(true);
        config.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        config.setJavaScriptCanOpenWindowsAutomatically(false); config.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (sameOrigin(request.getUrl())) return false;
                if (request.isForMainFrame() && request.hasGesture() && "https".equalsIgnoreCase(request.getUrl().getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); } catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError failure) {
                if (request.isForMainFrame()) { error.setText("暂时无法连接服务器，请检查网络与服务地址后刷新。"); error.setVisibility(View.VISIBLE); }
            }
            @Override public void onPageFinished(WebView view, String url) { CookieManager.getInstance().flush(); }
            // Platform default cancels invalid TLS certificates; never override it to proceed.
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setProgress(value); progress.setVisibility(value < 100 ? View.VISIBLE : View.GONE); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent choose = new Intent(Intent.ACTION_OPEN_DOCUMENT); choose.addCategory(Intent.CATEGORY_OPENABLE); choose.setType("*/*");
                choose.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "text/comma-separated-values", "text/plain", "application/octet-stream", "application/vnd.ms-excel"});
                try { startActivityForResult(choose, PICK_FILE); } catch (ActivityNotFoundException e) { fileCallback.onReceiveValue(null); fileCallback = null; Toast.makeText(MainActivity.this, "没有可用的文件选择器", Toast.LENGTH_SHORT).show(); }
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("确认", (d, w) -> result.confirm()).setNegativeButton("取消", (d, w) -> result.cancel()).setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
        });
        web.setDownloadListener((url, agent, disposition, mime, size) -> {
            Uri uri = Uri.parse(url);
            if (!sameOrigin(uri)) { Toast.makeText(this, "仅允许从当前服务下载文件", Toast.LENGTH_SHORT).show(); return; }
            try {
                DownloadManager.Request request = new DownloadManager.Request(uri);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) request.addRequestHeader("Cookie", cookies);
                request.setMimeType("text/csv"); request.setTitle("账迹账单导出");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "bill-dashboard-" + System.currentTimeMillis() + ".csv");
                getSystemService(DownloadManager.class).enqueue(request);
                Toast.makeText(this, "已开始下载，请查看下载目录", Toast.LENGTH_LONG).show();
            } catch (RuntimeException e) { Toast.makeText(this, "无法下载文件，请稍后重试", Toast.LENGTH_LONG).show(); }
        });
        refresh.setOnClickListener(v -> { error.setVisibility(View.GONE); web.reload(); });
        settings.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("切换服务地址")
                .setMessage("将清除当前应用内的登录状态，服务器账单会保留。")
                .setNegativeButton("取消", null).setPositiveButton("继续", (d, w) -> {
                    web.stopLoading(); web.clearCache(true);
                    CookieManager.getInstance().removeAllCookies(done -> { CookieManager.getInstance().flush(); WebStorage.getInstance().deleteAllData(); showConnection(); });
                }).show());
        web.loadUrl(origin + "/");
    }
    private boolean sameOrigin(Uri uri) {
        Uri base = Uri.parse(origin);
        return "https".equalsIgnoreCase(uri.getScheme()) && base.getHost() != null && base.getHost().equalsIgnoreCase(uri.getHost())
                && (base.getPort() == -1 ? 443 : base.getPort()) == (uri.getPort() == -1 ? 443 : uri.getPort());
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(result == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); }
    @Override protected void onDestroy() { if (fileCallback != null) fileCallback.onReceiveValue(null); if (web != null) web.destroy(); super.onDestroy(); }
}

