package io.github.origest.billdashboard;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

public final class ModeActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(40,80,40,40);setContentView(root);
        TextView title=new TextView(this);title.setText("账迹");title.setTextSize(32);root.addView(title);
        TextView hint=new TextView(this);hint.setText("本机账本与在线服务相互独立，不会自动迁移或上传数据。");root.addView(hint);
        Button local=new Button(this);local.setText("本机账本 · 无需服务器");root.addView(local);local.setOnClickListener(v->startActivity(new Intent(this,LocalDashboardActivity.class)));
        Button online=new Button(this);online.setText("在线服务 · 原有模式");root.addView(online);online.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));
    }
}
