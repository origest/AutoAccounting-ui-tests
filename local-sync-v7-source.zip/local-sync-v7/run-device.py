#!/usr/bin/env python3
"""One disposable hosted AVD only. Prepared code; not device-validated. No artifact upload."""
import hashlib,json,os,re,secrets,subprocess,time,uuid,queue,threading
from pathlib import Path

SOURCE='net.ankio.auto'; RECEIVER='io.github.origest.billdashboard'
SCOMP=SOURCE+'.test/net.ankio.auto.qa.SourceQaRunner'
RCOMP=RECEIVER+'.test/io.github.origest.billdashboard.ReceiverQaRunner'
def result_fields(output,expected_case=None,expected_run=None):
    fields={}
    for line in output.splitlines():
        if line.startswith('INSTRUMENTATION_RESULT: '):
            pair=line[len('INSTRUMENTATION_RESULT: '):].split('=',1)
            if len(pair)==2:
                if pair[0] in fields: raise ValueError('duplicate instrumentation field')
                fields[pair[0]]=pair[1]
    if any(x in output for x in ['INSTRUMENTATION_FAILED','INSTRUMENTATION_ABORTED','shortMsg=']):
        raise ValueError('instrumentation aborted')
    if not any(k in fields for k in ['qa_status','qa_result']) or any(fields[k]!='PASS' for k in ['qa_status','qa_result'] if k in fields) or re.findall(r'^INSTRUMENTATION_CODE: (-?[0-9]+)[ \t]*$',output,re.M)!=['-1']:
        raise ValueError('instrumentation did not explicitly pass')
    if expected_case is not None and fields.get('case')!=expected_case: raise ValueError('wrong case')
    if expected_run is not None and fields.get('qa_run')!=expected_run: raise ValueError('wrong QA run')
    return fields

def main():
    root=Path(os.environ['QA_ROOT']).resolve();work=Path(os.environ['QA_WORK']).resolve()
    assert os.environ.get('GITHUB_ACTIONS')=='true' and os.environ.get('RUNNER_ENVIRONMENT')=='github-hosted'
    assert os.environ.get('GITHUB_REPOSITORY')=='origest/AutoAccounting-ui-tests'
    assert os.environ.get('GITHUB_EVENT_NAME')=='workflow_dispatch'
    assert re.fullmatch('[0-9a-f]{40}',os.environ.get('QA_APPROVED_SHA',''))
    assert os.environ['QA_APPROVED_SHA']==os.environ.get('GITHUB_SHA')
    assert work.is_relative_to(Path(os.environ['RUNNER_TEMP']).resolve()) and work!=root
    sdk=Path(os.environ['ANDROID_HOME']);adb=str(sdk/'platform-tools/adb');emu=str(sdk/'emulator/emulator')
    apksigner=str(sdk/'build-tools/35.0.0/apksigner');gradle=os.environ['GRADLE_BIN']
    run=str(uuid.uuid4());serial='emulator-5580';results=[];process=None;completed=False;phase='preflight/build'
    def command(argv,timeout=600,env=None):
        p=subprocess.run([str(x) for x in argv],capture_output=True,text=True,timeout=timeout,env=env)
        if p.returncode:
            detail='\n'.join((p.stdout+'\n'+p.stderr).splitlines()[-16:])[-2400:]
            for k,v in (env or os.environ).items():
                if re.search('KEY|PASS|TOKEN|SECRET',k,re.I) and len(v)>8:detail=detail.replace(v,'[REDACTED]')
            print('Bounded synthetic command failure: '+detail,flush=True)
            raise RuntimeError('command failed: '+Path(str(argv[0])).name+'; code='+str(p.returncode))
        return p.stdout
    def device(*args,timeout=240):
        assert process is not None and process.poll() is None,'owned emulator not alive'
        return command([adb,'-s',serial,*args],timeout)
    def instrument(app,case,**args):
        nonlocal phase
        phase=app+':'+case
        # No adb exit-code-only pass; target runner must affirm its fixture ownership gate.
        params={'allowBlankEmulator':'YES','qa_run':run,'case':case,**args}
        cmd=['shell','am','instrument','-w','-r']
        for k,v in params.items():cmd+=['-e',k,str(v)]
        start=time.monotonic();out=device(*cmd,SCOMP if app=='source' else RCOMP,timeout=600)
        (work/(app+'-'+case+'-'+str(len(results))+'.log')).write_text(out)
        try:fields=result_fields(out,case,run)
        except ValueError:
            safe=re.findall(r'^INSTRUMENTATION_RESULT: (?:qa_status|qa_result|case|error_class|failure)=[^\n]{0,240}$',out,re.M)
            print('Synthetic case failure: '+'; '.join(safe),flush=True)
            raise
        results.append({'app':app,'case':case,'status':'PASS','elapsed_seconds':round(time.monotonic()-start,2)})
        print(json.dumps(results[-1]),flush=True);return fields
    def kill_at_checkpoint(case,expected,**args):
        nonlocal phase
        phase='checkpoint:'+expected
        params={'allowBlankEmulator':'YES','qa_run':run,'case':case,'hold_ms':'30000',**args}
        argv=[adb,'-s',serial,'shell','am','instrument','-w','-r']
        for k,v in params.items():argv+=['-e',k,str(v)]
        argv+=[SCOMP]
        child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        lines=queue.Queue();output=[];fields={};checkpoint=None
        def reader():
            for line in child.stdout:lines.put(line)
            lines.put(None)
        threading.Thread(target=reader,daemon=True).start()
        deadline=time.monotonic()+120
        try:
            while time.monotonic()<deadline:
                line=lines.get(timeout=max(0.1,deadline-time.monotonic()))
                if line is None:break
                output.append(line)
                if line.startswith('INSTRUMENTATION_STATUS: '):
                    pair=line[len('INSTRUMENTATION_STATUS: '):].strip().split('=',1)
                    if len(pair)==2:fields[pair[0]]=pair[1]
                if line.startswith('INSTRUMENTATION_STATUS_CODE:'):
                    if fields.get('qa_result')=='CHECKPOINT' and fields.get('qa_checkpoint')==expected:
                        checkpoint=dict(fields);break
                    fields={}
            assert checkpoint is not None,'no exact durable checkpoint observed'
            assert checkpoint.get('qa_run')==run,'checkpoint from wrong fixture'
            pid=device('shell','pidof',SOURCE).strip()
            assert re.fullmatch('[1-9][0-9]*',pid) and pid==checkpoint.get('source_pid'),'unexpected process'
            device('shell','run-as',SOURCE,'kill','-9',pid)
            child.wait(timeout=30)
            results.append({'app':'source','case':case,'checkpoint':expected,'status':'CHECKPOINT_KILLED_PENDING_RECOVERY'})
            print(json.dumps(results[-1]),flush=True)
            return checkpoint
        finally:
            if child.poll() is None:child.terminate();child.wait(timeout=10)
            while not lines.empty():
                value=lines.get_nowait()
                if value is not None:output.append(value)
            (work/('checkpoint-'+expected+'.log')).write_text(''.join(output))

    def certificate(apk):
        out=command([apksigner,'verify','--print-certs',apk]);values=re.findall(r'^Signer #[0-9]+ certificate SHA-256 digest: ([0-9a-f]{64})$',out,re.M)
        assert len(values)==1;return values[0]
    def install(apk):device('install','--no-streaming',str(apk))
    def resign(apk,key,out):
        env=os.environ.copy();env['QA_EPHEMERAL_KEYPASS']=secrets.token_hex(24)
        command(['keytool','-genkeypair','-keystore',key,'-storepass:env','QA_EPHEMERAL_KEYPASS','-keypass:env','QA_EPHEMERAL_KEYPASS','-alias','qa','-keyalg','RSA','-keysize','2048','-validity','2','-dname','CN=Disposable Synthetic QA'],env=env)
        # Re-sign both app and target instrumentation with one ephemeral alternative identity.
        outputs=[]
        for src,dst in zip(apk,out):
            command([apksigner,'sign','--ks',key,'--ks-key-alias','qa','--ks-pass','env:QA_EPHEMERAL_KEYPASS','--key-pass','env:QA_EPHEMERAL_KEYPASS','--out',dst,src],env=env)
            outputs.append(certificate(dst))
        assert len(set(outputs))==1
        return outputs[0]
    try:
        manifest=json.loads((root/'bundle-manifest.json').read_text())
        for path,digest in manifest.items():
            p=(root/path).resolve();assert p.is_relative_to(root) and p.is_file()
            assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,'reviewed input drift'
        command(['python3',root/'source/verify_sources.py','--copies-only'])
        for path,digest in json.loads((root/'receiver/production-copy-sha256.json').read_text()).items():
            assert hashlib.sha256((root/'receiver/app/src/main'/path).read_bytes()).hexdigest()==digest
        command([gradle,'-Duser.home='+str(work/'home'),'--no-daemon','--no-parallel','--max-workers=2','-p',root/'receiver',':app:assembleDebug',':app:assembleDebugAndroidTest'],timeout=1200)
        receiver=root/'receiver/app/build/outputs/apk/debug/app-debug.apk';rtest=root/'receiver/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'
        pin=certificate(receiver);assert certificate(rtest)==pin
        command([gradle,'-Duser.home='+str(work/'home'),'--no-daemon','--no-parallel','--max-workers=2','-PlocalDashboardReceiverCertSha256='+pin,'-p',root/'source',':app:assembleDebug',':app:assembleDebugAndroidTest'],timeout=1200)
        source=root/'source/app/build/outputs/apk/debug/app-debug.apk';stest=root/'source/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'
        assert certificate(source)==certificate(stest)
        assert not [x for x in command([adb,'devices']).splitlines()[1:] if x.strip()],'do not touch an existing device'
        avd='local_sync_v7_'+run.replace('-','');avdpath=work/'userdata'
        p=subprocess.run([os.environ['AVDMANAGER'],'create','avd','--name',avd,'--package','system-images;android-35;google_apis;x86_64','--path',str(avdpath)],input='no\n',text=True,capture_output=True,timeout=120)
        assert p.returncode==0
        command([emu,'-accel-check'])
        emulog=open(work/'emulator.log','w')
        process=subprocess.Popen([emu,'-avd',avd,'-port','5580','-no-window','-no-audio','-no-boot-anim','-no-snapshot','-gpu','swiftshader_indirect','-memory','3072','-accel','on'],stdout=emulog,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+360
        while time.monotonic()<deadline:
            if process.poll() is not None: raise RuntimeError('emulator exited before boot')
            try:
                if device('shell','getprop','sys.boot_completed',timeout=10).strip()=='1':break
            except (RuntimeError,subprocess.TimeoutExpired):pass
            time.sleep(2)
        else:raise RuntimeError('emulator boot timeout')
        assert device('shell','getprop','ro.kernel.qemu').strip()=='1'
        assert int(device('shell','getprop','ro.build.version.sdk').strip())==35
        assert not device('shell','pm','list','packages',SOURCE).strip()
        assert not device('shell','pm','list','packages',RECEIVER).strip()
        for apk in [receiver,rtest,source,stest]:install(apk)
        instrument('receiver','core',allow_synthetic_reset='true')
        instrument('receiver','interrupt-prepare')
        device('shell','am','force-stop',RECEIVER)
        instrument('receiver','interrupt-resume') # Explicit relaunch; not a transaction-crash proof.
        instrument('receiver','pair',allow_pair='true',allow_synthetic_reset='true')
        instrument('source','seed')
        sent=instrument('source','manual',allow_authorize='true')
        instrument('receiver','received',snapshot_id=sent['snapshot_id'],source_id=sent['source_id'],expected_expense='0.3')
        instrument('source','auto-arm',allow_authorize='true')
        instrument('source','auto-await')
        instrument('receiver','received',source_id=sent['source_id'],expected_expense='0.3')
        changed=instrument('source','mutate')
        instrument('source','auto-await',min_sequence=changed['source_sequence'])
        instrument('receiver','received',source_id=sent['source_id'],expected_expense='0.6')
        instrument('source','unchanged-wake') # Observes no new manifest; does not prove every wake executed.
        instrument('source','auto-revoke')
        instrument('source','prepare-pending',stop_at='bound',allow_authorize='true')
        instrument('source','send-first-page')
        instrument('receiver','evidence')
        instrument('source','revoke-pending-denied')
        instrument('receiver','assert-unchanged')
        for stage in ['reserved','frozen']:
            ck=kill_at_checkpoint('prepare-pending',stage,stop_at=stage,allow_authorize='true')
            resumed=instrument('source','resume-pending')
            instrument('receiver','received',snapshot_id=ck['pending_snapshot'],source_id=sent['source_id'],expected_expense='0.6')
            instrument('source','auto-revoke')
        ck=kill_at_checkpoint('prepare-pending','bound',stop_at='bound',allow_authorize='true')
        page=kill_at_checkpoint('send-first-page','after_first_page')
        assert page['pending_snapshot']==ck['pending_snapshot']
        ack=kill_at_checkpoint('complete-without-local-ack','remote_complete_before_local_cursor')
        assert ack['pending_snapshot']==ck['pending_snapshot']
        instrument('source','resume-pending')
        instrument('receiver','received',snapshot_id=ck['pending_snapshot'],source_id=sent['source_id'],expected_expense='0.6')
        kill_at_checkpoint('auto-revoke','revoked')
        instrument('source','revoked-evidence')
        instrument('receiver','evidence')
        instrument('source','capacity-fill',allow_capacity='true')
        instrument('source','auto-arm',allow_authorize='true')
        instrument('source','auto-await-paused',expected_pause='capacity_or_record_limit')
        instrument('source','auto-revoke')
        instrument('receiver','assert-unchanged')
        instrument('receiver','evidence')
        instrument('source','evidence')
        alt=work/'source-wrong.apk';altt=work/'source-wrong-test.apk'
        assert resign([source,stest],work/'source-wrong.jks',[alt,altt])!=certificate(source)
        device('uninstall',SOURCE+'.test');device('uninstall',SOURCE)
        install(alt);install(altt)
        instrument('source','seed')
        instrument('source','expect-receiver-denial',allow_authorize='true')
        instrument('receiver','assert-unchanged',require_wrong_signer='true')
        device('uninstall',SOURCE+'.test');device('uninstall',SOURCE)
        install(source);install(stest);instrument('source','seed')
        instrument('receiver','capacity-bytes',allow_synthetic_reset='true')
        instrument('receiver','capacity-manifests',allow_synthetic_reset='true')
        alt=work/'receiver-wrong.apk';altt=work/'receiver-wrong-test.apk'
        assert resign([receiver,rtest],work/'receiver-wrong.jks',[alt,altt])!=pin
        instrument('receiver','evidence')
        instrument('source','prepare-manual-grant',allow_authorize='true')
        device('uninstall',RECEIVER+'.test');device('uninstall',RECEIVER)
        install(alt);install(altt)
        instrument('receiver','core',allow_synthetic_reset='true')
        instrument('receiver','evidence')
        instrument('source','expect-receiver-identity-denial',allow_authorize='true')
        instrument('receiver','assert-unchanged')
        completed=True
    finally:
        # Only terminate our own emulator subprocess; never adb kill-server or global device actions.
        if process is not None and process.poll() is None:
            process.terminate()
            try:process.wait(timeout=20)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
        report={'overall_status':'PASS' if completed else 'FAIL','failed_at':None if completed else phase,'cases':results,'consent_ui':'NOT_RUN','offline_network_test':'NOT_RUN','release_ready':False,'full_source_app_tests':'NOT_RUN','mid_transaction_process_kill':'NOT_PROVEN','physical_device_performance':'NOT_RUN'}
        (work/'result.json').write_text(json.dumps(report,indent=2))
        if os.environ.get('GITHUB_STEP_SUMMARY'):
            with open(os.environ['GITHUB_STEP_SUMMARY'],'a') as f:f.write('Synthetic script status: '+('PASS' if completed else 'FAIL')+'; passing assertions: '+str(sum(x['status']=='PASS' for x in results))+'. Full app/device performance NOT validated. Durable-checkpoint kills are not mid-transaction proof.\n')
if __name__=='__main__':main()
