#!/usr/bin/env bash
# Prepared only. The workflow remains disabled; explicit publication/execution approval required.
set -euo pipefail
: "${QA_APPROVED_SHA:?Concrete reviewed SHA required}"
: "${QA_ACCEPT_SDK_LICENSES:?Set YES only with explicit Android SDK license acceptance}"
test "$QA_ACCEPT_SDK_LICENSES" = YES
test "${GITHUB_ACTIONS:-}" = true
test "${RUNNER_ENVIRONMENT:-}" = github-hosted
test "${GITHUB_REPOSITORY:-}" = origest/AutoAccounting-ui-tests
test "${GITHUB_EVENT_NAME:-}" = workflow_dispatch
[[ "$QA_APPROVED_SHA" =~ ^[0-9a-f]{40}$ ]]
test "$QA_APPROVED_SHA" = "${GITHUB_SHA:-}"
test -c /dev/kvm && test -r /dev/kvm && test -w /dev/kvm
HERE=$(cd "$(dirname "$0")" && pwd)
export QA_ROOT="$HERE" QA_WORK="$(mktemp -d "${RUNNER_TEMP:?}/local-sync-v7.XXXXXX")"
# Never use account credentials, user AVDs, shared signing material or caches.
export HOME="$QA_WORK/home"
mkdir -p "$HOME"
export GRADLE_USER_HOME="$QA_WORK/gradle-home" ANDROID_USER_HOME="$QA_WORK/android-user" ANDROID_AVD_HOME="$QA_WORK/avds"
export JAVA_HOME="${JAVA_HOME_21_X64:?Official hosted JDK21 required}"
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME="${ANDROID_HOME:?Official hosted Android SDK required}" ANDROID_SDK_ROOT="$ANDROID_HOME"
export SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
export AVDMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/avdmanager"
test -x "$SDKMANAGER" && test -x "$AVDMANAGER"
python3 - <<'PY'
import os,subprocess
with open(os.path.join(os.environ['QA_WORK'],'sdk-license.log'),'w') as log:
 subprocess.run([os.environ['SDKMANAGER'],'--licenses'],input='y\n'*100,text=True,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
PY
"$SDKMANAGER" 'platforms;android-36' 'build-tools;35.0.0' 'platform-tools' 'emulator' 'system-images;android-35;google_apis;x86_64' > "$QA_WORK/sdk-install.log" 2>&1
curl --fail --location --proto '=https' --tlsv1.2 https://services.gradle.org/distributions/gradle-8.11.1-bin.zip -o "$QA_WORK/gradle.zip"
printf '%s  %s\n' f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6 "$QA_WORK/gradle.zip" | sha256sum --check --strict
unzip -q "$QA_WORK/gradle.zip" -d "$QA_WORK"
export GRADLE_BIN="$QA_WORK/gradle-8.11.1/bin/gradle"
python3 "$HERE/run-device.py"
# Logs, APKs, AVD and temporary signing keys remain only on this disposable VM.
# No artifact/cache/release upload and no automatic second run.
