# Synthetic V7 source harness, not AutoAccounting release

This project uses18 unchanged allowlisted production files plus explicit QA-only Room wiring, generation lifecycle, settings, API delegation, application bootstrap and instrumentation. `production-inputs.json` hashes and `verify_sources.py` distinguish unchanged inputs from adapters. No original full App/manifest/settings/database/credentials are copied. Upstream license and source headers retained. Do not install on a user's device or distribute as an app update.

The local-only coordinator helper `build-source.sh <receiver-public-cert-sha256>` (excluded from the public-minimum file list) builds local debug app/test APKs only. It does NOT install, launch, upload, connect adb or change KVM. Empty pin permits compiling but fails closed at runtime. Existing official AGP8.9.3/Kotlin2.3.0/Room2.8.4/WorkManager2.10.5/coroutines1.10.2/Gson2.12.1 are reused; no new test dependency. Source instrumentation extends android.app.Instrumentation, not AndroidX/JUnit.

## Coordinated future execution (not performed)

Fresh disposable emulator required; /dev/kvm not present on current cloud. Before any installation externally verify explicit emulator serial/qemu property/no accounts/new userdata; never select default adb device. Install receiver debug app/test and source debug app/test only after public certificate pin matches. Do not call install from this build script.

Runner `net.ankio.auto.test/net.ankio.auto.qa.SourceQaRunner` requires all of:
- `allowBlankEmulator=YES`
- `qa_run=<UUID shared across this disposable run>`
- `case=<one of below>`
- actual emulator property ro.kernel.qemu=1

The QA manifest disables automatic WorkManager initialization until a QA marker exists; QA Application uses Configuration.Provider. First `seed` refuses any existing database/sidecar/shared-preference/file/noBackup file, then creates and fsyncs a run marker and exactly3 synthetic Edited/top-level/CNY rows: Expend0.1, Expend0.2, Income100. It refuses reseeding a nonempty DB and doesn't delete anything. Source Application already refuses non-emulator environments. Then receiver runner `case=pair` explicitly pins this source certificate (see sibling receiver harness docs). If receiver core tests ran first, use receiver's explicit synthetic reset flag during pair as its docs require; **never reset received case**.

Source cases:
- `seed`: synthetic fixture only, no grants/transfers. Receiver must be installed to verify distinct UIDs in evidence.
- `manual`, with `allow_authorize=true`: grants this fixture snapshot through actual production source Actions and transfers via actual ContentResolver to receiver; receiver reverse verifier must call the real source provider. Returns snapshot_id/source_id/digest/count; asserts source sequence unchanged. This is explicit test setup, NOT proof consent UI was clicked.
- `auto-arm`, with `allow_authorize=true`: enables separate real automatic state with actual receiver certificate then production WorkManager configure. Source/source-provider code unchanged. Synthetic Application bootstrap is not original App signal wiring.
- `auto-await`: waits up to180seconds for confirmed selectedAt, reports safe failure if paused. Delays are observations, not30second guarantee. Calls production workers via actual scheduler, not WorkManager TestDriver.
- `auto-revoke`: persists real automatic revoke then cancels work. Does not delete rows or remote copies.
- `evidence`: fixture metadata only (PID/UID/source sequence/row count/automatic pending and receipt), no raw rows or credentials.

Receiver `case=received` should validate snapshot and expected expense0.3/income100. Supply returned snapshot_id/source_id if desired. Source and receiver UIDs must differ. Shell content call as shell UID is not an equivalent positive round-trip.

## Not implemented/executed in this scaffold

No emulator run or actual Binder evidence yet. Expanded cases are documented in CASES.md: exact wrong-signer denial assertions (host re-signs APKs), durable checkpoint seams, actual bounded source capacity, mutation/revoke evidence. These are prepared/compiled cases, not executed device tests. No arbitrary mid-Binder/Room transaction kill, physical expiry wait, completed background reboot orchestration, UI consent-click test or whole reconstructed App/Xposed/AI test is claimed. Production source files remain unchanged. Full source/receiver test suite status belongs to parent evidence, not this harness build.

## Standalone minimum source bundle

`PUBLIC_FILES.txt` lists the exact proposed publishable source-only set. No publication is performed here. It excludes builds, logs, `.gradle`, local.properties, SDK/cache/proxy helpers, keystores, credentials and the full reconstructed checkout. `python verify_sources.py --copies-only` verifies18 copied production files against frozen hashes without reading the original checkout. Default mode additionally checks the original local checkout. The reference-only original DAO hash is provenance, not a standalone input requirement.

There is no runnable public CI/device workflow or completed run-device installer. On a separately coordinated authorized runner, install official Gradle8.11.1/JDK21/SDK36 and run the Gradle project with the receiver public certificate pin. Do not enable a workflow on the strength of these source/build files alone; blank-device ownership/orchestration/adversarial stages still require review.

Local compilation completed for app and instrumentation APKs (final ownership-gated build49s); evidence is in the coordinator log and local BUILD_STATUS.json. This is compile evidence only, not an executed device test. Merged source manifest has no INTERNET permission and no WorkManagerInitializer metadata.
