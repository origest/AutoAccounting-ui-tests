package net.ankio.auto.qa

import android.app.Activity
import android.app.Instrumentation
import android.os.Bundle
import android.os.Process
import kotlinx.coroutines.*
import androidx.room.withTransaction
import net.ankio.auto.BuildConfig
import net.ankio.auto.adapter.*
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.db.*
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.constant.*
import java.io.File
import java.util.UUID
import com.google.gson.Gson
import android.net.Uri
import android.content.Context

/** Fixture-only instrumentation. Never export a fixture provider. It runs in the real source app UID. */
class SourceQaRunner:Instrumentation(){
 private lateinit var args:Bundle
 override fun onCreate(arguments:Bundle?){args=arguments?:Bundle();super.onCreate(arguments);start()}
 override fun onStart(){
  val output=Bundle()
  try {
   check(BuildConfig.QA_ONLY&&isEmulator()&&args.getString("allowBlankEmulator")=="YES"){"QA_GATE"}
   val run=checkNotNull(args.getString("qa_run"));check(UUID.fromString(run).toString()==run);output.putString("qa_run",run)
   val marker=File(targetContext.noBackupFilesDir,"synthetic-v7-qa-run")
   if(marker.exists())check(marker.readText()==run){"QA_RUN_MISMATCH"}else{
    check(args.getString("case")=="seed"){"QA_SEED_REQUIRED"}
    // Refuse ownership of any pre-existing app data, including a real installation's DB/prefs.
    val data=File(targetContext.applicationInfo.dataDir)
    val dirs=listOf(File(data,"databases"),File(data,"shared_prefs"),targetContext.filesDir,targetContext.noBackupFilesDir)
    check(dirs.none{dir->dir.exists()&&dir.walkTopDown().any{it.isFile}}){"QA_EXISTING_DATA_REFUSED"}
    check(marker.createNewFile()){ "QA_MARKER_RACE" }
    java.io.FileOutputStream(marker).use{it.write(run.toByteArray(Charsets.UTF_8));it.fd.sync()}
    check(marker.readText()==run){ "QA_MARKER_WRITE" }
   }
   check(targetContext.packageName=="net.ankio.auto")
   val mode=args.getString("case")?:error("QA_CASE_REQUIRED")
   runBlocking {
    when(mode){
     "seed"->seed()
     "manual"->{authorizeGate();manual(output)}
     "prepare-manual-grant"->{authorizeGate();manual(output,false)}
     "auto-arm"->{authorizeGate();arm()}
     "auto-await"->awaitReceipt()
     "auto-await-paused"->awaitPaused()
     "mutate"->mutate(output)
     "unchanged-wake"->unchangedWake(output)
     "prepare-pending"->{authorizeGate();preparePending(output)}
     "send-first-page"->firstPage(output)
     "complete-without-local-ack"->resumePending(output,false)
     "resume-pending"->resumePending(output,true)
     "release-pending-to-worker"->{checkpointMode(false);LocalAutomaticCopyScheduler.configure(targetContext)}
     "capacity-fill"->capacity(output)
     "expect-receiver-denial"->{authorizeGate();expectReceiverDenial(output)}
     "expect-receiver-identity-denial"->expectIdentityDenial(output)
     "revoked-evidence"->revokedEvidence(output)
     "revoke-pending-denied"->revokePendingDenied(output)
     "auto-revoke"->revoke(output)
     "evidence"->Unit
     else->error("QA_UNKNOWN_CASE")
    }
    evidence(output)
   }
   output.putString("qa_result","PASS");output.putString("case",mode);finish(Activity.RESULT_OK,output)
  }catch(t:Throwable){output.putString("qa_result","FAIL");output.putString("error_class",t.javaClass.simpleName);finish(Activity.RESULT_CANCELED,output)}
 }
 private fun authorizeGate(){check(args.getString("allow_authorize")=="true"){"QA_EXPLICIT_AUTH_REQUIRED"}}
 private suspend fun seed(){
  check(LocalAutomaticCopyScheduler.store(targetContext).state()?.enabled!=true)
  Db.withLocalSyncDatabase{db->db.withTransaction{
   check(db.billInfoDao().count()==0){"QA_ALREADY_SEEDED"}
   listOf(0.1,0.2,100.0).forEachIndexed{i,money->
    db.billInfoDao().insert(BillInfoModel(id=(i+1).toLong(),type=if(i<2)BillType.Expend else BillType.Income,money=money,currency="CNY",time=1_700_000_000_000L+i,shopName="fixture-$i",bookName="fixture-book",cateName="fixture-category",remark="synthetic only",state=BillState.Edited,groupId=-1))
   }
  }}
  PrefManager.featureFee=true;PrefManager.featureAssetManage=true
 }
 private suspend fun manual(out:Bundle,transmit:Boolean=true){
  val before=LocalFrozenSnapshot.currentVersion()
  val manifest=LocalFrozenSnapshot.captureCurrent()
  val grant=LocalSnapshotGrantActions.authorizeFromUserButton(targetContext,net.ankio.auto.adapter.LocalSnapshotLease(manifest.sourceId,manifest.snapshotId,manifest.digest,manifest.sequence))
  // Actual ContentResolver to receiver and its actual reverse ContentResolver to source provider.
  if(transmit)LocalSnapshotTransferClient(targetContext).transfer(grant){}
  check(before==LocalFrozenSnapshot.currentVersion()){ "QA_SOURCE_MUTATED" }
  out.putString("snapshot_id",manifest.snapshotId);out.putString("source_id",manifest.sourceId);out.putString("digest",manifest.digest)
  out.putInt("fixture_rows",manifest.totalRows)
 }
 private suspend fun arm(){
  val store=LocalAutomaticCopyScheduler.store(targetContext);val expected=store.state()?.epoch
  val cert=LocalAutomaticCopyIdentity.certificate(targetContext)
  val source=LocalFrozenSnapshot.currentVersion().first
  store.enableExplicit(source,cert,expected)
  checkpointMode(false)
  LocalAutomaticCopyScheduler.configure(targetContext)
 }
 private suspend fun evidence(out:Bundle){
  val version=LocalFrozenSnapshot.currentVersion();out.putString("source_id",version.first);out.putLong("source_sequence",version.second)
  out.putInt("source_uid",Process.myUid());out.putInt("source_pid",Process.myPid())
  val info=targetContext.packageManager.getApplicationInfo(LocalReceiverIdentity.PACKAGE,0)
  check(info.uid!=Process.myUid()){ "QA_MUST_BE_TWO_UIDS" };out.putInt("receiver_uid",info.uid)
  Db.withLocalSyncDatabase{db->out.putInt("source_rows",db.billInfoDao().count());out.putLong("source_manifests",scalar(db,"SELECT COUNT(*) FROM LocalFrozenManifest"));out.putLong("retained_bytes",db.localFrozenDao().retainedBytes())}
  LocalAutomaticCopyScheduler.store(targetContext).state()?.let{s->out.putBoolean("auto_enabled",s.enabled);out.putLong("selected_at",s.selectedAt);out.putLong("last_sequence",s.lastSequence);out.putString("pending_snapshot",s.pendingId);out.putString("pause",s.pause)}
 }
 private fun prefs()=targetContext.getSharedPreferences("synthetic-v7-checkpoints",Context.MODE_PRIVATE)
 private fun checkpointMode(enabled:Boolean){check(prefs().edit().putBoolean("manual_checkpoint_mode",enabled).commit())}
 private fun scalar(db:AppDatabase,sql:String)=db.openHelper.writableDatabase.query(sql).use{check(it.moveToFirst());it.getLong(0)}
 private fun autoStore()=LocalAutomaticCopyScheduler.store(targetContext)
 private suspend fun checkpoint(out:Bundle,stage:String){
  check(prefs().edit().putString("stage",stage).commit());out.putString("qa_checkpoint",stage)
  val status=Bundle();evidence(status);status.putString("qa_run",args.getString("qa_run"));status.putString("case",args.getString("case"));status.putString("qa_checkpoint",stage);status.putString("qa_result","CHECKPOINT");sendStatus(1,status)
  val hold=args.getString("hold_ms","0")!!.toLong();require(hold in 0..30_000)
  if(hold>0)delay(hold)
 }
 private suspend fun awaitReceipt(){
  val minimum=args.getString("min_sequence")?.toLong()?:LocalFrozenSnapshot.currentVersion().second
  withTimeout(180_000){while(true){val s=autoStore().state();check(s?.pause==null){"QA_AUTO_PAUSED"};if(s!=null&&s.selectedAt>0&&s.lastSequence>=minimum)break;delay(1000)}}
 }
 private suspend fun awaitPaused(){
  val expected=args.getString("expected_pause")?:"capacity_or_record_limit"
  require(expected in setOf("capacity_or_record_limit","retry_limit","source_changed","pending_expired","projection_changed","receiver_changed"))
  withTimeout(180_000){while(true){val s=autoStore().state();if(s?.pause!=null){check(s.pause==expected){"QA_UNEXPECTED_PAUSE"};break};delay(1000)}}
 }
 private suspend fun mutate(out:Bundle){
  Db.withLocalSyncDatabase{db->db.withTransaction{
   val bill=checkNotNull(db.billInfoDao().queryId(1));check(bill.shopName=="fixture-0"&&bill.money==0.1){"QA_MUTATION_REQUIRES_ORIGINAL_FIXTURE"}
   bill.money=0.4;bill.categoryRevision+=1;db.billInfoDao().update(bill)
  }}
  LocalAutomaticCopyScheduler.wake(targetContext);out.putString("expected_expense","0.6")
 }
 private suspend fun unchangedWake(out:Bundle){
  val before=autoStore().state()?:error("QA_AUTO_REQUIRED")
  check(before.enabled&&before.pause==null&&before.pendingId==null&&before.lastSequence==LocalFrozenSnapshot.currentVersion().second)
  val count=Db.withLocalSyncDatabase{scalar(it,"SELECT COUNT(*) FROM LocalFrozenManifest")}
  repeat(20){LocalAutomaticCopyScheduler.wake(targetContext)}
  delay(65_000) // Observational inexact-scheduler case, not proof a worker necessarily ran.
  check(autoStore().state()?.lastSequence==before.lastSequence)
  check(Db.withLocalSyncDatabase{scalar(it,"SELECT COUNT(*) FROM LocalFrozenManifest")}==count){"QA_UNCHANGED_CREATED_COPY"}
  out.putString("observation","65s_no_new_manifest_worker_execution_not_assumed")
 }
 private suspend fun preparePending(out:Bundle){
  check(autoStore().state()?.enabled!=true){"QA_REVOKE_EXISTING_AUTOMATIC_FIRST"}
  checkpointMode(true);LocalAutomaticCopyScheduler.cancel(targetContext)
  val version=LocalFrozenSnapshot.currentVersion();val store=autoStore()
  val state=store.enableExplicit(version.first,LocalAutomaticCopyIdentity.certificate(targetContext),store.state()?.epoch)
  val reserved=store.reserve(state.epoch,System.currentTimeMillis())
  val stop=args.getString("stop_at","bound")!!;require(stop in setOf("reserved","frozen","bound"))
  if(stop=="reserved"){checkpoint(out,"reserved");return}
  val manifest=LocalFrozenSnapshot.captureReserved(reserved.pendingId!!,state.source)
  if(stop=="frozen"){checkpoint(out,"frozen");return}
  store.bind(state.epoch,net.ankio.auto.adapter.LocalSnapshotLease(manifest.sourceId,manifest.snapshotId,manifest.digest,manifest.sequence),manifest.capturedAt,System.currentTimeMillis())
  checkpoint(out,"bound")
 }
 private suspend fun boundPending():LocalSnapshotGrant {
  check(prefs().getBoolean("manual_checkpoint_mode",false)){"QA_CHECKPOINT_MODE_REQUIRED"}
  val store=autoStore();val s=checkNotNull(store.state());check(s.enabled&&s.pause==null)
  val m=LocalFrozenSnapshot.captureReserved(checkNotNull(s.pendingId),s.source)
  val bound=store.bind(s.epoch,net.ankio.auto.adapter.LocalSnapshotLease(m.sourceId,m.snapshotId,m.digest,m.sequence),m.capturedAt,System.currentTimeMillis())
  return checkNotNull(bound.pendingGrant)
 }
 private suspend fun firstPage(out:Bundle){
  val grant=boundPending();val before=LocalFrozenSnapshot.currentVersion()
  check(autoStore().permits(grant,System.currentTimeMillis()))
  check(LocalAutomaticCopyIdentity.certificate(targetContext)==grant.receiverCert)
  val page=LocalFrozenSnapshot.pageCurrent(grant.lease.snapshotId,grant.lease.sourceId,0,1)
  fun request()=Bundle().apply{putInt("protocol",2);putString("snapshot_id",grant.lease.snapshotId);putString("grant_json",Gson().toJson(grant));putString("contract",grant.contract)}
  targetContext.contentResolver.acquireContentProviderClient(Uri.parse("content://io.github.origest.billdashboard.localsync"))!!.use{client->
   fun checkReply(reply:Bundle?,status:String){check(reply!=null&&reply.getInt("protocol")==2&&reply.getString("status")==status&&reply.getString("source_id")==grant.lease.sourceId&&reply.getString("snapshot_id")==grant.lease.snapshotId&&reply.getString("digest")==grant.lease.digest)}
   checkReply(client.call("snapshot-begin-v2",null,request().apply{putString("manifest_json",Gson().toJson(page.manifest))}),"staged")
   val rows=ArrayList<Bundle>();for(row in page.rows){val bytes=row.payload.toByteArray(Charsets.UTF_8);check(bytes.size<=256*1024);rows.add(Bundle().apply{putLong("id",row.billId);putByteArray("payload",bytes)})}
   check(rows.size==1)
   checkReply(client.call("snapshot-page-v2",null,request().apply{putParcelableArrayList("rows",rows)}),"accepted")
  }
  check(autoStore().permits(grant,System.currentTimeMillis()));check(before==LocalFrozenSnapshot.currentVersion())
  // Deterministic QA protocol driver, not a modified production transfer loop.
  checkpoint(out,"after_first_page")
 }
 private suspend fun resumePending(out:Bundle,acknowledge:Boolean){
  val grant=boundPending();val before=LocalFrozenSnapshot.currentVersion()
  LocalSnapshotTransferClient(targetContext).transfer(grant){}
  check(before==LocalFrozenSnapshot.currentVersion())
  if(acknowledge){autoStore().selected(grant.automaticEpoch!!,grant,System.currentTimeMillis());checkpoint(out,"locally_acknowledged")}
  else checkpoint(out,"remote_complete_before_local_cursor")
  out.putString("snapshot_id",grant.lease.snapshotId);out.putString("digest",grant.lease.digest)
 }
 private suspend fun revoke(out:Bundle){
  val prior=autoStore().state();val grant=prior?.pendingGrant
  autoStore().revoke();LocalAutomaticCopyScheduler.cancel(targetContext)
  val revoked=checkNotNull(autoStore().state());check(!revoked.enabled&&revoked.epoch!=prior?.epoch)
  if(grant!=null)check(!autoStore().permits(grant,System.currentTimeMillis()))
  val count=Db.withLocalSyncDatabase{scalar(it,"SELECT COUNT(*) FROM LocalFrozenManifest")}
  check(prefs().edit().putString("revoked_epoch",revoked.epoch).putLong("revoked_manifest_count",count).commit())
  checkpoint(out,"revoked")
 }
 private suspend fun revokedEvidence(out:Bundle){
  val expected=checkNotNull(prefs().getString("revoked_epoch",null))
  val count=prefs().getLong("revoked_manifest_count",-1)
  repeat(20){LocalAutomaticCopyScheduler.wake(targetContext)}
  val current=checkNotNull(autoStore().state());check(!current.enabled&&current.epoch==expected)
  check(Db.withLocalSyncDatabase{scalar(it,"SELECT COUNT(*) FROM LocalFrozenManifest")}==count)
  checkpoint(out,"revocation_survived_restart")
 }
 private suspend fun capacity(out:Bundle){
  check(args.getString("allow_capacity")=="true"){"QA_CAPACITY_CONSENT_REQUIRED"}
  check(autoStore().state()?.enabled!=true){"QA_CAPACITY_MUST_BE_ISOLATED"}
  checkpointMode(true);LocalAutomaticCopyScheduler.cancel(targetContext)
  Db.withLocalSyncDatabase{db->db.withTransaction{
   check(db.billInfoDao().count()==3){"QA_CAPACITY_REQUIRES_ORIGINAL_FIXTURE"}
   val payload="x".repeat(192*1024)
   for(i in 1..64)db.billInfoDao().insert(BillInfoModel(id=(1000+i).toLong(),type=BillType.Expend,money=0.0,currency="CNY",shopName="fixture-capacity-$i",remark=payload,state=BillState.Edited))
  }}
  var capacityHit=false
  for(attempt in 1..12){
   val before=Db.withLocalSyncDatabase{scalar(it,"SELECT COUNT(*) FROM LocalFrozenManifest") to it.localFrozenDao().retainedBytes()}
   try{LocalFrozenSnapshot.captureCurrent()}
   catch(e:IllegalArgumentException){
    check(e.message in setOf("LOCAL_SNAPSHOT_BYTE_LIMIT","LOCAL_SNAPSHOT_RETAINED_LIMIT","LOCAL_SNAPSHOT_MANIFEST_LIMIT")){"QA_NOT_CAPACITY_FAILURE"}
    check(Db.withLocalSyncDatabase{scalar(it,"SELECT COUNT(*) FROM LocalFrozenManifest") to it.localFrozenDao().retainedBytes()}==before){"QA_CAPACITY_PARTIAL_COMMIT"}
    capacityHit=true;break
   }
  }
  check(capacityHit){"QA_CAPACITY_NOT_REACHED_IN_BOUND"}
  check(Db.withLocalSyncDatabase{it.localFrozenDao().retainedBytes()}<=LocalFrozenSnapshot.MAX_RETAINED_BYTES)
  out.putBoolean("capacity_reached",true);checkpoint(out,"source_capacity_limit_verified_no_deletion")
 }
 private suspend fun expectReceiverDenial(out:Bundle){
  val before=LocalFrozenSnapshot.currentVersion()
  val m=LocalFrozenSnapshot.captureCurrent()
  val grant=LocalSnapshotGrantActions.authorizeFromUserButton(targetContext,net.ankio.auto.adapter.LocalSnapshotLease(m.sourceId,m.snapshotId,m.digest,m.sequence))
  var denied=false
  try{LocalSnapshotTransferClient(targetContext).transfer(grant){}}
  catch(e:SecurityException){check(e.message=="Receiver not paired with caller"){"QA_WRONG_SECURITY_FAILURE"};denied=true}
  check(denied){"QA_EXPECTED_RECEIVER_SECURITY_DENIAL"};check(before==LocalFrozenSnapshot.currentVersion())
  out.putString("denial","Receiver not paired with caller")
 }
 private suspend fun expectIdentityDenial(out:Bundle){
  val before=LocalFrozenSnapshot.currentVersion()
  val store=LocalSnapshotGrantStore(LocalSnapshotGrantFile(targetContext))
  val grant=checkNotNull(store.current(System.currentTimeMillis())){"QA_PREPARED_VALID_MANUAL_GRANT_REQUIRED"}
  check(grant.automaticEpoch==null&&grant.receiverCert==BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256)
  check(LocalFrozenSnapshot.currentLease(grant.lease.sourceId,grant.lease.snapshotId).valid)
  val info=targetContext.packageManager.getPackageInfo(LocalReceiverIdentity.PACKAGE,android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
  val signers=checkNotNull(info.signingInfo?.apkContentsSigners);check(signers.size==1)
  val actual=java.security.MessageDigest.getInstance("SHA-256").digest(signers.single().toByteArray()).joinToString(""){"%02x".format(it)}
  check(actual!=grant.receiverCert){"QA_WRONG_SIGNER_FIXTURE_REQUIRED"}
  var identityDenied=false
  try{LocalAutomaticCopyIdentity.certificate(targetContext)}
  catch(e:IllegalStateException){check(e.message=="AUTO_RECEIVER_CHANGED"){"QA_WRONG_IDENTITY_FAILURE"};identityDenied=true}
  check(identityDenied)
  var clientDenied=false
  try{LocalSnapshotTransferClient(targetContext).transfer(grant){}}
  catch(e:IllegalStateException){
   // Frozen allowlisted source has an unlabelled check(trusted) at line45. Reject every other generic failure.
   val frame=e.stackTrace.firstOrNull{it.className=="net.ankio.auto.adapter.LocalSnapshotTransferClient"}
   check(e.message=="Check failed."&&frame!=null&&frame.methodName=="send"&&frame.lineNumber==45){"QA_WRONG_CLIENT_FAILURE"}
   clientDenied=true
  }
  check(clientDenied){"QA_EXPECTED_REAL_CLIENT_PIN_DENIAL"}
  check(before==LocalFrozenSnapshot.currentVersion()&&store.current(System.currentTimeMillis())==grant)
  out.putBoolean("identity_denied",true);out.putString("client_denial_branch","LocalSnapshotTransferClient.send:45")
  // This is actual production-client refusal. Receiver fingerprint assertions are separate; no fabricated call counter.
 }

 private suspend fun revokePendingDenied(out:Bundle){
  check(prefs().getString("stage",null)=="after_first_page"){"QA_FIRST_PAGE_CHECKPOINT_REQUIRED"}
  val store=autoStore();val beforeState=checkNotNull(store.state());val grant=checkNotNull(beforeState.pendingGrant)
  check(store.permits(grant,System.currentTimeMillis())){"QA_VALID_PENDING_REQUIRED"}
  val beforeVersion=LocalFrozenSnapshot.currentVersion()
  store.revoke();LocalAutomaticCopyScheduler.cancel(targetContext)
  val revoked=checkNotNull(store.state());check(!revoked.enabled&&revoked.epoch!=beforeState.epoch)
  var refused=false
  try{LocalSnapshotTransferClient(targetContext).transfer(grant){}}
  catch(e:IllegalStateException){check(e.message=="SNAPSHOT_GRANT_INVALID"){"QA_WRONG_REVOCATION_FAILURE"};refused=true}
  check(refused){"QA_REVOKED_CLIENT_DID_NOT_REFUSE"}
  check(store.state()==revoked&&LocalFrozenSnapshot.currentVersion()==beforeVersion){"QA_REVOKED_ATTEMPT_MUTATED_SOURCE"}
  check(!store.permits(grant,System.currentTimeMillis()))
  out.putString("denial","SNAPSHOT_GRANT_INVALID");out.putBoolean("pending_transfer_revoked",true)
  // Receiver's independently captured database fingerprint must also remain unchanged.
 }

}
