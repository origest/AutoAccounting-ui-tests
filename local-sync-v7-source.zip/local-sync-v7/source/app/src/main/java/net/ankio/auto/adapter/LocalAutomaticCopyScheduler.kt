package net.ankio.auto.adapter

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

/** Independent from online export and AI. Android scheduling is inexact, not real time. */
object LocalAutomaticCopyScheduler {
    private const val IMMEDIATE="local-offline-copy-refresh-v1"
    private const val PERIODIC="local-offline-copy-reconcile-v1"
    internal fun store(c:Context)=LocalAutomaticCopyStore(LocalSnapshotGrantFile(c,"local-automatic-copy-v1.json"))
    fun wake(c:Context) {
        val s=runCatching{store(c).state()}.getOrNull()?:return
        if(!s.enabled||s.pause!=null)return
        WorkManager.getInstance(c).enqueueUniqueWork(IMMEDIATE,ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<LocalAutomaticCopyWorker>().setInitialDelay(30,TimeUnit.SECONDS)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,60,TimeUnit.SECONDS).build())
    }
    fun configure(c:Context) {
        val s=runCatching{store(c).state()}.getOrNull()
        val work=WorkManager.getInstance(c)
        if(s==null||!s.enabled||s.pause!=null){work.cancelUniqueWork(IMMEDIATE);work.cancelUniqueWork(PERIODIC);return}
        work.enqueueUniquePeriodicWork(PERIODIC,ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<LocalAutomaticCopyWorker>(15,TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,60,TimeUnit.SECONDS).build())
        wake(c)
    }
    fun cancel(c:Context) {WorkManager.getInstance(c).cancelUniqueWork(IMMEDIATE);WorkManager.getInstance(c).cancelUniqueWork(PERIODIC)}
}
