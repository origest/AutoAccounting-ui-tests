package net.ankio.auto.adapter

import com.google.gson.Gson
import java.security.MessageDigest
import java.util.UUID

/** Separate standing permission. No writes to bill/AI state. All callbacks under lock are local only. */
internal data class LocalAutomaticCopyState(
    val version:Int=1,val enabled:Boolean,val epoch:String,val source:String,val certificate:String,
    val contract:String=LocalSnapshotGrantStore.OFFLINE_COPY_CONTRACT,
    val pendingId:String?=null,val pendingGrant:LocalSnapshotGrant?=null,
    val lastSequence:Long=-1,val selectedAt:Long=0,val capturedAt:Long=0,
    val attemptedAt:Long=0,val failures:Int=0,val pause:String?=null)
internal object LocalAutomaticCopyPolicy {
    fun needsRefresh(s:LocalAutomaticCopyState,source:String,sequence:Long):Boolean {
        check(source==s.source){"LOCAL_SNAPSHOT_SOURCE_CHANGED"}
        check(sequence>=s.lastSequence){"LOCAL_SNAPSHOT_SEQUENCE_REGRESSED"}
        return s.pendingId!=null || sequence!=s.lastSequence
    }
}
internal class LocalAutomaticCopyStore(private val disk:LocalSnapshotGrantPersistence) {
    companion object { private val lock=Any();private val gson=Gson()
        private fun uuid(s:String)=UUID.fromString(s).toString()==s
        private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
    }
    private data class Envelope(val payload:String,val sha256:String)
    private fun read():LocalAutomaticCopyState? {
        val bytes=disk.read()?:return null;require(bytes.size<=8192)
        val e=gson.fromJson(bytes.toString(Charsets.UTF_8),Envelope::class.java);require(hash(e.payload)==e.sha256)
        val s=gson.fromJson(e.payload,LocalAutomaticCopyState::class.java)
        require(s.version==1&&uuid(s.epoch)&&uuid(s.source)&&s.certificate.matches(Regex("[0-9a-f]{64}")))
        require(s.contract==LocalSnapshotGrantStore.OFFLINE_COPY_CONTRACT&&s.lastSequence>=-1&&s.failures in 0..5)
        require(s.selectedAt>=0&&s.capturedAt>=0&&s.attemptedAt>=0)
        s.pendingId?.let{require(uuid(it))}
        s.pendingGrant?.let{g->require(g.lease.snapshotId==s.pendingId&&g.lease.sourceId==s.source&&g.receiverCert==s.certificate&&g.automaticEpoch==s.epoch&&g.revokeEpoch==s.epoch&&g.contract==s.contract&&uuid(g.grantId)&&g.lease.sequence>=0&&g.lease.digest.matches(Regex("[0-9a-f]{64}"))&&g.issuedAt>0&&g.expiresAt>g.issuedAt&&g.expiresAt-g.issuedAt<=86_400_000)}
        return s
    }
    private fun save(s:LocalAutomaticCopyState) {val p=gson.toJson(s);val bytes=gson.toJson(Envelope(p,hash(p))).toByteArray(Charsets.UTF_8);disk.write(bytes);check(disk.read()?.contentEquals(bytes)==true)}
    fun state():LocalAutomaticCopyState?=synchronized(lock){read()}
    fun enableExplicit(source:String,certificate:String,expectedEpoch:String?,ensureActive:()->Unit={}):LocalAutomaticCopyState=synchronized(lock){
        require(uuid(source)&&certificate.matches(Regex("[0-9a-f]{64}")))
        // Corrupt existing authority must not be silently repaired or discarded.
        check(read()?.epoch==expectedEpoch){"AUTO_AUTHORIZATION_CHANGED"}
        val s=LocalAutomaticCopyState(enabled=true,epoch=UUID.randomUUID().toString(),source=source,certificate=certificate)
        ensureActive();save(s);s
    }
    fun revoke()=synchronized(lock){
        val previous=read()
        val tombstone=previous?:LocalAutomaticCopyState(enabled=false,epoch=UUID.randomUUID().toString(),
            source="00000000-0000-0000-0000-000000000000",certificate="0".repeat(64))
        // Persist even before first enable: another UI's captured null epoch must become stale.
        save(tombstone.copy(enabled=false,pause="revoked",pendingGrant=null,epoch=UUID.randomUUID().toString()))
    }
    private fun update(epoch:String,change:(LocalAutomaticCopyState)->LocalAutomaticCopyState):LocalAutomaticCopyState=synchronized(lock){
        val old=checkNotNull(read());check(old.enabled&&old.epoch==epoch){"AUTO_REVOKED"};val next=change(old);save(next);next
    }
    fun reserve(epoch:String,now:Long):LocalAutomaticCopyState=update(epoch){s->check(s.pause==null);require(now>0);s.copy(pendingId=s.pendingId?:UUID.randomUUID().toString(),attemptedAt=now)}
    fun bind(epoch:String,lease:LocalSnapshotLease,capturedAt:Long,now:Long):LocalAutomaticCopyState=update(epoch){s->
        check(s.pause==null&&lease.sourceId==s.source&&lease.snapshotId==s.pendingId)
        if(s.pendingGrant!=null){check(s.pendingGrant.lease==lease);s}else{
            require(now>0&&now<=Long.MAX_VALUE-86_400_000)
            s.copy(capturedAt=capturedAt,pendingGrant=LocalSnapshotGrant(lease,s.certificate,UUID.randomUUID().toString(),epoch,now,now+86_400_000,s.contract,epoch))
        }
    }
    fun selected(epoch:String,grant:LocalSnapshotGrant,now:Long)=update(epoch){s->check(s.pause==null&&s.pendingGrant==grant);s.copy(lastSequence=grant.lease.sequence,selectedAt=now,pendingId=null,pendingGrant=null,failures=0,pause=null)}
    fun pause(epoch:String,reason:String)=update(epoch){it.copy(pause=reason)}
    fun failure(epoch:String)=update(epoch){val n=(it.failures+1).coerceAtMost(5);it.copy(failures=n,pause=if(n>=5)"retry_limit" else it.pause)}
    fun permits(grant:LocalSnapshotGrant,now:Long):Boolean=synchronized(lock){runCatching{val s=read()?:return@runCatching false;s.enabled&&s.pause==null&&s.epoch==grant.automaticEpoch&&s.pendingGrant==grant&&now>=grant.issuedAt&&now<grant.expiresAt}.getOrDefault(false)}
}
