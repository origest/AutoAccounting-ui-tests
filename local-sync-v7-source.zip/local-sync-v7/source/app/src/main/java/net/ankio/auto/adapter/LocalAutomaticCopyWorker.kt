package net.ankio.auto.adapter

import android.content.Context
import android.content.pm.PackageManager
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import net.ankio.auto.BuildConfig
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.db.LocalFrozenSnapshot
import java.security.MessageDigest

internal object LocalAutomaticCopyIdentity {
    fun certificate(c:Context):String {
        val pm=c.packageManager;val p=checkNotNull(pm.resolveContentProvider("${LocalReceiverIdentity.PACKAGE}.localsync",0))
        val info=pm.getPackageInfo(LocalReceiverIdentity.PACKAGE,PackageManager.GET_SIGNING_CERTIFICATES)
        val uid=info.applicationInfo?.uid?:-1
        val signatures=info.signingInfo?.apkContentsSigners?:error("AUTO_RECEIVER_CHANGED")
        check(signatures.size==1){"AUTO_RECEIVER_CHANGED"}
        val cert=MessageDigest.getInstance("SHA-256").digest(signatures.single().toByteArray()).joinToString(""){"%02x".format(it)}
        check(LocalReceiverIdentity.trusted(BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256,
            LocalReceiverIdentity.Facts(p.packageName,uid,p.applicationInfo.uid,pm.getPackagesForUid(uid)?.toSet()?:emptySet(),setOf(cert),info.lastUpdateTime))){"AUTO_RECEIVER_CHANGED"}
        return cert
    }
}
class LocalAutomaticCopyWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p) {
    companion object { private val running=Mutex() }
    override suspend fun doWork():Result=running.withLock {
        val store=LocalAutomaticCopyScheduler.store(applicationContext)
        var state=try{store.state()}catch(_:Exception){return@withLock Result.failure()}?:return@withLock Result.success()
        if(!state.enabled||state.pause!=null)return@withLock Result.success()
        val epoch=state.epoch
        try {
            if(!PrefManager.featureFee||!PrefManager.featureAssetManage){store.pause(epoch,"projection_changed");return@withLock Result.success()}
            val cert=try{LocalAutomaticCopyIdentity.certificate(applicationContext)}catch(_:Exception){store.pause(epoch,"receiver_changed");return@withLock Result.success()}
            if(cert!=state.certificate){store.pause(epoch,"receiver_changed");return@withLock Result.success()}
            val version=LocalFrozenSnapshot.currentVersion()
            if(version.first!=state.source){store.pause(epoch,"source_changed");return@withLock Result.success()}
            if(!LocalAutomaticCopyPolicy.needsRefresh(state,version.first,version.second))return@withLock Result.success()
            val now=System.currentTimeMillis()
            if(now<state.attemptedAt){store.pause(epoch,"clock_changed");return@withLock Result.success()}
            if(now-state.attemptedAt<60_000)return@withLock Result.retry()
            state=store.reserve(epoch,now) // Durable identity precedes Room capture, surviving either crash window.
            currentCoroutineContext().ensureActive()
            val manifest=LocalFrozenSnapshot.captureReserved(checkNotNull(state.pendingId),state.source)
            currentCoroutineContext().ensureActive()
            state=store.bind(epoch,LocalSnapshotLease(manifest.sourceId,manifest.snapshotId,manifest.digest,manifest.sequence),manifest.capturedAt,now)
            val grant=checkNotNull(state.pendingGrant)
            if(now>=grant.expiresAt){store.pause(epoch,"pending_expired");return@withLock Result.success()}
            LocalSnapshotTransferClient(applicationContext).transfer(grant){}
            currentCoroutineContext().ensureActive()
            store.selected(epoch,grant,System.currentTimeMillis()) // Only exact scoped selected ACK reaches here.
            val after=LocalFrozenSnapshot.currentVersion()
            if(after.first!=state.source){store.pause(epoch,"source_changed");Result.success()}
            else if(after.second!=grant.lease.sequence)Result.retry() else Result.success()
        }catch(e:CancellationException){throw e}
        catch(e:Exception){
            val current=runCatching{store.state()}.getOrNull()
            if(current==null||!current.enabled||current.epoch!=epoch)return@withLock Result.success()
            val code=e.message.orEmpty()
            val permanent=when {
                code=="LOCAL_SNAPSHOT_SOURCE_CHANGED"||code=="LOCAL_SNAPSHOT_SEQUENCE_REGRESSED"->"source_changed"
                code.startsWith("LOCAL_SNAPSHOT_")&&(code.contains("LIMIT")||code.contains("TIMEOUT"))->"capacity_or_record_limit"
                else->null
            }
            if(permanent!=null){store.pause(epoch,permanent);Result.success()}
            else {val failed=store.failure(epoch);if(failed.pause!=null)Result.success() else Result.retry()}
        }
    }
}
