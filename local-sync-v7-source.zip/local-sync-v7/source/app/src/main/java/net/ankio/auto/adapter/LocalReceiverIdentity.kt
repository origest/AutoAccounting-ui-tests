package net.ankio.auto.adapter

/** Public identity facts only. Missing pin and shared/multiple signers fail closed. */
internal object LocalReceiverIdentity {
    const val PACKAGE = "io.github.origest.billdashboard"
    data class Facts(val providerPackage: String?, val packageUid: Int, val providerUid: Int,
        val uidPackages: Set<String>, val currentSigners: Set<String>, val lastUpdateTime: Long)
    fun trusted(pin: String, facts: Facts): Boolean = pin.matches(Regex("[0-9a-f]{64}")) &&
        facts.providerPackage == PACKAGE && facts.packageUid >= 0 && facts.providerUid == facts.packageUid &&
        facts.uidPackages == setOf(PACKAGE) && facts.currentSigners == setOf(pin)
}
