package net.ankio.auto.adapter

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import net.ankio.auto.BuildConfig
import net.ankio.auto.http.api.BillAPI
import java.security.MessageDigest

/** Source UI must show snapshot/receiver/scope first and invoke only on an explicit user click. */
internal object LocalSnapshotGrantActions {
    suspend fun authorizeFromUserButton(context: Context, displayed: LocalSnapshotLease): LocalSnapshotGrant = withContext(Dispatchers.IO) {
        val pin = BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256
        val pm = context.packageManager
        val provider = pm.resolveContentProvider("${LocalReceiverIdentity.PACKAGE}.localsync",0)
            ?: error("GRANT_RECEIVER_UNAVAILABLE")
        val info = pm.getPackageInfo(LocalReceiverIdentity.PACKAGE,PackageManager.GET_SIGNING_CERTIFICATES)
        val uid = info.applicationInfo?.uid ?: -1
        val signers = info.signingInfo?.apkContentsSigners?.map {
            MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) }
        }?.toSet() ?: emptySet()
        check(LocalReceiverIdentity.trusted(pin,LocalReceiverIdentity.Facts(provider.packageName,uid,
            provider.applicationInfo.uid,pm.getPackagesForUid(uid)?.toSet() ?: emptySet(),signers,info.lastUpdateTime))) {
            "GRANT_RECEIVER_UNTRUSTED"
        }
        val live = BillAPI.localSnapshotLease(displayed.sourceId,displayed.snapshotId)
        check(live.valid && LocalSnapshotLease(live.source_id,live.snapshot_id,live.digest,live.sequence) == displayed) {
            "GRANT_SNAPSHOT_CHANGED"
        }
        val authorizationContext = currentCoroutineContext()
        authorizationContext.ensureActive()
        LocalSnapshotGrantStore(LocalSnapshotGrantFile(context)).authorizeExplicit(displayed,pin,System.currentTimeMillis(),
            ensureAuthorizationActive = { authorizationContext.ensureActive() })
    }
    suspend fun revokeFromUserButton(context: Context) = withContext(Dispatchers.IO) {
        LocalSnapshotGrantStore(LocalSnapshotGrantFile(context)).revoke()
    }
}
