package net.ankio.auto.adapter

import android.content.Context
import android.util.AtomicFile
import java.io.File

internal class LocalSnapshotGrantFile(context: Context, filename: String = "local-snapshot-grant-v1.json") : LocalSnapshotGrantPersistence {
    private val atomic = AtomicFile(File(context.noBackupFilesDir, filename))
    override fun read(): ByteArray? = try { atomic.openRead().use { stream ->
        val bytes = stream.readNBytesCompat(8193)
        require(bytes.size <= 8192); bytes
    } } catch (e: java.io.FileNotFoundException) {
        if (atomic.baseFile.exists() || File(atomic.baseFile.path + ".bak").exists()) throw e else null
    }
    override fun write(bytes: ByteArray) {
        val stream = atomic.startWrite()
        try { stream.write(bytes); stream.fd.sync(); atomic.finishWrite(stream) }
        catch (e: Exception) { atomic.failWrite(stream); throw e }
    }
    private fun java.io.InputStream.readNBytesCompat(max: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        while (output.size() < max) {
            val count = read(buffer, 0, minOf(buffer.size, max-output.size()))
            if (count < 0) break
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }
}
