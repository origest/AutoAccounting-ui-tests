package net.ankio.auto.adapter

import android.content.ContentProvider
import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import com.google.gson.Gson
import net.ankio.auto.BuildConfig
import net.ankio.auto.utils.PrefManager
import net.ankio.auto.http.api.BillAPI
import kotlinx.coroutines.runBlocking
import java.security.MessageDigest

/** Metadata verification only. There is deliberately no Binder method to authorize a grant. */
class LocalSnapshotGrantProvider : ContentProvider() {
    override fun onCreate() = true
    private fun trustedCaller(): Boolean {
        val pm = requireNotNull(context).packageManager
        val uid = Binder.getCallingUid()
        val packages = pm.getPackagesForUid(uid)?.toSet() ?: emptySet()
        if (packages != setOf(LocalReceiverIdentity.PACKAGE)) return false
        val info = pm.getPackageInfo(LocalReceiverIdentity.PACKAGE, PackageManager.GET_SIGNING_CERTIFICATES)
        val signers = info.signingInfo?.apkContentsSigners?.map {
            MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) }
        }?.toSet() ?: emptySet()
        return LocalReceiverIdentity.trusted(BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256,
            LocalReceiverIdentity.Facts(LocalReceiverIdentity.PACKAGE, info.applicationInfo?.uid ?: -1,
                uid, packages, signers, info.lastUpdateTime))
    }
    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        val denied = Bundle().apply { putInt("protocol",1);putString("status","denied") }
        return try {
            if (method != "verify-v1" || !trustedCaller() || !PrefManager.featureFee || !PrefManager.featureAssetManage) return denied
            val json = extras?.getString("grant_json") ?: return denied
            if (json.toByteArray(Charsets.UTF_8).size > 4096) return denied
            val request = Gson().fromJson(json, LocalSnapshotGrant::class.java)
            val store = LocalSnapshotGrantStore(LocalSnapshotGrantFile(requireNotNull(context)))
            val valid = if(request.automaticEpoch!=null) {
                val auto=LocalAutomaticCopyScheduler.store(requireNotNull(context))
                if(request.receiverCert!=BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256 || !auto.permits(request,System.currentTimeMillis())) false else {
                    val lease=runBlocking { BillAPI.localSnapshotLease(request.lease.sourceId,request.lease.snapshotId) }
                    lease.valid && LocalSnapshotLease(lease.source_id,lease.snapshot_id,lease.digest,lease.sequence)==request.lease && auto.permits(request,System.currentTimeMillis())
                }
            } else store.verify(request, BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256,
                System::currentTimeMillis) {
                    val lease = runBlocking { BillAPI.localSnapshotLease(request.lease.sourceId,request.lease.snapshotId) }
                    if (!lease.valid) null else LocalSnapshotLease(lease.source_id,lease.snapshot_id,lease.digest,lease.sequence)
                }
            if (!valid || !trustedCaller() || !PrefManager.featureFee || !PrefManager.featureAssetManage) return denied
            Bundle().apply { putInt("protocol",1);putString("status","valid");putString("grant_json",Gson().toJson(request)) }
        } catch (_: Exception) { denied }
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = throw SecurityException("UNSUPPORTED")
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw SecurityException("UNSUPPORTED")
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw SecurityException("UNSUPPORTED")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw SecurityException("UNSUPPORTED")
}
