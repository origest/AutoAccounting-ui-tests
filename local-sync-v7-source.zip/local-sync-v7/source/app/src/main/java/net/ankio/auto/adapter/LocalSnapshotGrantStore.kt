package net.ankio.auto.adapter

import com.google.gson.Gson
import java.security.MessageDigest
import java.util.UUID

/** One explicitly approved snapshot, not blanket access to subsequent snapshots. */
internal data class LocalSnapshotLease(val sourceId: String, val snapshotId: String,
    val digest: String, val sequence: Long)
internal data class LocalSnapshotGrant(val lease: LocalSnapshotLease, val receiverCert: String,
    val grantId: String, val revokeEpoch: String, val issuedAt: Long, val expiresAt: Long, val contract: String? = null, val automaticEpoch: String? = null)
internal interface LocalSnapshotGrantPersistence {
    fun read(): ByteArray?
    /** Must atomically replace, durably flush and throw on failure. */
    fun write(bytes: ByteArray)
}

internal class LocalSnapshotGrantStore(private val persistence: LocalSnapshotGrantPersistence) {
    private data class State(val version: Int, val epoch: String, val grant: LocalSnapshotGrant?)
    private data class Envelope(val payload: String, val sha256: String)
    companion object {
        // All app-process store instances serialize disk access; provider is not a separate process.
        const val OFFLINE_COPY_CONTRACT = "offline-copy-v1"
        private val lock = Any()
        private val gson = Gson()
        private fun uuid(s: String) = runCatching { UUID.fromString(s).toString() == s }.getOrDefault(false)
        private fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        private fun validLease(l: LocalSnapshotLease) = uuid(l.sourceId) && uuid(l.snapshotId) &&
            l.digest.matches(Regex("[0-9a-f]{64}")) && l.sequence >= 0
    }
    private fun readState(): State? {
        val bytes = persistence.read() ?: return null
        require(bytes.size <= 8192)
        val e = gson.fromJson(bytes.toString(Charsets.UTF_8), Envelope::class.java)
        require(e.sha256 == hash(e.payload))
        val state = gson.fromJson(e.payload, State::class.java)
        require(state.version == 1 && uuid(state.epoch))
        state.grant?.let { g ->
            require(g.automaticEpoch == null && (g.contract == null || g.contract == OFFLINE_COPY_CONTRACT) && validLease(g.lease) && uuid(g.grantId) && g.revokeEpoch == state.epoch &&
                g.receiverCert.matches(Regex("[0-9a-f]{64}")) && g.issuedAt > 0 &&
                g.expiresAt > g.issuedAt && g.expiresAt - g.issuedAt <= 600_000)
        }
        return state
    }
    private fun save(state: State) {
        val payload = gson.toJson(state)
        val bytes = gson.toJson(Envelope(payload, hash(payload))).toByteArray(Charsets.UTF_8)
        persistence.write(bytes)
        check(persistence.read()?.contentEquals(bytes) == true) { "GRANT_PERSIST_FAILED" }
    }
    /** Call only after a visible, explicit approval for these exact metadata and receiver. */
    fun authorizeExplicit(lease: LocalSnapshotLease, receiverCert: String, now: Long,
        ttlMillis: Long = 300_000, ensureAuthorizationActive: () -> Unit = {}): LocalSnapshotGrant = synchronized(lock) {
        require(validLease(lease) && receiverCert.matches(Regex("[0-9a-f]{64}")))
        require(now > 0 && ttlMillis in 1..600_000 && now <= Long.MAX_VALUE - ttlMillis)
        val previous = readState()?.grant
        require(previous == null || previous.lease.snapshotId != lease.snapshotId) { "NEW_SNAPSHOT_REQUIRED_FOR_CONTRACT" }
        val expires = now + ttlMillis
        require(expires > now)
        val epoch = UUID.randomUUID().toString()
        val grant = LocalSnapshotGrant(lease, receiverCert, UUID.randomUUID().toString(), epoch, now, expires, OFFLINE_COPY_CONTRACT)
        // Local non-suspending cancellation check under the same lock as revoke. Never call Binder here.
        ensureAuthorizationActive()
        save(State(1, epoch, grant)); grant
    }
    /** Metadata display only, including expired grant; never use this to authorize transmission. */
    fun storedForDisplay(): LocalSnapshotGrant? = synchronized(lock) {
        runCatching { readState()?.grant }.getOrNull()
    }
    /** Read-only restart recovery; does not renew or create authorization. */
    fun current(now: Long): LocalSnapshotGrant? = synchronized(lock) {
        runCatching { readState()?.grant?.takeIf { now >= it.issuedAt && now < it.expiresAt } }.getOrNull()
    }
    fun revoke() = synchronized(lock) { save(State(1, UUID.randomUUID().toString(), null)) }

    /** Re-read after live generation check so revocation during that call fails closed. */
    fun verify(request: LocalSnapshotGrant, receiverCert: String, now: () -> Long,
        currentLease: () -> LocalSnapshotLease?): Boolean {
        fun current(): Boolean = synchronized(lock) {
            runCatching {
                val g = readState()?.grant ?: return@runCatching false
                val time = now()
                g == request && receiverCert == g.receiverCert && time >= g.issuedAt && time < g.expiresAt
            }.getOrDefault(false)
        }
        if (!current()) return false
        val live = runCatching { currentLease() }.getOrNull() ?: return false
        return live == request.lease && current()
    }
}
