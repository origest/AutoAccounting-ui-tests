package net.ankio.auto.adapter

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Parcel
import com.google.gson.Gson
import kotlinx.coroutines.*
import net.ankio.auto.BuildConfig
import net.ankio.auto.http.api.BillAPI
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.db.LocalFrozenSnapshot
import java.security.MessageDigest

/** Explicit offline-copy transfer; receiver selects only under matching versioned consent. No source bill ACK. */
internal class LocalSnapshotTransferClient(private val context: Context) {
    private val gson = Gson()
    private val store = LocalSnapshotGrantStore(LocalSnapshotGrantFile(context))
    private val authority = "${LocalReceiverIdentity.PACKAGE}.localsync"
    private fun identity(): LocalReceiverIdentity.Facts {
        val pm=context.packageManager
        val provider=checkNotNull(pm.resolveContentProvider(authority,0))
        val info=pm.getPackageInfo(LocalReceiverIdentity.PACKAGE,PackageManager.GET_SIGNING_CERTIFICATES)
        val uid=info.applicationInfo?.uid?:-1
        val signers=info.signingInfo?.apkContentsSigners?.map {
            MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString(""){b->"%02x".format(b)}
        }?.toSet()?:emptySet()
        return LocalReceiverIdentity.Facts(provider.packageName,uid,provider.applicationInfo.uid,
            pm.getPackagesForUid(uid)?.toSet()?:emptySet(),signers,info.lastUpdateTime)
    }
    private suspend fun verify(grant: LocalSnapshotGrant) {
        currentCoroutineContext().ensureActive()
        check(grant.receiverCert==BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256)
        check(PrefManager.featureFee && PrefManager.featureAssetManage){"SNAPSHOT_FEATURE_DISABLED"}
        check(if(grant.automaticEpoch==null)store.current(System.currentTimeMillis()) == grant else LocalAutomaticCopyScheduler.store(context).permits(grant,System.currentTimeMillis())){"SNAPSHOT_GRANT_INVALID"}
        val live=BillAPI.localSnapshotLease(grant.lease.sourceId,grant.lease.snapshotId)
        check(live.valid && LocalSnapshotLease(live.source_id,live.snapshot_id,live.digest,live.sequence)==grant.lease)
        check(if(grant.automaticEpoch==null)store.current(System.currentTimeMillis()) == grant else LocalAutomaticCopyScheduler.store(context).permits(grant,System.currentTimeMillis()))
        currentCoroutineContext().ensureActive()
    }
    private suspend fun send(method:String, request:Bundle, grant:LocalSnapshotGrant, statuses:Set<String>) {
        verify(grant)
        val facts=identity()
        check(LocalReceiverIdentity.trusted(BuildConfig.LOCAL_DASHBOARD_RECEIVER_CERT_SHA256,facts))
        val parcel=Parcel.obtain()
        try {parcel.writeBundle(request);check(parcel.dataSize()<=384*1024){"SNAPSHOT_PACKET_LIMIT"}}
        finally{parcel.recycle()}
        // No app/store/lifecycle lock is held across this reentrant Binder operation.
        val result=context.contentResolver.acquireContentProviderClient(Uri.parse("content://$authority"))?.use {
            check(identity()==facts)
            it.call(method,null,request)
        }
        check(identity()==facts)
        verify(grant)
        check(result != null && result.getInt("protocol") == 2 && result.getString("status") in statuses &&
            result.getString("source_id") == grant.lease.sourceId && result.getString("snapshot_id") == grant.lease.snapshotId &&
            result.getString("digest") == grant.lease.digest){"SNAPSHOT_STAGE_REJECTED"}
    }
    suspend fun transfer(grant:LocalSnapshotGrant, progress:suspend (Int)->Unit) = withContext(Dispatchers.IO) {
        verify(grant)
        val first=LocalFrozenSnapshot.pageCurrent(grant.lease.snapshotId,grant.lease.sourceId,0,50)
        val manifest=first.manifest
        check(LocalSnapshotLease(manifest.sourceId,manifest.snapshotId,manifest.digest,manifest.sequence)==grant.lease)
        fun request()=Bundle().apply{putInt("protocol",2);putString("snapshot_id",manifest.snapshotId);putString("grant_json",gson.toJson(grant));grant.contract?.let{putString("contract",it)}}
        send("snapshot-begin-v2",request().apply{putString("manifest_json",gson.toJson(manifest))},grant,setOf("staged"))
        var after=0L;var count=0
        while(true) {
            verify(grant)
            val page=LocalFrozenSnapshot.pageCurrent(manifest.snapshotId,manifest.sourceId,after,50)
            check(page.manifest==manifest)
            val packet=ArrayList<Bundle>();var bytes=0
            suspend fun flush() {
                if(packet.isEmpty())return
                send("snapshot-page-v2",request().apply{putParcelableArrayList("rows",ArrayList(packet))},grant,setOf("accepted"))
                count+=packet.size;progress(count);packet.clear();bytes=0
            }
            for(row in page.rows) {
                val payload=row.payload.toByteArray(Charsets.UTF_8)
                check(payload.size<=256*1024)
                // Conservative metadata reserve; exact Parcel cap checked before every call.
                if(bytes+payload.size+256>360*1024)flush()
                packet.add(Bundle().apply{putLong("id",row.billId);putByteArray("payload",payload)})
                bytes+=payload.size+256
            }
            flush();verify(grant)
            after=page.next
            if(page.done)break
            check(page.rows.isNotEmpty())
        }
        check(count==manifest.totalRows)
        check(LocalFrozenSnapshot.currentLease(grant.lease.sourceId,grant.lease.snapshotId,verifyContent=true).valid)
        send("snapshot-complete-v2",request(),grant,if(grant.contract==LocalSnapshotGrantStore.OFFLINE_COPY_CONTRACT)setOf("selected") else setOf("complete"))
    }
}
