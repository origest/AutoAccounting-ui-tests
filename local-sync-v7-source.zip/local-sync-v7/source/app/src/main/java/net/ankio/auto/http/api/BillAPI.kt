package net.ankio.auto.http.api

/** QA-only narrow delegation, never an HTTP client. */
object BillAPI {
 suspend fun localSnapshotLease(sourceId:String,snapshotId:String)=org.ezbook.server.db.LocalFrozenSnapshot.currentLease(sourceId,snapshotId)
}
