package net.ankio.auto.qa

import android.app.Application
import net.ankio.auto.BuildConfig
import net.ankio.auto.adapter.LocalAutomaticCopyScheduler
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.db.Db

class QaApplication:Application(),androidx.work.Configuration.Provider {
 override val workManagerConfiguration:androidx.work.Configuration get()=androidx.work.Configuration.Builder().build()
 override fun onCreate(){super.onCreate()
 check(BuildConfig.QA_ONLY && isEmulator()){ "QA_EMULATOR_ONLY" }
 PrefManager.init(this);Db.init(this)
 // Reconciliation is actual production scheduler; no authority is created on launch.
 if(java.io.File(noBackupFilesDir,"synthetic-v7-qa-run").exists() && !getSharedPreferences("synthetic-v7-checkpoints",MODE_PRIVATE).getBoolean("manual_checkpoint_mode",false))LocalAutomaticCopyScheduler.configure(this)
}}
fun isEmulator():Boolean=runCatching{ProcessBuilder("/system/bin/getprop","ro.kernel.qemu").start().inputStream.bufferedReader().use{it.readText().trim()=="1"}}.getOrDefault(false)
