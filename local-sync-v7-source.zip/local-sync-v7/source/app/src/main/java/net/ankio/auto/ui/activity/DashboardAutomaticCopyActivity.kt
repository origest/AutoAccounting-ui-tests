package net.ankio.auto.ui.activity

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import kotlinx.coroutines.*
import net.ankio.auto.adapter.*
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.db.LocalFrozenSnapshot

/** Launch never enables anything. Standing permission is separate from the manual snapshot grant. */
class DashboardAutomaticCopyActivity:Activity() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private var enabling:Job?=null
    private var version=0L
    private var refreshVersion=0L
    private var refreshTask:Job?=null
    private lateinit var status:TextView
    private lateinit var enable:Button
    private fun store()=LocalAutomaticCopyScheduler.store(this)
    override fun onCreate(state:Bundle?) {
        super.onCreate(state)
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
        layout.addView(TextView(this).apply{text="自动更新本机看板（独立授权）\n开启后将持续向本机已验证签名的账迹发送完整账单副本，包括费用、资产、备注、待编辑和归组数据；不走线上、不修改账单或AI。完整接收后更新看板。\n系统后台调度并非实时。关闭只停止后续传输，已收或在途副本可能继续完成并更新看板，不删除历史。旧副本有128MiB/1000份容量上限，达到上限将暂停，不自动清理。单份传输授权24小时，到期需重新确认。来源、签名或费用/资产开关变化将暂停。"})
        status=TextView(this);layout.addView(status)
        enable=Button(this).apply{text="开启 / 重新明确授权";setOnClickListener{
            AlertDialog.Builder(this@DashboardAutomaticCopyActivity).setTitle("允许持续本机同步？")
                .setMessage("授权范围：当前来源数据库、当前已验证签名的账迹、完整原始账单。将持续创建并发送副本，直到关闭或安全暂停。暂停后重新授权会创建新快照，旧副本保留。")
                .setNegativeButton("取消",null).setPositiveButton("允许自动更新"){_,_->enableExplicit()}.show()
        }};layout.addView(enable)
        layout.addView(Button(this).apply{text="关闭自动更新并撤销后续发送";setOnClickListener{
            val turn=++version;enabling?.cancel();enable.isEnabled=false
            scope.launch {
                try{withContext(Dispatchers.IO){store().revoke()};LocalAutomaticCopyScheduler.cancel(this@DashboardAutomaticCopyActivity);if(turn==version)refresh()}
                catch(_:Exception){if(turn==version)status.text="未能确认撤销，请保留数据并核查本机存储"}
                finally{if(turn==version)enable.isEnabled=true}
            }
        }})
        layout.addView(Button(this).apply{text="刷新状态（不重新授权）";setOnClickListener{refresh()}})
        setContentView(ScrollView(this).apply{addView(layout)});refresh()
    }
    private fun enableExplicit() {
        val turn=++version;enabling?.cancel();enable.isEnabled=false
        // Capture at the explicit click, before any async identity/DB work; another UI's revoke invalidates it.
        val expectedEpoch=try{store().state()?.epoch}catch(_:Exception){status.text="安全状态读取失败，未授权；请保留数据核查";enable.isEnabled=true;return}
        enabling=scope.launch {
            try {
                withContext(Dispatchers.IO){
                    check(PrefManager.featureFee&&PrefManager.featureAssetManage)
                    val cert=LocalAutomaticCopyIdentity.certificate(this@DashboardAutomaticCopyActivity)
                    val source=LocalFrozenSnapshot.currentVersion().first
                    val ctx=currentCoroutineContext()
                    store().enableExplicit(source,cert,expectedEpoch){ctx.ensureActive()}
                }
                ensureActive();LocalAutomaticCopyScheduler.configure(this@DashboardAutomaticCopyActivity)
                if(turn==version)refresh()
            }catch(e:CancellationException){throw e}
            catch(_:Exception){if(turn==version)status.text="未开启：请检查费用/资产开关、接收应用签名和本机存储；不要清数据"}
            finally{if(turn==version)enable.isEnabled=true}
        }
    }
    private fun refresh() {
        val authorizationVersion=version
        val requestVersion=++refreshVersion
        refreshTask?.cancel()
        refreshTask=scope.launch {
        val text=withContext(Dispatchers.IO){runCatching{
            val s=store().state()?:return@runCatching "尚未授权自动更新"
            val paused=when(s.pause){null->"无";"capacity_or_record_limit"->"容量、单条大小或捕获时限；未删除任何历史";"retry_limit"->"连续失败，保留同一快照，请检查接收端";"pending_expired"->"本次传输授权过期";"source_changed"->"源数据库已变化";"receiver_changed"->"接收应用或签名不可验证";"projection_changed"->"费用/资产开关变化";"revoked"->"已撤销";else->"需要核查"}
            "自动更新：${if(s.enabled&&s.pause==null)"已授权，等待系统调度" else "关闭或暂停"}\n暂停原因：$paused\n最后确认接收：${if(s.selectedAt==0L)"尚无" else java.util.Date(s.selectedAt)}\n最后捕获：${if(s.capturedAt==0L)"尚无" else java.util.Date(s.capturedAt)}\n待发送：${if(s.pendingId==null)"无" else "有，重试同一副本"}\n这不是实时状态；失败不代表远端未接收。单次手动授权不受此开关控制。"
        }.getOrDefault("无法读取安全状态，未自动授权；请保留数据核查")}
        if(authorizationVersion==version&&requestVersion==refreshVersion)status.text=text
    }}
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}
