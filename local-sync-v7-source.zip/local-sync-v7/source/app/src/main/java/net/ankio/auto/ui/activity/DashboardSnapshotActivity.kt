package net.ankio.auto.ui.activity

import android.app.Activity
import android.os.Bundle
import android.widget.*
import kotlinx.coroutines.*
import net.ankio.auto.adapter.*
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.db.LocalFrozenSnapshot

/** An exported launch displays consent only; it never captures, authorizes or sends automatically. */
class DashboardSnapshotActivity : Activity() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private var task:Job?=null
    private var taskVersion=0L
    private var selected:LocalSnapshotLease?=null
    private var mayAuthorizeOfflineCopy=false
    private lateinit var status:TextView
    private val buttons=ArrayList<Button>()
    private fun store()=LocalSnapshotGrantStore(LocalSnapshotGrantFile(this))
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
        layout.addView(TextView(this).apply{text="本机离线副本同步\n\n此操作发送完整原始账单，包括费用、资产、待编辑及归组记录。必须开启费用及资产管理功能。不修改源账单或AI。完整接收后，这份副本将成为账迹当前看板；旧副本保留。\n\n先创建快照，再明确允许发送这份快照。授权有效5分钟。撤销只停止后续传输；已接收及正在传输的副本可能仍会完成并更新看板，不会远程删除。"})
        status=TextView(this).apply{text="未开始"};layout.addView(status)
        fun button(label:String,action:()->Unit){val b=Button(this).apply{text=label;setOnClickListener{action()}};buttons.add(b);layout.addView(b)}
        button("1. 创建本机快照，不发送") { runTask {
            requireFeatures()
            val m=withContext(Dispatchers.IO){LocalFrozenSnapshot.captureCurrent()}
            currentCoroutineContext().ensureActive()
            selected=LocalSnapshotLease(m.sourceId,m.snapshotId,m.digest,m.sequence)
            mayAuthorizeOfflineCopy=true
            showSelected("已创建 ${m.totalRows} 条；尚未授权发送")
        } }
        button("2. 允许发送并在完成后更新账迹看板") { runTask {
            requireFeatures()
            if(!mayAuthorizeOfflineCopy){status.text="新授权必须先创建新快照；已有有效授权请用继续，过期或撤销后需重新创建";return@runTask}
            mayAuthorizeOfflineCopy=false // Consume the fresh capture even if authorization fails or is cancelled.
            val lease=checkNotNull(selected)
            val grant=LocalSnapshotGrantActions.authorizeFromUserButton(this@DashboardSnapshotActivity,lease)
            transfer(grant)
        } }
        button("继续已有有效授权，从头幂等重发") { runTask {
            requireFeatures()
            val grant=withContext(Dispatchers.IO){checkNotNull(store().current(System.currentTimeMillis()))}
            check(selected==grant.lease)
            transfer(grant)
        } }
        layout.addView(Button(this).apply{text="停止传输";setOnClickListener{task?.cancel();status.text="正在停止；已接收或在途副本可能仍会完成并更新看板"}})
        layout.addView(Button(this).apply{text="撤销该份授权";setOnClickListener{
            mayAuthorizeOfflineCopy=false
            val version=++taskVersion
            task?.cancel()
            buttons.forEach{it.isEnabled=false}
            task=scope.launch {
                // Do not wait for blocked remote Binder: revoke is a local durable write.
                try{LocalSnapshotGrantActions.revokeFromUserButton(this@DashboardSnapshotActivity);if(version==taskVersion)status.text="后续传输授权已撤销；已接收或在途副本可能已完成，不删除接收副本"}
                catch(_:Exception){if(version==taskVersion)status.text="撤销未能确认，请停止操作并核查存储，不要清数据"}
                finally{if(version==taskVersion)buttons.forEachIndexed{index,button->button.isEnabled=index!=1||mayAuthorizeOfflineCopy}}
            }
        }})
        layout.addView(Button(this).apply{text="自动更新本机看板（单独授权）";setOnClickListener{startActivity(android.content.Intent(this@DashboardSnapshotActivity,DashboardAutomaticCopyActivity::class.java))}})
        setContentView(ScrollView(this).apply{addView(layout)})
        // Recovery is read-only; no grant renewal or transfer on Activity launch.
        runTask {
            val stored=withContext(Dispatchers.IO){store().storedForDisplay()}
            selected=stored?.lease
            mayAuthorizeOfflineCopy=false
            showSelected("已恢复快照信息，未发送。已有有效授权只能继续；新授权、过期或撤销后必须先创建新快照")
        }
    }
    private fun requireFeatures(){check(PrefManager.featureFee && PrefManager.featureAssetManage)}
    private fun showSelected(prefix:String) {
        status.text=selected?.let{"$prefix\n快照：${it.snapshotId}\n来源：${it.sourceId}\n序号：${it.sequence}\n摘要：${it.digest}"}?:"没有可继续的快照，请先创建"
    }
    private suspend fun transfer(grant:LocalSnapshotGrant) {
        LocalSnapshotTransferClient(this).transfer(grant){count->withContext(Dispatchers.Main){status.text="已确认接收 $count 条，正在完成同步"}}
        currentCoroutineContext().ensureActive()
        status.text=if(grant.contract==LocalSnapshotGrantStore.OFFLINE_COPY_CONTRACT) "完整副本已接收并选为账迹当前看板。源账单未修改。" else "旧授权副本仅暂存，未更新看板；请创建新快照后明确授权"
    }
    private fun runTask(block:suspend ()->Unit) {
        if(task?.isActive==true)return
        val version=++taskVersion
        buttons.forEach{it.isEnabled=false}
        task=scope.launch {
            try{block()}
            catch(e:CancellationException){if(version==taskVersion)status.text="已停止后续传输；已接收或在途副本可能已完成并更新看板。可查看账迹确认";throw e}
            catch(_:Exception){if(version==taskVersion)status.text="未能确认本轮完成，接收副本可能已提交，请先查看账迹。请检查自动记账本机服务、费用/资产开关、授权是否过期、来源是否变化或记录是否过大。不要卸载或清数据；保留暂存以便核查"}
            finally{if(version==taskVersion)buttons.forEachIndexed{index,button->button.isEnabled=index!=1||mayAuthorizeOfflineCopy}}
        }
    }
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}
