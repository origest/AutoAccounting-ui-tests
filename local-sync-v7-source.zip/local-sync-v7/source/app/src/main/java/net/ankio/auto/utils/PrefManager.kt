package net.ankio.auto.utils
import android.content.Context
import android.content.SharedPreferences
/** Synthetic-only settings, not user's MMKV. */
object PrefManager {
 private lateinit var prefs:SharedPreferences
 fun init(c:Context){prefs=c.getSharedPreferences("synthetic-v7-features",Context.MODE_PRIVATE)}
 var featureFee:Boolean
  get()=prefs.getBoolean("fee",false)
  set(value){check(prefs.edit().putBoolean("fee",value).commit())}
 var featureAssetManage:Boolean
  get()=prefs.getBoolean("asset",false)
  set(value){check(prefs.edit().putBoolean("asset",value).commit())}
}
