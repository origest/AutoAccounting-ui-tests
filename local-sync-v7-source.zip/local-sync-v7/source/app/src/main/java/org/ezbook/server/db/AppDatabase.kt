package org.ezbook.server.db

import androidx.room.*
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.constant.BillState
import org.ezbook.server.constant.BillType

/** QA-only wiring, NOT the production Room25 schema or migration graph. */
@Database(entities=[BillInfoModel::class,LocalLedgerClock::class,LocalLedgerChange::class,LocalFrozenManifest::class,LocalFrozenRow::class],version=1,exportSchema=false)
@TypeConverters(QaConverters::class)
abstract class AppDatabase:RoomDatabase(){abstract fun billInfoDao():QaBillDao;abstract fun localFrozenDao():LocalFrozenDao}
class QaConverters {
 @TypeConverter fun state(value:String)=BillState.valueOf(value)
 @TypeConverter fun state(value:BillState)=value.name
 @TypeConverter fun type(value:String)=BillType.valueOf(value)
 @TypeConverter fun type(value:BillType)=value.name
}
@Dao interface QaBillDao {
 @Query("SELECT * FROM BillInfoModel WHERE id = :id") suspend fun queryId(id:Long):BillInfoModel?
 @Query("SELECT id FROM BillInfoModel WHERE id > :after ORDER BY id LIMIT :limit") suspend fun localSnapshotIds(after:Long,limit:Int):List<Long>
 @Query("SELECT length(CAST(`id` AS BLOB)) + length(CAST(`type` AS BLOB)) + length(CAST(`currency` AS BLOB)) + length(CAST(`money` AS BLOB)) + length(CAST(`fee` AS BLOB)) + length(CAST(`time` AS BLOB)) + length(CAST(`shopName` AS BLOB)) + length(CAST(`shopItem` AS BLOB)) + length(CAST(`cateName` AS BLOB)) + length(CAST(`extendData` AS BLOB)) + length(CAST(`bookName` AS BLOB)) + length(CAST(`accountNameFrom` AS BLOB)) + length(CAST(`accountNameTo` AS BLOB)) + length(CAST(`app` AS BLOB)) + length(CAST(`groupId` AS BLOB)) + length(CAST(`channel` AS BLOB)) + length(CAST(`state` AS BLOB)) + length(CAST(`remark` AS BLOB)) + length(CAST(`auto` AS BLOB)) + length(CAST(`ruleName` AS BLOB)) + length(CAST(`tags` AS BLOB)) + length(CAST(`flag` AS BLOB)) + length(CAST(`rawAccountNameFrom` AS BLOB)) + length(CAST(`rawAccountNameTo` AS BLOB)) + length(CAST(`pendingCategory` AS BLOB)) + length(CAST(`categoryOrigin` AS BLOB)) + length(CAST(`categoryRevision` AS BLOB)) FROM BillInfoModel WHERE id=:id") suspend fun localSnapshotRawBytes(id:Long):Long?
 @Insert suspend fun insert(bill:BillInfoModel):Long
 @Update suspend fun update(bill:BillInfoModel)
 @Query("SELECT COUNT(*) FROM BillInfoModel") suspend fun count():Int
}
