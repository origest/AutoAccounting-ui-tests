package org.ezbook.server.db

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/** QA-only lifecycle/source identity; production import/restore fences are NOT tested by this adapter. */
object Db {
 private val lifecycle=Mutex()
 private lateinit var db:AppDatabase
 private lateinit var context:Context
 fun init(c:Context){context=c.applicationContext;db=Room.databaseBuilder(context,AppDatabase::class.java,"synthetic-v7-qa.db").addCallback(LocalLedgerSequence.CALLBACK).build()}
 suspend fun <T> withLocalSyncDatabase(block:suspend(AppDatabase)->T):T=lifecycle.withLock{block(db)}
 suspend fun localSyncGeneration(database:AppDatabase):String {
  check(database===db)
  val prefs=context.getSharedPreferences("synthetic-v7-generation",Context.MODE_PRIVATE)
  val old=prefs.getString("source",null)
  if(old!=null){require(UUID.fromString(old).toString()==old);return old}
  val fresh=UUID.randomUUID().toString();check(prefs.edit().putString("source",fresh).commit());return fresh
 }
}
