package org.ezbook.server.db

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.google.gson.Gson
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID

@Entity
data class LocalFrozenManifest(@PrimaryKey val snapshotId:String,val sourceId:String,val sequence:Long,
    val capturedAt:Long,val totalRows:Int,val totalBytes:Long,val digest:String)
@Entity(primaryKeys=["snapshotId","billId"])
data class LocalFrozenRow(val snapshotId:String,val billId:Long,val payload:String)
@Dao interface LocalFrozenDao {
    @Insert suspend fun manifest(value:LocalFrozenManifest)
    @Insert suspend fun row(value:LocalFrozenRow)
    @Query("SELECT * FROM LocalFrozenManifest WHERE snapshotId=:id") suspend fun manifest(id:String):LocalFrozenManifest?
    @Query("SELECT * FROM LocalFrozenRow WHERE snapshotId=:id AND billId>:after ORDER BY billId LIMIT :limit")
    suspend fun page(id:String,after:Long,limit:Int):List<LocalFrozenRow>
    @Query("SELECT COALESCE(SUM(totalBytes),0) FROM LocalFrozenManifest") suspend fun retainedBytes():Long
}

data class LocalSnapshotLease(val source_id:String,val snapshot_id:String,val digest:String,val sequence:Long,
    val observed_at:Long,val valid:Boolean)

/** Internal raw capture kernel ONLY: not exposed through IPC/HTTP/UI. Transport projection pending. */
object LocalFrozenSnapshot {
    const val MAX_ROWS=20000
    const val MAX_PAYLOAD_BYTES=256*1024
    const val MAX_PAGE_BYTES=1024*1024
    const val MAX_SNAPSHOT_BYTES=32L*1024*1024
    const val MAX_RETAINED_BYTES=128L*1024*1024
    val MIGRATION_24_25=object:Migration(24,25) {
        override fun migrate(db:SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `LocalFrozenManifest` (`snapshotId` TEXT NOT NULL, `sourceId` TEXT NOT NULL, `sequence` INTEGER NOT NULL, `capturedAt` INTEGER NOT NULL, `totalRows` INTEGER NOT NULL, `totalBytes` INTEGER NOT NULL, `digest` TEXT NOT NULL, PRIMARY KEY(`snapshotId`))")
            db.execSQL("CREATE TABLE IF NOT EXISTS `LocalFrozenRow` (`snapshotId` TEXT NOT NULL, `billId` INTEGER NOT NULL, `payload` TEXT NOT NULL, PRIMARY KEY(`snapshotId`, `billId`))")
        }
    }
    fun updateDigest(digest:MessageDigest,id:Long,payload:ByteArray) {
        val idBytes=id.toString().toByteArray(Charsets.US_ASCII)
        for(bytes in listOf(idBytes,payload)){digest.update(ByteBuffer.allocate(4).putInt(bytes.size).array());digest.update(bytes)}
    }
    /** Production entry when a future UI explicitly requests raw capture. No network transfer. */
    suspend fun captureCurrent():LocalFrozenManifest=Db.withLocalSyncDatabase { db ->
        db.withTransaction { capture(db,Db.localSyncGeneration(db),System.currentTimeMillis()) }
    }
    /** Local automatic reconciliation reads authoritative sequence without making a copy. */
    suspend fun currentVersion():Pair<String,Long> = Db.withLocalSyncDatabase { db -> db.withTransaction {
        LocalLedgerSequence.validate(db.openHelper.writableDatabase)
        Db.localSyncGeneration(db) to db.openHelper.writableDatabase.query("SELECT sequence FROM LocalLedgerClock WHERE id=1").use{it.moveToFirst();it.getLong(0)}
    } }
    /** Persist the chosen ID before capture; retry after a crash reuses its committed immutable manifest. */
    suspend fun captureReserved(snapshotId:String,expectedSource:String):LocalFrozenManifest=Db.withLocalSyncDatabase { db -> db.withTransaction {
        require(UUID.fromString(snapshotId).toString()==snapshotId)
        check(Db.localSyncGeneration(db)==expectedSource){"LOCAL_SNAPSHOT_SOURCE_CHANGED"}
        captureReserved(db,snapshotId,expectedSource,System.currentTimeMillis())
    } }
    internal suspend fun captureReserved(db:AppDatabase,snapshotId:String,source:String,now:Long):LocalFrozenManifest=db.withTransaction {
        require(UUID.fromString(snapshotId).toString()==snapshotId)
        val existing=db.localFrozenDao().manifest(snapshotId)
        if(existing!=null){check(existing.sourceId==source);existing}
        else capture(db,source,now,snapshotId=snapshotId)
    }
    /** test seam permits deterministic concurrent-write/cancellation checks on synthetic DBs. */
    internal suspend fun capture(db:AppDatabase,sourceId:String,capturedAt:Long,
        snapshotId:String=UUID.randomUUID().toString(),afterRow:suspend ()->Unit={}):LocalFrozenManifest=db.withTransaction {
        require(UUID.fromString(sourceId).toString()==sourceId && capturedAt>=0)
        val sqlite=db.openHelper.writableDatabase
        LocalLedgerSequence.validate(sqlite)
        val sequence=sqlite.query("SELECT sequence FROM LocalLedgerClock WHERE id=1").use {it.moveToFirst();it.getLong(0)}
        val count=sqlite.query("SELECT COUNT(*) FROM BillInfoModel").use {it.moveToFirst();it.getLong(0)}
        require(count<=MAX_ROWS){"LOCAL_SNAPSHOT_ROW_LIMIT"}
        val manifests=sqlite.query("SELECT COUNT(*) FROM LocalFrozenManifest").use {it.moveToFirst();it.getLong(0)}
        require(manifests<1000){"LOCAL_SNAPSHOT_MANIFEST_LIMIT"}
        val retained=db.localFrozenDao().retainedBytes()
        require(retained<=MAX_RETAINED_BYTES){"LOCAL_SNAPSHOT_RETAINED_LIMIT"}
        val snapshot=snapshotId;val digest=MessageDigest.getInstance("SHA-256");val gson=Gson()
        var after=0L;var bytes=0L;var rows=0;val started=System.nanoTime()
        while(true) {
            currentCoroutineContext().ensureActive()
            check(System.nanoTime()-started<10_000_000_000L){"LOCAL_SNAPSHOT_CAPTURE_TIMEOUT"}
            val ids=db.billInfoDao().localSnapshotIds(after,100)
            if(ids.isEmpty())break
            for(id in ids) {
                currentCoroutineContext().ensureActive()
                check(System.nanoTime()-started<10_000_000_000L){"LOCAL_SNAPSHOT_CAPTURE_TIMEOUT"}
                require(id>after)
                require(checkNotNull(db.billInfoDao().localSnapshotRawBytes(id))<=MAX_PAYLOAD_BYTES){"LOCAL_SNAPSHOT_RAW_RECORD_LIMIT"}
                val bill=checkNotNull(db.billInfoDao().queryId(id))
                val payload=gson.toJson(bill);val utf8=payload.toByteArray(Charsets.UTF_8)
                require(utf8.size<=MAX_PAYLOAD_BYTES){"LOCAL_SNAPSHOT_RECORD_LIMIT"}
                bytes+=utf8.size
                require(bytes<=MAX_SNAPSHOT_BYTES && retained+bytes<=MAX_RETAINED_BYTES){"LOCAL_SNAPSHOT_BYTE_LIMIT"}
                db.localFrozenDao().row(LocalFrozenRow(snapshot,id,payload))
                updateDigest(digest,id,utf8);rows++;after=id;afterRow()
            }
        }
        check(rows.toLong()==count){"LOCAL_SNAPSHOT_COUNT_CHANGED"}
        val result=LocalFrozenManifest(snapshot,sourceId,sequence,capturedAt,rows,bytes,digest.digest().joinToString(""){"%02x".format(it)})
        db.localFrozenDao().manifest(result) // Visibility only after the surrounding transaction commits.
        result
    }
    internal fun requireCurrentSource(expected:String,current:String,manifestSource:String) {
        require(UUID.fromString(expected).toString()==expected)
        check(expected==current && current==manifestSource){"LOCAL_SNAPSHOT_SOURCE_CHANGED"}
    }
    /** Future delivery must use this lease check, never the raw archival page reader below. */
    suspend fun pageCurrent(snapshotId:String,expectedSource:String,after:Long,limit:Int=100):Page=
        Db.withLocalSyncDatabase { db -> db.withTransaction {
            val manifest=checkNotNull(db.localFrozenDao().manifest(snapshotId)){"LOCAL_SNAPSHOT_NOT_COMPLETE"}
            requireCurrentSource(expectedSource,Db.localSyncGeneration(db),manifest.sourceId)
            page(db,snapshotId,after,limit)
        } }
    /** Point-in-time metadata check only; this is NOT a lock spanning a later remote activation. */
    suspend fun currentLease(sourceId:String,snapshotId:String,verifyContent:Boolean=false):LocalSnapshotLease=Db.withLocalSyncDatabase { db ->
        db.withTransaction {
            val m=checkNotNull(db.localFrozenDao().manifest(snapshotId)){"LOCAL_SNAPSHOT_NOT_COMPLETE"}
            requireCurrentSource(sourceId,Db.localSyncGeneration(db),m.sourceId)
            if(verifyContent)verifyFrozen(db,m) // Avoid O(number-of-pages × full-snapshot) hashing during transport.
            LocalSnapshotLease(m.sourceId,m.snapshotId,m.digest,m.sequence,System.currentTimeMillis(),true)
        }
    }
    /** Cursor verification bounds memory; no payload leaves this function. */
    internal fun verifyFrozen(db:AppDatabase,m:LocalFrozenManifest) {
        require(m.totalRows in 0..MAX_ROWS && m.totalBytes in 0..MAX_SNAPSHOT_BYTES)
        val digest=MessageDigest.getInstance("SHA-256");var count=0;var total=0L;var previous=0L
        db.openHelper.writableDatabase.query("SELECT billId,payload FROM LocalFrozenRow WHERE snapshotId=? ORDER BY billId",arrayOf(m.snapshotId)).use { c ->
            while(c.moveToNext()) {
                val id=c.getLong(0);require(id>previous && count<MAX_ROWS)
                val payload=c.getString(1).toByteArray(Charsets.UTF_8);require(payload.size<=MAX_PAYLOAD_BYTES)
                total+=payload.size;require(total<=m.totalBytes);updateDigest(digest,id,payload);count++;previous=id
            }
        }
        check(count==m.totalRows && total==m.totalBytes && digest.digest().joinToString(""){"%02x".format(it)}==m.digest){"LOCAL_SNAPSHOT_CORRUPT"}
    }
    data class Page(val manifest:LocalFrozenManifest,val rows:List<LocalFrozenRow>,val next:Long,val done:Boolean)
    internal suspend fun page(db:AppDatabase,snapshotId:String,after:Long,limit:Int=100):Page=db.withTransaction {
        require(UUID.fromString(snapshotId).toString()==snapshotId && after>=0 && limit in 1..100)
        val manifest=checkNotNull(db.localFrozenDao().manifest(snapshotId)){"LOCAL_SNAPSHOT_NOT_COMPLETE"}
        // Do not materialize limit+1 Room entities before enforcing the byte budget:
        // 101 individually valid rows can otherwise allocate >25 MiB per page.
        val rows=ArrayList<LocalFrozenRow>();var bytes=0;var done=true
        db.openHelper.writableDatabase.query(
            "SELECT billId,payload FROM LocalFrozenRow WHERE snapshotId=? AND billId>? ORDER BY billId LIMIT ?",
            arrayOf<Any>(snapshotId,after,limit+1)
        ).use { c ->
            while(c.moveToNext()) {
                currentCoroutineContext().ensureActive()
                if(rows.size==limit){done=false;break}
                val id=c.getLong(0);val payload=c.getString(1)
                val raw=payload.toByteArray(Charsets.UTF_8).size
                require(raw<=MAX_PAYLOAD_BYTES){"LOCAL_SNAPSHOT_RECORD_LIMIT"}
                val size=raw+id.toString().length+8
                if(bytes+size>MAX_PAGE_BYTES){done=false;break}
                rows.add(LocalFrozenRow(snapshotId,id,payload));bytes+=size
            }
        }
        check(done || rows.isNotEmpty()){"LOCAL_SNAPSHOT_PAGE_STALLED"}
        Page(manifest,rows,rows.lastOrNull()?.billId?:after,done)
    }
}
