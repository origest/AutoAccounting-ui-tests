package org.ezbook.server.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity
data class LocalLedgerClock(@PrimaryKey val id: Int, val sequence: Long)

/** Immutable raw SQLite images; no enum converters or lossy projection. */
@Entity(primaryKeys = ["sequence", "image", "bill_id"])
data class LocalLedgerChange(
    val sequence: Long,
    val image: String,
    val operation: String,
    val bill_id: Long,
    val bill_type: String,
    val bill_currency: String,
    val bill_money: Double,
    val bill_fee: Double,
    val bill_time: Long,
    val bill_shopName: String,
    val bill_shopItem: String,
    val bill_cateName: String,
    val bill_extendData: String,
    val bill_bookName: String,
    val bill_accountNameFrom: String,
    val bill_accountNameTo: String,
    val bill_app: String,
    val bill_groupId: Long,
    val bill_channel: String,
    val bill_state: String,
    val bill_remark: String,
    val bill_auto: Long,
    val bill_ruleName: String,
    val bill_tags: String,
    val bill_flag: Long,
    val bill_rawAccountNameFrom: String,
    val bill_rawAccountNameTo: String,
    val bill_pendingCategory: String,
    val bill_categoryOrigin: String,
    val bill_categoryRevision: Long
)

/** Additive archive only. Does not make multi-write grouping atomic, or implement a mirror. */
object LocalLedgerSequence {
    private const val CREATE_CLOCK = """CREATE TABLE IF NOT EXISTS `LocalLedgerClock` (`id` INTEGER NOT NULL, `sequence` INTEGER NOT NULL, PRIMARY KEY(`id`))"""
    private const val CREATE_ARCHIVE = """CREATE TABLE IF NOT EXISTS `LocalLedgerChange` (`sequence` INTEGER NOT NULL, `image` TEXT NOT NULL, `operation` TEXT NOT NULL, `bill_id` INTEGER NOT NULL, `bill_type` TEXT NOT NULL, `bill_currency` TEXT NOT NULL, `bill_money` REAL NOT NULL, `bill_fee` REAL NOT NULL, `bill_time` INTEGER NOT NULL, `bill_shopName` TEXT NOT NULL, `bill_shopItem` TEXT NOT NULL, `bill_cateName` TEXT NOT NULL, `bill_extendData` TEXT NOT NULL, `bill_bookName` TEXT NOT NULL, `bill_accountNameFrom` TEXT NOT NULL, `bill_accountNameTo` TEXT NOT NULL, `bill_app` TEXT NOT NULL, `bill_groupId` INTEGER NOT NULL, `bill_channel` TEXT NOT NULL, `bill_state` TEXT NOT NULL, `bill_remark` TEXT NOT NULL, `bill_auto` INTEGER NOT NULL, `bill_ruleName` TEXT NOT NULL, `bill_tags` TEXT NOT NULL, `bill_flag` INTEGER NOT NULL, `bill_rawAccountNameFrom` TEXT NOT NULL, `bill_rawAccountNameTo` TEXT NOT NULL, `bill_pendingCategory` TEXT NOT NULL, `bill_categoryOrigin` TEXT NOT NULL, `bill_categoryRevision` INTEGER NOT NULL, PRIMARY KEY(`sequence`, `image`, `bill_id`))"""
    private const val BASELINE = """INSERT INTO `LocalLedgerChange` (`sequence`, `image`, `operation`, `bill_id`, `bill_type`, `bill_currency`, `bill_money`, `bill_fee`, `bill_time`, `bill_shopName`, `bill_shopItem`, `bill_cateName`, `bill_extendData`, `bill_bookName`, `bill_accountNameFrom`, `bill_accountNameTo`, `bill_app`, `bill_groupId`, `bill_channel`, `bill_state`, `bill_remark`, `bill_auto`, `bill_ruleName`, `bill_tags`, `bill_flag`, `bill_rawAccountNameFrom`, `bill_rawAccountNameTo`, `bill_pendingCategory`, `bill_categoryOrigin`, `bill_categoryRevision`) SELECT 0, 'BASELINE', 'BASELINE', `id`, `type`, `currency`, `money`, `fee`, `time`, `shopName`, `shopItem`, `cateName`, `extendData`, `bookName`, `accountNameFrom`, `accountNameTo`, `app`, `groupId`, `channel`, `state`, `remark`, `auto`, `ruleName`, `tags`, `flag`, `rawAccountNameFrom`, `rawAccountNameTo`, `pendingCategory`, `categoryOrigin`, `categoryRevision` FROM `BillInfoModel`"""
    private val triggers = linkedMapOf(
        "local_ledger_bill_insert" to """CREATE TRIGGER `local_ledger_bill_insert` AFTER INSERT ON `BillInfoModel` BEGIN
SELECT CASE WHEN (SELECT COUNT(*) FROM `LocalLedgerClock`) != 1 OR NOT EXISTS (SELECT 1 FROM `LocalLedgerClock` WHERE `id` = 1 AND typeof(`sequence`) = 'integer' AND `sequence` >= 0 AND `sequence` < 9223372036854775807 AND `sequence` = (SELECT COALESCE(MAX(`sequence`), 0) FROM `LocalLedgerChange`)) THEN RAISE(ABORT, 'LOCAL_LEDGER_CLOCK_INVALID_OR_EXHAUSTED') END;
UPDATE `LocalLedgerClock` SET `sequence` = `sequence` + 1 WHERE `id` = 1;
INSERT INTO `LocalLedgerChange` (`sequence`, `image`, `operation`, `bill_id`, `bill_type`, `bill_currency`, `bill_money`, `bill_fee`, `bill_time`, `bill_shopName`, `bill_shopItem`, `bill_cateName`, `bill_extendData`, `bill_bookName`, `bill_accountNameFrom`, `bill_accountNameTo`, `bill_app`, `bill_groupId`, `bill_channel`, `bill_state`, `bill_remark`, `bill_auto`, `bill_ruleName`, `bill_tags`, `bill_flag`, `bill_rawAccountNameFrom`, `bill_rawAccountNameTo`, `bill_pendingCategory`, `bill_categoryOrigin`, `bill_categoryRevision`) SELECT `sequence`, 'NEW', 'INSERT', NEW.`id`, NEW.`type`, NEW.`currency`, NEW.`money`, NEW.`fee`, NEW.`time`, NEW.`shopName`, NEW.`shopItem`, NEW.`cateName`, NEW.`extendData`, NEW.`bookName`, NEW.`accountNameFrom`, NEW.`accountNameTo`, NEW.`app`, NEW.`groupId`, NEW.`channel`, NEW.`state`, NEW.`remark`, NEW.`auto`, NEW.`ruleName`, NEW.`tags`, NEW.`flag`, NEW.`rawAccountNameFrom`, NEW.`rawAccountNameTo`, NEW.`pendingCategory`, NEW.`categoryOrigin`, NEW.`categoryRevision` FROM `LocalLedgerClock` WHERE `id` = 1;
END""",
        "local_ledger_bill_update" to """CREATE TRIGGER `local_ledger_bill_update` AFTER UPDATE ON `BillInfoModel` BEGIN
SELECT CASE WHEN (SELECT COUNT(*) FROM `LocalLedgerClock`) != 1 OR NOT EXISTS (SELECT 1 FROM `LocalLedgerClock` WHERE `id` = 1 AND typeof(`sequence`) = 'integer' AND `sequence` >= 0 AND `sequence` < 9223372036854775807 AND `sequence` = (SELECT COALESCE(MAX(`sequence`), 0) FROM `LocalLedgerChange`)) THEN RAISE(ABORT, 'LOCAL_LEDGER_CLOCK_INVALID_OR_EXHAUSTED') END;
UPDATE `LocalLedgerClock` SET `sequence` = `sequence` + 1 WHERE `id` = 1;
INSERT INTO `LocalLedgerChange` (`sequence`, `image`, `operation`, `bill_id`, `bill_type`, `bill_currency`, `bill_money`, `bill_fee`, `bill_time`, `bill_shopName`, `bill_shopItem`, `bill_cateName`, `bill_extendData`, `bill_bookName`, `bill_accountNameFrom`, `bill_accountNameTo`, `bill_app`, `bill_groupId`, `bill_channel`, `bill_state`, `bill_remark`, `bill_auto`, `bill_ruleName`, `bill_tags`, `bill_flag`, `bill_rawAccountNameFrom`, `bill_rawAccountNameTo`, `bill_pendingCategory`, `bill_categoryOrigin`, `bill_categoryRevision`) SELECT `sequence`, 'OLD', 'UPDATE', OLD.`id`, OLD.`type`, OLD.`currency`, OLD.`money`, OLD.`fee`, OLD.`time`, OLD.`shopName`, OLD.`shopItem`, OLD.`cateName`, OLD.`extendData`, OLD.`bookName`, OLD.`accountNameFrom`, OLD.`accountNameTo`, OLD.`app`, OLD.`groupId`, OLD.`channel`, OLD.`state`, OLD.`remark`, OLD.`auto`, OLD.`ruleName`, OLD.`tags`, OLD.`flag`, OLD.`rawAccountNameFrom`, OLD.`rawAccountNameTo`, OLD.`pendingCategory`, OLD.`categoryOrigin`, OLD.`categoryRevision` FROM `LocalLedgerClock` WHERE `id` = 1;
INSERT INTO `LocalLedgerChange` (`sequence`, `image`, `operation`, `bill_id`, `bill_type`, `bill_currency`, `bill_money`, `bill_fee`, `bill_time`, `bill_shopName`, `bill_shopItem`, `bill_cateName`, `bill_extendData`, `bill_bookName`, `bill_accountNameFrom`, `bill_accountNameTo`, `bill_app`, `bill_groupId`, `bill_channel`, `bill_state`, `bill_remark`, `bill_auto`, `bill_ruleName`, `bill_tags`, `bill_flag`, `bill_rawAccountNameFrom`, `bill_rawAccountNameTo`, `bill_pendingCategory`, `bill_categoryOrigin`, `bill_categoryRevision`) SELECT `sequence`, 'NEW', 'UPDATE', NEW.`id`, NEW.`type`, NEW.`currency`, NEW.`money`, NEW.`fee`, NEW.`time`, NEW.`shopName`, NEW.`shopItem`, NEW.`cateName`, NEW.`extendData`, NEW.`bookName`, NEW.`accountNameFrom`, NEW.`accountNameTo`, NEW.`app`, NEW.`groupId`, NEW.`channel`, NEW.`state`, NEW.`remark`, NEW.`auto`, NEW.`ruleName`, NEW.`tags`, NEW.`flag`, NEW.`rawAccountNameFrom`, NEW.`rawAccountNameTo`, NEW.`pendingCategory`, NEW.`categoryOrigin`, NEW.`categoryRevision` FROM `LocalLedgerClock` WHERE `id` = 1;
END""",
        "local_ledger_bill_delete" to """CREATE TRIGGER `local_ledger_bill_delete` AFTER DELETE ON `BillInfoModel` BEGIN
SELECT CASE WHEN (SELECT COUNT(*) FROM `LocalLedgerClock`) != 1 OR NOT EXISTS (SELECT 1 FROM `LocalLedgerClock` WHERE `id` = 1 AND typeof(`sequence`) = 'integer' AND `sequence` >= 0 AND `sequence` < 9223372036854775807 AND `sequence` = (SELECT COALESCE(MAX(`sequence`), 0) FROM `LocalLedgerChange`)) THEN RAISE(ABORT, 'LOCAL_LEDGER_CLOCK_INVALID_OR_EXHAUSTED') END;
UPDATE `LocalLedgerClock` SET `sequence` = `sequence` + 1 WHERE `id` = 1;
INSERT INTO `LocalLedgerChange` (`sequence`, `image`, `operation`, `bill_id`, `bill_type`, `bill_currency`, `bill_money`, `bill_fee`, `bill_time`, `bill_shopName`, `bill_shopItem`, `bill_cateName`, `bill_extendData`, `bill_bookName`, `bill_accountNameFrom`, `bill_accountNameTo`, `bill_app`, `bill_groupId`, `bill_channel`, `bill_state`, `bill_remark`, `bill_auto`, `bill_ruleName`, `bill_tags`, `bill_flag`, `bill_rawAccountNameFrom`, `bill_rawAccountNameTo`, `bill_pendingCategory`, `bill_categoryOrigin`, `bill_categoryRevision`) SELECT `sequence`, 'OLD', 'DELETE', OLD.`id`, OLD.`type`, OLD.`currency`, OLD.`money`, OLD.`fee`, OLD.`time`, OLD.`shopName`, OLD.`shopItem`, OLD.`cateName`, OLD.`extendData`, OLD.`bookName`, OLD.`accountNameFrom`, OLD.`accountNameTo`, OLD.`app`, OLD.`groupId`, OLD.`channel`, OLD.`state`, OLD.`remark`, OLD.`auto`, OLD.`ruleName`, OLD.`tags`, OLD.`flag`, OLD.`rawAccountNameFrom`, OLD.`rawAccountNameTo`, OLD.`pendingCategory`, OLD.`categoryOrigin`, OLD.`categoryRevision` FROM `LocalLedgerClock` WHERE `id` = 1;
END"""
    )
    private val billColumns = linkedMapOf("id" to "INTEGER", "type" to "TEXT", "currency" to "TEXT", "money" to "REAL", "fee" to "REAL", "time" to "INTEGER", "shopName" to "TEXT", "shopItem" to "TEXT", "cateName" to "TEXT", "extendData" to "TEXT", "bookName" to "TEXT", "accountNameFrom" to "TEXT", "accountNameTo" to "TEXT", "app" to "TEXT", "groupId" to "INTEGER", "channel" to "TEXT", "state" to "TEXT", "remark" to "TEXT", "auto" to "INTEGER", "ruleName" to "TEXT", "tags" to "TEXT", "flag" to "INTEGER", "rawAccountNameFrom" to "TEXT", "rawAccountNameTo" to "TEXT", "pendingCategory" to "TEXT", "categoryOrigin" to "TEXT", "categoryRevision" to "INTEGER")
    private val archiveColumns = linkedMapOf("sequence" to "INTEGER", "image" to "TEXT", "operation" to "TEXT", "bill_id" to "INTEGER", "bill_type" to "TEXT", "bill_currency" to "TEXT", "bill_money" to "REAL", "bill_fee" to "REAL", "bill_time" to "INTEGER", "bill_shopName" to "TEXT", "bill_shopItem" to "TEXT", "bill_cateName" to "TEXT", "bill_extendData" to "TEXT", "bill_bookName" to "TEXT", "bill_accountNameFrom" to "TEXT", "bill_accountNameTo" to "TEXT", "bill_app" to "TEXT", "bill_groupId" to "INTEGER", "bill_channel" to "TEXT", "bill_state" to "TEXT", "bill_remark" to "TEXT", "bill_auto" to "INTEGER", "bill_ruleName" to "TEXT", "bill_tags" to "TEXT", "bill_flag" to "INTEGER", "bill_rawAccountNameFrom" to "TEXT", "bill_rawAccountNameTo" to "TEXT", "bill_pendingCategory" to "TEXT", "bill_categoryOrigin" to "TEXT", "bill_categoryRevision" to "INTEGER")

    val MIGRATION_23_24: Migration = object : Migration(23, 24) {
        override fun migrate(db: SupportSQLiteDatabase) = install(db)
    }
    val CALLBACK: RoomDatabase.Callback = object : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) = install(db)
        override fun onOpen(db: SupportSQLiteDatabase) = validate(db)
    }

    /** Call inside Room's migration/create transaction. Existing archive is never reset. */
    fun install(db: SupportSQLiteDatabase) {
        db.execSQL("PRAGMA recursive_triggers = ON")
        db.execSQL(CREATE_CLOCK)
        db.execSQL(CREATE_ARCHIVE)
        validateColumns(db, "BillInfoModel", billColumns, listOf("id"))
        validateColumns(db, "LocalLedgerClock", linkedMapOf("id" to "INTEGER", "sequence" to "INTEGER"), listOf("id"))
        validateColumns(db, "LocalLedgerChange", archiveColumns, listOf("sequence", "image", "bill_id"))
        val initialized = scalar(db, "SELECT COUNT(*) FROM LocalLedgerClock")
        if (initialized == 0L) {
            check(scalar(db, "SELECT COUNT(*) FROM LocalLedgerChange") == 0L) { "LOCAL_LEDGER_ORPHAN_ARCHIVE" }
            check(triggerDefinitions(db).isEmpty()) { "LOCAL_LEDGER_ORPHAN_TRIGGERS" }
            db.execSQL("INSERT INTO LocalLedgerClock(id, sequence) VALUES (1, 0)")
            db.execSQL(BASELINE)
            triggers.values.forEach { db.execSQL(it) }
        }
        validate(db)
    }

    /** Fail closed rather than silently repairing missing/altered capture history. */
    fun validate(db: SupportSQLiteDatabase) {
        db.execSQL("PRAGMA recursive_triggers = ON")
        check(scalar(db, "PRAGMA recursive_triggers") == 1L) { "LOCAL_LEDGER_RECURSION_DISABLED" }
        validateColumns(db, "BillInfoModel", billColumns, listOf("id"))
        validateColumns(db, "LocalLedgerClock", linkedMapOf("id" to "INTEGER", "sequence" to "INTEGER"), listOf("id"))
        validateColumns(db, "LocalLedgerChange", archiveColumns, listOf("sequence", "image", "bill_id"))
        check(scalar(db, "SELECT COUNT(*) FROM LocalLedgerClock") == 1L &&
            scalar(db, "SELECT COUNT(*) FROM LocalLedgerClock WHERE id = 1 AND typeof(sequence) = 'integer' AND sequence >= 0 AND sequence = (SELECT COALESCE(MAX(sequence), 0) FROM LocalLedgerChange)") == 1L) {
            "LOCAL_LEDGER_CLOCK_INVALID"
        }
        check(triggerDefinitions(db).mapValues { normalize(it.value) } == triggers.mapValues { normalize(it.value) }) {
            "LOCAL_LEDGER_TRIGGER_MISMATCH"
        }
    }

    private fun normalize(sql: String) = sql.trim().replace(Regex("\\s+"), " ")
    private fun scalar(db: SupportSQLiteDatabase, sql: String): Long = db.query(sql).use {
        check(it.moveToFirst()); it.getLong(0)
    }
    private fun triggerDefinitions(db: SupportSQLiteDatabase): Map<String, String> =
        db.query("SELECT name, sql FROM sqlite_master WHERE type = 'trigger' AND name LIKE 'local_ledger_bill_%'").use { cursor ->
            val result = linkedMapOf<String, String>()
            while (cursor.moveToNext()) result[cursor.getString(0)] = cursor.getString(1)
            result
        }
    private fun validateColumns(db: SupportSQLiteDatabase, table: String, expected: Map<String, String>, primary: List<String>) {
        val actual = linkedMapOf<String, String>()
        val keys = sortedMapOf<Int, String>()
        db.query("PRAGMA table_info(`$table`)").use { cursor ->
            while (cursor.moveToNext()) {
                val name = cursor.getString(1)
                actual[name] = cursor.getString(2).uppercase(java.util.Locale.ROOT)
                check(cursor.getInt(3) == 1) { "LOCAL_LEDGER_NULLABLE_COLUMN" }
                val order = cursor.getInt(5)
                if (order > 0) keys[order] = name
            }
        }
        check(actual == expected && keys.values.toList() == primary) { "LOCAL_LEDGER_COLUMN_MISMATCH:$table" }
    }
}
