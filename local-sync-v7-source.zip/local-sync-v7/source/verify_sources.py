#!/usr/bin/env python3
"""Read-only allowlist verification. Never compiles or installs."""
import argparse,json,hashlib
from pathlib import Path
here=Path(__file__).resolve().parent
root=here.parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--copies-only',action='store_true',help='Standalone bundle: verify copied files against frozen hashes without original checkout')
args=parser.parse_args()
m=json.loads((here/'production-inputs.json').read_text())
bad=[]
for item in m['files']:
 source=root/m['source_root']/item['path']
 if not args.copies_only and (not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=item['sha256']):
  bad.append('source:'+item['path'])
 if item['usage']=='copy_unchanged':
  copied=here/'app/src/main/java'/item['path'].split('/src/main/java/',1)[1]
  if not copied.is_file() or hashlib.sha256(copied.read_bytes()).hexdigest()!=item['sha256']:
   bad.append('copy:'+item['path'])
print(json.dumps({'copied_production_files':m['copied_production_files'],'mismatches':bad,'mode':'copies-only' if args.copies_only else 'original-and-copies'}))
raise SystemExit(bool(bad))
