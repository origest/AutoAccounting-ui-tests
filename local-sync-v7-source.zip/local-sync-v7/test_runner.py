import importlib.util,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('runner',Path(__file__).with_name('run-device.py'));r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
class ParserTest(unittest.TestCase):
 def valid(self):return 'INSTRUMENTATION_RESULT: qa_status=PASS\nINSTRUMENTATION_RESULT: case=core\nINSTRUMENTATION_RESULT: qa_run=fixture\nINSTRUMENTATION_CODE: -1\n'
 def test_success(self):self.assertEqual(r.result_fields(self.valid(),'core','fixture')['qa_status'],'PASS')
 def test_failure_flag(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid().replace('PASS','FAIL'))
 def test_aborted(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid()+'INSTRUMENTATION_ABORTED\n')
 def test_lookalike_code(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid().replace('CODE: -1','CODE: -11'))
 def test_duplicate_code(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid()+'INSTRUMENTATION_CODE: -1\n')
 def test_duplicate_field(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid()+'INSTRUMENTATION_RESULT: qa_status=PASS\n')
 def test_wrong_case(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid(),'other','fixture')
 def test_wrong_run(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid(),'core','other')
 def test_conflicting_flags(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid()+'INSTRUMENTATION_RESULT: qa_result=FAIL\n')
 def test_missing_code(self):
  with self.assertRaises(ValueError):r.result_fields(self.valid().replace('INSTRUMENTATION_CODE: -1\n',''))
if __name__=='__main__':unittest.main()
