# Source attribution and license notice

This is a modified, source-only isolated UI test project derived from AutoAccounting. The root LICENSE is the original GNU General Public License version 3 text. Existing author and copyright notices remain in the copied files. This package does not relicense third-party code.

Upstream: https://github.com/AutoAccountingOrg/AutoAccounting
The upstream GPL root license was independently checked against commit ed5c2ad94b152f7351d76fcd33f9099a5f7532eb. This candidate also contains subsequent application and test changes; it is not a verbatim snapshot of that commit.

Some inherited source headers refer to a nonexistent "Apache License, Version 3.0". They are retained as historical author notices rather than silently rewritten to a different license. The upstream root GPL license and existing source attribution are retained. These inconsistent headers should be clarified by the relevant copyright holders.

## Modified scope

Guava remains pinned to the previously resolved 33.5.0-android version after removal of the LiteRT transitive dependency. Build definitions select only the isolated test host and exclude the OCR, back-tap, and Bugly dependencies. Four peripheral integration imports select new fail-closed adapters, and a telemetry app ID is replaced with an unavailable placeholder. Four unrelated hook comments containing historical captured data are removed. One design-time phone-like preview attribute is removed. No assertions or tested UI/Room/refund/idempotency logic are replaced.

## Gradle Wrapper

The included gradle/wrapper/gradle-wrapper.jar is Gradle Wrapper, licensed under Apache License 2.0. Its license is provided in licenses/Gradle-Wrapper-LICENSE.txt. SHA-256: e996d452d2645e70c01c11143ca2d3742734a28da2bf61f25c82bdc288c9e637.

Official wrapper checksums: https://github.com/gradle/actions/blob/main/sources/src/wrapper-validation/wrapper-checksums.json
Official license: https://github.com/gradle/gradle/blob/v6.6.0/LICENSE
The wrapper JAR predates the selected Gradle 8.11.1 distribution. The distribution is separately pinned by SHA-256 in gradle-wrapper.properties.

## Downloaded build and runtime dependencies

Other dependencies are declared by their coordinates and downloaded by Gradle; their binary artifacts and caches are not included in this source package. Their individual licenses and terms continue to apply. This candidate is intended for source publication and ephemeral CI testing, with no APK, AAR, model, dependency-cache, or raw-log publication. It is not a redistribution-clearance statement for the resulting APK. In particular, MMKV is deliberately retained to preserve tested preference behavior; its bundled old OpenSSL/SSLeay notices require separate compatibility review before binary redistribution.
