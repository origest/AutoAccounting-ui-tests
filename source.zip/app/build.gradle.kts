import java.util.Calendar

plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.ksp)
    alias(libs.plugins.materialThemeBuilder)
    alias(libs.plugins.autoresconfig)
}

autoResConfig {
    generateClass.set(true)
    generateRes.set(false)
    generatedClassFullName.set("net.ankio.auto.util.LangList")
    generatedArrayFirstItem.set("SYSTEM")
}

materialThemeBuilder {
    themes {
        for ((name, color) in listOf(
            "Default" to "6750A4",
            "Red" to "F44336",
            "Pink" to "E91E63",
            "Purple" to "9C27B0",
            "DeepPurple" to "673AB7",
            "Indigo" to "3F51B5",
            "Blue" to "2196F3",
            "LightBlue" to "03A9F4",
            "Cyan" to "00BCD4",
            "Teal" to "009688",
            "Green" to "4FAF50",
            "LightGreen" to "8BC3A4",
            "Lime" to "CDDC39",
            "Yellow" to "FFEB3B",
            "Amber" to "FFC107",
            "Orange" to "FF9800",
            "DeepOrange" to "FF5722",
            "Brown" to "795548",
            "BlueGrey" to "607D8F",
            "Sakura" to "FF9CA8"
        )) {
            create("Material$name") {
                lightThemeFormat = "ThemeOverlay.Light.%s"
                darkThemeFormat = "ThemeOverlay.Dark.%s"
                primaryColor = "#$color"
            }
        }
    }
    // Add Material Design 3 color tokens (such as palettePrimary100) in generated theme
    // rikka.material >= 2.0.0 provides such attributes
    generatePalette = true
}

// Opt-in only: never mix the legacy device tests into this isolated UI harness.
val isolatedUiTests = true
val hookSmokeTests = false
require(!(hookSmokeTests && isolatedUiTests)) { "Choose exactly one test harness" }
val appVersionCode = 20261110
val appVersionName = "4.0.2"

base {
    archivesName.set("app-$appVersionName($appVersionCode)")
}

android {
    namespace = "net.ankio.auto"
    compileSdk = 36


    defaultConfig {
        applicationId = "net.ankio.auto"
        minSdk = 29
        targetSdk = 36
        versionCode = appVersionCode
        versionName = appVersionName
        testInstrumentationRunner = if (isolatedUiTests)
            "net.ankio.auto.isolated.IsolatedUiTestRunner"
        else "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("boolean", "ISOLATED_UI", "false")
        flavorDimensions += "version"



        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
        aidl = true
    }

    testBuildType = if (hookSmokeTests) "hookSmoke" else if (isolatedUiTests) "isolatedUi" else "debug"
    // Real hardware feedback is absent from the permission-free UI harness.
    sourceSets.getByName("debug").java.srcDir("src/production/java")
    sourceSets.getByName("release").java.srcDir("src/production/java")
    if (isolatedUiTests || hookSmokeTests) {
        sourceSets.getByName("androidTest").java.setSrcDirs(emptyList<String>())
        sourceSets.getByName("androidTest").assets.setSrcDirs(emptyList<String>())
        sourceSets.getByName("androidTest").res.setSrcDirs(emptyList<String>())
    }

    buildTypes {
        getByName("debug") {
            ndk {
                abiFilters.clear()
                abiFilters.addAll(listOf("arm64-v8a", "x86_64"))
            }
        }
        create("hookSmoke") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".hooksmoke"
            versionNameSuffix = "-synthetic-hook-smoke-never-distribute"
            matchingFallbacks += listOf("debug")
        }
        create("isolatedUi") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".isolatedui"
            versionNameSuffix = "-isolated-ui-never-distribute"
            matchingFallbacks += listOf("debug")
            buildConfigField("boolean", "ISOLATED_UI", "true")
        }
        getByName("release") {
            // 开启代码压缩以启用R8优化，但通过proguard规则禁用混淆
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_21)
        }
    }

    packaging {
        // 普通资源（非 .so）放这里
        resources {
            merges += setOf("META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/io.netty.versions.properties", "META-INF/services/**")
            excludes += listOf(
                "META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA", "META-INF/INDEX.LIST", "META-INF/DEPENDENCIES"
            )
        }

        jniLibs {
            useLegacyPackaging = true
        }
    }






    androidResources {
        additionalParameters.addAll(
            listOf("--allow-reserved-package-id", "--package-id", "0x65")
        )
    }

    bundle {
        language {
            enableSplit = false
        }
    }

    lint {
        checkReleaseBuilds = true
        abortOnError = true
        warningsAsErrors = false
        fatal += setOf(
            "CheckResult",
            "InlinedApi",
            "NewApi",
            "Recycle",
            "MissingPermission",
            "WrongConstant",
            "LaunchActivityFromNotification",
        )
    }

}
fun calculateVersionCode(): Int {
    val calendar = Calendar.getInstance()
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH) + 1
    val day = calendar.get(Calendar.DAY_OF_MONTH)
    return year * 10000 + month * 100 + day
}

configurations.configureEach {
    exclude("androidx.appcompat", "appcompat")
}

dependencies {
    // Keep the previously resolved Android Guava version after removing LiteRT.
    implementation("com.google.guava:guava:33.5.0-android")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("junit:junit:4.13.2")
    add("isolatedUiImplementation", libs.androidx.room.runtime)
    add("hookSmokeImplementation", libs.androidx.room.runtime)
    implementation(project(":chatgpt"))


    implementation(libs.androidx.swiperefreshlayout)


    // 打包依赖
    implementation(libs.core.ktx)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.androidx.navigation.ui.ktx)
    implementation(libs.fragment.ktx)
    implementation(libs.androidx.browser)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.work.runtime.ktx)

    // Html转换
    implementation(libs.html.ktx)

    // gson
    implementation(libs.gson)

    // toast
    implementation(libs.toaster)
    implementation(libs.preferenceKtx)
    implementation(libs.androidx.lifecycle.service)

    // xp依赖
    compileOnly(libs.xposed)

    // flexbox
    implementation(libs.flexbox)

    // 圆角
    implementation(libs.round)


    // okhttp
    implementation(libs.okhttp)

    // Dex工具
    implementation(project(":dex"))

    // xml2json
    implementation(libs.xmltojson)

    implementation(project(":server"))
    // App-local OCR transactions directly use Room APIs exposed by the server models.
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    implementation(project(":shell"))

    // debug依赖
    // Heap dumping is a developer diagnostic, not a default in distributed test builds.
    if (providers.gradleProperty("enableLeakCanary").orNull == "true") {
        debugImplementation(libs.leakcanary.android)
    }



    implementation(libs.rikkaMaterial)
    implementation(libs.rikkaMaterialPreference)
    implementation(libs.about)

    implementation(libs.glide)

    implementation(libs.mmkv)
    implementation(libs.zip4j)
    implementation(kotlin("reflect"))


    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))

    testImplementation(libs.junit)

}


// This source package is only an isolated test host, never a production application.
androidComponents {
    beforeVariants(selector().all()) { variant ->
        variant.enable = variant.buildType == "isolatedUi"
    }
}
