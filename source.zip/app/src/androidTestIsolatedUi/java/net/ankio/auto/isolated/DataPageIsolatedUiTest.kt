package net.ankio.auto.isolated

import android.os.SystemClock
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.inspector.WindowInspector
import net.ankio.auto.ui.adapter.AppDataAdapter
import net.ankio.auto.ui.components.MaterialSearchView
import org.ezbook.server.constant.DataType
import org.ezbook.server.db.model.AppDataModel
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.runBlocking
import net.ankio.auto.R
import net.ankio.auto.ui.fragment.DataFragment
import org.junit.Assert.*
import org.junit.Test

/** Real DataFragment / adapter / status / swipe UI, synthetic NOTICE rows, no OS notifications. */
class DataPageIsolatedUiTest : IsolatedUiFixture() {
    private fun showData(): DataFragment = onMain { host.showData() }
    private fun root(fragment: DataFragment): View = onMain { fragment.requireView() }
    private fun visible(fragment: DataFragment, id: Int): Boolean =
        fragment.view?.findViewById<View>(id)?.isShown == true
    private fun count(fragment: DataFragment): Int =
        fragment.view?.findViewById<RecyclerView>(R.id.content_view)?.adapter?.itemCount ?: -1

    private fun swipeRefresh(fragment: DataFragment) {
        val bounds = screenBounds(onMain {
            fragment.requireView().findViewById<View>(R.id.swipe_refresh_layout)
        })
        gesture(bounds.exactCenterX(), bounds.top + bounds.height() * .15f,
            bounds.exactCenterX(), bounds.top + bounds.height() * .90f, 700)
    }

    @Test fun successfulEmptyResponseShowsEmptyNotError() {
        val fragment = showData()
        await("True empty state") { visible(fragment, R.id.group_empty) }
        onMain {
            assertFalse(visible(fragment, R.id.group_error))
            assertFalse(fragment.swipeRefreshLayout.isRefreshing)
            assertEquals(0, count(fragment))
        }
    }

    @Test fun transportFailureShowsErrorAndActualRetryTapRecovers() {
        backend.dataFailure = SyntheticUiBackend.Failure.TRANSPORT
        val fragment = showData()
        await("Transport error state") { visible(fragment, R.id.group_error) }
        onMain { assertFalse(visible(fragment, R.id.group_empty)) }
        runBlocking { backend.insertNotice("Synthetic retry notice") }
        backend.dataFailure = SyntheticUiBackend.Failure.NONE
        click(root(fragment), R.id.group_error)
        await("Retry tap loaded one row") { visible(fragment, R.id.group_content) && count(fragment) == 1 }
        await("Real raw-data row text bound") {
            allViews(fragment.requireView()).filterIsInstance<TextView>().any {
                it.text.toString().contains("Synthetic retry notice")
            }
        }
    }

    @Test fun nonSuccessAndMissingDataNeverMasqueradeAsEmpty() {
        backend.dataFailure = SyntheticUiBackend.Failure.NON_SUCCESS
        val fragment = showData()
        await("Non-success error") { visible(fragment, R.id.group_error) }
        val firstRequests = backend.dataRequests.get()
        backend.dataFailure = SyntheticUiBackend.Failure.MISSING_DATA
        click(root(fragment), R.id.group_error)
        await("Missing response data remains an error") {
            backend.dataRequests.get() > firstRequests && visible(fragment, R.id.group_error)
        }
        onMain { assertFalse(visible(fragment, R.id.group_empty)) }
        backend.dataFailure = SyntheticUiBackend.Failure.NONE
        click(root(fragment), R.id.group_error)
        await("Confirmed empty response recovers") { visible(fragment, R.id.group_empty) }
    }

    @Test fun syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage() {
        val fragment = showData()
        await("Empty first") { visible(fragment, R.id.group_empty) }
        runBlocking { backend.insertNotice("Synthetic newly persisted notification") }
        await("Visible periodic refresh sees persisted row", 12_000) {
            visible(fragment, R.id.group_content) && count(fragment) == 1
        }
    }

    @Test fun actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning() {
        runBlocking { backend.insertNotice("Synthetic existing row") }
        val fragment = showData()
        await("Initial row") { count(fragment) == 1 }
        val gate = CompletableDeferred<Unit>()
        backend.dataGate = gate
        val before = backend.dataRequests.get()
        swipeRefresh(fragment)
        await("Swipe started a read") { backend.dataRequests.get() > before }
        swipeRefresh(fragment)
        runBlocking { backend.insertNotice("Synthetic added during refresh") }
        backend.dataGate = null
        gate.complete(Unit)
        await("Exactly two rows after repeated gesture") {
            count(fragment) == 2 && !fragment.swipeRefreshLayout.isRefreshing
        }
        onMain { assertFalse(visible(fragment, R.id.group_error)) }
    }

    @Test fun programmaticNavigationPauseStopsPollingAndReentryRefreshes() {
        val fragment = showData()
        await("Initial empty") { visible(fragment, R.id.group_empty) }
        onMain {
            host.supportFragmentManager.beginTransaction()
                .replace(IsolatedUiHostActivity.CONTAINER_ID, Fragment())
                .addToBackStack("synthetic-away").commit()
            host.supportFragmentManager.executePendingTransactions()
        }
        await("Read cancelled on pause") { backend.activeRequests.get() == 0 }
        val before = backend.dataRequests.get()
        runBlocking { backend.insertNotice("Synthetic while away") }
        SystemClock.sleep(5_500)
        assertEquals("Paused page must not poll", before, backend.dataRequests.get())
        onMain { assertTrue(host.supportFragmentManager.popBackStackImmediate()) }
        await("Reentry shows latest row", 4_000) { count(fragment) == 1 && visible(fragment, R.id.group_content) }
    }

    @Test fun destroyedViewCancelsInflightReadAndNewPageRecovers() {
        val gate = CompletableDeferred<Unit>()
        backend.dataGate = gate
        val old = showData()
        await("Read in flight") { backend.dataRequests.get() > 0 }
        onMain { host.supportFragmentManager.beginTransaction().remove(old).commitNow() }
        await("Old request cancelled before backend release") { backend.activeRequests.get() == 0 }
        backend.dataGate = null
        gate.complete(Unit)
        runBlocking { backend.insertNotice("Synthetic recreated page") }
        val replacement = showData()
        await("Replacement not overwritten by stale read") { count(replacement) == 1 }
        onMain { assertNull(old.view) }
    }

    @Test fun actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry() {
        runBlocking {
            backend.insertNotice("needle notice")
            backend.insertNotice("different notice")
            backend.db.dataDao().insert(AppDataModel().apply {
                type = DataType.DATA; app = "synthetic.notification.fixture"; data = "needle raw data"
            })
        }
        val fragment = showData()
        await("Three initial rows") { count(fragment) == 3 }
        click(root(fragment), R.id.type_button)
        val label = host.resources.getStringArray(R.array.rule_type_options)[1]
        val item = onMain {
            WindowInspector.getGlobalWindowViews().asReversed().flatMap { allViews(it) }
                .filterIsInstance<TextView>().first { it.isShown && it.text.toString() == label }
        }
        val tappedBounds = tapView(item)
        await("Notice filter applied via menu at $tappedBounds", diagnostics = {
            "type=${fragment.type}, rows=${count(fragment)}, label=$label"
        }) {
            count(fragment) == 2 && fragment.type == DataType.NOTICE.name
        }
        onMain {
            val menu = fragment.requireView().findViewById<Toolbar>(R.id.toolbar).menu.findItem(R.id.action_search)
            menu.expandActionView()
            // Fixture text in the real SearchView invokes the production change listener.
            (menu.actionView as MaterialSearchView).setQuery("needle", false)
        }
        await("Search excludes nonmatching rows") { count(fragment) == 1 }
        runBlocking {
            backend.insertNotice("needle added while visible")
            backend.insertNotice("unrelated added while visible")
        }
        await("Periodic refresh retains both filters") { count(fragment) == 2 }
        onMain {
            assertEquals(DataType.NOTICE.name, fragment.type)
            assertEquals("needle", fragment.searchData)
            val rows = (fragment.statusPage.contentView!!.adapter as AppDataAdapter).getItems()
            assertTrue(rows.all { it.type == DataType.NOTICE && it.data.contains("needle") })
            host.supportFragmentManager.beginTransaction().replace(IsolatedUiHostActivity.CONTAINER_ID, Fragment())
                .addToBackStack("synthetic-filter-away").commit()
            host.supportFragmentManager.executePendingTransactions()
            assertTrue(host.supportFragmentManager.popBackStackImmediate())
        }
        await("Filtered state restored after view recreation") { count(fragment) == 2 }
        onMain {
            assertEquals(label, fragment.requireView().findViewById<TextView>(R.id.type_button).text.toString())
            val search = fragment.requireView().findViewById<Toolbar>(R.id.toolbar).menu
                .findItem(R.id.action_search).actionView as MaterialSearchView
            assertEquals("needle", search.query.toString())
        }
    }

    @Test fun multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset() {
        runBlocking { repeat(201) { backend.insertNotice("Synthetic paged row $it") } }
        val fragment = showData()
        await("First full page") { count(fragment) == 100 }
        val recycler = onMain { fragment.statusPage.contentView!! }
        // Programmatic position setup, followed by a real upward gesture to exercise paging.
        onMain { recycler.scrollToPosition(96) }
        instrumentation.waitForIdleSync()
        val bounds = screenBounds(recycler)
        gesture(bounds.exactCenterX(), bounds.top + bounds.height() * .8f,
            bounds.exactCenterX(), bounds.top + bounds.height() * .2f)
        await("Second page loaded") { count(fragment) == 200 && fragment.page == 2 }
        onMain { (recycler.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(120, 24) }
        await("Scroll settled beyond first page") {
            recycler.scrollState == RecyclerView.SCROLL_STATE_IDLE &&
                (recycler.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition() >= 100
        }
        fun anchor(): Pair<Long, Int>? {
            val layout = recycler.layoutManager as LinearLayoutManager
            val position = layout.findFirstVisibleItemPosition()
            val row = (recycler.adapter as AppDataAdapter).getItems().getOrNull(position) ?: return null
            val view = layout.findViewByPosition(position) ?: return null
            return row.id to view.top
        }
        val before = onMain { requireNotNull(anchor()) }
        val newId = runBlocking { backend.insertNotice("Synthetic newer page head") }
        await("Loaded prefix refreshed") {
            (recycler.adapter as AppDataAdapter).getItems().firstOrNull()?.id == newId
        }
        await("Same visible anchor after adapter layout") { anchor()?.first == before.first }
        onMain {
            assertEquals(2, fragment.page)
            assertEquals(200, count(fragment))
            assertTrue("Row offset changed: $before -> ${anchor()}", kotlin.math.abs(requireNotNull(anchor()).second - before.second) <= 2)
            val ids = (recycler.adapter as AppDataAdapter).getItems().map { it.id }
            assertEquals(ids.size, ids.distinct().size)
        }
    }


    @Test fun activityRecreationRestoresNewFragmentFiltersPagesAndScroll() {
        runBlocking { repeat(201) { backend.insertNotice("state needle row $it") } }
        // Configure a filtered second-page fixture. Other cases cover menu/search interaction.
        val original = onMain { host.showData(DataFragment().apply {
            app = "synthetic.notification.fixture"
            type = DataType.NOTICE.name
            match = false
            searchData = "state needle"
        }) }
        await("Filtered first page") { count(original) == 100 }
        val originalList = onMain { original.statusPage.contentView!! }
        onMain { originalList.scrollToPosition(96) }
        instrumentation.waitForIdleSync()
        val bounds = screenBounds(originalList)
        gesture(bounds.exactCenterX(), bounds.top + bounds.height() * .8f,
            bounds.exactCenterX(), bounds.top + bounds.height() * .2f)
        await("Second filtered page") { original.page == 2 && count(original) == 200 }
        onMain { (originalList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(120, 24) }
        await("Second-page anchor settled") {
            originalList.scrollState == RecyclerView.SCROLL_STATE_IDLE &&
                (originalList.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition() >= 100
        }
        fun anchor(list: RecyclerView): Pair<Long, Int>? {
            val layout = list.layoutManager as LinearLayoutManager
            val position = layout.findFirstVisibleItemPosition()
            val row = (list.adapter as AppDataAdapter).getItems().getOrNull(position) ?: return null
            val view = layout.findViewByPosition(position) ?: return null
            return row.id to view.top
        }
        val before = onMain { requireNotNull(anchor(originalList)) }
        val previousHost = host
        val monitor = instrumentation.addMonitor(IsolatedUiHostActivity::class.java.name, null, false)
        try {
            onMain { previousHost.recreate() }
            val replacement = instrumentation.waitForMonitorWithTimeout(monitor, 8_000)
            assertNotNull("Recreated activity was not observed", replacement)
            host = replacement as IsolatedUiHostActivity
        } finally {
            instrumentation.removeMonitor(monitor)
        }
        instrumentation.waitForIdleSync()
        assertNotSame(previousHost, host)
        val restored = onMain {
            host.supportFragmentManager.findFragmentById(IsolatedUiHostActivity.CONTAINER_ID) as DataFragment
        }
        assertNotSame("Must test a new Fragment instance, not only back-stack view recreation", original, restored)
        await("Restored second-page prefix") { restored.page == 2 && count(restored) == 200 }
        val restoredList = onMain { restored.statusPage.contentView!! }
        await("Restored saved scroll anchor $before", diagnostics = {
            "actual=${anchor(restoredList)}, page=${restored.page}, rows=${count(restored)}"
        }) { anchor(restoredList)?.first == before.first }
        onMain {
            assertEquals("synthetic.notification.fixture", restored.app)
            assertEquals(DataType.NOTICE.name, restored.type)
            assertEquals(false, restored.match)
            assertEquals("state needle", restored.searchData)
            assertEquals(host.resources.getStringArray(R.array.rule_type_options)[1],
                restored.requireView().findViewById<TextView>(R.id.type_button).text.toString())
            assertEquals(host.resources.getStringArray(R.array.match_options)[2],
                restored.requireView().findViewById<TextView>(R.id.match_button).text.toString())
            val search = restored.requireView().findViewById<Toolbar>(R.id.toolbar).menu
                .findItem(R.id.action_search).actionView as MaterialSearchView
            assertEquals("state needle", search.query.toString())
            assertTrue("Saved pixel offset was not restored", kotlin.math.abs(requireNotNull(anchor(restoredList)).second - before.second) <= 2)
        }
    }

}
