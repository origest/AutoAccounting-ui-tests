package net.ankio.auto.isolated

import android.app.Dialog
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.MotionEvent
import android.graphics.Rect
import android.view.ViewGroup
import android.view.inspector.WindowInspector
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import net.ankio.auto.R
import net.ankio.auto.http.LocalNetwork
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.dialog.BillEditorDialog
import org.ezbook.server.constant.BillType
import org.ezbook.server.db.model.BillInfoModel
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.rules.TestRule
import org.junit.rules.TestWatcher
import org.junit.runner.Description
import net.ankio.auto.isolated.IsolatedUiProgress.Step

import java.util.concurrent.Callable
import java.util.concurrent.FutureTask

/** No Espresso/UIAutomator dependency, shell commands, permission grants, or accessibility edits. */
abstract class IsolatedUiFixture {
    // Process-wide and never reset by another test: a timed-out action may already be running.
    private companion object { val deadlineWait = UiTestDeadline() }
    @get:Rule val progress: TestRule = UiTestFailureRule(object : TestWatcher() {
        override fun starting(description: Description) { IsolatedUiProgress.begin(description) }
        override fun finished(description: Description) { IsolatedUiProgress.finish() }
    })
    protected fun <T> step(name: Step, action: () -> T): T = IsolatedUiProgress.step(name, action)

    protected val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    protected lateinit var backend: SyntheticUiBackend
    protected lateinit var host: IsolatedUiHostActivity

    @Before fun setUpIsolatedUi() {
        deadlineWait.assertHealthy()
        IsolatedUiApplication.assertIsolatedPackage(instrumentation.targetContext)
        step(Step.SETUP_RESET) { onMain { IsolatedUiApplication.resetSyntheticPreferences() } }
        backend = step(Step.SETUP_BACKEND) { SyntheticUiBackend(instrumentation.targetContext) }
        LocalNetwork.installIsolatedTransport(backend::request)
        host = step(Step.SETUP_HOST) {
            instrumentation.startActivitySync(Intent(instrumentation.targetContext,
                IsolatedUiHostActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as IsolatedUiHostActivity
        }
        step(Step.SETUP_IDLE) { waitForUiIdle() }
    }

    @After fun tearDownIsolatedUi() {
        // Do not race cleanup or subsequent test UI against an action that timed out.
        // JUnit records an explicit failure, never an ignored/skipped or successful test.
        deadlineWait.assertHealthy()
        try {
            if (::host.isInitialized) {
                step(Step.TEARDOWN_HOST) {
                    onMain { host.finish() }
                    await("Host destroyed") { host.isDestroyed }
                }
            }
            if (::backend.isInitialized) {
                step(Step.TEARDOWN_REQUESTS) { await("Synthetic requests finished") { backend.activeRequests.get() == 0 } }
                // The filesystem check and Room close share one bounded cleanup operation.
                // If it returns late, the process-wide guard prevents another case from using it.
                val deadline = SystemClock.elapsedRealtime() + 12_000
                val close = FutureTask(Callable {
                    try {
                        assertTrue("Unexpected requests: ${backend.unexpectedRequests}", backend.unexpectedRequests.isEmpty())
                        val allowed = setOf(backend.databaseName, "${backend.databaseName}-wal",
                            "${backend.databaseName}-shm", "${backend.databaseName}-journal")
                        val unexpectedDatabases = instrumentation.targetContext.databaseList().filter { it !in allowed }
                        assertTrue("Non-synthetic databases created: $unexpectedDatabases", unexpectedDatabases.isEmpty())
                    } finally {
                        backend.close()
                    }
                })
                step(Step.TEARDOWN_DATABASE) {
                    Thread(close, "IsolatedUiCleanup").apply { isDaemon = true; start() }
                    deadlineWait.get(close, deadline, SystemClock::elapsedRealtime)
                }
            }
            LocalNetwork.installIsolatedTransport { _, _, _ -> error("Between tests; no backend") }
        } catch (error: Throwable) {
            // Any incomplete cleanup forbids continuing, even if the main queue itself responded.
            deadlineWait.preventFurtherActions()
            throw error
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    protected fun <T> onMain(action: () -> T): T =
        onMainUntil(SystemClock.elapsedRealtime() + 12_000, action)

    private fun <T> onMainUntil(deadline: Long, action: () -> T): T = step(Step.MAIN) {
        deadlineWait.assertHealthy()
        if (Looper.myLooper() == Looper.getMainLooper()) return@step action()
        val task = FutureTask(Callable(action))
        check(mainHandler.post(task)) { "UI_TEST_MAIN_QUEUE_REJECTED" }
        try {
            deadlineWait.get(task, deadline, SystemClock::elapsedRealtime)
        } finally {
            if (task.isCancelled) mainHandler.removeCallbacks(task)
        }
    }

    /** Same idle callback as waitForIdleSync, without an unbounded instrumentation-thread wait. */
    protected fun waitForUiIdle(): Unit = step(Step.IDLE) {
        deadlineWait.assertHealthy()
        check(Looper.myLooper() != Looper.getMainLooper()) { "UI_TEST_IDLE_ON_MAIN" }
        val deadline = SystemClock.elapsedRealtime() + 12_000
        val task = FutureTask(Callable { Unit })
        instrumentation.waitForIdle(task)
        deadlineWait.get(task, deadline, SystemClock::elapsedRealtime)
    }

    protected fun await(
        message: String,
        timeoutMs: Long = 12_000,
        diagnostics: () -> String = { "" },
        condition: () -> Boolean
    ) {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        var detail = ""
        do {
            val ready = onMainUntil(deadline) {
                val satisfied = condition()
                // Capture details within the same budget, never post a new UI call after expiry.
                if (!satisfied) detail = diagnostics()
                satisfied
            }
            if (ready) return
            val remaining = deadline - SystemClock.elapsedRealtime()
            if (remaining <= 0) break
            SystemClock.sleep(minOf(40L, remaining))
        } while (SystemClock.elapsedRealtime() < deadline)
        fail("Timed out: $message $detail".trim())
    }

    protected fun click(root: View, id: Int) = tapView(onMain {
        requireNotNull(root.findViewById<View>(id)) { "Missing view $id" }
    })

    protected fun tapView(view: View): Rect {
        onMain {
            assertTrue("Click target disabled", view.isEnabled)
            assertTrue("Click target hidden", view.isShown)
            view.requestRectangleOnScreen(Rect(0, 0, view.width, view.height), true)
        }
        waitForUiIdle()
        val bounds = screenBounds(view)
        gesture(bounds.exactCenterX(), bounds.exactCenterY(), bounds.exactCenterX(), bounds.exactCenterY(), 60)
        return bounds
    }

    /** getGlobalVisibleRect is root-relative; injected MotionEvents require screen coordinates. */
    protected fun screenBounds(view: View): Rect = onMain {
        val bounds = Rect()
        assertTrue("Touch target has no visible bounds", view.getGlobalVisibleRect(bounds))
        val origin = IntArray(2)
        view.rootView.getLocationOnScreen(origin)
        bounds.offset(origin[0], origin[1])
        assertTrue("Touch target has empty bounds", bounds.width() > 0 && bounds.height() > 0)
        bounds
    }

    protected fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 500) {
        deadlineWait.assertHealthy()
        val start = SystemClock.uptimeMillis()
        fun send(action: Int, time: Long, x: Float, y: Float) {
            val event = MotionEvent.obtain(start, time, action, x, y, 0)
            val point = when (action) {
                MotionEvent.ACTION_DOWN -> Step.POINTER_DOWN
                MotionEvent.ACTION_UP -> Step.POINTER_UP
                else -> Step.POINTER_MOVE
            }
            try { step(point) { instrumentation.sendPointerSync(event) } } finally { event.recycle() }
        }
        send(MotionEvent.ACTION_DOWN, start, x1, y1)
        repeat(10) { index ->
            SystemClock.sleep(durationMs / 10)
            val fraction = (index + 1) / 10f
            send(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis(),
                x1 + (x2 - x1) * fraction, y1 + (y2 - y1) * fraction)
        }
        send(MotionEvent.ACTION_UP, SystemClock.uptimeMillis(), x2, y2)
        waitForUiIdle()
    }

    protected fun rootWith(id: Int): View = onMain {
        WindowInspector.getGlobalWindowViews().lastOrNull {
            it.isAttachedToWindow && it.findViewById<View>(id)?.isShown == true
        } ?: error("No shown window contains view $id")
    }

    protected fun hasWindowWith(id: Int): Boolean = WindowInspector.getGlobalWindowViews().any {
        it.isAttachedToWindow && it.findViewById<View>(id)?.isShown == true
    }

    protected fun editor(bill: BillInfoModel, confirmed: (BillInfoModel) -> Unit = {}): BillEditorDialog {
        val creation = if (bill.id == 0L) runBlocking {
            val id = backend.insertNotice("Synthetic draft origin ${java.util.UUID.randomUUID()}")
            net.ankio.auto.utils.BillCreationJournal.forRawRecord(backend.db.dataDao().queryId(id)!!,
                org.ezbook.server.server.billCreationSource(backend.db)).target
        } else null
        return onMain {
            BaseSheetDialog.create<BillEditorDialog>(host).setBillInfo(bill)
                .apply { creation?.let { bindCreation(it) } }
                .setOnConfirm(confirmed).setOnCancel {}.also { it.show() }
        }
    }

    protected fun dialogRoot(dialog: Dialog): View = onMain { requireNotNull(dialog.window).decorView }
    protected fun saveButton(dialog: Dialog): View = dialogRoot(dialog).findViewById(R.id.confirm_button)

    protected fun expense(money: Double = 100.0): BillInfoModel = runBlocking {
        BillInfoModel(type = BillType.Expend, money = money, bookName = "Synthetic", currency = "CNY",
            cateName = "Synthetic category", time = 1_800_000_000_000L)
            .also { it.id = backend.db.billInfoDao().insert(it) }
    }

    protected fun refund(money: Double = 25.0, link: String = ""): BillInfoModel =
        BillInfoModel(type = BillType.IncomeRefund, money = money, bookName = "Synthetic", currency = "CNY",
            cateName = "Synthetic category", extendData = link, time = 1_800_000_000_001L)

    protected fun allViews(root: View): List<View> = buildList {
        add(root)
        if (root is ViewGroup) for (index in 0 until root.childCount) addAll(allViews(root.getChildAt(index)))
    }
}
