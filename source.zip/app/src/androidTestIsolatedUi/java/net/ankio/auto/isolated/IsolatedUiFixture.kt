package net.ankio.auto.isolated

import android.app.Dialog
import android.content.Intent
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.MotionEvent
import android.graphics.Rect
import android.view.ViewGroup
import android.view.inspector.WindowInspector
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import net.ankio.auto.R
import net.ankio.auto.http.LocalNetwork
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.dialog.BillEditorDialog
import org.ezbook.server.constant.BillType
import org.ezbook.server.db.model.BillInfoModel
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import java.util.concurrent.Callable
import java.util.concurrent.FutureTask

/** No Espresso/UIAutomator dependency, shell commands, permission grants, or accessibility edits. */
abstract class IsolatedUiFixture {
    protected val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    protected lateinit var backend: SyntheticUiBackend
    protected lateinit var host: IsolatedUiHostActivity

    @Before fun setUpIsolatedUi() {
        IsolatedUiApplication.assertIsolatedPackage(instrumentation.targetContext)
        onMain { IsolatedUiApplication.resetSyntheticPreferences() }
        backend = SyntheticUiBackend(instrumentation.targetContext)
        LocalNetwork.installIsolatedTransport(backend::request)
        host = instrumentation.startActivitySync(Intent(instrumentation.targetContext,
            IsolatedUiHostActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as IsolatedUiHostActivity
        instrumentation.waitForIdleSync()
    }

    @After fun tearDownIsolatedUi() {
        try {
            if (::host.isInitialized) {
                onMain { host.finish() }
                await("Host destroyed") { host.isDestroyed }
            }
            if (::backend.isInitialized) {
                await("Synthetic requests finished") { backend.activeRequests.get() == 0 }
                assertTrue("Unexpected requests: ${backend.unexpectedRequests}", backend.unexpectedRequests.isEmpty())
                val allowed = setOf(backend.databaseName, "${backend.databaseName}-wal",
                    "${backend.databaseName}-shm", "${backend.databaseName}-journal")
                val unexpectedDatabases = instrumentation.targetContext.databaseList().filter { it !in allowed }
                assertTrue("Non-synthetic databases created: $unexpectedDatabases", unexpectedDatabases.isEmpty())
            }
        } finally {
            if (::backend.isInitialized) backend.close()
            LocalNetwork.installIsolatedTransport { _, _, _ -> error("Between tests; no backend") }
        }
    }

    protected fun <T> onMain(action: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return action()
        val task = FutureTask(Callable(action))
        instrumentation.runOnMainSync(task)
        return task.get()
    }

    protected fun await(
        message: String,
        timeoutMs: Long = 12_000,
        diagnostics: () -> String = { "" },
        condition: () -> Boolean
    ) {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        do {
            if (onMain(condition)) return
            SystemClock.sleep(40)
        } while (SystemClock.elapsedRealtime() < deadline)
        fail("Timed out: $message ${onMain(diagnostics)}".trim())
    }

    protected fun click(root: View, id: Int) = tapView(onMain {
        requireNotNull(root.findViewById<View>(id)) { "Missing view $id" }
    })

    protected fun tapView(view: View): Rect {
        onMain {
            assertTrue("Click target disabled", view.isEnabled)
            assertTrue("Click target hidden", view.isShown)
            view.requestRectangleOnScreen(Rect(0, 0, view.width, view.height), true)
        }
        instrumentation.waitForIdleSync()
        val bounds = screenBounds(view)
        gesture(bounds.exactCenterX(), bounds.exactCenterY(), bounds.exactCenterX(), bounds.exactCenterY(), 60)
        return bounds
    }

    /** getGlobalVisibleRect is root-relative; injected MotionEvents require screen coordinates. */
    protected fun screenBounds(view: View): Rect = onMain {
        val bounds = Rect()
        assertTrue("Touch target has no visible bounds", view.getGlobalVisibleRect(bounds))
        val origin = IntArray(2)
        view.rootView.getLocationOnScreen(origin)
        bounds.offset(origin[0], origin[1])
        assertTrue("Touch target has empty bounds", bounds.width() > 0 && bounds.height() > 0)
        bounds
    }

    protected fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 500) {
        val start = SystemClock.uptimeMillis()
        fun send(action: Int, time: Long, x: Float, y: Float) {
            val event = MotionEvent.obtain(start, time, action, x, y, 0)
            try { instrumentation.sendPointerSync(event) } finally { event.recycle() }
        }
        send(MotionEvent.ACTION_DOWN, start, x1, y1)
        repeat(10) { index ->
            SystemClock.sleep(durationMs / 10)
            val fraction = (index + 1) / 10f
            send(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis(),
                x1 + (x2 - x1) * fraction, y1 + (y2 - y1) * fraction)
        }
        send(MotionEvent.ACTION_UP, SystemClock.uptimeMillis(), x2, y2)
        instrumentation.waitForIdleSync()
    }

    protected fun rootWith(id: Int): View = onMain {
        WindowInspector.getGlobalWindowViews().lastOrNull {
            it.isAttachedToWindow && it.findViewById<View>(id)?.isShown == true
        } ?: error("No shown window contains view $id")
    }

    protected fun hasWindowWith(id: Int): Boolean = WindowInspector.getGlobalWindowViews().any {
        it.isAttachedToWindow && it.findViewById<View>(id)?.isShown == true
    }

    protected fun editor(bill: BillInfoModel, confirmed: (BillInfoModel) -> Unit = {}): BillEditorDialog {
        val creation = if (bill.id == 0L) runBlocking {
            val id = backend.insertNotice("Synthetic draft origin ${java.util.UUID.randomUUID()}")
            net.ankio.auto.utils.BillCreationJournal.forRawRecord(backend.db.dataDao().queryId(id)!!,
                org.ezbook.server.server.billCreationSource(backend.db)).target
        } else null
        return onMain {
            BaseSheetDialog.create<BillEditorDialog>(host).setBillInfo(bill)
                .apply { creation?.let { bindCreation(it) } }
                .setOnConfirm(confirmed).setOnCancel {}.also { it.show() }
        }
    }

    protected fun dialogRoot(dialog: Dialog): View = onMain { requireNotNull(dialog.window).decorView }
    protected fun saveButton(dialog: Dialog): View = dialogRoot(dialog).findViewById(R.id.confirm_button)

    protected fun expense(money: Double = 100.0): BillInfoModel = runBlocking {
        BillInfoModel(type = BillType.Expend, money = money, bookName = "Synthetic", currency = "CNY",
            cateName = "Synthetic category", time = 1_800_000_000_000L)
            .also { it.id = backend.db.billInfoDao().insert(it) }
    }

    protected fun refund(money: Double = 25.0, link: String = ""): BillInfoModel =
        BillInfoModel(type = BillType.IncomeRefund, money = money, bookName = "Synthetic", currency = "CNY",
            cateName = "Synthetic category", extendData = link, time = 1_800_000_000_001L)

    protected fun allViews(root: View): List<View> = buildList {
        add(root)
        if (root is ViewGroup) for (index in 0 until root.childCount) addAll(allViews(root.getChildAt(index)))
    }
}
