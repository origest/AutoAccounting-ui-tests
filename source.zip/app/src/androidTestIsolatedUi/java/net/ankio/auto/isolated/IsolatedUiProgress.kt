package net.ankio.auto.isolated

import android.os.SystemClock
import android.util.Log
import org.junit.runner.Description

/** Test-only fixed tokens. No view text, throwable, route, database name or raw data. */
object IsolatedUiProgress {
    enum class Step {
        CASE, SETUP_RESET, SETUP_BACKEND, SETUP_HOST, SETUP_IDLE,
        TEARDOWN_HOST, TEARDOWN_REQUESTS, TEARDOWN_DATABASE,
        SWIPE_INSERT_INITIAL, SWIPE_SHOW, SWIPE_INITIAL_ROWS, SWIPE_FIRST,
        SWIPE_REQUEST_OBSERVED, SWIPE_SECOND, SWIPE_INSERT_SECOND, SWIPE_RELEASE,
        SWIPE_FINAL_ROWS, SWIPE_FINAL_ERROR, MAIN, IDLE, POINTER_DOWN, POINTER_MOVE, POINTER_UP
    }
    private val cases = mapOf(
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#successfulEmptyResponseShowsEmptyNotError" to "C01",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#transportFailureShowsErrorAndActualRetryTapRecovers" to "C02",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#nonSuccessAndMissingDataNeverMasqueradeAsEmpty" to "C03",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#syntheticNoticeInsertedWhileVisibleAppearsWithoutLeavingPage" to "C04",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning" to "C05",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#programmaticNavigationPauseStopsPollingAndReentryRefreshes" to "C06",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#destroyedViewCancelsInflightReadAndNewPageRecovers" to "C07",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#actualTypeFilterAndSearchTextSurviveVisibleRefreshAndReentry" to "C08",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#multiPagePassiveRefreshKeepsLoadedPageCountAndVisibleRowOffset" to "C09",
        "net.ankio.auto.isolated.DataPageIsolatedUiTest#activityRecreationRestoresNewFragmentFiltersPagesAndScroll" to "C10",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen" to "C11",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft" to "C12",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#emptyPickerDoesNotImplicitlyClearExistingLink" to "C13",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation" to "C14",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#failedSaveKeepsEditorAndRetryPersistsExactlyOnce" to "C15",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected" to "C16",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#committedCreateWithLostResponseReconcilesWithoutDuplicateRefund" to "C17",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#repeatedConfirmWhileSavingCannotCreateDuplicateRefunds" to "C18",
        "net.ankio.auto.isolated.RefundIsolatedUiTest#explicitClearNeedsPickerAndEditorConfirmationToPersist" to "C19",
    )
    private val origin = SystemClock.elapsedRealtime()
    private var active: String? = null
    private var sequence = 0

    @Synchronized fun begin(description: Description) {
        check(active == null)
        active = checkNotNull(cases["${description.className}#${description.methodName}"])
        emit(active, Step.CASE, "BEGIN")
    }

    @Synchronized fun finish() {
        emit(active, Step.CASE, "END") // completion marker only; pass/fail still comes from JUnit.
        active = null
    }

    @Synchronized private fun emit(case: String?, step: Step, event: String) {
        if (case == null || active != case) return
        // High-frequency helper details only for the observed repeated-swipe case.
        if (step in setOf(Step.MAIN, Step.IDLE, Step.POINTER_DOWN, Step.POINTER_MOVE, Step.POINTER_UP)
            && case != "C05") return
        val elapsed = SystemClock.elapsedRealtime() - origin
        if (elapsed !in 0..600_000L) return
        Log.i("IsolatedUiStep", "UI_STEP_V1|${++sequence}|$case|${step.name}|$event|$elapsed")
    }

    fun <T> step(step: Step, action: () -> T): T {
        val case = synchronized(this) { active }
        emit(case, step, "BEGIN")
        return try {
            val result = action()
            emit(case, step, "END")
            result
        } catch (error: Throwable) {
            emit(case, step, "ERROR")
            throw error
        }
    }
}
