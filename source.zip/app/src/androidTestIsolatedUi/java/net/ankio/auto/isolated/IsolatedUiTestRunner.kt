package net.ankio.auto.isolated

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.test.runner.AndroidJUnitRunner

/** Verify safety before Application instantiation, providers and onCreate, not in @Before. */
class IsolatedUiTestRunner : AndroidJUnitRunner() {
    override fun newApplication(cl: ClassLoader, className: String, context: Context): Application {
        check(className == IsolatedUiApplication::class.java.name) { "Wrong Application: $className" }
        IsolatedUiApplication.assertIsolatedPackage(context)
        return super.newApplication(cl, className, context)
    }

    override fun onCreate(arguments: Bundle) {
        val allowed = setOf(DataPageIsolatedUiTest::class.java.name, RefundIsolatedUiTest::class.java.name)
        val requested = arguments.getString("class")
        if (requested != null) check(requested.split(',').all { it.substringBefore('#') in allowed }) {
            "Only the dedicated isolated UI tests are permitted"
        }
        // Even without a caller filter, never discover or run the legacy androidTest suite.
        arguments.putString("class", requested ?: allowed.joinToString(","))
        super.onCreate(arguments)
    }
}
