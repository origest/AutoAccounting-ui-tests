package net.ankio.auto.isolated

import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.runBlocking
import net.ankio.auto.R
import net.ankio.auto.ui.adapter.BillSelectorAdapter
import net.ankio.auto.ui.dialog.BillEditorDialog
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.tools.LocalRefunds
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** Actual editor -> actual picker -> fake HTTP serialization -> real transaction/validation DAO. */
class RefundIsolatedUiTest : IsolatedUiFixture() {
    private fun picker(editor: BillEditorDialog): View {
        click(dialogRoot(editor), R.id.choose_bill_button)
        await("Picker shown") { hasWindowWith(R.id.statusMessage) }
        return rootWith(R.id.statusMessage)
    }

    private fun waitCandidates(root: View) {
        await("Candidates rendered") {
            root.findViewById<RecyclerView>(R.id.content_view)?.adapter?.itemCount?.let { it > 0 } == true &&
                root.findViewById<View>(R.id.confirmButton).isEnabled
        }
    }

    private fun choose(root: View, originalId: Long) {
        val recycler = onMain { root.findViewById<RecyclerView>(R.id.content_view) }
        val position = onMain { (recycler.adapter as BillSelectorAdapter).getItems()
            .indexOfFirst { it.remoteId == LocalRefunds.encode(originalId) } }
        assertTrue(position >= 0)
        onMain { recycler.scrollToPosition(position) }
        await("Candidate row laid out") { recycler.findViewHolderForAdapterPosition(position) != null }
        tapView(onMain { recycler.findViewHolderForAdapterPosition(position)!!.itemView })
    }

    private fun backFromPicker() {
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
        await("Picker dismissed by Back") { !hasWindowWith(R.id.statusMessage) }
    }

    private fun changeAmount(editor: BillEditorDialog, amount: String) {
        click(dialogRoot(editor), R.id.amount_container)
        await("Real amount editor visible") { hasWindowWith(R.id.input) }
        val root = rootWith(R.id.input)
        // Text is fixture input in the real EditText; confirmation uses a real touch event.
        onMain { root.findViewById<EditText>(R.id.input).setText(amount) }
        click(root, R.id.positiveButton)
        await("Amount edit confirmed") { !hasWindowWith(R.id.input) }
    }

    private fun stored(id: Long): BillInfoModel = runBlocking { backend.db.billInfoDao().queryId(id)!! }

    @Test fun confirmedPickerAndEditorPersistLocalLinkAcrossDatabaseReopen() {
        val original = expense()
        val caller = refund()
        val confirmed = AtomicReference<BillInfoModel>()
        val editor = editor(caller) { confirmed.set(it.copy()) }
        val picker = picker(editor)
        waitCandidates(picker)
        choose(picker, original.id)
        click(picker, R.id.confirmButton)
        await("Picker confirmation returned to editor") { !hasWindowWith(R.id.statusMessage) }
        assertEquals("Caller still owns the unchanged model", "", caller.extendData)
        assertEquals(0, backend.saveRequests.get())
        click(dialogRoot(editor), R.id.confirm_button)
        await("Confirmed save closes real editor") { confirmed.get() != null && !editor.isShowing }
        val saved = confirmed.get()
        await("No in-flight request before reopen") { backend.activeRequests.get() == 0 }
        backend.reopenDatabase()
        val reopened = stored(saved.id)
        assertEquals(LocalRefunds.encode(original.id), reopened.extendData)
        assertEquals(25.0, reopened.money, 0.0)
        assertEquals(original, stored(original.id))
        assertEquals(1, backend.saveRequests.get())
    }

    @Test fun pickerBackAndEditorCancelNeverMutateCallerOrPersistDraft() {
        val original = expense()
        val other = expense(200.0)
        val caller = refund(link = LocalRefunds.encode(original.id))
        caller.id = runBlocking { backend.db.billInfoDao().saveWithLocalRefundValidation(caller) }
        val before = stored(caller.id)
        val confirmations = AtomicInteger()
        val editor = editor(caller) { confirmations.incrementAndGet() }
        val picker = picker(editor)
        waitCandidates(picker)
        choose(picker, other.id)
        backFromPicker()
        changeAmount(editor, "40")
        click(dialogRoot(editor), R.id.cancel_button)
        await("Editor Cancel") { !editor.isShowing }
        assertEquals(LocalRefunds.encode(original.id), caller.extendData)
        assertEquals(25.0, caller.money, 0.0)
        assertEquals(before, stored(caller.id))
        assertEquals(0, backend.saveRequests.get())
        assertEquals(0, confirmations.get())
    }

    @Test fun emptyPickerDoesNotImplicitlyClearExistingLink() {
        val original = expense()
        val caller = refund(link = LocalRefunds.encode(original.id))
        backend.emptyCandidates = true
        val editor = editor(caller)
        val picker = picker(editor)
        await("Explicit empty candidates state") { picker.findViewById<View>(R.id.group_empty).isShown }
        onMain {
            assertFalse(picker.findViewById<View>(R.id.confirmButton).isEnabled)
            assertTrue(picker.findViewById<View>(R.id.clearSelectionButton).isShown)
        }
        backFromPicker()
        click(dialogRoot(editor), R.id.cancel_button)
        assertEquals(LocalRefunds.encode(original.id), caller.extendData)
        assertEquals(0, backend.saveRequests.get())
    }

    @Test fun candidateErrorRetryAndRepeatedRetryStayProvisionalUntilConfirmation() {
        val original = expense()
        backend.candidateFailure = SyntheticUiBackend.Failure.TRANSPORT
        val editor = editor(refund())
        val picker = picker(editor)
        await("Picker error rather than empty") { picker.findViewById<View>(R.id.group_error).isShown }
        onMain { assertFalse(picker.findViewById<View>(R.id.confirmButton).isEnabled) }
        backend.candidateFailure = SyntheticUiBackend.Failure.NONE
        val gate = CompletableDeferred<Unit>()
        backend.candidateGate = gate
        val retryBounds = screenBounds(onMain { picker.findViewById<View>(R.id.retryButton) })
        click(picker, R.id.retryButton)
        await("Retry began") { backend.candidateRequests.get() == 2 }
        // Retry hides while loading, so a second actual touch at its old location is inert.
        onMain { assertFalse(picker.findViewById<View>(R.id.retryButton).isShown) }
        gesture(retryBounds.exactCenterX(), retryBounds.exactCenterY(),
            retryBounds.exactCenterX(), retryBounds.exactCenterY(), 50)
        assertEquals(2, backend.candidateRequests.get())
        backend.candidateGate = null
        gate.complete(Unit)
        waitCandidates(picker)
        choose(picker, original.id)
        backFromPicker()
        click(dialogRoot(editor), R.id.cancel_button)
        assertEquals(2, backend.candidateRequests.get())
        assertEquals(0, backend.saveRequests.get())
    }

    @Test fun failedSaveKeepsEditorAndRetryPersistsExactlyOnce() {
        val original = expense()
        val confirmations = AtomicInteger()
        val saved = AtomicReference<BillInfoModel>()
        backend.failNextSave = true
        val editor = editor(refund(link = LocalRefunds.encode(original.id))) {
            confirmations.incrementAndGet(); saved.set(it.copy())
        }
        click(dialogRoot(editor), R.id.confirm_button)
        await("Failure restores editable dialog") { backend.saveRequests.get() == 1 &&
            editor.isShowing && saveButton(editor).isEnabled }
        assertEquals(0, confirmations.get())
        assertEquals(1, runBlocking { backend.db.billInfoDao().getBillsCount() })
        click(dialogRoot(editor), R.id.confirm_button)
        await("Retry confirmed") { confirmations.get() == 1 && !editor.isShowing }
        assertEquals(LocalRefunds.encode(original.id), stored(saved.get().id).extendData)
        assertEquals(2, backend.saveRequests.get())
        assertEquals(2, runBlocking { backend.db.billInfoDao().getBillsCount() })
    }

    @Test fun overRefundAndZeroValidationKeepEditorOpenUntilAmountCorrected() {
        val original = expense(100.0)
        val saved = AtomicReference<BillInfoModel>()
        val editor = editor(refund(money = 101.0, link = LocalRefunds.encode(original.id))) { saved.set(it.copy()) }
        click(dialogRoot(editor), R.id.confirm_button)
        await("Over-refund rejected by real DAO") {
            backend.lastSaveFailure == "退款金额超过原单剩余可退金额" && saveButton(editor).isEnabled
        }
        assertTrue(onMain { editor.isShowing })
        assertEquals(original, stored(original.id))
        changeAmount(editor, "0")
        click(dialogRoot(editor), R.id.confirm_button)
        await("Zero rejected") { backend.lastSaveFailure == "退款金额必须大于 0" && saveButton(editor).isEnabled }
        assertNull(saved.get())
        changeAmount(editor, "30")
        click(dialogRoot(editor), R.id.confirm_button)
        await("Corrected amount saves") { saved.get() != null && !editor.isShowing }
        assertEquals(30.0, stored(saved.get().id).money, 0.0)
        assertEquals(original, stored(original.id))
    }

    @Test fun committedCreateWithLostResponseReconcilesWithoutDuplicateRefund() {
        val original = expense()
        val confirmations = AtomicInteger()
        backend.loseNextCreateResponse = true
        val editor = editor(refund(link = LocalRefunds.encode(original.id))) { confirmations.incrementAndGet() }
        click(dialogRoot(editor), R.id.confirm_button)
        await("Unknown response restores dialog") { backend.saveRequests.get() == 1 && saveButton(editor).isEnabled }
        assertEquals(0, confirmations.get())
        assertEquals(2, runBlocking { backend.db.billInfoDao().getBillsCount() })
        click(dialogRoot(editor), R.id.confirm_button)
        await("Receipt reconciled") { confirmations.get() == 1 && !editor.isShowing }
        assertEquals(2, backend.saveRequests.get())
        assertEquals(2, runBlocking { backend.db.billInfoDao().getBillsCount() })
    }

    @Test fun repeatedConfirmWhileSavingCannotCreateDuplicateRefunds() {
        val original = expense()
        val gate = CompletableDeferred<Unit>()
        backend.saveGate = gate
        val confirmations = AtomicInteger()
        val editor = editor(refund(link = LocalRefunds.encode(original.id))) { confirmations.incrementAndGet() }
        val root = dialogRoot(editor)
        click(root, R.id.confirm_button)
        await("Save running") { backend.saveRequests.get() == 1 && !saveButton(editor).isEnabled }
        val bounds = screenBounds(onMain { saveButton(editor) })
        gesture(bounds.exactCenterX(), bounds.exactCenterY(), bounds.exactCenterX(), bounds.exactCenterY(), 50)
        assertEquals(1, backend.saveRequests.get())
        onMain { assertFalse(root.findViewById<View>(R.id.cancel_button).isEnabled) }
        backend.saveGate = null
        gate.complete(Unit)
        await("Single confirmation") { confirmations.get() == 1 && !editor.isShowing }
        assertEquals(2, runBlocking { backend.db.billInfoDao().getBillsCount() })
    }

    @Test fun explicitClearNeedsPickerAndEditorConfirmationToPersist() {
        val original = expense()
        val bill = refund(link = LocalRefunds.encode(original.id))
        bill.id = runBlocking { backend.db.billInfoDao().saveWithLocalRefundValidation(bill) }
        val saved = AtomicReference<BillInfoModel>()
        val editor = editor(bill) { saved.set(it.copy()) }
        val picker = picker(editor)
        waitCandidates(picker)
        click(picker, R.id.clearSelectionButton)
        assertEquals(LocalRefunds.encode(original.id), stored(bill.id).extendData)
        click(picker, R.id.confirmButton)
        await("Clear accepted provisionally") { !hasWindowWith(R.id.statusMessage) }
        assertEquals(LocalRefunds.encode(original.id), stored(bill.id).extendData)
        click(dialogRoot(editor), R.id.confirm_button)
        await("Explicit unlink saved") { saved.get() != null && !editor.isShowing }
        assertEquals("", stored(bill.id).extendData)
        assertEquals(original, stored(original.id))
    }
}
