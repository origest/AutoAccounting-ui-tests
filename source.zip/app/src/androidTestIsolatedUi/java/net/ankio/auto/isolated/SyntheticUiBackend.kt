package net.ankio.auto.isolated

import android.content.Context
import android.net.Uri
import androidx.room.Room
import com.google.gson.Gson
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.coroutines.CompletableDeferred
import org.ezbook.server.constant.DataType
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.AppDataModel
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookBillModel
import org.ezbook.server.db.model.BookNameModel
import org.ezbook.server.models.ResultModel
import org.ezbook.server.tools.LocalRefunds
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/** In-process fake HTTP boundary, real Room DAOs, no server/socket, no production Db singleton. */
class SyntheticUiBackend(private val context: Context) : AutoCloseable {
    enum class Failure { NONE, TRANSPORT, NON_SUCCESS, MISSING_DATA }
    val databaseName = "synthetic-isolated-ui-${UUID.randomUUID()}.db"
    var db: AppDatabase = openDatabase()
        private set
    private val gson = Gson()
    val unexpectedRequests = CopyOnWriteArrayList<String>()
    val dataRequests = AtomicInteger()
    private data class GatedDataRead(val gate: CompletableDeferred<Unit>, val job: Job)
    private val gatedDataReads = ConcurrentHashMap<Int, GatedDataRead>()

    /** Observation only: include cancelling reads until their gate-await finally has exited. */
    fun dataReadsAtGate(gate: CompletableDeferred<Unit>): Map<Int, Boolean> =
        gatedDataReads.entries.filter { it.value.gate === gate }
            .associate { it.key to it.value.job.isActive }

    val candidateRequests = AtomicInteger()
    val saveRequests = AtomicInteger()
    val activeRequests = AtomicInteger()
    @Volatile var dataFailure = Failure.NONE
    @Volatile var candidateFailure = Failure.NONE
    @Volatile var emptyCandidates = false
    @Volatile var failNextSave = false
    @Volatile var loseNextCreateResponse = false
    @Volatile var lastSaveFailure: String? = null
    @Volatile var dataGate: CompletableDeferred<Unit>? = null
    @Volatile var candidateGate: CompletableDeferred<Unit>? = null
    @Volatile var saveGate: CompletableDeferred<Unit>? = null

    init {
        check(context.packageName == IsolatedUiApplication.PACKAGE)
        check(databaseName.startsWith("synthetic-isolated-ui-"))
    }

    private fun openDatabase(): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, databaseName).build()

    fun reopenDatabase() {
        check(activeRequests.get() == 0)
        db.close()
        db = openDatabase()
    }

    suspend fun insertNotice(text: String): Long = db.dataDao().insert(AppDataModel().apply {
        type = DataType.NOTICE
        app = "synthetic.notification.fixture"
        data = text
        time = 1_800_000_000_000L
    })

    private fun response(data: Any?): String = gson.toJson(ResultModel.ok(data))
    private fun failure(mode: Failure): String? = when (mode) {
        Failure.NONE -> null
        Failure.TRANSPORT -> throw IOException("synthetic_offline")
        Failure.NON_SUCCESS -> gson.toJson(ResultModel.error(503, "synthetic_unavailable"))
        Failure.MISSING_DATA -> "{\"code\":200,\"msg\":\"OK\"}"
    }

    suspend fun request(method: String, path: String, body: String?): String {
        // Deliberately no catch-all empty success: unexpected endpoints fail and fail tearDown.
        activeRequests.incrementAndGet()
        try {
            val uri = Uri.parse("synthetic://fixture/$path")
            val route = uri.path!!.trimStart('/')
            return when ("$method $route") {
                "GET bill/createSource" -> response(org.ezbook.server.server.billCreationSource(db))
                "POST bill/createReceipt" -> response(org.ezbook.server.server.lookupBillCreation(
                    gson.fromJson(body, org.ezbook.server.server.BillCreateTarget::class.java), db))
                "POST bill/create" -> {
                    saveRequests.incrementAndGet()
                    saveGate?.await()
                    if (failNextSave) {
                        failNextSave = false
                        throw IOException("synthetic_save_offline")
                    }
                    try {
                        val result = org.ezbook.server.server.createBillOnce(
                            gson.fromJson(body, org.ezbook.server.server.BillCreateRequest::class.java), db)
                        if (loseNextCreateResponse) {
                            loseNextCreateResponse = false
                            throw IOException("synthetic_committed_response_lost")
                        }
                        lastSaveFailure = null
                        response(result)
                    } catch (e: org.ezbook.server.server.BillCreateRejected) {
                        lastSaveFailure = e.message
                        gson.toJson(ResultModel.error(422, e.message ?: "synthetic_invalid"))
                    } catch (e: IllegalStateException) {
                        lastSaveFailure = e.message
                        gson.toJson(ResultModel.error(409, e.message ?: "synthetic_conflict"))
                    }
                }
                "GET data/list" -> {
                    val requestId = dataRequests.incrementAndGet()
                    dataGate?.let { gate ->
                        gatedDataReads[requestId] = GatedDataRead(gate, currentCoroutineContext().job)
                        try {
                            gate.await()
                        } finally {
                            gatedDataReads.remove(requestId)
                        }
                    }
                    failure(dataFailure) ?: run {
                        val page = uri.getQueryParameter("page")!!.toInt()
                        val limit = uri.getQueryParameter("limit")!!.toInt()
                        response(db.dataDao().load(limit, (page - 1) * limit,
                            uri.getQueryParameter("app").orEmpty(),
                            uri.getQueryParameter("match")?.toBooleanStrictOrNull(),
                            uri.getQueryParameter("type")?.takeIf { it.isNotEmpty() },
                            uri.getQueryParameter("search")))
                    }
                }
                "GET data/apps" -> response(emptyMap<String, String>())
                "POST bill/refund/candidates" -> {
                    candidateRequests.incrementAndGet()
                    candidateGate?.await()
                    failure(candidateFailure) ?: run {
                        val refund = gson.fromJson(body, BillInfoModel::class.java)
                        val candidates = db.billInfoDao().localRefundCandidates(refund.bookName, refund.id)
                            .filter { LocalRefunds.isCandidate(it, refund) }
                            .mapNotNull { original ->
                                val reference = LocalRefunds.encode(original.id)
                                val remaining = LocalRefunds.remaining(original,
                                    db.billInfoDao().localRefundsFor(reference, refund.id))
                                if (remaining.signum() <= 0) null else BookBillModel().apply {
                                    remoteId = reference
                                    money = original.money
                                    time = original.time
                                    category = original.cateName
                                    remark = "Synthetic original; remaining $remaining"
                                }
                            }
                        response(if (emptyCandidates) emptyList<BookBillModel>() else candidates)
                    }
                }
                "POST bill/put" -> {
                    saveRequests.incrementAndGet()
                    saveGate?.await()
                    if (failNextSave) {
                        failNextSave = false
                        throw IOException("synthetic_save_offline")
                    }
                    val bill = gson.fromJson(body, BillInfoModel::class.java)
                    try {
                        check(bill.id > 0) { "synthetic_legacy_create_forbidden" }
                        val id = db.billInfoDao().saveWithLocalRefundValidation(bill)
                        lastSaveFailure = null
                        response(id)
                    } catch (e: IllegalArgumentException) {
                        lastSaveFailure = e.message
                        gson.toJson(ResultModel.error(422, e.message ?: "synthetic_invalid"))
                    } catch (e: IllegalStateException) {
                        lastSaveFailure = e.message
                        gson.toJson(ResultModel.error(409, e.message ?: "synthetic_stale"))
                    }
                }
                "GET book/get", "GET book/default" -> response(BookNameModel().apply {
                    id = 1L; name = "Synthetic"; remoteId = "synthetic-book"
                })
                "POST book/list" -> response(listOf(BookNameModel().apply {
                    id = 1L; name = "Synthetic"; remoteId = "synthetic-book"
                }))
                "GET assets/list", "GET category/list" -> response(emptyList<Any>())
                "GET assets/get", "GET category/get" -> response(null)
                // Logger may emit diagnostics, kept in-process and never exported.
                "POST log/addBatch" -> response(emptyList<Long>())
                else -> {
                    unexpectedRequests += "$method $route"
                    error("Forbidden synthetic endpoint: $method $route")
                }
            }
        } finally {
            activeRequests.decrementAndGet()
        }
    }

    override fun close() {
        db.close()
        check(context.packageName == IsolatedUiApplication.PACKAGE)
        check(databaseName.startsWith("synthetic-isolated-ui-"))
        check(context.deleteDatabase(databaseName)) { "Synthetic database cleanup failed" }
    }
}
