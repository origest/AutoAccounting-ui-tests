package net.ankio.auto.isolated;

import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.LongSupplier;

/** Test-only deadline shared by posting, polling and observation. No Android dependency. */
final class UiTestDeadline {
    private final AtomicBoolean poisoned = new AtomicBoolean();

    void assertHealthy() {
        if (poisoned.get()) throw new AssertionError("UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS");
    }

    synchronized void preventFurtherActions() { poisoned.set(true); }

    <T> Task<T> task(Callable<T> action) {
        assertHealthy();
        return new Task<>(this, action, new AtomicReference<>(Lifecycle.QUEUED));
    }

    enum Lifecycle { QUEUED, RUNNING, FINISHED, CANCELLED_BEFORE_START }

    /**
     * Future.isDone/isCancelled cannot establish quiescence: cancel(false) can mark a
     * running FutureTask done while its Callable keeps writing. Only this task's own
     * start/cancel CAS, or the Callable's finally, can establish that it cannot write.
     * FINISHED says nothing about asynchronous work started by the Callable; the
     * fixture must still destroy the host, drain requests and close/delete its database.
     */
    static final class Task<T> extends FutureTask<T> {
        private final UiTestDeadline owner;
        private final AtomicReference<Lifecycle> state;

        private Task(UiTestDeadline owner, Callable<T> action, AtomicReference<Lifecycle> state) {
            super(() -> {
                try {
                    return action.call();
                } finally {
                    state.set(Lifecycle.FINISHED);
                }
            });
            this.owner = owner;
            this.state = state;
        }

        @Override public void run() {
            // Serialize admission with permanent poisoning. Already-running actions
            // cannot be stopped safely; their failure prevents all subsequent actions.
            synchronized (owner) {
                if (owner.poisoned.get()) {
                    cancel(false);
                    return;
                }
                if (!state.compareAndSet(Lifecycle.QUEUED, Lifecycle.RUNNING)) return;
            }
            super.run();
        }

        @Override public boolean cancel(boolean mayInterruptIfRunning) {
            // Never interrupt the Android main thread, or mark a RUNNING action done.
            if (!state.compareAndSet(Lifecycle.QUEUED, Lifecycle.CANCELLED_BEFORE_START)) return false;
            return super.cancel(false);
        }

        private boolean stopBeforeStartOrFinished() {
            cancel(false);
            Lifecycle current = state.get();
            return current == Lifecycle.CANCELLED_BEFORE_START || current == Lifecycle.FINISHED;
        }
    }

    /** Called for scheduler failures too, whose accepted/queued outcome may be unknown. */
    void failed(Future<?> task, Throwable failure) {
        if (task instanceof Task<?> && ((Task<?>) task).owner == this) {
            if (!((Task<?>) task).stopBeforeStartOrFinished()) preventFurtherActions();
        } else {
            // An arbitrary Future supplies no trustworthy Callable-lifecycle evidence.
            preventFurtherActions();
            try {
                task.cancel(false);
            } catch (Throwable cancellationFailure) {
                if (cancellationFailure != failure) failure.addSuppressed(cancellationFailure);
            }
        }
    }

    <T> T get(Future<T> task, long deadlineMs, LongSupplier clock) {
        try {
            assertHealthy();
            long remaining = deadlineMs - clock.getAsLong();
            if (remaining <= 0) throw new TimeoutException();
            return task.get(remaining, TimeUnit.MILLISECONDS);
        } catch (TimeoutException timeout) {
            AssertionError failure = new AssertionError("UI_TEST_DEADLINE_EXCEEDED");
            failed(task, failure);
            throw failure;
        } catch (InterruptedException interrupted) {
            AssertionError failure = new AssertionError("UI_TEST_WAIT_INTERRUPTED", interrupted);
            failed(task, failure);
            Thread.currentThread().interrupt();
            throw failure;
        } catch (CancellationException cancelled) {
            AssertionError failure = new AssertionError("UI_TEST_ACTION_CANCELLED", cancelled);
            failed(task, failure);
            throw failure;
        } catch (ExecutionException executionFailure) {
            Throwable cause = executionFailure.getCause();
            failed(task, cause != null ? cause : executionFailure);
            if (cause instanceof Error) throw (Error) cause;
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            throw new AssertionError("UI_TEST_MAIN_ACTION_FAILED", cause);
        } catch (RuntimeException | Error failure) {
            // Includes a prior process guard or a clock/get implementation failure.
            failed(task, failure);
            throw failure;
        }
    }
}
