package net.ankio.auto.isolated;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.LongSupplier;

/** Test-only deadline shared by posting, polling and observation. No Android dependency. */
final class UiTestDeadline {
    private final AtomicBoolean poisoned = new AtomicBoolean();

    void assertHealthy() {
        if (poisoned.get()) throw new AssertionError("UI_TEST_PRIOR_WAIT_FAILED_NO_FURTHER_ACTIONS");
    }

    void preventFurtherActions() { poisoned.set(true); }

    <T> T get(Future<T> task, long deadlineMs, LongSupplier clock) {
        assertHealthy();
        try {
            long remaining = deadlineMs - clock.getAsLong();
            if (remaining <= 0) throw new TimeoutException();
            return task.get(remaining, TimeUnit.MILLISECONDS);
        } catch (TimeoutException timeout) {
            // Do not interrupt Android's main thread. A queued FutureTask will never execute.
            poisoned.set(true);
            task.cancel(false);
            throw new AssertionError("UI_TEST_DEADLINE_EXCEEDED");
        } catch (InterruptedException interrupted) {
            poisoned.set(true);
            task.cancel(false);
            Thread.currentThread().interrupt();
            throw new AssertionError("UI_TEST_WAIT_INTERRUPTED");
        } catch (ExecutionException failed) {
            Throwable cause = failed.getCause();
            if (cause instanceof Error) throw (Error) cause;
            if (cause instanceof RuntimeException) throw (RuntimeException) cause;
            throw new AssertionError("UI_TEST_MAIN_ACTION_FAILED", cause);
        }
    }
}
