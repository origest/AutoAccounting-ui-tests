package net.ankio.auto.isolated;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.MultipleFailureException;
import org.junit.runners.model.Statement;

/** Keep the first failure when Android's result printer overwrites repeated failure callbacks. */
final class UiTestFailureRule implements TestRule {
    private final TestRule delegate;

    UiTestFailureRule(TestRule delegate) { this.delegate = delegate; }

    @Override public Statement apply(Statement base, Description description) {
        Statement watched = delegate.apply(base, description);
        return new Statement() {
            @Override public void evaluate() throws Throwable {
                try {
                    watched.evaluate();
                } catch (MultipleFailureException failures) {
                    // All @After methods have already run. Never skip cleanup or clear its guard.
                    throw preserveFirst(failures);
                }
            }
        };
    }

    private static Throwable preserveFirst(MultipleFailureException aggregate) {
        List<Throwable> failures = new ArrayList<>();
        Set<Throwable> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        ArrayDeque<Throwable> pending = new ArrayDeque<>();
        pending.push(aggregate);
        while (!pending.isEmpty()) {
            Throwable next = pending.pop();
            if (!seen.add(next)) continue;
            if (next instanceof MultipleFailureException) {
                List<Throwable> children = ((MultipleFailureException) next).getFailures();
                if (children.isEmpty()) return retained(aggregate, failures);
                for (int i = children.size() - 1; i >= 0; i--) {
                    Throwable child = children.get(i);
                    if (child == null) return retained(aggregate, failures);
                    pending.push(child);
                }
            } else {
                failures.add(next);
            }
        }
        if (failures.isEmpty()) return retained(aggregate, failures);
        Throwable first = failures.get(0);
        for (int i = 1; i < failures.size(); i++) {
            Throwable later = failures.get(i);
            if (!hasSuppressed(first, later)) first.addSuppressed(later);
            // Throwable can disable suppression. Preserve every error without turning it into a pass.
            if (!hasSuppressed(first, later)) return retained(first, failures.subList(1, failures.size()));
        }
        return first;
    }

    private static boolean hasSuppressed(Throwable first, Throwable later) {
        for (Throwable existing : first.getSuppressed()) if (existing == later) return true;
        return false;
    }

    private static Throwable retained(Throwable first, List<Throwable> later) {
        AssertionError failure = new AssertionError("UI_TEST_MULTIPLE_FAILURES_RETAINED", first);
        for (Throwable error : later) if (error != first) failure.addSuppressed(error);
        return failure;
    }
}
