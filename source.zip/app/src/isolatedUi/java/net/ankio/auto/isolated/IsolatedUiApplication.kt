package net.ankio.auto.isolated

import android.content.Context
import android.content.pm.PackageManager
import com.tencent.mmkv.MMKV
import net.ankio.auto.App
import net.ankio.auto.BuildConfig
import net.ankio.auto.autoApp
import net.ankio.auto.http.LocalNetwork
import net.ankio.auto.ui.utils.ToastUtils
import org.ezbook.server.constant.Setting
import java.io.File
import java.util.UUID

/** Test-only entry point. App's build-time guard excludes all production initialization. */
class IsolatedUiApplication : App() {
    override fun attachBaseContext(base: Context) {
        assertIsolatedPackage(base)
        super.attachBaseContext(base)
    }

    override fun onCreate() {
        assertIsolatedPackage(this)
        // App.onCreate returns immediately after Application.onCreate in this build.
        // Keep both the pre-startup assertions and the framework lifecycle contract.
        super.onCreate()
        autoApp = this
        LocalNetwork.installIsolatedTransport { _, path, _ ->
            error("No synthetic backend installed: $path")
        }
        MMKV.initialize(this, File(filesDir, "synthetic-mmkv-${UUID.randomUUID()}").absolutePath)
        resetSyntheticPreferences()
        ToastUtils.init(this)
    }

    companion object {
        const val PACKAGE = "net.ankio.auto.isolatedui"

        @Suppress("DEPRECATION")
        fun assertIsolatedPackage(context: Context) {
            check(BuildConfig.ISOLATED_UI && context.packageName == PACKAGE)
            val info = context.packageManager.getPackageInfo(PACKAGE,
                PackageManager.GET_PERMISSIONS or PackageManager.GET_PROVIDERS or
                    PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS or PackageManager.GET_ACTIVITIES)
            check(info.requestedPermissions.isNullOrEmpty()) { "Isolated APK must request no permissions" }
            check(info.providers.isNullOrEmpty() && info.services.isNullOrEmpty() && info.receivers.isNullOrEmpty()) {
                "Production or dependency startup components leaked into isolated APK"
            }
            check(info.activities?.map { it.name } == listOf(IsolatedUiHostActivity::class.java.name))
            check(info.activities?.single()?.exported == false)
            check(info.applicationInfo?.className == IsolatedUiApplication::class.java.name)
        }

        fun resetSyntheticPreferences() {
            assertIsolatedPackage(autoApp)
            // Only this permission-free test APK's private recovery journal may be reset here.
            android.util.AtomicFile(File(autoApp.noBackupFilesDir, "bill_create_recovery_v1.json")).delete()
            // Direct synthetic store writes, not PrefManager setters (which synchronize settings).
            MMKV.mmkvWithID("settings", MMKV.MULTI_PROCESS_MODE).apply {
                clearAll()
                encode("_mmkv_migrated_v1", true)
                encode(Setting.BOOK_APP_ID, "synthetic.local.only")
                encode(Setting.MANUAL_SYNC, true)
                // Refund picker is inside the asset-management payment component.
                // Enable its real UI prerequisite in this synthetic store only.
                encode(Setting.SETTING_ASSET_MANAGER, true)
                encode(Setting.AUTO_CREATE_CATEGORY, false)
                encode(Setting.AUTO_ASSET_MAPPING, false)
                encode(Setting.SHOW_SUCCESS_POPUP, false)
                encode(Setting.FEATURE_AI_AVAILABLE, false)
                encode(Setting.AI_CATEGORY_CHATGPT, false)
                encode(Setting.AI_CATEGORY_HISTORY, false)
            }
        }
    }
}
