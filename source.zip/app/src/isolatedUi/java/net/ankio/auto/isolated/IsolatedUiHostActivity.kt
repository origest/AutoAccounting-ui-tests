package net.ankio.auto.isolated

import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import net.ankio.auto.ui.fragment.DataFragment

/** Empty host only. All displayed screens/dialogs are the production UI components. */
class IsolatedUiHostActivity : AppCompatActivity() {
    companion object { const val CONTAINER_ID = 0x123456 }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(FrameLayout(this).apply { id = CONTAINER_ID })
    }

    fun showData(fragment: DataFragment = DataFragment()): DataFragment {
        supportFragmentManager.beginTransaction().replace(CONTAINER_ID, fragment).commitNow()
        return fragment
    }
}
