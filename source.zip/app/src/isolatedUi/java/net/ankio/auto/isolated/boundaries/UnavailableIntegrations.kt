// SPDX-License-Identifier: GPL-3.0-only
// New isolated-test-only adapters. No upstream SDK implementation is copied here.
package net.ankio.auto.isolated.boundaries

import android.content.Context
import android.graphics.Bitmap
import java.io.Closeable

private fun unavailable(component: String): Nothing =
    throw UnsupportedOperationException("$component is excluded from the isolated UI test source package")

class UnavailableOcrProcessor : Closeable {
    init { unavailable("OCR") }
    fun debug(enabled: Boolean): UnavailableOcrProcessor = unavailable("OCR")
    fun log(sink: (String, Int) -> Unit): UnavailableOcrProcessor = unavailable("OCR")
    fun attach(context: Context): UnavailableOcrProcessor = unavailable("OCR")
    suspend fun startProcess(bitmap: Bitmap): String = unavailable("OCR")
    override fun close(): Unit = unavailable("OCR")
}

class UnavailableBackTapDetector(context: Context, callback: () -> Unit) {
    init { unavailable("Back-tap detection") }
    fun start(): Unit = unavailable("Back-tap detection")
    fun stop(): Unit = unavailable("Back-tap detection")
    fun isStarted(): Boolean = unavailable("Back-tap detection")
}

object UnavailableTapLogger {
    var hook: ((Int, String, Throwable?) -> Unit)?
        get() = unavailable("Back-tap logging")
        set(value) { unavailable("Back-tap logging") }
}

object UnavailableCrashReporter {
    class UserStrategy(context: Context) {
        init { unavailable("Crash reporting") }
        var appVersion: String = ""
        var appPackageName: String = ""
        var deviceModel: String = ""
    }
    fun initCrashReport(context: Context, appId: String, debug: Boolean, strategy: UserStrategy): Unit =
        unavailable("Crash reporting")
    fun postCatchedException(error: Throwable): Unit = unavailable("Crash reporting")
}
