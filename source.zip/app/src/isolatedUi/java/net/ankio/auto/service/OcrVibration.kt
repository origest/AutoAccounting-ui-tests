package net.ankio.auto.service

import android.content.Context
import net.ankio.auto.BuildConfig

/** Deliberate no-op: the isolated variant has no hardware-feedback permission or call. */
internal object OcrVibration {
    fun trigger(context: Context) {
        check(BuildConfig.ISOLATED_UI && context.packageName == "net.ankio.auto.isolatedui")
    }
}
