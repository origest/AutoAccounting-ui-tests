/*
 * Copyright (C) 2026 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

@file:Suppress("DEPRECATION")

package com.google.android.accessibility.selecttospeak

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.android.accessibility.selecttospeak.SelectToSpeakService.Companion.instance
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import net.ankio.auto.service.AnalysisUtils
import net.ankio.auto.service.CoreService
import net.ankio.auto.service.ocr.PageSignatureManager
import net.ankio.auto.storage.Logger
import net.ankio.auto.utils.PrefManager
import net.ankio.auto.utils.Debounce
import org.ezbook.server.intent.IntentType

/**
 * OCR 无障碍服务
 *
 * 职责：
 * - 跟踪当前前台应用包名及 Activity（通过窗口变化事件）
 * - 页面切换时自动触发 OCR：当切换到已记住页面或白名单应用时
 * - 提供截图能力（Android 11+ takeScreenshot API）
 * - 提供收起通知栏能力（performGlobalAction）
 *
 * 该服务仅在用户选择「无障碍」授权方式时由系统启动，
 * 通过静态 [instance] 引用供 [net.ankio.auto.service.ocr.OcrTools] 访问。
 */
class SelectToSpeakService : AccessibilityService() {

    private var captureController: net.ankio.auto.capture.PaymentCaptureController? = null
    val paymentCapture: net.ankio.auto.capture.PaymentCaptureController
        get() = captureController ?: net.ankio.auto.capture.PaymentCaptureController(this).also { captureController = it }

    companion object {
        /** 当前服务实例，null 表示服务未运行 */
        @Volatile
        var instance: SelectToSpeakService? = null
            private set

        /** 最近一次检测到的前台应用包名 */
        @Volatile
        var topPackage: String? = null
            private set

        /** 最近一次检测到的 Activity 类名（TYPE_WINDOW_STATE_CHANGED 时 event.className） */
        @Volatile
        var topActivity: String? = null
            private set

        var lastContentFingerprint: String? = null

        var structFp: String? = null

    }

    /** 内容变化防抖：最后一次变化后 500ms 执行，保证一定会执行 */
    private val contentChangeDebounce = Debounce<Unit>(delayMs = 500) {
        processContentChange()
    }

    private fun filterPkg(pkg: String?): Boolean {
        if (pkg.isNullOrEmpty()) {
            Logger.d("Package name is null or empty, skip")
            return false
        }

        val p = pkg.lowercase()

        // 1. 过滤标准 Android 系统组件
        if (p == "android" || p.startsWith("com.android.")) {
            Logger.d("Filter out Android system package: $pkg")
            return false
        }

        // 2. 过滤常见的厂商系统/设置组件
        if (p.contains("systemui") || p.contains("settings")) {
            Logger.d("Filter out system/settings package: $pkg")
            return false
        }

        // 3. 过滤桌面 (Launcher)

        val androidLauncherList = listOf<String>(
            "com.google.android.apps.nexuslauncher",   // Google Pixel (Pixel Launcher)
            "com.sec.android.app.launcher",             // 三星 (One UI Home)
            "com.miui.home",                            // 小米/红米 (MIUI/HyperOS)
            "com.huawei.android.launcher",              // 华为 (HarmonyOS/EMUI)
            "com.hihonor.android.launcher",             // 荣耀 (MagicOS)
            "com.oppo.launcher",                        // OPPO (ColorOS)
            "com.bbk.launcher2",                        // vivo/iQOO (OriginOS - 早期及核心)
            "com.vivo.launcher",                        // vivo (部分海外版或新机型)
            "net.oneplus.launcher",                     // 一加 (氢OS/早期氧OS)
            "com.meizu.flyme.launcher",                 // 魅族 (Flyme)
            "com.motorola.launcher3",                   // 摩托罗拉
            "com.sonyericsson.home",                    // 索尼 (Xperia Home)
            "com.android.launcher3",                    // AOSP/原生安卓/类原生
            "com.android.launcher2",                    // 极老旧安卓原生版本
            "com.htc.launcher",                         // HTC (Sense)
            "com.lge.launcher",                         // LG
            "com.transsion.hilauncher",                 // 传音 (Tecno/Infinix)
            "com.nothing.launcher"                      // Nothing Phone
        )

        if (androidLauncherList.any { p.contains(it) }) {
            Logger.d("Filter out known launcher package: $pkg")
            return false
        }

        return true
    }

    suspend fun getTopPackage(): String? = withTimeout(10_000L) {
        if (topPackage.isNullOrEmpty()) {
            Logger.d("Top package is null or empty")

            while (instance == null || instance?.rootInActiveWindow == null) {
                Logger.d("Waiting for accessibility service to be ready...")
                delay(500)
            }
            val rootNode = rootInActiveWindow
            if (rootNode != null) {
                val packageName = rootNode.packageName?.toString()
                if (filterPkg(packageName)) {
                    Logger.i("Top package from active window: $packageName")
                    topPackage = packageName
                    return@withTimeout packageName
                }
                rootNode.recycle()
            }
            return@withTimeout null
        }
        return@withTimeout topPackage
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Logger.d("Accessibility service connected")
        // 设置 FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY，使 WebView 子节点可被遍历（findAccessibilityNodeInfosByText 对 WebView 无效，需先找 WebView 再遍历其子节点）
        @Suppress("DEPRECATION")
        serviceInfo?.let { info ->
            info.flags =
                info.flags or AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY
            serviceInfo = info
        }
        // 不在此处 startActivity 拉起本应用主界面：
        // Xposed/OCR 混合场景下无障碍会随 OCR 结束反复 disable/enable，
        // 每次 onServiceConnected 都启动主 Activity 会把用户从待识别 App（银行/微信等）强行拉回自动记账，
        // 且此时 topPackage 尚未更新，易触发「无法正确识别前台应用」。
        // 从系统设置开启无障碍后，用户按返回键即可回到原应用。
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) paymentCapture.event()
        if (!filterPkg(pkg)) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                topPackage = pkg
                topActivity = event.className?.toString()?.takeIf { it.isNotBlank() }
                paymentCapture.event()
                Logger.d("[OcrTopApp] cache updated: topPackage=$pkg topActivity=$topActivity")
            }

            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                if (!PrefManager.ocrAccessibilityAutoTrigger) return
                contentChangeDebounce.run()
            }

            else -> {

            }
        }
    }

    /** 防抖后的实际处理：收集结构指纹进行匹配，内容指纹去重 */
    private fun processContentChange() {
        val pkg = topPackage ?: return
        val activity = topActivity ?: ""
        // 收集视图结构指纹用于精确匹配页面
        val structFp = collectStructureFingerprint()
        if (!PageSignatureManager.matches(pkg, activity, structFp)) {
            Logger.d("Page not matched: pkg=$pkg, activity=$activity, structFp=$structFp")
            return
        }

        val rawText = collectPageText(maxDepth = 50)
        if (rawText.isBlank()) {
            Logger.d("Page text empty, skip: pkg=$pkg")
            return
        }
        val contentFp = generateFingerprint(rawText)
        if (contentFp == lastContentFingerprint) {
            Logger.d("Content unchanged, skip: pkg=$pkg")
            return
        }
        lastContentFingerprint = contentFp

        if (AnalysisUtils.inWhitelist(contentFp)) {
            Logger.i("OCR auto-trigger: pkg=$pkg, activity=$activity")
            val intent = Intent(this, CoreService::class.java).apply {
                putExtra("intentType", IntentType.OCR.name)
                putExtra("manual", true)
            }
            startService(intent)
        }
    }

    /**
     * 生成内容指纹：移除可变信息后归一化，相同布局得相同指纹
     * - 千分位逗号移除（1,234.56 → 1234.56）
     * - 数字替换为 #
     */
    fun generateFingerprint(ocrText: String): String {
        if (ocrText.isBlank()) return ""
        return ocrText
            .replace(Regex("(?<=\\d),(?=\\d)"), "")
            .replace(Regex("\\d+(\\.\\d+)?"), "#")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(300)
    }

    /**
     * 收集页面视图结构指纹：类名 + id + name 骨架。
     * 不含文本，不受数据变化影响；同一页面布局始终产生近似结果。
     * - class: 节点类名（短名）
     * - id: viewIdResourceName 最后一段（如 btn_submit）
     * - name: contentDescription 归一化后（数字替换为 #，截断 30 字符）
     */
    fun collectStructureFingerprint(): String {
        val root = rootInActiveWindow
        if (root == null) {
            Logger.d("rootInActiveWindow is null, cannot collect structure")
            return ""
        }
        val skeleton = buildStructureSkeleton(root, 0, 5)
        root.recycle()
        return skeleton
    }


    /**
     * 打印 Tree 层次结构（含 class、id、name），用于调试
     *
     * @param root view
     * @param deep 层级，用于缩进
     */
    private fun getViewTreeStr(root: AccessibilityNodeInfo?, deep: Int): String {
        val builder = StringBuilder()
        if (root != null) {
            val tag = buildNodeDescriptor(root)
            builder.append(getSpace(deep)).append("<").append(tag).append(">\n")
            val childCount = root.childCount
            for (i in 0..<childCount) {
                builder.append(getViewTreeStr(root.getChild(i), deep + 1))
            }
            builder.append(getSpace(deep)).append("</").append(tag).append(">\n")
        }
        return builder.toString()
    }

    private fun getSpace(deep: Int): String {
        val s = StringBuilder()
        for (i in 0..<deep) {
            s.append("\t")
        }
        return s.toString()
    }

    /**
     * 递归构建结构骨架：class + id + name，每层最多取前 10 个子节点。
     * 格式：cls / cls#id / cls@name / cls#id@name
     */
    private fun buildStructureSkeleton(
        node: AccessibilityNodeInfo,
        depth: Int,
        maxDepth: Int
    ): String {
        if (depth > maxDepth) return ""
        val descriptor = buildNodeDescriptor(node)
        val childCount = minOf(node.childCount, 10)
        val children = (0 until childCount).mapNotNull { i ->
            node.getChild(i)?.let { child ->
                buildStructureSkeleton(child, depth + 1, maxDepth).also { child.recycle() }
            }
        }.filter { it.isNotEmpty() }
        return if (children.isEmpty()) descriptor else "$descriptor[${children.joinToString(",")}]"
    }

    /**
     * 构建单节点描述符：class + id(viewIdResourceName) + name(contentDescription)
     * - id: 取 viewIdResourceName 最后一段，如 "com.xx:id/btn_ok" -> "btn_ok"
     * - name: contentDescription 归一化（数字->#，空白归一，截断 30 字符）
     */
    private fun buildNodeDescriptor(node: AccessibilityNodeInfo): String {
        val cls = node.className?.toString()?.substringAfterLast('.') ?: "?"
        val id =
            node.viewIdResourceName?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
        val name = node.contentDescription?.toString()
            ?.replace(Regex("\\d+(\\.\\d+)?"), "#")
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
            ?.take(30)
            ?.takeIf { it.isNotBlank() }
        return buildString {
            append(cls)
            id?.let { append("#$it") }
            name?.let { append("@$it") }
        }
    }

    /**
     * 从当前窗口无障碍树收集文本（最多 [maxDepth] 层）
     * 用于生成内容指纹，供 [PageSignatureManager.matches] 模糊匹配
     *
     * 策略：
     * 1. 常规遍历收集原生控件文本
     * 2. 专项处理 WebView：findAccessibilityNodeInfosByText 对 WebView 无效，需先递归找出 WebView 节点再遍历其子控件
     * 3. WebView 子控件无 ID，只能获取 contentDescription 等有限信息；加载完成后可获取包括屏幕外在内的全部内容
     */
    private fun collectPageText(maxDepth: Int): String {
        val root = rootInActiveWindow
        if (root == null) {
            Logger.d("rootInActiveWindow is null, cannot collect page text")
            return ""
        }
        return collectTextFromNodeWithWebView(root, 0, maxDepth).also { root.recycle() }
    }

    /**
     * 遍历收集文本，遇到 WebView 时专项遍历其子控件（需 FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY）
     */
    private fun collectTextFromNodeWithWebView(
        node: AccessibilityNodeInfo,
        depth: Int,
        maxDepth: Int
    ): String {
        if (depth > maxDepth) return ""
        val texts = mutableListOf<String>()
        val childCount = node.childCount
        if (childCount > 0) {
            for (i in 0 until childCount) {
                node.getChild(i)?.let { child ->
                    val grandchildCount = child.childCount
                    if (grandchildCount > 0) {
                        texts.add(collectTextFromNodeWithWebView(child, depth + 1, maxDepth))
                    } else {
                        child.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
                        child.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                            ?.let { texts.add(it) }
                    }
                    child.recycle()
                }
            }
        } else {
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
        }
        return texts.filter { it.isNotBlank() }.joinToString(" ")
    }

    /**
     * 递归遍历：只收集叶子节点的 text/contentDescription。
     * - 有子节点：仅递归，不收集当前节点（避免容器重复）
     * - 无子节点：收集 text 和 contentDescription（含根节点为叶子的情况）
     */
    private fun collectTextFromNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        maxDepth: Int
    ): String {
        if (depth > maxDepth) return ""
        val texts = mutableListOf<String>()
        val childCount = node.childCount
        if (childCount > 0) {
            for (i in 0 until childCount) {
                node.getChild(i)?.let { child ->
                    val grandchildCount = child.childCount
                    if (grandchildCount > 0) {
                        texts.add(collectTextFromNode(child, depth + 1, maxDepth))
                    } else {
                        child.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
                        child.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                            ?.let { texts.add(it) }
                    }
                    child.recycle()
                }
            }
        } else {
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
        }
        return texts.filter { it.isNotBlank() }.joinToString(" ")
    }

    override fun onInterrupt() {
        captureController?.close()
        captureController = null
        Logger.w("Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Logger.d("Accessibility service destroyed")
        captureController?.close()
        captureController = null
        instance = null
        topPackage = null
        topActivity = null
    }
}
