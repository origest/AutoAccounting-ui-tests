package net.ankio.auto.ai.review

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.ankio.auto.classification.ManualBillCategoryDialog
import net.ankio.auto.ui.api.BaseActivity
import net.ankio.auto.ui.utils.SettingsPage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Unified safe status view. It never starts inference merely because the screen is opened. */
class AiReviewActivity : BaseActivity() {
    private var tab = "queue"
    private val anchors = mutableListOf<AiReviewCursor?>(null)
    private var currentPage = AiReviewPage(emptyList(), 0, null)
    private var loaded = false
    private var settingsPage: SettingsPage? = null
    private var summaryView: android.widget.TextView? = null
    private var error: String? = null
    private lateinit var refreshController: AiReviewRefresh<AiReviewPage>
    private var historyDialog: androidx.appcompat.app.AlertDialog? = null
    private var historyJob: kotlinx.coroutines.Job? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        tab = AiReviewTab.from(savedInstanceState?.getString("tab") ?: intent.getStringExtra("tab") ?: "queue").key
        refreshController = AiReviewRefresh(
            read = {
                AiReviewUiFixture.readStarted()
                val selected = AiReviewTab.from(tab)
                val anchor = anchors.last()
                withContext(Dispatchers.IO) { AiReviewStore(applicationContext).use { it.page(selected, anchor) } }
            },
            deliver = { next ->
                if (loaded && error == null && next.records == currentPage.records && next.next == currentPage.next) {
                    // Background changes outside this page update only the count, not the whole view tree.
                    currentPage = next
                    summaryView?.text = pageSummary()
                } else if (!loaded || next != currentPage || error != null) {
                    currentPage = next; loaded = true; error = null; render()
                }
            },
            failure = {
                if (error == null) {
                    error = "任务记录暂时无法读取，未发送请求或改动账单。请检查本机存储后重试。"
                    render()
                }
            }
        )
        supportFragmentManager.setFragmentResultListener(ManualBillCategoryDialog.RESULT, this) { _, _ -> refresh() }
        render()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                try { refreshController.runWhileVisible() }
                finally { historyDialog?.dismiss(); historyDialog = null }
            }
        }
    }
    override fun onSaveInstanceState(outState: Bundle) { outState.putString("tab", tab); super.onSaveInstanceState(outState) }
    private fun refresh() { refreshController.refresh() }
    private fun selectTab(next: String) {
        tab = next
        anchors.clear(); anchors.add(null)
        reloadPage()
    }
    private fun reloadPage() {
        historyJob?.cancel(); historyJob = null
        historyDialog?.dismiss(); historyDialog = null
        loaded = false; error = null
        render(preserveScroll = false)
        refreshController.invalidateAndRefresh()
    }
    private fun pageSummary() = "此状态共 ${currentPage.total} 条，第 ${anchors.size} 页显示 ${currentPage.records.size} 条（每页最多 100 条）。前台每 5 秒刷新当前页；翻页可查看较早记录，待确认不会因历史增加而删除。"
    private fun render(preserveScroll: Boolean = true) {
        val scroll = if (preserveScroll) settingsPage?.scrollPosition() ?: 0 else 0
        val page = SettingsPage(this, "AI 任务与记录")
        settingsPage = page
        page.section("统一状态", "仅显示已接入的 AI 流程。打开本页不会发起模型请求；取消或关闭结果弹窗仍保留待确认建议。")
        page.button("任务队列 · 等待 / 识别中 / 失败", tab == "queue") { selectTab("queue") }
        page.button("待确认 · 已完成识别", tab == "pending") { selectTab("pending") }
        page.button("应用与手动修改历史", tab == "history") { selectTab("history") }
        page.button("刷新当前页") { refresh() }
        if (anchors.size > 1) {
            page.button("上一页") { anchors.removeAt(anchors.lastIndex); reloadPage() }
            page.button("返回最新记录") { selectTab(tab) }
        }
        error?.let { page.text(it).accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        if (!loaded) { page.text("正在读取本机任务记录…"); return }
        val shown = currentPage.records
        summaryView = page.text(pageSummary())
        page.text("记录只含本机标识和分类/资产引用，不保存原文、图片或原始模型回复。")
        currentPage.next?.let { next -> page.button("下一页 · 较早记录", true) { anchors.add(next); reloadPage() } }
        if (shown.isEmpty()) page.text(if (anchors.size > 1) "本页记录的状态可能已经变化，可返回上一页或最新记录。" else "此页暂无记录。")
        shown.forEach { record ->
            val bill = if (record.target.billId > 0) "账单 #${record.target.billId}" else "尚未关联草稿"
            page.section("${kindLabel(record.kind)} · $bill", "${stateLabel(record.state)} · ${time(record.updatedAt)}")
            record.changes.forEach { page.text(changeLabel(it)) }
            if (record.errorCode.isNotEmpty()) page.text(errorLabel(record.errorCode))
            when (record.state) {
                AiReviewState.REVIEW -> page.button("查看并处理建议", true) { open(record, false) }
                AiReviewState.WAITING -> if (record.kind == AiReviewKind.OCR) {
                    page.button("核对本机草稿", true) { open(record, false) }
                } else if (record.kind == AiReviewKind.CATEGORY) {
                    page.button("开始处理", true) { open(record, true) }
                } else page.text("等待原流程处理；本页不会另发请求。")
                AiReviewState.FAILED -> if (record.kind == AiReviewKind.OCR) {
                    page.button("核对并打开本机草稿（不重发）", true) { open(record, false) }
                } else if (record.errorCode == "APPLY_UNCONFIRMED") {
                    page.text("上次保存可能已经完成。请先到原账单核对，不会重复发送或保存。")
                } else if (record.kind == AiReviewKind.CATEGORY) {
                    page.button("手动重试", true) { open(record, true) }
                } else page.text("此任务不会自动重发，请从原账单入口核对失败原因和当前数据。")
                else -> Unit
            }
            page.button("分页查看此任务历史") { showHistory(record) }
        }
        page.restoreScrollPosition(scroll)
    }
    private fun open(record: AiReviewRecord, sends: Boolean) {
        val action = {
            if (!AiReviewRegistry.open(this, record)) MaterialAlertDialogBuilder(this)
                .setMessage("此类任务的恢复处理尚未接入，记录仍保留。请从原功能入口核对，不会自动重试。")
                .setPositiveButton("知道了", null).show()
        }
        if (sends) MaterialAlertDialogBuilder(this).setTitle("重新处理这笔任务？")
            .setMessage("可能再次向已授权的 AI 服务发送此任务数据并使用额度。不会批量处理其他任务，失败后也不会自动重试。")
            .setPositiveButton("继续处理") { _, _ -> action() }.setNegativeButton("取消", null).show()
        else action()
    }
    private fun showHistory(record: AiReviewRecord, pages: List<Long?> = listOf(null)) {
        historyJob?.cancel()
        historyJob = refreshController.launchVisible {
            try {
                val page = withContext(Dispatchers.IO) { AiReviewStore(applicationContext).use { it.historyPage(record.id, pages.last()) } }
                val text = page.events.joinToString("\n\n") { event ->
                    "${time(event.timestamp)} · ${actionLabel(event.action)} · ${stateLabel(event.state)}" +
                        event.changes.joinToString(separator = "\n", prefix = if (event.changes.isEmpty()) "" else "\n") { changeLabel(it) } +
                        if (event.errorCode.isEmpty()) "" else "\n${errorLabel(event.errorCode)}"
                }
                val dialog = MaterialAlertDialogBuilder(this@AiReviewActivity).setTitle("任务历史 · 第 ${pages.size} 页（最多 100 条）")
                    .setMessage(text.ifEmpty { "暂无历史。" }).setPositiveButton("关闭", null)
                page.next?.let { next -> dialog.setNegativeButton("更早记录") { _, _ -> showHistory(record, pages + next) } }
                if (pages.size > 1) dialog.setNeutralButton("较新记录") { _, _ -> showHistory(record, pages.dropLast(1)) }
                historyDialog?.dismiss()
                historyDialog = dialog.create().also {
                    it.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                    it.show()
                    AiReviewUiFixture.dialogShown(it)
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) {
                historyDialog?.dismiss()
                historyDialog = MaterialAlertDialogBuilder(this@AiReviewActivity).setMessage("无法读取历史，原记录未被删除。")
                    .setPositiveButton("关闭", null).show()
            }
        }
    }
    private fun kindLabel(kind: AiReviewKind): String = when (kind.name) {
        "CATEGORY" -> "单笔分类"
        "OWNER_CATEGORY" -> "自动分类"
        "OCR_CATEGORY" -> "OCR 新类别"
        "ASSET" -> "资产建议"
        else -> "OCR 账单识别"
    }
    private fun stateLabel(state: AiReviewState) = when (state) {
        AiReviewState.WAITING -> "等待处理"
        AiReviewState.RUNNING -> "识别中"
        AiReviewState.FAILED -> "失败 / 需核对"
        AiReviewState.REVIEW -> "已完成 · 待确认"
        AiReviewState.APPLYING -> "正在保存"
        AiReviewState.APPLIED -> "已应用"
        AiReviewState.MANUAL -> "已手动修改"
        AiReviewState.STALE -> "原账单已变化 · 建议失效"
    }
    private fun changeLabel(change: AiReviewChange) = when (change.field) {
        "CATEGORY" -> "类别：${change.before.ifEmpty { "未分类" }} → ${change.after}" + if (change.createsNew) "（建议新建）" else ""
        "OCR_BILL" -> "本机草稿 #${change.after}"
        else -> (if (change.field == "ASSET_TO") "转入资产" else "资产") + if (change.createsNew)
            "：建议新建 ${change.kind}${change.currency.takeIf { it.isNotEmpty() }?.let { " · $it" }.orEmpty()}"
        else "：#${change.before.ifEmpty { "无" }} → #${change.after.ifEmpty { "无" }}"
    }
    private fun errorLabel(code: String) = when (code) {
        "APPLY_UNCONFIRMED" -> "保存结果未确认，请先核对原账单。"
        "REQUEST_INTERRUPTED", "CANCELLED" -> "识别被中断，未自动重发。"
        "NO_RESULT", "INVALID_RESULT" -> "未得到可用建议，原账单保持不变。"
        "STALE" -> "账单或来源已经变化，旧建议未写回。"
        "AUTH_CHANGED", "CLASSIFICATION_PAUSED", "SIGN_IN_REQUIRED", "MODEL_REQUIRED" -> "请检查当前账号、模型与数据发送授权。"
        "BUSY" -> "另一个任务正在运行，请稍后处理。"
        else -> "操作未完成，请核对本机服务和授权后再试。"
    }
    private fun actionLabel(action: String) = when (action) {
        "CREATED" -> "加入队列"
        "CLAIMED", "RETRIED" -> "开始识别"
        "REVIEW_READY" -> "建议已保存"
        "DEFERRED", "APPLY_DEFERRED" -> "保留待确认"
        "MANUAL_CHANGED" -> "手动调整建议"
        "APPLY_STARTED" -> "开始保存"
        "APPLY_FINISHED" -> "保存结果"
        "RECOVERED" -> "恢复中断任务"
        "RESULT_RECOVERED" -> "从本机恢复已完成建议"
        "DRAFT_RECONCILED" -> "已核对本机草稿状态"
        "CANCELLED" -> "任务已撤销"
        else -> "操作失败"
    }
    private fun time(value: Long) = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date(value))
}
