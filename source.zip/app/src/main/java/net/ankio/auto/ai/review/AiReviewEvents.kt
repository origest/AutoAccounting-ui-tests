package net.ankio.auto.ai.review

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Dismissal does not remove a durable REVIEW even when this optional event cannot be saved. */
internal object AiReviewEvents {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    fun defer(context: Context, id: String) {
        scope.launch { runCatching { AiReviewStore(context.applicationContext).use { it.defer(id) } } }
    }
}
