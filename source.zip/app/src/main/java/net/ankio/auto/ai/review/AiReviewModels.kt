package net.ankio.auto.ai.review

enum class AiReviewKind { CATEGORY, OWNER_CATEGORY, OCR_CATEGORY, ASSET, OCR }
enum class AiReviewState { WAITING, RUNNING, FAILED, REVIEW, APPLYING, APPLIED, MANUAL, STALE }
data class AiReviewTarget(val source: String, val billId: Long, val revision: Long, val fingerprint: String)
data class AiReviewChange(val field: String, val before: String, val after: String, val createsNew: Boolean = false,
    val kind: String = "", val currency: String = "")
data class AiReviewRecord(val id: String, val target: AiReviewTarget, val kind: AiReviewKind,
    val state: AiReviewState, val changes: List<AiReviewChange>, val errorCode: String,
    val attempt: Int, val createdAt: Long, val updatedAt: Long)
data class AiReviewClaim(val id: String, val attempt: Int, val token: String)
data class AiReviewEvent(val id: String, val taskId: String, val state: AiReviewState,
    val action: String, val changes: List<AiReviewChange>, val errorCode: String, val timestamp: Long)

/** Persist normalized local references only. Never pass provider replies or OCR text here. */
object AiReviewSafety {
    private val uuid = Regex("[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}")
    private fun localId(value: String): Boolean = value.toLongOrNull()?.let { it > 0 && it.toString() == value } == true
    private val assetKinds = setOf("CASH", "WECHAT_BALANCE", "ALIPAY_BALANCE", "DEBIT_CARD", "CREDIT_CARD", "HUABEI")
    private val errors = setOf("REQUEST_FAILED", "REQUEST_INTERRUPTED", "APPLY_UNCONFIRMED", "NO_RESULT",
        "AUTH_CHANGED", "STALE", "CANCELLED", "BUSY", "SIGN_IN_REQUIRED", "MODEL_REQUIRED",
        "CLASSIFICATION_PAUSED", "STORE_UNAVAILABLE", "UNSUPPORTED", "INVALID_RESULT")
    fun error(code: String): String = if (code in errors) code else "REQUEST_FAILED"
    fun target(target: AiReviewTarget): Boolean = (uuid.matches(target.source) || target.source == "ocr-local") &&
        target.billId >= 0 && target.revision >= 0 && (Regex("[A-Fa-f0-9]{16,128}").matches(target.fingerprint) || uuid.matches(target.fingerprint))
    private fun category(value: String): Boolean = value.length in 1..200 && value == value.trim() &&
        value.split(" - ").let { parts -> parts.size <= 2 && parts.all { part ->
            part.isNotBlank() && part == part.trim() && part.length <= 80 &&
                part.none { it.isISOControl() || it in "<>/\\\"{}[]@" }
        } }
    fun changes(kind: AiReviewKind, changes: List<AiReviewChange>): Boolean = changes.isNotEmpty() &&
        changes.size <= 2 && changes.map { it.field }.distinct().size == changes.size && changes.all {
            when (kind) {
                AiReviewKind.CATEGORY, AiReviewKind.OWNER_CATEGORY, AiReviewKind.OCR_CATEGORY -> it.field == "CATEGORY" && it.kind.isEmpty() && it.currency.isEmpty() &&
                    (it.before.isEmpty() || category(it.before)) && category(it.after) &&
                    (!it.createsNew || (it.after.length <= 30 && " - " !in it.after && it.after.none(Char::isDigit)))
                AiReviewKind.ASSET -> it.field in setOf("ASSET_FROM", "ASSET_TO") &&
                    (it.before.isEmpty() || localId(it.before)) && if (it.createsNew) {
                        it.after.isEmpty() && it.kind in assetKinds && (it.currency.isEmpty() || Regex("[A-Z]{3}").matches(it.currency))
                    } else { (it.after.isEmpty() || localId(it.after)) && it.kind.isEmpty() && it.currency.isEmpty() }
                AiReviewKind.OCR -> it.field == "OCR_BILL" && !it.createsNew && it.kind.isEmpty() && it.currency.isEmpty() &&
                    (it.before.isEmpty() || localId(it.before)) && localId(it.after)
            }
        }
}
