package net.ankio.auto.ai.review

internal enum class AiReviewTab(val key: String) {
    QUEUE("queue"), PENDING("pending"), HISTORY("history");
    companion object { fun from(key: String) = entries.firstOrNull { it.key == key } ?: QUEUE }
}
internal data class AiReviewCursor(val created: Long, val id: String)
internal data class AiReviewPage(val records: List<AiReviewRecord>, val total: Long, val next: AiReviewCursor?)
internal data class AiReviewHistoryPage(val events: List<AiReviewEvent>, val next: Long?)
internal data class AiReviewSql(val sql: String, val args: Array<String>)

/** Fixed predicates match partial indexes; cursors use immutable created/id, never mutable status. */
internal object AiReviewPaging {
    const val MAX_PAGE = 100
    const val QUEUE_WHERE = "state IN ('WAITING','RUNNING','FAILED','APPLYING')"
    const val PENDING_WHERE = "state='REVIEW'"
    const val HISTORY_WHERE = "state IN ('APPLIED','MANUAL','STALE')"
    const val ORDER = "created DESC,id ASC"
    const val AFTER_WHERE = "created<=? AND (created<? OR id>?)"
    fun where(tab: AiReviewTab): String = when (tab) {
        AiReviewTab.QUEUE -> QUEUE_WHERE
        AiReviewTab.PENDING -> PENDING_WHERE
        AiReviewTab.HISTORY -> HISTORY_WHERE
    }
    fun indexes(): List<String> = listOf(
        "CREATE INDEX IF NOT EXISTS task_queue_page ON task($ORDER) WHERE $QUEUE_WHERE",
        "CREATE INDEX IF NOT EXISTS task_pending_page ON task($ORDER) WHERE $PENDING_WHERE",
        "CREATE INDEX IF NOT EXISTS task_history_page ON task($ORDER) WHERE $HISTORY_WHERE",
        "CREATE INDEX IF NOT EXISTS task_state_owner ON task(state,owner)",
        "CREATE INDEX IF NOT EXISTS task_kind_state ON task(kind,state)",
        "CREATE INDEX IF NOT EXISTS event_action ON event(task_id,action,sequence DESC)"
    )
    fun query(tab: AiReviewTab, after: AiReviewCursor?, limit: Int): AiReviewSql {
        require(limit in 1..MAX_PAGE)
        val filter = if (after == null) "" else " AND $AFTER_WHERE"
        val args = if (after == null) arrayOf((limit + 1).toString())
            else arrayOf(after.created.toString(), after.created.toString(), after.id, (limit + 1).toString())
        return AiReviewSql("SELECT * FROM task INDEXED BY task_${tab.key}_page WHERE ${where(tab)}$filter ORDER BY $ORDER LIMIT ?", args)
    }
}
