package net.ankio.auto.ai.review

import android.content.Context

/** Persisted preferences only. Callers must obtain risk confirmation before disabling new-item prompts. */
class AiReviewPolicy(context: Context) {
    enum class Key { AUTO_APPLY_CATEGORY, AUTO_APPLY_ASSETS, AUTO_APPLY_OCR, PROMPT_NEW_CATEGORY, PROMPT_NEW_ASSET }
    fun get(key: Key): Boolean = settings().let { when (key) {
        Key.AUTO_APPLY_CATEGORY -> it.autoApplyCategory
        Key.AUTO_APPLY_ASSETS -> it.autoApplyAssets
        Key.AUTO_APPLY_OCR -> it.autoApplyOcr
        Key.PROMPT_NEW_CATEGORY -> it.confirmNewCategory
        Key.PROMPT_NEW_ASSET -> it.confirmNewAsset
    } }
    fun set(key: Key, enabled: Boolean): Boolean = synchronized(lock) {
        val old = settings()
        update(when (key) {
            Key.AUTO_APPLY_CATEGORY -> old.copy(autoApplyCategory = enabled)
            Key.AUTO_APPLY_ASSETS -> old.copy(autoApplyAssets = enabled)
            Key.AUTO_APPLY_OCR -> old.copy(autoApplyOcr = enabled)
            Key.PROMPT_NEW_CATEGORY -> old.copy(confirmNewCategory = enabled)
            Key.PROMPT_NEW_ASSET -> old.copy(confirmNewAsset = enabled)
        })
    }
    data class Settings(val autoApplyCategory: Boolean = false, val autoApplyAssets: Boolean = false,
        val autoApplyOcr: Boolean = false, val confirmNewCategory: Boolean = true, val confirmNewAsset: Boolean = true)
    private val prefs = context.applicationContext.getSharedPreferences(AiReviewUiFixture.policyName ?: "ai-review-policy", Context.MODE_PRIVATE)
    companion object {
        private val lock = Any()
        @Volatile private var blocked = false
        fun permitsAutomatic(settings: Settings, kind: AiReviewKind, changes: List<AiReviewChange>): Boolean =
            AiReviewSafety.changes(kind, changes) && changes.all { change ->
                when (kind) {
                    AiReviewKind.CATEGORY, AiReviewKind.OWNER_CATEGORY, AiReviewKind.OCR_CATEGORY -> if (change.createsNew) !settings.confirmNewCategory else settings.autoApplyCategory
                    AiReviewKind.ASSET -> if (change.createsNew) !settings.confirmNewAsset else settings.autoApplyAssets
                    AiReviewKind.OCR -> settings.autoApplyOcr
                }
            }
    }
    fun warning(): String? = if (blocked) "AI 设置未能可靠保存，已禁止自动应用。请重新保存设置。" else null
    fun settings(): Settings = synchronized(lock) {
        if (blocked) return@synchronized Settings()
        try { Settings(prefs.getBoolean("autoApplyCategory", false), prefs.getBoolean("autoApplyAssets", false),
            prefs.getBoolean("autoApplyOcr", false), prefs.getBoolean("confirmNewCategory", true),
            prefs.getBoolean("confirmNewAsset", true)) }
        catch (_: Exception) { blocked = true; Settings() }
    }
    /** False means no automatic action is authorized, even if SharedPreferences changed its cache. */
    fun update(settings: Settings): Boolean = synchronized(lock) {
        val saved = try { prefs.edit().putBoolean("autoApplyCategory", settings.autoApplyCategory)
            .putBoolean("autoApplyAssets", settings.autoApplyAssets).putBoolean("autoApplyOcr", settings.autoApplyOcr)
            .putBoolean("confirmNewCategory", settings.confirmNewCategory).putBoolean("confirmNewAsset", settings.confirmNewAsset)
            .commit() } catch (_: Exception) { false }
        blocked = !saved
        saved
    }
    fun canAutoApply(record: AiReviewRecord): Boolean = synchronized(lock) {
        val settings = settings()
        !blocked && record.state == AiReviewState.REVIEW && permitsAutomatic(settings, record.kind, record.changes)
    }
    /**
     * Local commit barrier only. The action must be a short local database commit on an IO thread.
     * Never hold this lock across HTTP, inference, user interaction, or work that needs this lock
     * from another thread. Policy changes serialize with this last local automatic mutation.
     */
    fun <T> withAutomaticApply(record: AiReviewRecord, action: () -> T): T? = synchronized(lock) {
        if (!canAutoApply(record)) null else action()
    }

    /** Preference only; execution still requires validated changes and a recorded authorization. */
    fun shouldPromptForNew(kind: AiReviewKind): Boolean = when (kind) {
        AiReviewKind.CATEGORY, AiReviewKind.OWNER_CATEGORY, AiReviewKind.OCR_CATEGORY -> settings().confirmNewCategory
        AiReviewKind.ASSET -> settings().confirmNewAsset
        AiReviewKind.OCR -> false
    }
}
