package net.ankio.auto.ai.review

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Main-thread controller. All reads are children of the visible lifecycle, never a background poll. */
internal class AiReviewRefresh<T>(
    private val read: suspend () -> T,
    private val deliver: (T) -> Unit,
    private val failure: () -> Unit,
    private val tick: suspend () -> Unit = { delay(5_000) }
) {
    private var visible: CoroutineScope? = null
    private var readJob: Job? = null
    private var generation = 0L
    private val reads = Mutex()
    suspend fun runWhileVisible(): Unit = coroutineScope {
        check(visible == null)
        visible = this
        try {
            while (currentCoroutineContext().isActive) { refresh(); tick() }
        } finally {
            visible = null
            generation++
            readJob?.cancel()
            readJob = null
        }
    }
    fun refresh() {
        val scope = visible?.takeIf { it.isActive } ?: return
        if (readJob?.isActive == true) return // Slow reads never stack up.
        val ticket = generation
        readJob = scope.launch {
            try {
                // A cancelled native SQLite call may finish late. Keep subsequent reads serialized.
                val result = reads.withLock { currentCoroutineContext().ensureActive(); read() }
                currentCoroutineContext().ensureActive()
                if (visible === scope && generation == ticket) deliver(result)
            } catch (error: CancellationException) { throw error }
            catch (_: Exception) { if (visible === scope && generation == ticket) failure() }
        }
    }
    fun invalidateAndRefresh() {
        generation++
        readJob?.cancel()
        readJob = null
        refresh()
    }
    fun launchVisible(block: suspend CoroutineScope.() -> Unit): Job? =
        visible?.takeIf { it.isActive }?.launch(block = block)
}
