package net.ankio.auto.ai.review

import androidx.fragment.app.FragmentActivity
import net.ankio.auto.classification.ManualBillCategoryDialog
import java.util.concurrent.ConcurrentHashMap

/** Install handlers at application startup; missing handlers never claim that work is complete. */
object AiReviewRegistry {
    private val handlers = ConcurrentHashMap<AiReviewKind, (FragmentActivity, AiReviewRecord) -> Unit>()
    init {
        register(AiReviewKind.CATEGORY) { host, record ->
            if (!host.supportFragmentManager.isStateSaved && host.supportFragmentManager.findFragmentByTag(ManualBillCategoryDialog.TAG) == null) {
                ManualBillCategoryDialog.createReview(record.id).showNow(host.supportFragmentManager, ManualBillCategoryDialog.TAG)
            }
        }
    }
    fun register(kind: AiReviewKind, handler: (FragmentActivity, AiReviewRecord) -> Unit) { handlers[kind] = handler }
    fun open(host: FragmentActivity, record: AiReviewRecord): Boolean {
        val handler = handlers[record.kind] ?: return false
        handler(host, record)
        return true
    }
}
