package net.ankio.auto.ai.review

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.gson.Gson
import java.io.Closeable
import java.io.File
import java.util.UUID

/** Private main-app ledger. A committed claim is required before any provider request. */
class AiReviewStore internal constructor(context: Context, name: String, private val owner: String) : Closeable {
    private data class Location(val name: String, val owner: String)
    private constructor(context: Context, location: Location) : this(context, location.name, location.owner)
    constructor(context: Context) : this(context, defaultLocation())
    companion object {
        private val PROCESS_OWNER = UUID.randomUUID().toString()
        private fun defaultLocation(): Location {
            // Capture once so install/clear can never pair the real database with a synthetic owner.
            val fixture = AiReviewUiFixture.databaseName
            return Location(fixture ?: "ai-review.db", if (fixture != null) "synthetic-ui" else PROCESS_OWNER)
        }
    }
    private val gson = Gson()
    private val helper: SQLiteOpenHelper
    init {
        require(Regex("[a-zA-Z0-9_.-]+\\.db").matches(name))
        helper = object : SQLiteOpenHelper(context.applicationContext, File(context.noBackupFilesDir, name).path, null, 2) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL("""CREATE TABLE task (
                    id TEXT PRIMARY KEY, source TEXT NOT NULL, bill_id INTEGER NOT NULL, revision INTEGER NOT NULL,
                    fingerprint TEXT NOT NULL, kind TEXT NOT NULL, state TEXT NOT NULL, changes TEXT NOT NULL,
                    error TEXT NOT NULL, attempt INTEGER NOT NULL, created INTEGER NOT NULL, updated INTEGER NOT NULL,
                    owner TEXT NOT NULL, token TEXT NOT NULL,
                    UNIQUE(source,bill_id,revision,fingerprint,kind))""")
                db.execSQL("""CREATE TABLE event (sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL UNIQUE,
                    task_id TEXT NOT NULL, state TEXT NOT NULL, action TEXT NOT NULL, changes TEXT NOT NULL,
                    error TEXT NOT NULL, timestamp INTEGER NOT NULL)""")
                db.execSQL("CREATE INDEX event_task ON event(task_id,sequence)")
                AiReviewPaging.indexes().forEach(db::execSQL)
            }
            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 1 && newVersion == 2) AiReviewPaging.indexes().forEach(db::execSQL)
                else error("UNSUPPORTED_REVIEW_SCHEMA")
            }
            override fun onOpen(db: SQLiteDatabase) {
                super.onOpen(db)
                // Multiple helpers in this process share an owner. Opening one must not cancel another.
                transaction(db) {
                    while (true) {
                        val abandoned = db.rawQuery("SELECT * FROM task WHERE state IN ('RUNNING','APPLYING') AND owner<>? LIMIT 100", arrayOf(owner))
                            .use { cursor -> buildList { while (cursor.moveToNext()) add(record(cursor)) } }
                        if (abandoned.isEmpty()) break
                        for (old in abandoned) {
                            val code = if (old.state == AiReviewState.APPLYING) "APPLY_UNCONFIRMED" else "REQUEST_INTERRUPTED"
                            check(transition(db, old, AiReviewState.FAILED, "RECOVERED", old.changes, code,
                                "id=? AND state=? AND owner<>?", arrayOf(old.id, old.state.name, owner)))
                        }
                    }
                }
            }
        }
    }
    private fun <T> transaction(db: SQLiteDatabase, block: () -> T): T {
        db.beginTransaction()
        try { val result = block(); db.setTransactionSuccessful(); return result }
        finally { db.endTransaction() } // Commit failures propagate. Never report success before this returns.
    }
    private fun Cursor.text(name: String) = getString(getColumnIndexOrThrow(name))
    private fun Cursor.number(name: String) = getLong(getColumnIndexOrThrow(name))
    private fun decode(json: String): List<AiReviewChange> = gson.fromJson(json, Array<AiReviewChange>::class.java).toList()
    private fun record(c: Cursor) = AiReviewRecord(c.text("id"), AiReviewTarget(c.text("source"), c.number("bill_id"),
        c.number("revision"), c.text("fingerprint")), AiReviewKind.valueOf(c.text("kind")), AiReviewState.valueOf(c.text("state")),
        decode(c.text("changes")), c.text("error"), c.number("attempt").toInt(), c.number("created"), c.number("updated"))
    private fun find(db: SQLiteDatabase, id: String): AiReviewRecord? = db.rawQuery("SELECT * FROM task WHERE id=?", arrayOf(id))
        .use { if (it.moveToFirst()) record(it) else null }
    private fun event(db: SQLiteDatabase, record: AiReviewRecord, action: String) {
        db.insertOrThrow("event", null, ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("task_id", record.id); put("state", record.state.name)
            put("action", action); put("changes", gson.toJson(record.changes)); put("error", record.errorCode); put("timestamp", record.updatedAt)
        })
    }
    private fun transition(db: SQLiteDatabase, old: AiReviewRecord, state: AiReviewState, action: String,
        changes: List<AiReviewChange> = old.changes, error: String = "", where: String, args: Array<String>,
        token: String = "", attempt: Int = old.attempt): Boolean {
        val next = old.copy(state = state, changes = changes, errorCode = error, attempt = attempt, updatedAt = System.currentTimeMillis())
        val changed = db.update("task", ContentValues().apply {
            put("state", state.name); put("changes", gson.toJson(changes)); put("error", error); put("attempt", attempt)
            put("updated", next.updatedAt); put("owner", owner); put("token", token)
        }, where, args) == 1
        if (changed) event(db, next, action)
        return changed
    }
    fun create(target: AiReviewTarget, kind: AiReviewKind): AiReviewRecord {
        require(AiReviewSafety.target(target)) { "INVALID_TARGET" }
        val db = helper.writableDatabase
        return transaction(db) {
            val args = arrayOf(target.source, target.billId.toString(), target.revision.toString(), target.fingerprint, kind.name)
            val existing = db.rawQuery("SELECT * FROM task WHERE source=? AND bill_id=? AND revision=? AND fingerprint=? AND kind=?", args)
                .use { if (it.moveToFirst()) record(it) else null }
            if (existing != null) return@transaction existing
            val now = System.currentTimeMillis()
            val record = AiReviewRecord(UUID.randomUUID().toString(), target, kind, AiReviewState.WAITING, emptyList(), "", 0, now, now)
            db.insertOrThrow("task", null, ContentValues().apply {
                put("id", record.id); put("source", target.source); put("bill_id", target.billId); put("revision", target.revision)
                put("fingerprint", target.fingerprint); put("kind", kind.name); put("state", record.state.name)
                put("changes", "[]"); put("error", ""); put("attempt", 0); put("created", now); put("updated", now)
                put("owner", owner); put("token", "")
            })
            event(db, record, "CREATED")
            record
        }
    }
    fun get(id: String): AiReviewRecord? = find(helper.writableDatabase, id)
    /** Filter in SQLite before LIMIT: old pending rows cannot be hidden by newer terminal history. */
    internal fun page(tab: AiReviewTab, after: AiReviewCursor? = null, limit: Int = AiReviewPaging.MAX_PAGE): AiReviewPage {
        val query = AiReviewPaging.query(tab, after, limit)
        val db = helper.writableDatabase
        return transaction(db) {
            val total = db.rawQuery("SELECT count(*) FROM task INDEXED BY task_${tab.key}_page WHERE ${AiReviewPaging.where(tab)}", null)
                .use { it.moveToFirst(); it.getLong(0) }
            val cursor = db.rawQuery(query.sql, query.args)
            val rows = try { buildList { while (cursor.moveToNext()) add(record(cursor)) } }
                finally { cursor.close() }
            val shown = rows.take(limit)
            AiReviewPage(shown, total, if (rows.size > limit) shown.last().let { AiReviewCursor(it.createdAt, it.id) } else null)
        }
    }
    fun findOcrReview(fingerprint: String): String? = helper.writableDatabase.rawQuery(
        "SELECT id FROM task WHERE source='ocr-local' AND bill_id=0 AND revision=0 AND fingerprint=? AND kind='OCR' LIMIT 1", arrayOf(fingerprint)
    ).use { if (it.moveToFirst()) it.getString(0) else null }

    fun claim(id: String, explicitRetry: Boolean = false): AiReviewClaim? {
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction null
            if (old.errorCode == "APPLY_UNCONFIRMED") return@transaction null
            if (old.state != AiReviewState.WAITING && !(old.state == AiReviewState.FAILED && explicitRetry)) return@transaction null
            if (old.attempt == Int.MAX_VALUE) return@transaction null
            val claim = AiReviewClaim(id, old.attempt + 1, UUID.randomUUID().toString())
            if (transition(db, old, AiReviewState.RUNNING, if (explicitRetry) "RETRIED" else "CLAIMED", emptyList(),
                    where = "id=? AND state=? AND attempt=?", args = arrayOf(id, old.state.name, old.attempt.toString()),
                    token = claim.token, attempt = claim.attempt)) claim else null
        }
    }
    fun review(claim: AiReviewClaim, changes: List<AiReviewChange>): Boolean {
        val safe = changes.toList()
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, claim.id) ?: return@transaction false
            require(AiReviewSafety.changes(old.kind, safe)) { "INVALID_CHANGES" }
            transition(db, old, AiReviewState.REVIEW, "REVIEW_READY", safe,
                where = "id=? AND state='RUNNING' AND attempt=? AND token=? AND owner=?",
                args = arrayOf(claim.id, claim.attempt.toString(), claim.token, owner))
        }
    }
    fun fail(claim: AiReviewClaim, errorCode: String): Boolean {
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, claim.id) ?: return@transaction false
            transition(db, old, AiReviewState.FAILED, "REQUEST_FAILED", emptyList(), AiReviewSafety.error(errorCode),
                "id=? AND state='RUNNING' AND attempt=? AND token=? AND owner=?", arrayOf(claim.id, claim.attempt.toString(), claim.token, owner))
        }
    }
    /** Records a user-edited safe suggestion. Earlier events retain the prior suggestion. */
    fun amendReview(id: String, changes: List<AiReviewChange>): Boolean {
        val safe = changes.toList()
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction false
            if (old.state != AiReviewState.REVIEW) return@transaction false
            require(AiReviewSafety.changes(old.kind, safe)) { "INVALID_CHANGES" }
            transition(db, old, AiReviewState.REVIEW, "MANUAL_CHANGED", safe,
                where = "id=? AND state='REVIEW'", args = arrayOf(id))
        }
    }
    /** Cancel unsent/pending work of one kind. APPLYING may have sent a write and is never touched. */
    fun cancelPending(kind: AiReviewKind, taskId: String? = null): Int {
        val db = helper.writableDatabase
        return transaction(db) {
            val filter = if (taskId == null) "" else " AND id=?"
            val arguments = if (taskId == null) arrayOf(kind.name) else arrayOf(kind.name, taskId)
            var cancelled = 0
            while (true) {
                val pending = db.rawQuery("SELECT * FROM task WHERE kind=? AND state IN ('WAITING','RUNNING','REVIEW')" + filter + " LIMIT 100", arguments)
                    .use { cursor -> buildList { while (cursor.moveToNext()) add(record(cursor)) } }
                if (pending.isEmpty()) break
                val changed = pending.count { old -> transition(db, old, AiReviewState.STALE, "CANCELLED", error = "CANCELLED",
                    where = "id=? AND kind=? AND state IN ('WAITING','RUNNING','REVIEW')", args = arrayOf(old.id, kind.name)) }
                check(changed > 0) { "CANCEL_NOT_PERSISTED" }
                cancelled += changed
            }
            cancelled
        }
    }
    /**
     * Recover ONLY an interrupted request with an already reliable, externally persisted result.
     * Caller MUST verify that result against CURRENT permission, authorization generation and bill
     * snapshot before calling. Does not send requests or increase attempts. Never revives cancelled,
     * stale, completed or uncertain-write tasks. Prior request tokens remain consumed.
     */
    fun recoverReview(id: String, changes: List<AiReviewChange>): Boolean {
        val safe = changes.toList()
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction false
            if (old.state != AiReviewState.FAILED || old.errorCode != "REQUEST_INTERRUPTED" || old.attempt <= 0) return@transaction false
            require(AiReviewSafety.changes(old.kind, safe)) { "INVALID_CHANGES" }
            transition(db, old, AiReviewState.REVIEW, "RESULT_RECOVERED", safe,
                where = "id=? AND state='FAILED' AND error='REQUEST_INTERRUPTED' AND attempt=?",
                args = arrayOf(id, old.attempt.toString()))
        }
    }
    /**
     * OCR-only reconciliation, never an external operation. Caller must first prove the durable
     * fingerprint-to-draft mapping and read the actual draft state in the local bill database.
     * confirmed=true requires a successfully persisted Edited/Synced draft, not an editor callback.
     */
    fun reconcileOcrDraft(id: String, draftId: Long, confirmed: Boolean): Boolean {
        require(draftId > 0)
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction false
            if (old.kind != AiReviewKind.OCR || old.state != AiReviewState.FAILED ||
                old.errorCode !in setOf("REQUEST_INTERRUPTED", "APPLY_UNCONFIRMED")) return@transaction false
            if (old.changes.any { it.field != "OCR_BILL" || it.after != draftId.toString() }) return@transaction false
            val changes = listOf(AiReviewChange("OCR_BILL", "", draftId.toString()))
            transition(db, old, if (confirmed) AiReviewState.APPLIED else AiReviewState.REVIEW, "DRAFT_RECONCILED", changes,
                where = "id=? AND kind='OCR' AND state='FAILED' AND error=?",
                args = arrayOf(id, old.errorCode))
        }
    }

    fun beginApply(id: String, expectedChanges: List<AiReviewChange>? = null): String? {
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction null
            if (expectedChanges != null && old.changes != expectedChanges) return@transaction null
            val token = UUID.randomUUID().toString()
            if (transition(db, old, AiReviewState.APPLYING, "APPLY_STARTED", where = "id=? AND state='REVIEW'",
                    args = arrayOf(id), token = token)) token else null
        }
    }
    /** FAILED explicitly represents an uncertain outcome; never retry an external write automatically. */
    fun finishApply(id: String, token: String, outcome: AiReviewState, appliedChanges: List<AiReviewChange>? = null): Boolean {
        require(outcome in setOf(AiReviewState.APPLIED, AiReviewState.MANUAL, AiReviewState.STALE, AiReviewState.FAILED))
        require(appliedChanges == null || outcome in setOf(AiReviewState.APPLIED, AiReviewState.MANUAL)) { "INVALID_FINAL_CHANGES" }
        val safe = appliedChanges?.toList()
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction false
            if (safe != null) require(AiReviewSafety.changes(old.kind, safe)) { "INVALID_CHANGES" }
            transition(db, old, outcome, "APPLY_FINISHED", changes = safe ?: old.changes,
                error = if (outcome == AiReviewState.FAILED) "APPLY_UNCONFIRMED" else "",
                where = "id=? AND state='APPLYING' AND token=? AND owner=?", args = arrayOf(id, token, owner))
        }
    }
    /**
     * Use ONLY after the caller has established that no external write was sent.
     * An uncertain or already-dispatched write must instead finish as FAILED/APPLY_UNCONFIRMED.
     * Preserves the suggestion for a fresh confirmation and consumes the apply token.
     */
    fun returnToReview(id: String, token: String, errorCode: String = ""): Boolean {
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction false
            transition(db, old, AiReviewState.REVIEW, "APPLY_DEFERRED",
                error = if (errorCode.isEmpty()) "" else AiReviewSafety.error(errorCode),
                where = "id=? AND state='APPLYING' AND token=? AND owner=?", args = arrayOf(id, token, owner))
        }
    }
    fun defer(id: String): Boolean {
        val db = helper.writableDatabase
        return transaction(db) {
            val old = find(db, id) ?: return@transaction false
            transition(db, old, AiReviewState.REVIEW, "DEFERRED", where = "id=? AND state='REVIEW'", args = arrayOf(id))
        }
    }
    private fun eventRecord(cursor: Cursor) = AiReviewEvent(cursor.text("id"), cursor.text("task_id"),
        AiReviewState.valueOf(cursor.text("state")), cursor.text("action"), decode(cursor.text("changes")), cursor.text("error"), cursor.number("timestamp"))
    internal fun historyPage(id: String, before: Long? = null, limit: Int = AiReviewPaging.MAX_PAGE): AiReviewHistoryPage {
        require(limit in 1..AiReviewPaging.MAX_PAGE)
        val filter = if (before == null) "" else " AND sequence<?"
        val args = if (before == null) arrayOf(id, (limit + 1).toString()) else arrayOf(id, before.toString(), (limit + 1).toString())
        val cursor = helper.writableDatabase.rawQuery("SELECT * FROM event WHERE task_id=?$filter ORDER BY sequence DESC LIMIT ?", args)
        val rows = try { buildList { while (cursor.moveToNext()) add(cursor.number("sequence") to eventRecord(cursor)) } }
            finally { cursor.close() }
        val shown = rows.take(limit)
        return AiReviewHistoryPage(shown.map { it.second }, if (rows.size > limit) shown.last().first else null)
    }
    /** Bounded compatibility helper for small synthetic tests; screens use explicit history pages. */
    internal fun history(id: String): List<AiReviewEvent> = historyPage(id).events.asReversed()
    /** Each action has a one-row index lookup, so old manual evidence survives arbitrarily many deferrals. */
    internal fun latestEvent(id: String, actions: Set<String>): AiReviewEvent? {
        require(actions.size in 1..8)
        return actions.mapNotNull { action ->
            helper.writableDatabase.rawQuery("SELECT * FROM event WHERE task_id=? AND action=? ORDER BY sequence DESC LIMIT 1", arrayOf(id, action))
                .use { if (it.moveToFirst()) it.number("sequence") to eventRecord(it) else null }
        }.maxByOrNull { it.first }?.second
    }
    override fun close() = helper.close()
}
