package net.ankio.auto.ai.review

import android.app.Dialog
import net.ankio.auto.BuildConfig

/** Instrumentation-only opt-in. No intent/setting can enable it and release builds never use it. */
internal object AiReviewUiFixture {
    @Volatile private var selectedName: String? = null
    @Volatile private var readObserver: (() -> Unit)? = null
    @Volatile private var dialogObserver: ((Dialog) -> Unit)? = null
    val databaseName: String? get() = if (BuildConfig.DEBUG) selectedName else null
    val policyName: String? get() = databaseName?.removeSuffix(".db")?.plus("-policy")
    fun install(name: String, onRead: () -> Unit, onDialog: (Dialog) -> Unit) {
        check(BuildConfig.DEBUG)
        require(Regex("review-ui-[0-9a-f-]{36}\\.db").matches(name))
        readObserver = onRead; dialogObserver = onDialog; selectedName = name
    }
    fun clear() { selectedName = null; readObserver = null; dialogObserver = null }
    fun readStarted() { if (databaseName != null) readObserver?.invoke() }
    fun dialogShown(dialog: Dialog) { if (databaseName != null) dialogObserver?.invoke(dialog) }
}
