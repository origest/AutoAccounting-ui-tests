package net.ankio.auto.ai.review

import android.content.Context
import android.util.AtomicFile
import com.google.gson.Gson
import net.ankio.auto.classification.OwnerCategoryQueue
import net.ankio.auto.utils.PrefManager
import net.ankio.chatgpt.ChatGptAccounts
import java.io.File
import java.util.UUID

/** Separate, no-backup permission for sending only a fixed payment-method enum automatically. */
object AssetAutomaticConsent {
    data class Ticket internal constructor(val generation: String)
    private data class Attempt(val id: String, val at: Long)
    private data class Grant(val enabled: Boolean = false, val account: String = "", val model: String = "",
        val mode: String = "", val epoch: Long = -1, val generation: String = "", val attempts: List<Attempt> = emptyList())
    private val lock = Any()
    private val gson = Gson()
    @Volatile private var blocked = false
    private fun file(context: Context) = AtomicFile(File(context.applicationContext.noBackupFilesDir, "asset-auto-consent.json"))
    private fun read(context: Context): Grant {
        val file = file(context)
        if (!file.baseFile.exists()) return Grant()
        return file.openRead().bufferedReader().use { gson.fromJson(it, Grant::class.java) ?: error("INVALID_GRANT") }
    }
    private fun current(context: Context, grant: Grant): Boolean {
        if (blocked || !grant.enabled || grant.generation.isBlank() || grant.epoch != OwnerCategoryQueue.epoch(context) ||
            grant.mode != PrefManager.workMode.name || !PrefManager.featureAiAvailable || !PrefManager.aiCategoryChatGpt ||
            !PrefManager.aiCategoryHistory || !PrefManager.aiCategoryRecognition || !PrefManager.featureAssetManage) return false
        val view = ChatGptAccounts.get(context).view()
        return view.active == grant.account && view.accounts.any { it.key == grant.account && it.enabled && it.model == grant.model }
    }
    private fun write(context: Context, grant: Grant): Boolean {
        val file = file(context)
        var output: java.io.FileOutputStream? = null
        return try {
            output = file.startWrite()
            output.write(gson.toJson(grant).toByteArray(Charsets.UTF_8))
            file.finishWrite(output)
            true
        } catch (_: Exception) {
            output?.let { runCatching { file.failWrite(it) } }
            blocked = true; false
        }
    }
    fun warning(): String? = if (blocked) "资产自动发送许可未能可靠保存，本次运行已阻止继续处理。请重试；重启后旧许可状态可能仍需核对。" else null
    fun isEnabled(context: Context): Boolean = synchronized(lock) {
        try { current(context, read(context)) } catch (_: Exception) { blocked = true; false }
    }
    fun enable(context: Context, model: String): Boolean = synchronized(lock) {
        try {
            if (model.isBlank()) return@synchronized false
            val view = ChatGptAccounts.get(context).view()
            val account = view.accounts.singleOrNull { it.key == view.active && it.enabled && it.model == model } ?: return@synchronized false
            val previous = read(context)
            val grant = Grant(true, account.key, model, PrefManager.workMode.name, OwnerCategoryQueue.epoch(context),
                UUID.randomUUID().toString(), previous.attempts)
            val saved = write(context, grant)
            if (saved) blocked = false
            saved
        } catch (_: Exception) { blocked = true; false }
    }
    fun disable(context: Context): Boolean = synchronized(lock) {
        blocked = true
        val previous = runCatching { read(context) }.getOrDefault(Grant())
        val saved = write(context, previous.copy(enabled = false, generation = UUID.randomUUID().toString()))
        if (saved) blocked = false
        saved
    }
    fun ticket(context: Context): Ticket? = synchronized(lock) {
        try { val grant = read(context); if (current(context, grant)) Ticket(grant.generation) else null }
        catch (_: Exception) { blocked = true; null }
    }
    fun permits(context: Context, ticket: Ticket): Boolean = synchronized(lock) {
        try { val grant = read(context); current(context, grant) && grant.generation == ticket.generation }
        catch (_: Exception) { blocked = true; false }
    }
    /** Durable rolling-hour debit before sending. Failures/cancellations still count; enabling never resets it. */
    fun claimAttempt(context: Context, ticket: Ticket, taskId: String, now: Long = System.currentTimeMillis()): Boolean = synchronized(lock) {
        try {
            val grant = read(context)
            if (!current(context, grant) || grant.generation != ticket.generation) return@synchronized false
            val attempts = grant.attempts.filter { it.at >= now - 3_600_000L }
            if (attempts.any { it.id == taskId } || attempts.size >= 10) return@synchronized false
            write(context, grant.copy(attempts = attempts + Attempt(taskId, now)))
        } catch (_: Exception) { blocked = true; false }
    }
}
