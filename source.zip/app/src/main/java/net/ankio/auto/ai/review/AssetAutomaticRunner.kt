package net.ankio.auto.ai.review

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import net.ankio.auto.classification.OwnerCategoryQueue
import net.ankio.auto.http.api.AssetsAPI
import net.ankio.chatgpt.ChatGptAccounts
import org.ezbook.server.ai.tools.AssetSuggestionPolicy
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.OwnerQueueInput

/** Called only for the original rule result, after category staging/application. Failures never replay category work. */
object AssetAutomaticRunner {
    private val mutex = Mutex()
    private fun samePayment(before: BillInfoModel, after: BillInfoModel): Boolean = after.copy(
        cateName = before.cateName, pendingCategory = before.pendingCategory, categoryOrigin = before.categoryOrigin,
        categoryRevision = before.categoryRevision, auto = before.auto) == before

    suspend fun analyzeAutomatic(context: Context, input: OwnerQueueInput, permitted: () -> Boolean): Unit = withContext(Dispatchers.IO) {
        if (input.bill.cateName !in setOf("其他", "其它") || !AssetSuggestionPolicy.eligible(input.bill) ||
            input.bill.categoryOrigin == "MANUAL" || !permitted()) return@withContext
        val ticket = AssetAutomaticConsent.ticket(context) ?: return@withContext
        val kind = AssetSuggestionPolicy.paymentKind(input.bill) ?: return@withContext
        if (!mutex.tryLock()) return@withContext
        var claim: AiReviewClaim? = null
        try {
            fun allowed() = permitted() && AssetAutomaticConsent.permits(context, ticket)
            if (!allowed()) return@withContext
            // Category application may have incremented revision; payment/context edits may not be ignored.
            val fresh = OwnerCategoryQueue.input(input.bill.id)
            if (fresh.source != input.source || !samePayment(input.bill, fresh.bill) ||
                !AssetSuggestionPolicy.eligible(fresh.bill) || !allowed()) return@withContext
            val assets = AssetsAPI.listForSuggestion()
            val before = assets.filter { it.name == fresh.bill.accountNameFrom }
            val duplicates = AssetSuggestionPolicy.duplicates(kind, assets)
            if (before.size > 1 || duplicates.size > 1) return@withContext
            val existing = duplicates.singleOrNull()
            val currency = AssetSuggestionPolicy.currencyCode(fresh.bill.currency)
            if (existing != null && (existing.type != kind.type || (currency != null && existing.currency.name != currency))) return@withContext
            if (existing != null && before.singleOrNull()?.id == existing.id) return@withContext // Already mapped; do not spend quota.
            val change = AiReviewChange("ASSET_FROM", before.singleOrNull()?.id?.toString().orEmpty(), existing?.id?.toString().orEmpty(),
                createsNew = existing == null, kind = if (existing == null) kind.name else "", currency = if (existing == null) currency.orEmpty() else "")
            val ready = AiReviewStore(context).use { store ->
                val record = store.create(AiReviewTarget(fresh.source, fresh.bill.id, fresh.bill.categoryRevision, fresh.bill.hash()), AiReviewKind.ASSET)
                // Claim refuses terminal, existing pending, and every unknown write result. Never automatic retry.
                claim = store.claim(record.id) ?: return@withContext
                currentCoroutineContext().ensureActive()
                if (!allowed()) { store.fail(requireNotNull(claim), "AUTH_CHANGED"); claim = null; return@withContext }
                if (!AssetAutomaticConsent.claimAttempt(context, ticket, record.id)) {
                    store.fail(requireNotNull(claim), "BUSY"); claim = null; return@withContext
                }
                if (!allowed()) { store.fail(requireNotNull(claim), "AUTH_CHANGED"); claim = null; return@withContext }
                val response = withTimeout(20_000) {
                    ChatGptAccounts.get(context).classify(AssetSuggestionPolicy.PROMPT, AssetSuggestionPolicy.input(kind))
                }
                if (!allowed()) { store.fail(requireNotNull(claim), "AUTH_CHANGED"); claim = null; return@withContext }
                if (AssetSuggestionPolicy.parse(response, kind) == null) {
                    store.fail(requireNotNull(claim), "NO_RESULT"); claim = null; return@withContext
                }
                check(store.review(requireNotNull(claim), listOf(change)))
                claim = null
                requireNotNull(store.get(record.id))
            }
            // Unknown currency can be reviewed, but is never silently guessed or automatically created.
            try {
                if ((!change.createsNew || change.currency.isNotEmpty()) && allowed() && AiReviewPolicy(context).canAutoApply(ready)) {
                    AssetReviewActions.apply(context, ready, fresh.bill, automatic = true, automaticAllowed = ::allowed)
                }
            } finally {
                if (currentCoroutineContext().isActive && allowed()) net.ankio.auto.classification.OwnerCategoryPrompts.offerAsset(ready.id)
            }
        } catch (_: TimeoutCancellationException) {
            claim?.let { value -> runCatching { AiReviewStore(context).use { it.fail(value, "REQUEST_INTERRUPTED") } } }
        } catch (e: CancellationException) {
            claim?.let { value -> runCatching { AiReviewStore(context).use { it.fail(value, "REQUEST_INTERRUPTED") } } }
            throw e
        } catch (_: Exception) {
            claim?.let { value -> runCatching { AiReviewStore(context).use { it.fail(value, "REQUEST_FAILED") } } }
            // Category work was already persisted. This failure is isolated to this asset task.
        } finally { mutex.unlock() }
    }
}
