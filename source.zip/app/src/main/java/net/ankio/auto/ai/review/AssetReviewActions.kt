package net.ankio.auto.ai.review

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import net.ankio.auto.http.api.AssetsAPI
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.AssetSuggestionConfirmation
import org.ezbook.server.server.AssetSuggestionPreview
import org.ezbook.server.server.AssetSuggestionPreviewRequest

/** Shared by the initial prompt and the durable review-list handler. No provider request or automatic retry. */
object AssetReviewActions {
    suspend fun preview(record: AiReviewRecord, bill: BillInfoModel): AssetSuggestionPreview? {
        if (record.kind != AiReviewKind.ASSET || record.state != AiReviewState.REVIEW || record.changes.size != 1 ||
            record.target.billId != bill.id || record.target.fingerprint != bill.hash() ||
            record.target.revision != bill.categoryRevision) return null
        val change = record.changes.single()
        if (change.field != "ASSET_FROM") return null
        val request = if (change.createsNew) {
            AssetSuggestionPreviewRequest(bill.id, bill.hash(), change.kind, change.currency, bill.categoryRevision)
        } else {
            val id = change.after.toLongOrNull()?.takeIf { it > 0 } ?: return null
            AssetSuggestionPreviewRequest(bill.id, bill.hash(), "", "", bill.categoryRevision, id)
        }
        val preview = AssetsAPI.previewSuggestion(request) ?: return null
        if (preview.source != record.target.source || preview.beforeId?.toString().orEmpty() != change.before) return null
        if (change.createsNew && preview.existingId != null) return null
        if (!change.createsNew && preview.existingId?.toString() != change.after) return null
        return preview
    }

    suspend fun apply(context: Context, record: AiReviewRecord, bill: BillInfoModel, automatic: Boolean,
        manual: Boolean = false, automaticAllowed: () -> Boolean = { false }): BillInfoModel? = withContext(Dispatchers.IO) {
        AiReviewStore(context).use { store ->
            val latest = store.get(record.id) ?: return@withContext null
            if (latest != record || latest.state != AiReviewState.REVIEW) return@withContext null
            val policy = AiReviewPolicy(context)
            if (automatic && (!automaticAllowed() || !policy.canAutoApply(latest))) return@withContext null
            val preview = preview(latest, bill) ?: return@withContext null
            if (automatic && (!automaticAllowed() || !policy.canAutoApply(latest))) return@withContext null
            val token = store.beginApply(latest.id, latest.changes) ?: return@withContext null
            var dispatched = false
            try {
                currentCoroutineContext().ensureActive()
                if (automatic && (!automaticAllowed() || !policy.canAutoApply(latest))) {
                    store.returnToReview(latest.id, token)
                    return@withContext null
                }
                dispatched = true
                val result = AssetsAPI.confirmSuggestion(AssetSuggestionConfirmation(preview.token, true, preview.existingId))
                check(store.finishApply(latest.id, token, if (result == null) AiReviewState.STALE
                    else if (manual) AiReviewState.MANUAL else AiReviewState.APPLIED,
                    appliedChanges = result?.let { listOf(AiReviewChange("ASSET_FROM", latest.changes.single().before, it.assetId.toString())) }))
                result?.bill
            } catch (e: Exception) {
                // Includes cancellation after dispatch: the server may have committed, so never replay.
                if (dispatched) store.finishApply(latest.id, token, AiReviewState.FAILED)
                else store.returnToReview(latest.id, token)
                if (e is CancellationException) throw e
                throw IllegalStateException("APPLY_UNCONFIRMED")
            }
        }
    }
}
