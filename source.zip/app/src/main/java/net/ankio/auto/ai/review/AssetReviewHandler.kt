package net.ankio.auto.ai.review

import android.view.View
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import net.ankio.auto.http.api.BillAPI
import net.ankio.auto.ui.dialog.AssetSuggestionDialog
import net.ankio.auto.ui.utils.ToastUtils

object AssetReviewHandler {
    private var active: java.lang.ref.WeakReference<AssetSuggestionDialog>? = null
    private var generation = 0L
    fun open(host: FragmentActivity, record: AiReviewRecord) {
        val ticket = ++generation
        active?.get()?.dispose()
        val owner = host.findViewById<View>(android.R.id.content)
        host.lifecycleScope.launch {
            val bill = BillAPI.get(record.target.billId)
            if (ticket != generation || host.isFinishing || host.isDestroyed) return@launch
            if (bill == null || bill.hash() != record.target.fingerprint || bill.categoryRevision != record.target.revision) {
                ToastUtils.error("账单已变化或不可读取，请打开最新账单手动处理。")
                return@launch
            }
            val controller = AssetSuggestionDialog(owner, host.lifecycleScope, { bill }, { updated ->
                bill.accountNameFrom = updated.accountNameFrom; bill.auto = updated.auto
                ToastUtils.info("已保存，待确认与历史记录已更新。")
            })
            active = java.lang.ref.WeakReference(controller)
            controller.resume(record)
        }
    }
}
