package net.ankio.auto.ai.review

import org.ezbook.server.constant.BillState
import org.ezbook.server.db.model.BillInfoModel

/** Accept only confirmed local edits; a completed external sync may advance the state afterwards. */
internal object ManualEditEvidence {
    fun matches(current: BillInfoModel, expected: BillInfoModel, target: AiReviewTarget): Boolean =
        current.id == target.billId && expected.id == target.billId && current.categoryRevision > target.revision &&
            current.hash() != target.fingerprint && current.categoryOrigin == "MANUAL" &&
            current.state in setOf(BillState.Edited, BillState.Synced) &&
            expected.state in setOf(BillState.Edited, BillState.Synced) &&
            current.copy(categoryRevision = expected.categoryRevision, categoryOrigin = expected.categoryOrigin,
                state = expected.state) == expected
}
