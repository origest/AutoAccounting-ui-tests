package net.ankio.auto.ai.review

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import net.ankio.auto.classification.ManualBillCategoryService
import net.ankio.auto.classification.ManualCategoryRequest
import net.ankio.auto.classification.OwnerCategoryQueue
import net.ankio.chatgpt.AccountFailure
import org.ezbook.server.ai.tools.HistoryCategoryTool
import org.ezbook.server.db.model.BillInfoModel

/** Durable review boundary around the existing single-bill request, not a second provider. */
internal class TrackedManualCategory(private val context: Context) {
    data class Result(val record: AiReviewRecord, val preview: ManualCategoryRequest.Preview, val resumed: Boolean)
    private val request by lazy { ManualBillCategoryService.create(context) }
    private suspend fun <T> stored(action: (AiReviewStore) -> T): T = withContext(Dispatchers.IO) {
        AiReviewStore(context).use(action)
    }

    // Preserve a committed CAS ticket across dispatcher cancellation, then settle it in catch.
    private suspend fun <T> committed(action: (AiReviewStore) -> T): T = withContext(NonCancellable) { stored(action) }

    suspend fun suggest(id: Long, revision: Long, original: String, reviewId: String? = null,
        progress: (String) -> Unit): Result {
        val record = if (reviewId != null) stored { requireNotNull(it.get(reviewId)) }
        else {
            val input = OwnerCategoryQueue.input(id)
            if (input.bill.categoryRevision != revision || input.bill.hash() != original) throw ManualCategoryRequest.Failure("STALE")
            stored { it.create(AiReviewTarget(input.source, id, revision, original), AiReviewKind.CATEGORY) }
        }
        require(record.kind == AiReviewKind.CATEGORY)
        if (record.state == AiReviewState.REVIEW) {
            val change = record.changes.single { it.field == "CATEGORY" }
            val suggestion = if (change.createsNew) HistoryCategoryTool.Suggestion(proposed = change.after)
                else HistoryCategoryTool.Suggestion(existing = change.after)
            val target = record.target
            try {
                return Result(record, request.restore(target.source, target.billId, target.revision, target.fingerprint, suggestion), true)
            } catch (e: ManualCategoryRequest.Failure) {
                if (e.code == "STALE") committed { store ->
                    store.beginApply(record.id)?.let { store.finishApply(record.id, it, AiReviewState.STALE) }
                }
                throw e
            }
        }
        if (record.state !in setOf(AiReviewState.WAITING, AiReviewState.FAILED)) throw ManualCategoryRequest.Failure("BUSY")
        // Even explicit reopen cannot replay a write whose result has not been established.
        if (record.errorCode == "APPLY_UNCONFIRMED") throw ManualCategoryRequest.Failure("APPLY_UNCONFIRMED")
        val claim = committed { it.claim(record.id, explicitRetry = record.state == AiReviewState.FAILED) }
            ?: throw ManualCategoryRequest.Failure("BUSY")
        try {
            currentCoroutineContext().ensureActive()
            val target = record.target
            val preview = request.request(target.billId, target.revision, target.fingerprint, target.source, progress)
            if (preview.input.source != target.source) throw ManualCategoryRequest.Failure("STALE")
            val change = AiReviewChange("CATEGORY", preview.input.bill.cateName,
                preview.suggestion.existing ?: preview.suggestion.proposed.orEmpty(), preview.suggestion.proposed != null)
            val ready = stored { store -> check(store.review(claim, listOf(change))); requireNotNull(store.get(record.id)) }
            return Result(ready, preview, false)
        } catch (e: Exception) {
            val code = when (e) {
                is CancellationException -> "CANCELLED"
                is ManualCategoryRequest.Failure -> e.code
                is AccountFailure -> e.code
                else -> "REQUEST_FAILED"
            }
            withContext(NonCancellable + Dispatchers.IO) { AiReviewStore(context).use { it.fail(claim, code) } }
            throw e
        }
    }

    fun mayApplyAutomatically(result: Result): Boolean = !result.resumed && !result.preview.readOnly &&
        AiReviewPolicy(context).canAutoApply(result.record)

    suspend fun apply(result: Result, automatic: Boolean): Boolean {
        if (automatic && !mayApplyAutomatically(result)) throw ManualCategoryRequest.Failure("POLICY_CHANGED")
        val token = committed { it.beginApply(result.record.id, result.record.changes) } ?: throw ManualCategoryRequest.Failure("BUSY")
        var dispatched = false
        try {
            currentCoroutineContext().ensureActive()
            val applied = request.apply(result.preview) {
                if (automatic && !AiReviewPolicy(context).canAutoApply(result.record)) throw ManualCategoryRequest.Failure("POLICY_CHANGED")
                dispatched = true
            }
            check(stored { it.finishApply(result.record.id, token, if (applied) AiReviewState.APPLIED else AiReviewState.STALE) })
            return applied
        } catch (e: Exception) {
            withContext(NonCancellable + Dispatchers.IO) {
                AiReviewStore(context).use { store ->
                    if (dispatched) store.finishApply(result.record.id, token, AiReviewState.FAILED)
                    else if (e is ManualCategoryRequest.Failure && e.code == "STALE") store.finishApply(result.record.id, token, AiReviewState.STALE)
                    else store.returnToReview(result.record.id, token, if (e is ManualCategoryRequest.Failure) e.code else "AUTH_CHANGED")
                }
            }
            throw e
        }
    }

    suspend fun defer(result: Result) = stored { it.defer(result.record.id) }

    /** Only mark manual history after the ordinary editor's persisted result is read back. */
    suspend fun recordManualEdit(result: Result, expected: BillInfoModel): Boolean {
        val current = OwnerCategoryQueue.input(result.record.target.billId)
        if (current.source != result.record.target.source ||
            !ManualEditEvidence.matches(current.bill, expected, result.record.target)) return false
        val changes = listOf(AiReviewChange("CATEGORY", result.record.changes.single().before, current.bill.cateName))
        if (!AiReviewSafety.changes(AiReviewKind.CATEGORY, changes)) return false
        return committed { store ->
            val token = store.beginApply(result.record.id, result.record.changes) ?: return@committed false
            store.finishApply(result.record.id, token, AiReviewState.MANUAL, changes)
        }
    }
}
