package net.ankio.auto.capture

import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.content.Context
import net.ankio.auto.ui.api.BaseActivity
import net.ankio.auto.ui.utils.SettingsPage
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.*
import com.google.android.accessibility.selecttospeak.SelectToSpeakService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PaymentCaptureActivity : BaseActivity() {
    private val prefs by lazy { getSharedPreferences("payment-capture", Context.MODE_PRIVATE) }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        render()
    }
    override fun onResume() { super.onResume(); render() }
    private fun render() {
        val page = SettingsPage(this, "支付截图")
        fun label(text: String) { page.text(text) }
        fun button(text: String, action: () -> Unit) { page.button(text, action = action) }
        page.section("仅保存在本机", "默认关闭 · Android 14 及以上")
        label("需要 Android 14+ 和无障碍权限。截图可能包含金额、姓名和账号，仅保存于应用私有目录，不进入云备份、不上传、不送入 AI。卸载或清除应用数据会删除截图。最多保存 100 张或 128 MiB，满后停止保存。")
        val enabled = prefs.getBoolean("enabled", false)
        button(if (enabled) "关闭支付截图" else "启用支付截图") {
            if (enabled) {
                synchronized(PaymentCaptureStore::class.java) {
                    prefs.edit().putBoolean("enabled", false).putBoolean("automatic", false)
                        .putLong("epoch", prefs.getLong("epoch", 0) + 1).commit()
                }
                render()
            } else if (Build.VERSION.SDK_INT < 34) {
                Toast.makeText(this, "此功能仅支持 Android 14 及以上", Toast.LENGTH_LONG).show()
            } else {
                MaterialAlertDialogBuilder(this).setTitle("允许保存支付截图？")
                    .setMessage("无障碍服务会读取微信和支付宝当前页面以匹配成功状态，并在你手动触发或启用自动截图后保存页面。截图可能包含敏感信息。系统禁止截图时会失败，不会绕过保护。此授权不启用 AI 或上传。")
                    .setNegativeButton("取消", null).setPositiveButton("同意") { _, _ ->
                        prefs.edit().putBoolean("enabled", true).putBoolean("automatic", false).commit(); render()
                    }.show()
            }
        }
        page.section("无障碍服务", "只有点击下方按钮才会打开系统权限设置。")
        label(if (SelectToSpeakService.instance == null) "无障碍服务未连接，请自行在系统设置开启" else "无障碍服务已连接")
        button("打开系统无障碍设置") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        page.section("自动与手动截图", "自动截图需单独开启并登记成功页面；系统禁止截图时停止，不绕过保护。")
        button(if (prefs.getBoolean("automatic", false)) "关闭自动截图" else "开启已登记页面的自动截图") {
            if (!prefs.getBoolean("enabled", false)) { Toast.makeText(this, "请先启用支付截图", Toast.LENGTH_LONG).show() }
            else {
                synchronized(PaymentCaptureStore::class.java) {
                    prefs.edit().putBoolean("automatic", !prefs.getBoolean("automatic", false))
                        .putLong("epoch", prefs.getLong("epoch", 0) + 1).commit()
                }
                render()
            }
        }
        label("自动截图仅适用于你登记过的页面，同时要求显示“支付成功”和“完成／返回商家／完成支付”。聊天消息、账单列表、其他语言或页面更新可能无法匹配；可使用手动截图。截图不能证明真实支付。")
        for (pkg in PaymentCapturePolicy.packages) label((if (pkg == "com.tencent.mm") "微信" else "支付宝") + if (prefs.contains("page_$pkg")) "：已登记" else "：未登记")
        button("5 秒后登记当前支付成功页（不截图）") { arm(true) }
        button("5 秒后手动截取微信／支付宝窗口") { arm(false) }
        button("清除已登记页面") {
            synchronized(PaymentCaptureStore::class.java) {
                prefs.edit().remove("page_com.tencent.mm").remove("page_com.eg.android.AlipayGphone")
                    .putLong("epoch", prefs.getLong("epoch", 0) + 1).commit()
            }
            render()
        }
        page.section("本机图库")
        val store = PaymentCaptureStore(this)
        val files = store.files()
        label("本机截图：${files.size} 张（不在系统相册中）")
        button("刷新列表") { render() }
        button("删除全部截图") {
            MaterialAlertDialogBuilder(this).setMessage("永久删除全部本机支付截图？")
                .setNegativeButton("取消", null).setPositiveButton("删除") { _, _ ->
                    synchronized(PaymentCaptureStore::class.java) {
                        prefs.edit().putLong("epoch", prefs.getLong("epoch", 0) + 1).commit(); store.clear()
                    }
                    render()
                }.show()
        }
        for (file in files) button(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(file.lastModified()))) {
            val image = ImageView(this).apply { adjustViewBounds = true }
            val bitmap = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = 2 })
            image.setImageBitmap(bitmap)
            val dialog = MaterialAlertDialogBuilder(this).setView(ScrollView(this).apply { addView(image) })
                .setPositiveButton("关闭", null).setNegativeButton("删除") { _, _ -> store.delete(file); render() }.create()
            dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            dialog.setOnDismissListener { image.setImageDrawable(null); bitmap?.recycle() }
            dialog.show()
        }
    }
    private fun arm(register: Boolean) {
        val service = SelectToSpeakService.instance
        if (service == null) { Toast.makeText(this, "请先在系统设置启用无障碍服务", Toast.LENGTH_LONG).show(); return }
        if (!prefs.getBoolean("enabled", false)) { Toast.makeText(this, "请先启用支付截图", Toast.LENGTH_LONG).show(); return }
        service.paymentCapture.arm(register)
        moveTaskToBack(true)
    }
}
