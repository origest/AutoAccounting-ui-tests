@file:Suppress("DEPRECATION")
package net.ankio.auto.capture

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.concurrent.Executors

/** Called on the accessibility main thread. No API, shell, MediaProjection or FLAG_SECURE fallback. */
class PaymentCaptureController(private val service: AccessibilityService) {
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val prefs = service.getSharedPreferences("payment-capture", Context.MODE_PRIVATE)
    @Volatile private var alive = true
    private var busy = false
    @Volatile private var serial = 0L
    private var lastScan = 0L
    private var action = 0 // 1 = register, 2 = manual
    private var actionAt = 0L
    private data class Page(val pkg: String, val activity: String, val window: Int, val shape: String, val texts: List<String>) {
        val fingerprint get() = PaymentCapturePolicy.digest(pkg + "\n" + activity + "\n" + texts.joinToString("\n"))
    }
    fun arm(register: Boolean) {
        if (Build.VERSION.SDK_INT < 34) { message("支付截图需要 Android 14 及以上"); return }
        if (!prefs.getBoolean("enabled", false)) { message("请先在支付截图设置中启用"); return }
        if (busy) { message("正在截图，请稍后再试"); return }
        action = if (register) 1 else 2
        actionAt = SystemClock.elapsedRealtime() + 5000
        handler.postDelayed({ scan() }, 5100)
        message("请在 5 秒内切换到微信或支付宝目标页面")
    }
    fun event() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastScan < 800) return
        lastScan = now
        scan()
    }
    private fun page(): Page? {
        val root = runCatching { service.rootInActiveWindow }.getOrNull() ?: return null
        try {
            val pkg = root.packageName?.toString().orEmpty()
            if (pkg !in PaymentCapturePolicy.packages) return null
            val texts = mutableListOf<String>()
            val shape = StringBuilder()
            var count = 0
            fun visit(node: AccessibilityNodeInfo, depth: Int) {
                check(++count <= 400 && depth <= 30)
                if (node.isVisibleToUser) {
                    shape.append(depth).append(':').append(node.className).append(':').append(node.viewIdResourceName).append(';')
                    node.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it.take(512)) }
                    node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it.take(512)) }
                }
                for (i in 0 until node.childCount) node.getChild(i)?.let {
                    try { visit(it, depth + 1) } finally { it.recycle() }
                }
            }
            visit(root, 0)
            val activity = com.google.android.accessibility.selecttospeak.SelectToSpeakService.topActivity.orEmpty()
            return Page(pkg, activity, root.windowId, shape.toString(), texts)
        } catch (_: Exception) { return null } finally { root.recycle() }
    }
    private fun scan() {
        if (action != 0 && SystemClock.elapsedRealtime() > actionAt + 3000) { action = 0; message("操作已过期，请重新手动触发"); return }
        if (!alive || busy || Build.VERSION.SDK_INT < 34 || !prefs.getBoolean("enabled", false)) return
        val pending = action
        if (pending != 0 && SystemClock.elapsedRealtime() < actionAt) return
        val page = page()
        if (pending != 0) action = 0
        if (page == null) { if (pending != 0) message("未找到可截图的微信或支付宝窗口"); return }
        if (pending == 1) {
            if (page.activity.isBlank() || !PaymentCapturePolicy.success(page.texts)) {
                message("仅可登记同时显示“支付成功”和完成按钮的页面"); return
            }
            prefs.edit().putString("page_${page.pkg}", PaymentCapturePolicy.digest(page.activity + "\n" + page.shape)).apply()
            message("已登记成功页面；页面结构变化后需要重新登记")
            return
        }
        if (pending != 2 && (!prefs.getBoolean("automatic", false) ||
            !PaymentCapturePolicy.matches(page.pkg, page.activity, page.shape, prefs.getString("page_${page.pkg}", null), page.texts))) return
        val seen = prefs.getStringSet("seen", emptySet()).orEmpty()
        if (pending != 2 && page.fingerprint in seen) return
        // Persist attempts, including failures, to avoid callback/event storms. Manual retry remains explicit.
        if (!prefs.edit().putStringSet("seen", (seen.toList().takeLast(127) + page.fingerprint).toSet()).commit()) { message("无法保存截图状态，已停止"); return }
        capture(page)
    }
    private fun capture(expected: Page) {
        if (Build.VERSION.SDK_INT < 34) return
        busy = true
        val ticket = ++serial
        val epoch = prefs.getLong("epoch", 0)
        handler.postDelayed({ if (ticket == serial && busy) { serial++; busy = false; message("截图超时，未保存；可手动重试") } }, 10000)
        try {
            service.takeScreenshotOfWindow(expected.window, service.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onFailure(errorCode: Int) {
                    if (!alive || ticket != serial) return
                    busy = false
                    message(if (errorCode == AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW) "该页面禁止截图，未保存" else "截图失败（$errorCode），未保存；可手动重试")
                }
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val buffer = result.hardwareBuffer
                    var software: Bitmap? = null
                    try {
                        val current = page()
                        if (!alive || ticket != serial || !prefs.getBoolean("enabled", false) || prefs.getLong("epoch", 0) != epoch ||
                            current?.window != expected.window || current.pkg != expected.pkg || current.fingerprint != expected.fingerprint) return
                        if (buffer.width.toLong() * buffer.height > 16_000_000L) { message("窗口尺寸过大，未保存"); return }
                        val hardware = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace) ?: return
                        try { software = hardware.copy(Bitmap.Config.ARGB_8888, false) } finally { hardware.recycle() }
                    } catch (_: Exception) { message("截图转换失败，未保存") }
                    finally { buffer.close(); if (ticket == serial) busy = false }
                    val bitmap = software ?: return
                    busy = true
                    io.execute {
                        var saved = false
                        try {
                            val store = PaymentCaptureStore(service)
                            val file = store.save(bitmap) {
                                alive && ticket == serial && prefs.getBoolean("enabled", false) && prefs.getLong("epoch", 0) == epoch
                            }
                            synchronized(PaymentCaptureStore::class.java) {
                                if (alive && ticket == serial && prefs.getBoolean("enabled", false) && prefs.getLong("epoch", 0) == epoch) saved = true
                                else store.delete(file)
                            }
                        } catch (_: Exception) { /* Never log page data or screenshot paths. */ }
                        finally { bitmap.recycle() }
                        handler.post { if (alive && ticket == serial) { busy = false; message(if (saved) "支付截图已保存到本机" else "未保存截图，请检查存储空间或删除旧截图") } }
                    }
                }
            })
        } catch (_: Exception) { busy = false; message("系统不允许截图，未保存") }
    }
    private fun message(text: String) { Toast.makeText(service, text, Toast.LENGTH_LONG).show() }
    fun close() { alive = false; serial++; action = 0; handler.removeCallbacksAndMessages(null); io.shutdown() }
}
