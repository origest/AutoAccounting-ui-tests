package net.ankio.auto.capture

import java.security.MessageDigest

internal object PaymentCapturePolicy {
    val packages = setOf("com.tencent.mm", "com.eg.android.AlipayGphone")
    fun success(texts: List<String>): Boolean = texts.any { it.trim() == "支付成功" } &&
        texts.any { it.trim() in setOf("完成", "返回商家", "完成支付") }
    fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
    fun matches(pkg: String, activity: String, shape: String, saved: String?, texts: List<String>): Boolean =
        pkg in packages && activity.isNotBlank() && shape.isNotBlank() &&
            saved == digest(activity + "\n" + shape) && success(texts)
}
