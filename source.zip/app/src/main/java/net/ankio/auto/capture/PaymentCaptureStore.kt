package net.ankio.auto.capture

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.OutputStream
import java.util.UUID

/** Private and excluded from Android backup; never exposed through a provider, network or OCR. */
internal class PaymentCaptureStore(
    context: Context,
    directoryName: String = "payment-captures",
    private val encode: (Bitmap, OutputStream) -> Boolean = { bitmap, output ->
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
    }
) {
    private val directory = File(context.noBackupFilesDir, directoryName).apply { mkdirs() }
    @Synchronized fun files(): List<File> = directory.listFiles()?.filter { it.extension == "png" }
        ?.sortedByDescending { it.name }.orEmpty()
    fun save(bitmap: Bitmap, permitted: () -> Boolean = { true }): File {
        check(permitted()) { "CANCELLED" }
        check(files().size < 100 && files().sumOf { it.length() } < 128L * 1024 * 1024) { "LIMIT" }
        val target = File(directory, "${System.currentTimeMillis()}-${UUID.randomUUID()}.png")
        val temp = File(directory, target.name + ".tmp")
        try {
            // Clear-all uses this lock: an old task must not create a temp file after it returns.
            val output = synchronized(PaymentCaptureStore::class.java) {
                check(permitted()) { "CANCELLED" }
                temp.outputStream()
            }
            // Encoding may be slow. Never hold the permission lock while writing image bytes.
            output.use { check(encode(bitmap, it)) }
            synchronized(PaymentCaptureStore::class.java) {
                // Disable/delete can run during encoding. Recheck before publishing to the gallery.
                check(permitted()) { "CANCELLED" }
                val existing = files()
                check(existing.size < 100 && temp.length() + existing.sumOf { it.length() } <= 128L * 1024 * 1024) { "LIMIT" }
                check(temp.renameTo(target))
            }
            return target
        } finally { temp.delete() }
    }
    @Synchronized fun delete(file: File): Boolean = file.parentFile == directory && file.extension == "png" && file.delete()
    @Synchronized fun clear() { directory.listFiles()?.filter { it.extension in setOf("png", "tmp") }?.forEach { it.delete() } }
}
