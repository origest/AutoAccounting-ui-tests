package net.ankio.auto.classification

/** Owner-side policy only. Never accept provenance, consent, or attempt state from an IPC payload. */
internal object ClassificationPolicy {
    enum class Mode { XPOSED, OCR }
    enum class Origin { RULE, UNASSIGNED, MANUAL, AI, LEGACY_UNKNOWN }
    enum class State { READY, RESERVED, DISPATCHED, SUCCEEDED, UNKNOWN, CANCELLED, STALE }
    data class Snapshot(
        val source: String,
        val billId: Long,
        val revision: Long,
        val mode: Mode,
        val origin: Origin,
        val category: String,
        val pendingProposal: Boolean = false,
        val groupedChild: Boolean = false,
    )
    data class Ticket(
        val snapshot: Snapshot,
        val consentEpoch: Long,
        val state: State = State.READY,
        val attemptId: String = "",
    )

    /** Legacy rows require explicit review: an empty/other category does not prove absence of edits. */
    fun eligible(bill: Snapshot): Boolean {
        if (bill.source.isBlank() || bill.billId <= 0 || bill.revision < 0 ||
            bill.pendingProposal || bill.groupedChild) return false
        if (bill.origin !in setOf(Origin.RULE, Origin.UNASSIGNED)) return false
        // Rules win in every mode. OCR text-to-bill extraction has its own separate consent path.
        return bill.category.trim() in setOf("其他", "其它")
    }

    /** Must be persisted atomically by the owner store before a worker can take the ticket. */
    fun reserve(ticket: Ticket, current: Snapshot, consentEpoch: Long, attemptId: String): Ticket? {
        if (ticket.state != State.READY || attemptId.isBlank() || !eligible(current) ||
            ticket.snapshot != current || ticket.consentEpoch != consentEpoch) return null
        return ticket.copy(state = State.RESERVED, attemptId = attemptId)
    }

    /** Persist before any provider call; a crash after this point is ambiguous, never auto-retry. */
    fun dispatch(ticket: Ticket, current: Snapshot, consentEpoch: Long, online: Boolean): Ticket {
        check(ticket.state == State.RESERVED)
        return when {
            ticket.consentEpoch != consentEpoch -> ticket.copy(state = State.CANCELLED)
            current != ticket.snapshot || !eligible(current) -> ticket.copy(state = State.STALE)
            !online -> ticket.copy(state = State.READY, attemptId = "")
            else -> ticket.copy(state = State.DISPATCHED)
        }
    }

    /** Every error after dispatch is uncertain, including timeout, HTTP failure and cancellation. */
    fun uncertain(ticket: Ticket): Ticket {
        check(ticket.state == State.DISPATCHED)
        return ticket.copy(state = State.UNKNOWN)
    }

    /** Run in the same transaction as applying a parsed result; mismatch must never edit a bill. */
    fun complete(ticket: Ticket, current: Snapshot, consentEpoch: Long, attemptId: String): Ticket? {
        if (ticket.state != State.DISPATCHED || ticket.attemptId != attemptId ||
            ticket.consentEpoch != consentEpoch || ticket.snapshot != current || !eligible(current)) return null
        return ticket.copy(state = State.SUCCEEDED)
    }

    fun recover(ticket: Ticket): Ticket = when (ticket.state) {
        State.RESERVED -> ticket.copy(state = State.READY, attemptId = "")
        State.DISPATCHED -> ticket.copy(state = State.UNKNOWN)
        else -> ticket
    }

    fun cancel(ticket: Ticket): Ticket = when (ticket.state) {
        State.READY, State.RESERVED -> ticket.copy(state = State.CANCELLED)
        State.DISPATCHED -> ticket.copy(state = State.UNKNOWN)
        else -> ticket
    }
}
