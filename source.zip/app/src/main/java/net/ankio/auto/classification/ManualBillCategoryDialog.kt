package net.ankio.auto.classification

import android.app.Dialog
import android.content.DialogInterface
import com.google.android.material.button.MaterialButton
import net.ankio.auto.ai.review.TrackedManualCategory
import net.ankio.auto.ai.review.AiReviewEvents
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.dialog.BillEditorDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import net.ankio.auto.ui.activity.ChatGptCategoryActivity
import net.ankio.chatgpt.AccountFailure
import net.ankio.chatgpt.DiagnosticFailure
import org.ezbook.server.db.model.BillInfoModel

/** Dismissal/navigation cancels inference. Restoration never silently resends a bill. */
class ManualBillCategoryDialog : DialogFragment() {
    private lateinit var status: TextView
    private lateinit var progress: LinearProgressIndicator
    private var job: Job? = null
    private var request: TrackedManualCategory? = null
    private var trackedResult: TrackedManualCategory.Result? = null
    private lateinit var manualButton: MaterialButton
    private var deferred = false
    private var preview: ManualCategoryRequest.Preview? = null
    private var started = false
    private var saving = false

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        started = savedInstanceState?.getBoolean("started") == true
        savedInstanceState?.getString("reviewId")?.let { requireArguments().putString("reviewId", it); started = false }
        val context = requireContext()
        val padding = (24 * resources.displayMetrics.density).toInt()
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding / 2, padding, 0)
        }
        progress = LinearProgressIndicator(context).apply { isIndeterminate = true }
        status = TextView(context).apply {
            textSize = 16f
            setPadding(0, padding / 2, 0, padding / 2)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            text = "只处理这笔账单，使用已登录账号、所选模型和现有发送授权。"
        }
        content.addView(progress)
        content.addView(status)
        manualButton = MaterialButton(context).apply {
            text = "手动修改这笔账单"
            visibility = View.GONE
            setOnClickListener { manualEdit() }
        }
        content.addView(manualButton)
        return MaterialAlertDialogBuilder(context)
            .setTitle("AI 分类 · ChatGPT")
            .setView(content)
            .setPositiveButton("重新分类", null)
            .setNegativeButton("取消", null)
            .setNeutralButton("账号与授权", null)
            .create()
    }

    override fun onStart() {
        super.onStart()
        val alert = dialog as AlertDialog
        alert.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            job?.cancel()
            dismiss()
            startActivity(Intent(requireContext(), ChatGptCategoryActivity::class.java))
        }
        alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (job?.isActive == true) return@setOnClickListener
            if (preview != null) save() else startRequest()
        }
        if (!requireArguments().getBoolean("supported", true)) {
            started = true
            status.text = "此账单类型不使用收支分类，或属于合并子账单；未发送请求。"
            controls(false)
        } else if (!started) startRequest()
        else if (trackedResult != null && job?.isActive != true) {
            preview = trackedResult!!.preview
            showSuggestion(trackedResult!!)
        } else if (preview == null && job?.isActive != true) {
            status.text = "上次操作已中断，未自动重发。若刚确认保存，请先关闭并刷新账单核对结果。"
            controls(false, "重新分类")
        }
    }

    private fun controls(busy: Boolean, action: String? = null) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        (dialog as? AlertDialog)?.let { alert ->
            alert.getButton(AlertDialog.BUTTON_POSITIVE).apply {
                visibility = if (action == null) View.GONE else View.VISIBLE
                text = action
                isEnabled = !busy
            }
            alert.getButton(AlertDialog.BUTTON_NEGATIVE).isEnabled = !saving
            alert.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled = !saving
        }
        isCancelable = !saving
    }

    private fun startRequest() {
        if (job?.isActive == true) return
        started = true
        preview = null
        controls(true)
        job = lifecycleScope.launch {
            try {
                val service = request ?: TrackedManualCategory(requireContext().applicationContext).also { request = it }
                val args = requireArguments()
                val tracked = service.suggest(args.getLong("id"), args.getLong("revision"), args.getString("original").orEmpty(), args.getString("reviewId")) {
                    status.text = it
                }
                trackedResult = tracked
                preview = tracked.preview
                deferred = false
                if (service.mayApplyAutomatically(tracked)) {
                    save(automatic = true)
                    return@launch
                }
                showSuggestion(tracked)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                status.text = errorMessage(e)
                val retry = e is ManualCategoryRequest.Failure && e.code in setOf("BUSY", "NO_RESULT")
                controls(false, if (retry) "重新分类" else null)
            }
        }
    }

    private fun showSuggestion(tracked: TrackedManualCategory.Result) {
        val result = tracked.preview
        val bill = result.input.bill
        val category = result.suggestion.existing ?: result.suggestion.proposed.orEmpty()
        status.text = "当前分类：${bill.cateName.ifBlank { "未分类" }}\nAI 建议：$category\n\n" + when {
            result.readOnly -> "这笔账单已同步，仅展示建议，不会修改本机或外部账本。"
            result.suggestion.proposed != null -> "这是新类别。确认后仅创建本地一级类别并用于这笔账单；外部记账应用可能需要另行创建或同步。\n取消或关闭会保留在待确认列表。"
            bill.cateName == category -> "建议与当前分类相同。可确认保留此分类，或关闭留待处理。"
            else -> "确认后才替换这笔账单的分类。取消或关闭会保留在待确认列表。"
        }
        manualButton.visibility = if (result.readOnly) View.GONE else View.VISIBLE
        controls(false, if (result.readOnly) null else if (result.suggestion.proposed != null) "创建并使用" else "确认分类")
    }

    private fun manualEdit() {
        val result = trackedResult ?: return
        if (saving || job?.isActive == true) return
        job = lifecycleScope.launch {
          try {
            val original = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val current = OwnerCategoryQueue.input(result.record.target.billId)
                if (current.source != result.record.target.source || current.bill.categoryRevision != result.record.target.revision ||
                    current.bill.hash() != result.record.target.fingerprint) throw ManualCategoryRequest.Failure("STALE")
                current.bill.copy()
            }
            BaseSheetDialog.create<BillEditorDialog>(requireContext())
            .setBillInfo(original.copy())
            .bindSaveToSnapshot(result.record.target.source, original)
            .setOnConfirm { savedBill ->
                job = lifecycleScope.launch {
                    try {
                        if (request?.recordManualEdit(result, savedBill) == true) {
                            trackedResult = null; preview = null
                            manualButton.visibility = View.GONE
                            parentFragmentManager.setFragmentResult(RESULT, Bundle())
                            status.text = "手动修改已保存，并记入 AI 修改历史。"
                            controls(false)
                        } else status.text = "未确认手动修改已保存，AI 建议仍保留待确认。请刷新账单核对。"
                    } catch (e: CancellationException) { throw e }
                    catch (_: Exception) { status.text = "暂未确认手动修改结果，AI 建议仍保留待确认。" }
                }
            }.show()
          } catch (e: CancellationException) { throw e }
          catch (_: Exception) { status.text = "账单或来源已变化，未打开旧快照。请刷新账单后重新处理。" }
        }
    }

    private fun save(automatic: Boolean = false) {
        val result = trackedResult ?: return
        saving = true
        controls(true)
        manualButton.visibility = View.GONE
        status.text = if (automatic) "正在按已开启的策略应用分类，并记录历史…" else "正在保存已确认的分类…"
        job = lifecycleScope.launch {
            try {
                if (request!!.apply(result, automatic)) {
                    preview = null
                    trackedResult = null
                    parentFragmentManager.setFragmentResult(RESULT, Bundle())
                    status.text = "分类已保存，账单列表已刷新。"
                } else {
                    preview = null
                    trackedResult = null
                    status.text = "账单或类别已变化，本次建议未写入。请关闭并刷新后重新分类。"
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                preview = null
                status.text = if (e is ManualCategoryRequest.Failure || e is AccountFailure) errorMessage(e)
                    else "保存结果未确认。请关闭并刷新账单核对结果，不要直接重复保存。"
            } finally {
                saving = false
                controls(false)
            }
        }
    }

    override fun onStop() {
        job?.cancel()
        deferOnce()
        preview = null
        super.onStop()
    }

    override fun onDismiss(dialog: DialogInterface) {
        job?.cancel()
        deferOnce()
        super.onDismiss(dialog)
    }

    private fun deferOnce() {
        if (deferred) return
        val result = trackedResult ?: return
        val context = context?.applicationContext ?: return
        deferred = true
        AiReviewEvents.defer(context, result.record.id)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("started", started)
        trackedResult?.let { outState.putString("reviewId", it.record.id) }
        super.onSaveInstanceState(outState)
    }

    private fun errorMessage(error: Exception): String = when (error) {
        is ManualCategoryRequest.Failure -> when (error.code) {
            "BUSY" -> "已有账单分类任务正在运行，请稍后再点。未发送这笔账单。"
            "STALE" -> "账单已被修改或来源已变化，未覆盖新内容。请关闭并刷新后重新分类。"
            "PENDING" -> "这笔账单已有待确认的新类别，请先进入账单编辑页接受或拒绝。"
            "UNSUPPORTED" -> "此账单类型不使用收支分类，或属于合并子账单；未发送请求。"
            "NO_RESULT" -> "ChatGPT 未返回可用的分类建议，原分类保持不变。重新分类会再次使用计划额度。"
            "POLICY_CHANGED" -> "自动应用策略已关闭，建议保留待确认，请重新打开记录手动确认。"
            "APPLY_UNCONFIRMED" -> "上次保存结果未确认，不会自动重试。请先刷新原账单核对，避免重复操作。"
            "READ_ONLY" -> "已同步账单仅展示建议，不会修改账本。"
            else -> "账号、模型或发送授权已变化，本次建议已失效。请检查账号与授权。"
        }
        is AccountFailure -> when (error.code) {
            "SIGN_IN_REQUIRED" -> "请先在“账号与授权”登录 ChatGPT。登录后还需选择模型并确认账单发送授权。"
            "MODEL_REQUIRED" -> "请在“账号与授权”刷新并选择模型。"
            "BUSY" -> "ChatGPT 账号正在处理其他操作，请稍后重新打开分类。"
            "STORE_UNAVAILABLE" -> "无法读取本地加密账号，请在“账号与授权”检查凭据状态。"
            "CANCELLED" -> "分类已取消，原分类保持不变；不会自动重试。"
            else -> "ChatGPT 分类发送许可尚未开启或已暂停。请在“账号与授权”确认发送授权，无需开启自动任务。"
        }
        is DiagnosticFailure -> "ChatGPT 分类未完成：${error.code.hint}" +
            (error.http?.let { "（HTTP $it）" } ?: "") +
            "\n原分类保持不变；不会自动重试，也不会切换服务商。请检查账号与发送授权后再试。"
        else -> "未能完成分类，请检查本机记账服务和 ChatGPT 授权。原分类未被本次请求修改，不会自动重试。"
    }

    companion object {
        const val TAG = "manual-bill-category"
        const val RESULT = "manual-bill-category-updated"
        fun createReview(id: String) = ManualBillCategoryDialog().apply { arguments = Bundle().apply { putString("reviewId", id) } }
        fun create(bill: BillInfoModel) = ManualBillCategoryDialog().apply {
            arguments = Bundle().apply {
                putBoolean("supported", org.ezbook.server.ai.tools.CategoryTool.categoryType(bill.type) != null && bill.groupId == -1L)
                putLong("id", bill.id)
                putLong("revision", bill.categoryRevision)
                putString("original", bill.hash())
            }
        }
    }
}
