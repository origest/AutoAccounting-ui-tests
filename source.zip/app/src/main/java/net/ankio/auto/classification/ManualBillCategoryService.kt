package net.ankio.auto.classification

import android.content.Context
import com.google.gson.Gson
import net.ankio.auto.utils.PrefManager
import net.ankio.chatgpt.AccountFailure
import net.ankio.chatgpt.ChatGptAccounts

/** Uses the owner's existing login/model/send consent, independent of automatic queue grants. */
internal object ManualBillCategoryService {
    fun create(context: Context): ManualCategoryRequest {
        val accounts = ChatGptAccounts.get(context.applicationContext)
        return ManualCategoryRequest(
            authority = {
                val view = accounts.view()
                val account = view.accounts.firstOrNull { it.key == view.active && it.signedIn }
                    ?: throw AccountFailure("SIGN_IN_REQUIRED")
                if (!account.enabled || !PrefManager.aiCategoryChatGpt || !PrefManager.featureAiAvailable ||
                    !PrefManager.aiCategoryRecognition || !PrefManager.aiCategoryHistory) throw AccountFailure("CLASSIFICATION_PAUSED")
                if (account.model.isBlank()) throw AccountFailure("MODEL_REQUIRED")
                Gson().toJson(listOf(OwnerCategoryQueue.scopeIdentity(), OwnerCategoryQueue.stamp()))
            },
            read = { OwnerCategoryQueue.input(it) },
            payload = { OwnerCategoryQueue.payload(it) },
            infer = { system, input -> accounts.classify(system, input) },
            write = {
                OwnerQueueHttp.post<Boolean>("ownerQueue/manualApply", Gson().toJson(it)).let { response ->
                    check(response.code == 200)
                    response.data == true
                }
            },
            mutex = OwnerCategoryQueue.mutex
        )
    }
}
