package net.ankio.auto.classification

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import org.ezbook.server.ai.tools.CategoryTool
import org.ezbook.server.ai.tools.HistoryCategoryTool
import org.ezbook.server.constant.BillState
import org.ezbook.server.server.ManualCategoryApply
import org.ezbook.server.server.OwnerQueueInput

/** One explicit tap, one inference. Suggestions never write without a separate confirmation. */
internal class ManualCategoryRequest(
    private val authority: () -> String,
    private val read: suspend (Long) -> OwnerQueueInput,
    private val payload: (OwnerQueueInput) -> String,
    private val infer: suspend (String, String) -> String,
    private val write: suspend (ManualCategoryApply) -> Boolean,
    private val mutex: Mutex = Mutex()
) {
    class Failure(val code: String) : Exception()
    data class Preview(val input: OwnerQueueInput, val response: String,
        val suggestion: HistoryCategoryTool.Suggestion, val authority: String) {
        val readOnly: Boolean get() = input.bill.state == BillState.Synced
    }

    suspend fun request(id: Long, revision: Long, original: String, expectedSource: String? = null, progress: (String) -> Unit): Preview {
        if (!mutex.tryLock()) throw Failure("BUSY")
        try {
            val ticket = authority()
            progress("正在读取这笔账单和相关历史…")
            val input = read(id)
            if ((expectedSource != null && input.source != expectedSource) || input.bill.categoryRevision != revision || input.bill.hash() != original) throw Failure("STALE")
            if (input.bill.groupId != -1L || CategoryTool.categoryType(input.bill.type) == null) throw Failure("UNSUPPORTED")
            if (input.bill.pendingCategory.isNotEmpty()) throw Failure("PENDING")
            val data = payload(input)
            currentCoroutineContext().ensureActive()
            if (ticket != authority()) throw Failure("AUTH_CHANGED")
            progress("正在使用已授权的 ChatGPT 模型分类…\n只生成建议，尚未修改账单。")
            val response = infer(HistoryCategoryTool.PROMPT, data)
            currentCoroutineContext().ensureActive()
            if (ticket != authority()) throw Failure("AUTH_CHANGED")
            val fresh = read(id)
            if (!sameBill(input, fresh)) throw Failure("STALE")
            val suggestion = HistoryCategoryTool.parse(response, fresh.categories) ?: throw Failure("NO_RESULT")
            return Preview(input, response, suggestion, ticket)
        } finally { mutex.unlock() }
    }

    suspend fun restore(source: String, id: Long, revision: Long, original: String,
        suggestion: HistoryCategoryTool.Suggestion): Preview {
        val permission = authority()
        val input = read(id)
        if (input.source != source || input.bill.categoryRevision != revision || input.bill.hash() != original) throw Failure("STALE")
        val response = com.google.gson.Gson().toJson(mapOf("existing" to suggestion.existing.orEmpty(), "proposed" to suggestion.proposed.orEmpty()))
        val parsed = HistoryCategoryTool.parse(response, input.categories) ?: throw Failure("STALE")
        if ((parsed.existing ?: parsed.proposed) != (suggestion.existing ?: suggestion.proposed)) throw Failure("STALE")
        if (permission != authority()) throw Failure("AUTH_CHANGED")
        return Preview(input, response, suggestion, permission)
    }

    suspend fun apply(preview: Preview, beforeWrite: () -> Unit = {}): Boolean {
        if (preview.readOnly) throw Failure("READ_ONLY")
        if (preview.authority != authority()) throw Failure("AUTH_CHANGED")
        if (!sameBill(preview.input, read(preview.input.bill.id))) throw Failure("STALE")
        currentCoroutineContext().ensureActive()
        if (preview.authority != authority()) throw Failure("AUTH_CHANGED")
        beforeWrite()
        val bill = preview.input.bill
        return write(ManualCategoryApply(preview.input.source, bill.id, bill.categoryRevision,
            bill.hash(), preview.response, preview.suggestion.existing ?: preview.suggestion.proposed.orEmpty(),
            preview.suggestion.proposed != null))
    }

    private fun sameBill(old: OwnerQueueInput, current: OwnerQueueInput) = old.source == current.source &&
        old.bill.categoryRevision == current.bill.categoryRevision && old.bill.hash() == current.bill.hash()
}
