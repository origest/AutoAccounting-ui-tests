package net.ankio.auto.classification

import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import kotlinx.coroutines.*
import net.ankio.chatgpt.ChatGptAccounts
import net.ankio.auto.utils.PrefManager
import net.ankio.auto.ui.api.BaseActivity
import net.ankio.auto.ui.utils.SettingsPage
import org.ezbook.server.server.OwnerQueueInput

class OwnerCategoryActivity : BaseActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var busy = false
    private lateinit var status: TextView
    private lateinit var limit: EditText
    private lateinit var days: EditText
    private lateinit var count: EditText
    private lateinit var automaticToggle: MaterialSwitch
    private lateinit var automaticStatus: TextView
    private val prefs by lazy { OwnerCategoryQueue.prefs(this) }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val page = SettingsPage(this, "自动分类与补识别")
        fun text(value: String) = page.text(value)
        fun field(label: String, value: String) = page.number(label, value)
        fun button(value: String, action: () -> Unit) { page.button(value) { if (!busy) action() } }
        page.section("处理规则与授权")
        text("需先在 ChatGPT 账号页授权、选模型并确认账单发送。凭据只留在主应用。现有本机记账接口尚未加固，其他本机应用及 root/Xposed 宿主可能伪造数据；队列与上限不能证明支付真实。仅在接受此风险时授权自动处理。")
        text("所有模式规则优先：仅规则结果为“其他／其它”时使用 AI 分类。只处理待编辑主账单，保留手动及已完成 AI 分类；已编辑/已同步账单不补识别。新类别仍需逐笔确认。历史“其他”可能是以前的手选结果，请先审查范围。")
        button("查看 ChatGPT 账号与发送授权") {
            startActivity(android.content.Intent(this, net.ankio.auto.ui.activity.ChatGptCategoryActivity::class.java))
        }
        page.section("范围与额度", "失败请求也计入尝试次数。历史范围只用于手动补识别，不扩大自动任务的授权范围。")
        limit = field("每小时上限", prefs.getInt("limit", 10).toString())
        text("历史范围：1–3650 天；每批 1–500 笔")
        days = field("天数", "30"); count = field("每批笔数", "100")
        status = text("离线未发送任务保留；发送后超时/取消记为结果未知，不自动重发。后台调度可能延迟约 15 分钟或更久。")
        page.section("自动处理新账单", "从确认时刻之后的新账单开始，不追溯发送历史账单。")
        automaticToggle = page.toggle("自动分类新账单") { enabled ->
            if (enabled) confirmAutomatic() else pauseQueue()
        }
        automaticStatus = text("未开启：不会自动发送新账单。")
        page.section("手动补识别", "先读取本机范围并预览数量；再次确认后才加入队列。结果未知的请求不会重发。")
        button("预览历史未识别账单") {
            val span = days.text.toString().toIntOrNull()?.takeIf { it in 1..3650 } ?: return@button showError("天数需为 1–3650")
            val max = count.text.toString().toIntOrNull()?.takeIf { it in 1..500 } ?: return@button showError("每批需为 1–500 笔")
            val cap = limit.text.toString().toIntOrNull()?.takeIf { it in 1..60 } ?: return@button showError("每小时上限需为 1–60")
            launchTask {
                val consent = consentStamp()
                val serverScope = OwnerCategoryQueue.scopeIdentity()
                val end = System.currentTimeMillis(); val start = end - span * 86400000L
                val preview = withContext(Dispatchers.IO) { preview(start, end, max) }
                if (preview.isEmpty()) { status.text = "范围内没有可补识别的账单；结果未知、已处理、手动及已同步账单均排除。"; return@launchTask }
                MaterialAlertDialogBuilder(this@OwnerCategoryActivity).setTitle("确认补识别 ${preview.size} 笔")
                    .setMessage("范围：最近 $span 天，最多 $max 笔待编辑账单，每小时最多 $cap 次。只发送本次预览的快照；账单被编辑后跳过。历史分类来源未知，请确认愿意重新分类。新类别仍需确认。\n\n" + preview.take(10).joinToString("\n") { "#${it.bill.id} ${it.bill.shopName.take(30)} · ${it.bill.cateName.take(20)}" } + if (preview.size > 10) "\n其余 ${preview.size - 10} 笔在同一范围内" else "")
                    .setNegativeButton("取消", null).setPositiveButton("确认发送这些账单") { _, _ -> launchTask {
                        check(consent == consentStamp())
                        val source = preview.map { it.source }.distinct().single()
                        OwnerCategoryQueue.authorizeServer(this@OwnerCategoryActivity, source, serverScope)
                        val approvedGeneration = requireNotNull(OwnerCategoryQueue.generation(source))
                        val approvedEpoch = synchronized(OwnerCategoryQueue) {
                            check(consent == consentStamp())
                            activate(cap)
                            OwnerCategoryQueue.epoch(this@OwnerCategoryActivity)
                        }
                        val added = withContext(Dispatchers.IO) {
                            OwnerQueueStore(this@OwnerCategoryActivity).use { store ->
                                preview.count { input ->
                                    synchronized(OwnerCategoryQueue) {
                                        check(OwnerCategoryQueue.enabled(this@OwnerCategoryActivity) &&
                                            approvedEpoch == OwnerCategoryQueue.epoch(this@OwnerCategoryActivity) && consent == consentStamp())
                                        store.enqueue(input, true, approvedEpoch, approvedGeneration).also { added ->
                                            if (added) OwnerCategoryReview.enqueue(this@OwnerCategoryActivity, input)
                                        }
                                    }
                                }
                            }
                        }
                        OwnerCategoryQueue.schedule(this@OwnerCategoryActivity); status.text = "已加入 $added 笔。队列最多容纳 500 笔待处理任务；其余账单可在完成后再次预览。"
                    } }.show()
            }
        }
        page.section("任务控制")
        page.button("暂停并取消剩余任务") { pauseQueue() }
        button("刷新队列状态／继续处理尚未发送任务") { launchTask {
            OwnerCategoryQueue.reconcileControl()
            status.text = withContext(Dispatchers.IO) { OwnerQueueStore(this@OwnerCategoryActivity).use { it.summary() } }.ifEmpty { "队列为空" }.replace("UNKNOWN", "结果未知（不自动重试）").replace("DISPATCHED", "已发出")
                .replace("SUCCEEDED", "已完成").replace("CANCELLED", "已取消").replace("STALE", "账单已变化")
                .replace("READY", "等待处理").replace("NO_RESULT", "没有有效结果").replace("RESULT", "等待写回")
            OwnerCategoryQueue.warning()?.let { status.append("\n" + it) }
            if (OwnerCategoryQueue.revoked()) status.append("\n服务端已确认撤销后续写回；此前已提交的写回不撤销。需重新确认授权才能处理。")
            OwnerCategoryQueue.schedule(this@OwnerCategoryActivity)
        } }
        OwnerCategoryQueue.initialize(this)
        OwnerCategoryQueue.warning()?.let { status.append("\n" + it) }
        updateAutomaticState()
    }
    private fun confirmAutomatic() {
        if (busy) return
        val cap = limit.text.toString().toIntOrNull()?.takeIf { it in 1..60 } ?: return showError("每小时上限需为 1–60")
        launchTask {
            val consent = consentStamp()
            val serverScope = OwnerCategoryQueue.scopeIdentity()
            val source = withContext(Dispatchers.IO) { OwnerCategoryQueue.page() }
            MaterialAlertDialogBuilder(this@OwnerCategoryActivity).setTitle("允许该来源自动使用额度？")
                .setMessage("从目前最大账单 ID ${source.upper} 之后的新待编辑账单开始。每小时最多 $cap 次尝试。向当前 ChatGPT 账号发送商户、商品、类型、可用类别及最多20条相关历史。来源真实性无法验证；可以随时暂停。")
                .setNegativeButton("取消", null).setPositiveButton("接受风险并开启") { _, _ -> launchTask {
                    check(consent == consentStamp())
                    OwnerCategoryQueue.authorizeServer(this@OwnerCategoryActivity, source.source, serverScope)
                    synchronized(OwnerCategoryQueue) {
                        check(consent == consentStamp())
                        activate(cap, source.source, source.upper)
                    }
                    OwnerCategoryQueue.schedule(this@OwnerCategoryActivity)
                    status.text = "自动分类已开启；仅处理此后新增账单。"
                } }.show()
        }
    }
    private fun pauseQueue() {
        try {
            val stopped = OwnerCategoryQueue.stop(this)
            if (stopped.localComplete) {
                status.text = OwnerCategoryQueue.warning() ?: "本机已暂停；服务端已确认撤销后续写回。此前已提交的写回不撤销；已发出请求仍可能消耗额度，不会重发。"
            } else showError(OwnerQueuePermissions.FAILURE_MESSAGE)
        } catch (_: Exception) { showError(OwnerCategoryQueue.warning() ?: OwnerQueuePermissions.FAILURE_MESSAGE) }
        finally { updateAutomaticState() }
    }
    private fun updateAutomaticState() {
        val enabled = runCatching { OwnerCategoryQueue.enabled(this) && prefs.getBoolean("automatic", false) }.getOrDefault(false)
        automaticToggle.isChecked = enabled
        val sending = runCatching {
            val view = ChatGptAccounts.get(this).view()
            view.accounts.any { it.key == view.active && it.signedIn && it.enabled } &&
                PrefManager.aiCategoryChatGpt && PrefManager.featureAiAvailable &&
                PrefManager.aiCategoryRecognition && PrefManager.aiCategoryHistory
        }.getOrDefault(false)
        automaticToggle.isEnabled = enabled || (!busy && sending)
        automaticStatus.text = OwnerCategoryQueue.warning() ?: when {
            enabled -> "已开启：只处理授权来源的新增账单，每小时最多 ${prefs.getInt("limit", 10)} 次。关闭会暂停全部分类任务并关闭账单发送许可。"
            !sending -> "未开启：请先在 ChatGPT 账号页开启账单发送许可，再确认自动处理范围。"
            else -> "未开启：不会自动发送新账单。历史补识别是单独确认的批次，不会开启此开关。"
        }
    }
    // Reject a dialog opened under a different account/model/mode or before cancellation.
    private fun consentStamp(): List<Any?> {
        val view = ChatGptAccounts.get(this).view()
        val account = view.accounts.firstOrNull { it.key == view.active }
        return listOf(OwnerCategoryQueue.stamp(), PrefManager.workMode, view.active, account?.model, account?.enabled)
    }
    private fun activate(cap: Int, source: String? = null, upper: Long = 0) {
        val accounts = ChatGptAccounts.get(this).view()
        check(accounts.accounts.any { it.key == accounts.active && it.enabled })
        check(PrefManager.aiCategoryChatGpt && PrefManager.featureAiAvailable &&
            PrefManager.aiCategoryRecognition && PrefManager.aiCategoryHistory)
        OwnerCategoryQueue.activate(this, cap, source, upper)
    }
    private suspend fun preview(start: Long, end: Long, max: Int): List<OwnerQueueInput> {
        val result = mutableListOf<OwnerQueueInput>()
        var after = 0L; var upper: Long? = null; var source: String? = null
        OwnerQueueStore(this).use { store ->
            repeat(100) { // bounded scan; return a clear, finite batch rather than unbounded resource use
                val page = OwnerCategoryQueue.page(after, upper, start, end)
                if (source == null) { source = page.source; upper = page.upper }
                check(source == page.source)
                if (page.bills.isEmpty()) return result
                for (bill in page.bills) {
                    check(bill.id > after); after = bill.id
                    val input = OwnerCategoryQueue.input(bill.id)
                    check(input.source == source)
                    if (OwnerCategoryQueue.eligible(input, true) && !store.contains(input)) result.add(input)
                    if (result.size == max) return result
                }
            }
        }
        return result
    }
    private fun showError(message: String) { status.text = message; Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun launchTask(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        updateAutomaticState()
        scope.launch {
            try { block() } catch (e: Exception) { if (e is CancellationException) throw e; showError(OwnerCategoryQueue.warning() ?: "操作未完成，请检查本机记账服务及 ChatGPT 分类授权。请刷新队列查看已加入的任务。") }
            finally { busy = false; updateAutomaticState() }
        }
    }
    override fun onResume() { super.onResume(); updateAutomaticState() }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
