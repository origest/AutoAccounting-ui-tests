package net.ankio.auto.classification

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import net.ankio.auto.ai.review.*
import java.lang.ref.WeakReference

/** Foreground-only prompts. Background results remain in the durable pending-review page. */
internal object OwnerCategoryPrompts : Application.ActivityLifecycleCallbacks {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var application: Application? = null
    private var resumed = WeakReference<FragmentActivity>(null)
    private var visit = 0L
    private var promptedThisVisit = false
    private val shownThisProcess = mutableSetOf<String>()
    private val automaticAssetResults = mutableSetOf<String>()
    private var pendingAfter: AiReviewCursor? = null
    private var scanJob: Job? = null
    private val queryLock = Mutex()

    fun install(app: Application) {
        if (application != null) return
        application = app
        app.registerActivityLifecycleCallbacks(this)
    }

    fun offer(recordId: String? = null) { scope.launch { resumed.get()?.let { requestScan(it, visit, recordId) } } }
    fun offerAsset(recordId: String) { scope.launch {
        automaticAssetResults.add(recordId)
        resumed.get()?.let { requestScan(it, visit, recordId) }
    } }

    private fun requestScan(host: FragmentActivity, ticket: Long, preferred: String? = null) {
        scanJob?.cancel()
        scanJob = scope.launch { scan(host, ticket, preferred) }
    }

    private suspend fun scan(host: FragmentActivity, ticket: Long, preferred: String? = null) {
        val app = application ?: return
        if (promptedThisVisit || host is AiReviewActivity || host.isFinishing || host.isDestroyed) return
        val prefs = app.getSharedPreferences("owner-category-prompts", Context.MODE_PRIVATE)
        val assets = automaticAssetResults.toSet()
        val anchor = pendingAfter
        val selection = queryLock.withLock { withContext(Dispatchers.IO) {
            runCatching { AiReviewStore(app).use { store ->
                val policy = AiReviewPolicy(app)
                fun eligible(row: AiReviewRecord) =
                    (row.kind == AiReviewKind.OWNER_CATEGORY || (row.kind == AiReviewKind.ASSET && row.id in assets)) &&
                        row.state == AiReviewState.REVIEW && !policy.canAutoApply(row) && !prefs.getBoolean(row.id, false)
                val offered = preferred?.let(store::get)?.takeIf(::eligible)
                if (offered != null) offered to anchor
                else {
                    val page = store.page(AiReviewTab.PENDING, anchor)
                    val record = page.records.firstOrNull(::eligible)
                    // Progress past already-shown candidates across visits; never let the first 100 block later tasks.
                    record to (record?.let { AiReviewCursor(it.createdAt, it.id) } ?: page.next)
                }
            } }.getOrNull()
        } } ?: return
        if (ticket != visit || resumed.get() !== host) return
        val record = selection.first
        if (record == null) { pendingAfter = selection.second; return }
        if (ticket != visit || resumed.get() !== host || promptedThisVisit || host.isFinishing ||
            host.isDestroyed || !host.window.decorView.hasWindowFocus() || host.supportFragmentManager.isStateSaved || record.id in shownThisProcess) return
        // Commit a candidate cursor only after it can actually be presented in this visit.
        pendingAfter = selection.second
        // At most one unsolicited prompt per foreground visit. Dismissal is not rejection or deletion.
        promptedThisVisit = true
        shownThisProcess.add(record.id)
        prefs.edit().putBoolean(record.id, true).apply()
        if (record.kind == AiReviewKind.OWNER_CATEGORY) OwnerCategoryReview.show(host, record)
        else AiReviewRegistry.open(host, record)
    }

    override fun onActivityResumed(activity: Activity) {
        if (activity !is FragmentActivity) return
        resumed = WeakReference(activity); visit++; promptedThisVisit = false
        val ticket = visit
        requestScan(activity, ticket)
    }
    override fun onActivityPaused(activity: Activity) {
        if (resumed.get() === activity) { resumed.clear(); visit++; scanJob?.cancel(); scanJob = null }
    }
    override fun onActivityDestroyed(activity: Activity) {
        if (resumed.get() === activity) { resumed.clear(); visit++; scanJob?.cancel(); scanJob = null }
    }
    override fun onActivityCreated(activity: Activity, state: Bundle?) = Unit
    override fun onActivityStarted(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, state: Bundle) = Unit
}
