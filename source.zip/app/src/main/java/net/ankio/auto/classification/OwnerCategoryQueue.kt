package net.ankio.auto.classification

import android.content.Context
import androidx.work.*
import com.google.gson.Gson
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.http.LocalNetwork
import net.ankio.auto.utils.PrefManager
import net.ankio.chatgpt.ChatGptAccounts
import org.ezbook.server.ai.tools.CategoryTool
import org.ezbook.server.ai.tools.HistoryCategoryTool
import org.ezbook.server.constant.BillState
import org.ezbook.server.server.*
import java.util.concurrent.TimeUnit

internal object OwnerCategoryQueue {
    val mutex = Mutex()
    fun prefs(context: Context) = context.getSharedPreferences("owner-category-queue", Context.MODE_PRIVATE)
    fun epoch(context: Context) = prefs(context).getLong("epoch", 0)
    private val permissions by lazy { OwnerQueuePermissions(prefs(net.ankio.auto.autoApp)) }
    private val controlScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val authorization by lazy {
        OwnerQueueAuthorization(OwnerQueueAuthorizationPreferences(prefs(net.ankio.auto.autoApp)), object : OwnerQueueAuthorization.Transport {
            override suspend fun read(): OwnerQueueAuthorization.Remote = OwnerQueueHttp.get<OwnerQueueAuthorization.Remote>("ownerQueue/authorization")
                .let { check(it.code == 200); requireNotNull(it.data) }
            override suspend fun change(change: OwnerQueueAuthorization.Change): OwnerQueueAuthorization.Reply =
                OwnerQueueHttp.post<OwnerQueueAuthorization.Reply>("ownerQueue/authorization", Gson().toJson(change))
                    .let { check(it.code == 200); requireNotNull(it.data) }
        })
    }
    private const val REVOKE_PENDING = "本机已暂停；服务端写回撤销尚未确认。请恢复原记账来源并刷新重试，确认前不能重新授权。"
    fun warning(): String? = permissions.warning ?: when {
        authorization.corrupted -> "授权记录损坏；本次运行已阻止队列。无法确认原来源的服务端撤销，请勿清除记录或重新授权。"
        authorization.storageFailed -> OwnerQueuePermissions.FAILURE_MESSAGE
        authorization.snapshot().pending != null -> REVOKE_PENDING
        else -> null
    }
    fun scopeIdentity(): String {
        val view = ChatGptAccounts.get(net.ankio.auto.autoApp).view()
        val account = view.accounts.firstOrNull { it.key == view.active && it.enabled }
        return Gson().toJson(listOf(PrefManager.workMode.name, view.active, account?.model, account?.enabled))
    }
    fun authorizationSource(): String = authorization.snapshot().source
    fun generation(source: String): Long? = authorization.generation(source, scopeIdentity())
    suspend fun authorizeServer(context: Context, source: String, expectedScope: String) {
        val expectedStamp = synchronized(this) {
            check(expectedScope == scopeIdentity())
            check(authorization.beginGrant(source, expectedScope)) { warning() ?: "请先暂停并确认旧授权已撤销。" }
            stamp()
        }
        val acknowledged = authorization.reconcile()
        synchronized(this) {
            val current = permissions.completeGrantIfCurrent(expectedStamp) {
                if (!acknowledged || expectedScope != scopeIdentity() || generation(source) == null) {
                    stop(context)
                    error(warning() ?: "授权未确认。")
                }
            }
            check(current) { "旧授权操作已取消；请使用最新确认。" }
        }
    }
    private fun reconcileLater() { controlScope.launch { authorization.reconcile() } }
    suspend fun reconcileControl(): Boolean = authorization.reconcile()
    fun revoked(): Boolean = authorization.snapshot().let { !authorization.storageFailed &&
        it.revision != null && !it.enabled && it.pending == null }
    /** Legacy authorization is never inherited. Cancel payloads, retain attempt ledger, then revoke. */
    @Synchronized fun initialize(context: Context) {
        if (authorization.snapshot().revision == null && authorization.snapshot().pending == null) stop(context)
        else if (authorization.snapshot().pending != null) reconcileLater()
        else if (authorization.snapshot().enabled &&
            (!prefs(context).getBoolean("enabled", false) || generation(authorization.snapshot().source) == null)) stop(context)
    }
    fun stamp(): OwnerQueuePermissions.Stamp = permissions.stamp()
    fun enabled(context: Context): Boolean = !permissions.blocked && !authorization.storageFailed && authorization.snapshot().pending == null &&
        authorization.snapshot().enabled && generation(authorization.snapshot().source) != null && prefs(context).getBoolean("enabled", false) &&
        PrefManager.aiCategoryChatGpt && PrefManager.featureAiAvailable && PrefManager.aiCategoryRecognition && PrefManager.aiCategoryHistory
    private fun reportFailure(context: Context) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(context.applicationContext, OwnerQueuePermissions.FAILURE_MESSAGE, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    @Synchronized
    fun stop(context: Context): OwnerQueuePermissions.StopResult {
        val durableIntent = try {
            val known = authorization.snapshot().pending?.source ?: authorization.snapshot().source
            val hint = if (known.isNotEmpty()) known else prefs(context).getString("source", "").orEmpty()
            authorization.stop(hint)
        } catch (_: Exception) {
            authorization.blockUnrecoverable()
            false // Still execute every local cancellation boundary below.
        }
        val local = permissions.stop(
            { OwnerQueueStore(context).use { it.cancel() }; OwnerCategoryReview.cancelPending(context) },
            { ChatGptAccounts.pauseIfInitialized() },
            { WorkManager.getInstance(context).cancelAllWorkByTag("owner-category") }
        )
        val result = local.copy(settings = local.settings && durableIntent, server = durableIntent && authorization.snapshot().pending == null)
        if (!result.localComplete || !durableIntent) reportFailure(context)
        reconcileLater()
        return result
    }
    @Synchronized
    fun activate(context: Context, cap: Int, source: String? = null, upper: Long = 0) {
        try {
            check(generation(authorization.snapshot().source) != null)
            permissions.activate(cap, source, upper)
        }
        catch (e: Exception) { stop(context); if (permissions.blocked) reportFailure(context); throw e }
    }
    @Synchronized
    fun saveCursor(context: Context, expected: OwnerQueuePermissions.Stamp, after: Long): Boolean {
        try { return permissions.saveCursor(expected, after) }
        catch (e: Exception) { if (permissions.blocked) reportFailure(context); throw e }
    }
    /** An error must match both the stop epoch and the latest explicit automatic grant. */
    @Synchronized
    fun disableAutomaticIfCurrent(context: Context, expected: OwnerQueuePermissions.Stamp): OwnerQueuePermissions.DisableResult {
        val result = permissions.disableAutomaticIfCurrent(expected)
        if (result == OwnerQueuePermissions.DisableResult.STORAGE_FAILURE) reportFailure(context)
        return result
    }
    fun schedule(context: Context) {
        initialize(context)
        if (!enabled(context)) return
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("owner-category-periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<OwnerCategoryWorker>(15, TimeUnit.MINUTES).setConstraints(constraints).addTag("owner-category").build())
        WorkManager.getInstance(context).enqueueUniqueWork("owner-category-now", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<OwnerCategoryWorker>().setConstraints(constraints).addTag("owner-category").build())
    }
    suspend fun page(after: Long = 0, upper: Long? = null, start: Long = Long.MIN_VALUE, end: Long = Long.MAX_VALUE): OwnerQueuePage =
        OwnerQueueHttp.get<OwnerQueuePage>("ownerQueue/page?after=$after&start=$start&end=$end" + (upper?.let { "&upper=$it" } ?: ""))
            .let { check(it.code == 200); requireNotNull(it.data) }
    suspend fun input(id: Long): OwnerQueueInput = OwnerQueueHttp.get<OwnerQueueInput>("ownerQueue/input?id=$id")
        .let { check(it.code == 200); requireNotNull(it.data) }
    fun shouldHoldForAi(bill: org.ezbook.server.db.model.BillInfoModel): Boolean = enabled(net.ankio.auto.autoApp) &&
        bill.categoryOrigin in setOf("RULE", "UNASSIGNED") && bill.cateName.trim() in setOf("其他", "其它")
    fun eligible(input: OwnerQueueInput, legacy: Boolean): Boolean {
        val b = input.bill
        if (b.state != BillState.Wait2Edit || b.groupId != -1L || b.pendingCategory.isNotEmpty() ||
            b.categoryOrigin !in (if (legacy) setOf("RULE", "UNASSIGNED", "LEGACY_UNKNOWN") else setOf("RULE", "UNASSIGNED"))) return false
        if (input.categories.size > 500 || input.history.size > 20) return false
        val origin = if (b.categoryOrigin == "LEGACY_UNKNOWN" && legacy) ClassificationPolicy.Origin.UNASSIGNED
            else runCatching { ClassificationPolicy.Origin.valueOf(b.categoryOrigin) }.getOrDefault(ClassificationPolicy.Origin.LEGACY_UNKNOWN)
        return ClassificationPolicy.eligible(ClassificationPolicy.Snapshot(input.source, b.id, b.categoryRevision,
            if (WorkMode.isOcr()) ClassificationPolicy.Mode.OCR else ClassificationPolicy.Mode.XPOSED, origin, b.cateName))
    }
    /** Main app constructs the prompt/data, never accepts provider instructions from the host. */
    fun payload(input: OwnerQueueInput): String {
        val bill = input.bill
        val paths = HistoryCategoryTool.paths(input.categories)
        require(paths.size <= 500 && paths.all { it.length <= 200 })
        val history = input.history.filter { it.id != bill.id && it.bookName == bill.bookName && it.type == bill.type &&
            it.state != BillState.Wait2Edit && it.groupId == -1L && it.cateName in paths &&
            ((bill.shopName.isNotBlank() && it.shopName == bill.shopName) || (bill.shopItem.isNotBlank() && it.shopItem == bill.shopItem))
        }.take(20).map { mapOf("merchant" to it.shopName.take(120), "item" to it.shopItem.take(120), "category" to it.cateName) }
        return Gson().toJson(mapOf("bill" to mapOf("merchant" to bill.shopName.take(120), "item" to bill.shopItem.take(120), "type" to bill.type.name),
            "categories" to paths, "history" to history)).also { require(it.length <= 64_000) }
    }
}

class OwnerCategoryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!OwnerCategoryQueue.mutex.tryLock()) return Result.success()
        val context = applicationContext
        val prefs = OwnerCategoryQueue.prefs(context)
        try {
            val accounts = ChatGptAccounts.get(context)
            val ticket = synchronized(OwnerCategoryQueue) {
                if (!OwnerCategoryQueue.enabled(context)) return Result.success()
                val account = accounts.view().let { v -> v.accounts.firstOrNull { it.key == v.active && it.enabled } }
                    ?: return Result.success()
                Triple(OwnerCategoryQueue.stamp(), PrefManager.workMode.name, account)
            }
            val (grant, mode, account) = ticket
            val epoch = grant.epoch
            val serverSource = OwnerCategoryQueue.authorizationSource()
            val serverGeneration = OwnerCategoryQueue.generation(serverSource) ?: return Result.success()
            fun permitted(): Boolean = OwnerCategoryQueue.enabled(context) && OwnerCategoryQueue.epoch(context) == epoch &&
                OwnerCategoryQueue.generation(serverSource) == serverGeneration &&
                PrefManager.workMode.name == mode && accounts.view().let { v -> v.active == account.key && v.accounts.any { it.key == account.key && it.enabled && it.model == account.model } }
            OwnerQueueStore(context).use { store ->
                val automaticScope = synchronized(OwnerCategoryQueue) {
                    if (!permitted() || OwnerCategoryQueue.stamp() != grant) return Result.success()
                    if (prefs.getBoolean("automatic", false)) prefs.getString("source", "") to prefs.getLong("cursor", 0) else null
                }
                if (automaticScope != null) {
                    val list = OwnerCategoryQueue.page(automaticScope.second)
                    synchronized(OwnerCategoryQueue) {
                        if (!permitted() || OwnerCategoryQueue.stamp() != grant) return Result.success()
                        if (list.source != automaticScope.first) return if (OwnerCategoryQueue.stop(context).complete) Result.success()
                            else Result.failure(workDataOf("queueError" to "STOP_INCOMPLETE"))
                    }
                    for (bill in list.bills) {
                        if (!permitted()) return Result.success()
                        val input = OwnerCategoryQueue.input(bill.id)
                        val advanced = synchronized(OwnerCategoryQueue) {
                            if (!permitted() || OwnerCategoryQueue.stamp() != grant) return Result.success()
                            if (input.source != list.source) return if (OwnerCategoryQueue.stop(context).complete) Result.success()
                                else Result.failure(workDataOf("queueError" to "STOP_INCOMPLETE"))
                            if (OwnerCategoryQueue.eligible(input, false) && !store.contains(input)) {
                                if (!store.enqueue(input, false, epoch, serverGeneration)) false
                                else {
                                    OwnerCategoryReview.enqueue(context, input)
                                    OwnerCategoryQueue.saveCursor(context, grant, bill.id)
                                }
                            } else OwnerCategoryQueue.saveCursor(context, grant, bill.id)
                        }
                        if (!advanced) break
                    }
                    if (list.bills.isEmpty()) OwnerCategoryQueue.saveCursor(context, grant, list.upper)
                }
                repeat(60) {
                    if (!permitted()) return Result.success()
                    val task = store.next() ?: return Result.success()
                    if (task.epoch != epoch || task.mode != mode || task.generation != serverGeneration || task.input.source != serverSource) {
                        store.status(task.key, task.epoch, task.state, "CANCELLED")
                        OwnerCategoryReview.invalidate(context, task.input)
                        return@repeat
                    }
                    val fresh = OwnerCategoryQueue.input(task.input.bill.id)
                    if (fresh.source != task.input.source || fresh.bill.categoryRevision != task.input.bill.categoryRevision ||
                        fresh.bill.hash() != task.input.bill.hash() || !OwnerCategoryQueue.eligible(fresh, task.legacy)) {
                        store.status(task.key, task.epoch, task.state, "STALE")
                        OwnerCategoryReview.invalidate(context, task.input)
                        return@repeat
                    }
                    var response = task.response
                    var reviewClaim: net.ankio.auto.ai.review.AiReviewClaim? = null
                    if (task.state == "READY") {
                        val payload = OwnerCategoryQueue.payload(task.input)
                        if (!permitted()) return Result.success()
                        if (!store.dispatch(task.key, task.epoch, prefs.getInt("limit", 10).coerceIn(1, 60), System.currentTimeMillis())) return Result.success()
                        try {
                            reviewClaim = OwnerCategoryReview.claim(context, task)
                            check(reviewClaim != null) // No inference without a committed unified history claim.
                            response = accounts.classify(HistoryCategoryTool.PROMPT, payload)
                            if (HistoryCategoryTool.parse(response, task.input.categories) == null) {
                                OwnerCategoryReview.fail(context, reviewClaim, "NO_RESULT")
                                store.status(task.key, task.epoch, "DISPATCHED", "NO_RESULT")
                                if (permitted()) net.ankio.auto.ai.review.AssetAutomaticRunner.analyzeAutomatic(context, task.input, ::permitted)
                                return@repeat
                            }
                            if (!store.status(task.key, task.epoch, "DISPATCHED", "RESULT", response)) return@repeat
                        } catch (error: Exception) {
                            runCatching { OwnerCategoryReview.fail(context, reviewClaim, "REQUEST_FAILED") }
                            var disabled = OwnerQueuePermissions.DisableResult.STALE
                            try { store.status(task.key, task.epoch, "DISPATCHED", "UNKNOWN") }
                            finally {
                                try { disabled = OwnerCategoryQueue.disableAutomaticIfCurrent(context, grant) }
                                finally { if (error is kotlinx.coroutines.CancellationException) throw error }
                            }
                            if (disabled == OwnerQueuePermissions.DisableResult.STORAGE_FAILURE) {
                                return Result.failure(workDataOf("queueError" to "PERMISSION_STORAGE_FAILURE"))
                            }
                            return Result.success()
                        }
                    }
                    if (!permitted()) { store.status(task.key, task.epoch, "RESULT", "CANCELLED"); return Result.success() }
                    val review = OwnerCategoryReview.review(context, task.copy(state = "RESULT"), response, reviewClaim)
                        ?: return Result.success()
                    if (!store.status(task.key, task.epoch, "RESULT", "REVIEW", response)) return Result.success()
                    // Default policy only stages the result. Existing/new category automation is separately authorized.
                    OwnerCategoryReview.apply(context, review, manual = false)
                    OwnerCategoryPrompts.offer(review.id)
                    if (permitted()) net.ankio.auto.ai.review.AssetAutomaticRunner.analyzeAutomatic(context, task.input, ::permitted)
                }
            }
            return Result.success()
        } catch (error: Exception) {
            if (error is kotlinx.coroutines.CancellationException) throw error
            if (OwnerCategoryQueue.warning() != null) return Result.failure(workDataOf("queueError" to "PERMISSION_STORAGE_FAILURE"))
            return Result.success() // local read/apply failures retain READY/RESULT; no provider replay
        } finally { OwnerCategoryQueue.mutex.unlock() }
    }
}
