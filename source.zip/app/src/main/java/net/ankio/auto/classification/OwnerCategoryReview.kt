package net.ankio.auto.classification

import android.content.Context
import android.widget.Toast
import android.view.WindowManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.ankio.auto.ai.review.*
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.dialog.BillEditorDialog
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.ai.tools.HistoryCategoryTool
import org.ezbook.server.constant.BillState
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.OwnerQueueApply
import org.ezbook.server.server.OwnerQueueInput

/** Bridges automatic results to the same review policy without bypassing the server revoke fence. */
object OwnerCategoryReview {
    // A confirmed editor save must finish its bounded audit write even if its host is dismissed.
    private val historyScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private fun target(input: OwnerQueueInput) = AiReviewTarget(input.source, input.bill.id,
        input.bill.categoryRevision, input.bill.hash())

    fun enqueue(context: Context, input: OwnerQueueInput): AiReviewRecord = AiReviewStore(context).use {
        it.create(target(input), AiReviewKind.OWNER_CATEGORY)
    }

    fun cancelPending(context: Context) { AiReviewStore(context).use { it.cancelPending(AiReviewKind.OWNER_CATEGORY) } }
    internal fun invalidate(context: Context, input: OwnerQueueInput) {
        AiReviewStore(context).use { store ->
            val record = store.create(target(input), AiReviewKind.OWNER_CATEGORY)
            store.cancelPending(AiReviewKind.OWNER_CATEGORY, record.id)
        }
    }

    internal fun claim(context: Context, task: OwnerQueueStore.Task): AiReviewClaim? = AiReviewStore(context).use {
        it.claim(it.create(target(task.input), AiReviewKind.OWNER_CATEGORY).id)
    }

    internal fun fail(context: Context, claim: AiReviewClaim?, code: String) {
        if (claim != null) AiReviewStore(context).use { it.fail(claim, code) }
    }

    private fun permitted(context: Context, task: OwnerQueueStore.Task): Boolean =
        OwnerCategoryQueue.enabled(context) && OwnerCategoryQueue.epoch(context) == task.epoch &&
            PrefManager.workMode.name == task.mode && task.generation != null &&
            OwnerCategoryQueue.generation(task.input.source) == task.generation

    /** Only a durable RESULT can be recovered here. This method never invokes the provider. */
    internal fun review(context: Context, task: OwnerQueueStore.Task, response: String, claim: AiReviewClaim?): AiReviewRecord? {
        if (!permitted(context, task)) return null
        val suggestion = HistoryCategoryTool.parse(response, task.input.categories) ?: return null
        val changes = listOf(AiReviewChange("CATEGORY", task.input.bill.cateName,
            suggestion.existing ?: suggestion.proposed ?: return null, suggestion.proposed != null))
        return AiReviewStore(context).use { store ->
            val record = store.create(target(task.input), AiReviewKind.OWNER_CATEGORY)
            val ready = when (record.state) {
                AiReviewState.REVIEW -> record.changes == changes
                AiReviewState.RUNNING -> claim != null && claim.id == record.id && store.review(claim, changes)
                AiReviewState.WAITING -> store.claim(record.id)?.let { store.review(it, changes) } == true
                AiReviewState.FAILED -> task.state == "RESULT" && record.errorCode == "REQUEST_INTERRUPTED" &&
                    store.recoverReview(record.id, changes)
                else -> false
            }
            if (ready) store.get(record.id) else null
        }
    }

    fun register() {
        AiReviewRegistry.register(AiReviewKind.OWNER_CATEGORY) handler@ { host, record ->
            if (record.state != AiReviewState.REVIEW) {
                MaterialAlertDialogBuilder(host).setMessage("该自动任务不会重复发送。等待任务由原队列处理；已失败任务请先核对原账单与发送状态。")
                    .setPositiveButton("知道了", null).show()
                return@handler
            }
            show(host, record)
        }
        OwnerCategoryPrompts.install(net.ankio.auto.autoApp)
    }

    internal fun show(host: FragmentActivity, record: AiReviewRecord) {
            val change = record.changes.singleOrNull() ?: return
            val dialog = MaterialAlertDialogBuilder(host).setTitle(if (change.createsNew) "确认创建并应用类别" else "确认应用分类建议")
                .setMessage("原类别：${change.before.ifEmpty { "未分类" }}\n建议：${change.after}" +
                    if (change.createsNew) "\n将创建本地类别；外部记账应用可能仍需同步。原始来源、账单版本和授权将在写回前重新核验。" else
                    "\n只修改这笔账单的分类。原始来源、账单版本和授权将在写回前重新核验。")
                .setNegativeButton("暂不处理") { _, _ -> AiReviewEvents.defer(host, record.id) }
                .setNeutralButton("手动修改") { _, _ -> editManually(host, record) }
                .setPositiveButton("确认应用") { _, _ -> host.lifecycleScope.launch {
                    val outcome = apply(host.applicationContext, record, manual = true)
                    Toast.makeText(host, outcome, Toast.LENGTH_LONG).show()
                } }.create()
            dialog.setOnCancelListener { AiReviewEvents.defer(host, record.id) }
            dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            dialog.show()
            AiReviewUiFixture.dialogShown(dialog)
    }

    private fun editManually(host: FragmentActivity, record: AiReviewRecord) {
        host.lifecycleScope.launch {
            try {
                val original = withContext(Dispatchers.IO) {
                    check(record.kind == AiReviewKind.OWNER_CATEGORY && record.state == AiReviewState.REVIEW)
                    AiReviewStore(host).use { check(it.get(record.id) == record) }
                    OwnerQueueStore(host).use { queue ->
                        val task = requireNotNull(queue.find(record.target.source + ":" + record.target.billId))
                        check(task.state == "REVIEW" && target(task.input) == record.target && permitted(host, task))
                        val current = OwnerCategoryQueue.input(record.target.billId)
                        check(target(current) == record.target && permitted(host, task))
                        current.bill.copy()
                    }
                }
                currentCoroutineContext().ensureActive()
                if (host.isFinishing || host.isDestroyed || host.supportFragmentManager.isStateSaved ||
                    !host.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) || !host.window.decorView.hasWindowFocus()) return@launch
                // Open the original bill, never pre-apply the AI suggestion or route through CATEGORY.
                val editor = BaseSheetDialog.create<BillEditorDialog>(host).setBillInfo(original.copy())
                    .bindSaveToSnapshot(record.target.source, original)
                    .setOnConfirm { saved ->
                        val snapshot = saved.copy()
                        historyScope.launch {
                            val recorded = runCatching {
                                recordManualEdit(host.applicationContext, record, original, snapshot)
                            }.getOrDefault(false)
                            withContext(Dispatchers.Main) {
                                if (!host.isFinishing && !host.isDestroyed) Toast.makeText(host,
                                    if (recorded) "手动修改已保存并记入历史。"
                                    else "账单已完成保存回调，但任务历史与清理尚未完整核实；请刷新账单与任务记录，不会自动应用旧建议。",
                                    Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                // Cancel/back/outside-dismiss leaves REVIEW untouched; no apply token was acquired.
                editor.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                editor.show()
            } catch (error: CancellationException) { throw error }
            catch (_: Exception) {
                Toast.makeText(host, "来源、账单或授权已改变，未打开旧快照。请刷新后重新处理。", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun recordManualEdit(context: Context, record: AiReviewRecord, original: BillInfoModel,
        expected: BillInfoModel): Boolean = withContext(Dispatchers.IO) {
        if (expected.id != original.id || original.id != record.target.billId ||
            original.categoryRevision != record.target.revision || original.hash() != record.target.fingerprint) return@withContext false
        val current = OwnerCategoryQueue.input(record.target.billId)
        val saved = current.bill
        if (current.source != record.target.source || !ManualEditEvidence.matches(saved, expected, record.target)) return@withContext false
        val changes = listOf(AiReviewChange("CATEGORY", original.cateName, saved.cateName))
        if (!AiReviewSafety.changes(AiReviewKind.OWNER_CATEGORY, changes)) return@withContext false
        currentCoroutineContext().ensureActive()
        // Only local bookkeeping follows. Never replay an editor save or invoke an AI apply route.
        withContext(NonCancellable + Dispatchers.IO) {
            AiReviewStore(context).use { reviews ->
                val token = reviews.beginApply(record.id, record.changes) ?: return@use false
                var finished = false
                try {
                    check(reviews.finishApply(record.id, token, AiReviewState.MANUAL, changes))
                    finished = true
                    OwnerQueueStore(context).use { queue ->
                        val task = queue.find(record.target.source + ":" + record.target.billId)
                        // A concurrent pause may already have scrubbed the owner payload.
                        task == null || (task.state == "REVIEW" && target(task.input) == record.target &&
                            queue.status(task.key, task.epoch, "REVIEW", "SUCCEEDED"))
                    }
                } catch (error: Exception) {
                    if (!finished) runCatching { reviews.finishApply(record.id, token, AiReviewState.FAILED) }
                    throw error
                }
            }
        }
    }

    /** No provider retry. Failed/uncertain apply consumes its token and remains in history. */
    suspend fun apply(context: Context, record: AiReviewRecord, manual: Boolean): String = withContext(Dispatchers.IO) {
        if (record.kind != AiReviewKind.OWNER_CATEGORY || record.state != AiReviewState.REVIEW) return@withContext "任务状态已改变，请刷新。"
        AiReviewStore(context).use { reviews ->
            val current = reviews.get(record.id) ?: return@withContext "任务不存在。"
            if (current != record) return@withContext "建议已改变，请刷新后重新确认。"
            val policy = AiReviewPolicy(context)
            if (!manual && !policy.canAutoApply(current)) return@withContext "结果已进入待确认。"
            val token = reviews.beginApply(record.id, current.changes) ?: return@withContext "任务正在处理或已经完成。"
            var dispatched = false
            try {
                currentCoroutineContext().ensureActive()
                OwnerQueueStore(context).use { queue ->
                    val task = queue.find(record.target.source + ":" + record.target.billId)
                    if (task == null || task.state != "REVIEW" || target(task.input) != record.target || !permitted(context, task)) {
                        reviews.finishApply(record.id, token, AiReviewState.STALE)
                        return@withContext "来源、账单或授权已改变，未应用。"
                    }
                    val suggestion = HistoryCategoryTool.parse(task.response, task.input.categories)
                    val change = current.changes.singleOrNull()
                    if (suggestion == null || change == null || change.field != "CATEGORY" ||
                        change.before != task.input.bill.cateName || change.after != (suggestion.existing ?: suggestion.proposed) ||
                        change.createsNew != (suggestion.proposed != null)) {
                        reviews.finishApply(record.id, token, AiReviewState.STALE)
                        return@withContext "建议校验失败，未应用。"
                    }
                    // Do not hold the owner lock across HTTP: pause must stay immediately available.
                    if (!permitted(context, task)) {
                        reviews.finishApply(record.id, token, AiReviewState.STALE)
                        return@withContext "授权已改变，未应用。"
                    }
                    if (!manual && !policy.canAutoApply(current)) {
                        reviews.returnToReview(record.id, token)
                        return@withContext "自动处理已关闭，结果保留待确认。"
                    }
                    val request = OwnerQueueApply(task.input.source, task.input.bill.id, task.input.bill.categoryRevision,
                        task.input.bill.hash(), task.response, task.legacy, task.generation,
                        confirmedCategory = change.after, allowCreate = change.createsNew, manual = manual)
                    currentCoroutineContext().ensureActive()
                    dispatched = true
                    val result = OwnerQueueHttp.post<Boolean>("ownerQueue/apply", Gson().toJson(request))
                    check(result.code == 200)
                    val applied = result.data == true
                    queue.status(task.key, task.epoch, "REVIEW", if (applied) "SUCCEEDED" else "STALE")
                    check(reviews.finishApply(record.id, token, if (applied) AiReviewState.APPLIED else AiReviewState.STALE))
                    if (applied) "分类已应用，操作已记录到历史。" else "账单或来源已改变，未应用。"
                }
            } catch (error: Exception) {
                // An interrupted or lost HTTP response cannot prove that the server did not commit.
                runCatching { if (dispatched) reviews.finishApply(record.id, token, AiReviewState.FAILED)
                    else reviews.returnToReview(record.id, token) }
                if (error is CancellationException) throw error
                if (dispatched) "写回结果未确认，不会自动重试；请检查账单与历史。" else "本次未发送写回，请刷新待确认后重试。"
            }
        }
    }
}
