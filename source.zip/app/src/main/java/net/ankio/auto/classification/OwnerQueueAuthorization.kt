package net.ankio.auto.classification

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/** Durable server fence. Network never holds the monitor used by stop().
 * The transport is independent of the provider's operation lock and request executor.
 */
internal class OwnerQueueAuthorization(private val disk: Persistence, private val transport: Transport) {
    data class Remote(val source: String, val revision: Long, val enabled: Boolean, val operationId: String?)
    data class Change(val source: String, val expectedRevision: Long, val enabled: Boolean, val operationId: String)
    data class Reply(val accepted: Boolean, val state: Remote)
    data class Pending(val source: String, val enabled: Boolean, val operationId: String,
        val expectedRevision: Long? = null, val scope: String = "")
    data class Record(val source: String = "", val revision: Long? = null, val scope: String = "",
        val enabled: Boolean = false, val pending: Pending? = null)
    interface Persistence { fun read(): Record?; fun write(record: Record): Boolean }
    interface Transport { suspend fun read(): Remote; suspend fun change(change: Change): Reply }
    private val control = Mutex()
    private var record: Record
    @Volatile var corrupted = false
        private set
    @Volatile var storageFailed = false
        private set
    init {
        record = try { (disk.read() ?: Record()).also { require(valid(it)) } }
        catch (_: Exception) { corrupted = true; storageFailed = true; Record() }
        // An interrupted grant is not renewed consent on process restart.
        if (record.pending?.enabled == true) stop(record.pending!!.source)
    }
    private fun valid(value: Record): Boolean = try {
        value.source.length <= 256 && value.scope.length <= 4096 &&
            (value.revision == null || value.revision > 0 && value.source.isNotEmpty()) &&
            (!value.enabled || (value.revision != null && value.revision > 0 && value.source.isNotEmpty() && value.scope.isNotEmpty() && value.pending == null)) &&
            (value.pending?.let { p -> !value.enabled && p.source == value.source &&
                p.operationId.matches(Regex("[A-Za-z0-9_.:-]{1,128}")) &&
                (p.expectedRevision == null || p.expectedRevision >= 0 && p.expectedRevision < Long.MAX_VALUE && p.source.isNotEmpty()) &&
                (!p.enabled || p.source.isNotEmpty() && p.scope.isNotEmpty()) && p.scope.length <= 4096 } ?: true)
    } catch (_: Exception) { false }
    private fun validRemote(value: Remote): Boolean = try {
        value.source.isNotEmpty() && value.source.length <= 256 && value.revision >= 0 &&
            (value.operationId == null && value.revision == 0L && !value.enabled ||
                value.operationId?.matches(Regex("[A-Za-z0-9_.:-]{1,128}")) == true && value.revision > 0)
    } catch (_: Exception) { false }
    @Synchronized fun blockUnrecoverable() { corrupted = true; storageFailed = true }
    @Synchronized fun snapshot(): Record = record
    @Synchronized fun generation(source: String, scope: String): Long? =
        record.revision?.takeIf { !storageFailed && record.enabled && record.pending == null && record.source == source && record.scope == scope }
    @Synchronized private fun save(next: Record): Boolean {
        if (corrupted || !valid(next)) { storageFailed = true; return false }
        record = next // Fail closed even when disk has an uncertain outcome.
        val ok = try { disk.write(next) } catch (_: Exception) { false }
        if (!ok) storageFailed = true
        return ok
    }
    /** Called before cancellation callbacks; never waits for a provider or a network mutex. */
    @Synchronized fun stop(sourceHint: String = ""): Boolean {
        val source = record.pending?.source ?: record.source.ifEmpty { sourceHint }
        // Keep a stable pending revoke across repeated local stops and transport retries.
        val pending = record.pending?.takeIf { !it.enabled } ?: Pending(source, false, UUID.randomUUID().toString())
        return save(record.copy(source = source, enabled = false, pending = pending))
    }
    @Synchronized fun beginGrant(source: String, scope: String): Boolean {
        if (storageFailed || record.pending != null || source.isEmpty() || scope.isEmpty()) return false
        if (generation(source, scope) != null) return true // Do not invalidate unrelated manual tasks.
        // A different source/scope must be explicitly revoked first.
        if (record.enabled) return false
        return save(record.copy(source = source, enabled = false,
            pending = Pending(source, true, UUID.randomUUID().toString(), scope = scope)))
    }
    /** Read/CAS/re-read recovery. Only the exact latest operation payload can acknowledge an intent.
     * A source mismatch remains unresolved; a different host at the same port cannot revoke this host.
     */
    suspend fun reconcile(): Boolean = control.withLock {
        try {
            while (true) {
                val pending = synchronized(this) { record.pending } ?: return@withLock !storageFailed
                val remote = transport.read()
                if (!validRemote(remote) || remote.revision == Long.MAX_VALUE && pending.expectedRevision == null ||
                    (pending.source.isNotEmpty() && remote.source != pending.source)) return@withLock false
                val prepared = synchronized(this) {
                    if (record.pending != pending) null else {
                        val next = pending.copy(source = remote.source,
                            expectedRevision = pending.expectedRevision ?: remote.revision)
                        if (!save(record.copy(source = next.source, pending = next))) return@withLock false
                        next
                    }
                } ?: continue
                val expected = requireNotNull(prepared.expectedRevision)
                val exact = remote.operationId == prepared.operationId && remote.enabled == prepared.enabled &&
                    expected < Long.MAX_VALUE && remote.revision == expected + 1
                val reply = if (exact) Reply(true, remote) else transport.change(Change(prepared.source, expected, prepared.enabled, prepared.operationId))
                synchronized(this) {
                    if (record.pending != prepared) return@synchronized // A later stop owns the state now.
                    val state = reply.state
                    if (!validRemote(state) || state.source != prepared.source) return@withLock false
                    val acknowledged = reply.accepted && state.operationId == prepared.operationId &&
                        state.enabled == prepared.enabled && expected < Long.MAX_VALUE && state.revision == expected + 1
                    if (acknowledged) {
                        if (!save(Record(state.source, state.revision, prepared.scope, state.enabled))) return@withLock false
                        // Only a durable acknowledged revoke can clear a previous process-local write failure.
                        if (!state.enabled) storageFailed = false
                    } else {
                        // A grant conflict is not authority to overwrite another controller's intent.
                        // Turn it into a revoke, requiring a fresh explicit user grant afterward.
                        if (state.revision == Long.MAX_VALUE) return@withLock false
                        val retry = Pending(prepared.source, false, UUID.randomUUID().toString(), state.revision)
                        if (!save(record.copy(enabled = false, pending = retry))) return@withLock false
                        return@withLock false
                    }
                }
            }
            @Suppress("UNREACHABLE_CODE") false
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            false // Pending intent remains durable; no blind fresh grant on timeout.
        }
    }
}
