package net.ankio.auto.classification

import android.content.SharedPreferences
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject

/** Missing is a fresh/legacy installation. Present metadata must have a complete typed schema. */
internal class OwnerQueueAuthorizationPreferences(private val prefs: SharedPreferences) : OwnerQueueAuthorization.Persistence {
    private val gson = GsonBuilder().serializeNulls().create()
    private fun fields(value: JsonObject, names: Set<String>) { require(value.entrySet().map { it.key }.toSet() == names) }
    private fun string(value: JsonObject, key: String) { require(value[key].isJsonPrimitive && value[key].asJsonPrimitive.isString) }
    private fun bool(value: JsonObject, key: String) { require(value[key].isJsonPrimitive && value[key].asJsonPrimitive.isBoolean) }
    private fun revision(value: JsonObject, key: String) {
        val v = value[key]
        if (v.isJsonNull) return
        require(v.isJsonPrimitive && v.asJsonPrimitive.isNumber && v.toString().matches(Regex("0|[1-9][0-9]*")))
        require(v.asString.toLong() >= 0)
    }
    override fun read(): OwnerQueueAuthorization.Record? {
        if (!prefs.contains("serverAuthorization")) return null
        val json = requireNotNull(prefs.getString("serverAuthorization", null))
        val root = requireNotNull(gson.fromJson(json, JsonObject::class.java))
        fields(root, setOf("schema", "record"))
        require(root["schema"].toString() == "1")
        val value = root["record"].asJsonObject
        fields(value, setOf("source", "revision", "scope", "enabled", "pending"))
        string(value, "source"); string(value, "scope"); bool(value, "enabled"); revision(value, "revision")
        if (!value["pending"].isJsonNull) {
            val pending = value["pending"].asJsonObject
            fields(pending, setOf("source", "enabled", "operationId", "expectedRevision", "scope"))
            string(pending, "source"); string(pending, "operationId"); string(pending, "scope")
            bool(pending, "enabled"); revision(pending, "expectedRevision")
        }
        return requireNotNull(gson.fromJson(value, OwnerQueueAuthorization.Record::class.java))
    }
    override fun write(record: OwnerQueueAuthorization.Record): Boolean {
        val root = JsonObject().apply { addProperty("schema", 1); add("record", gson.toJsonTree(record)) }
        return prefs.edit().putString("serverAuthorization", gson.toJson(root)).commit()
    }
}
