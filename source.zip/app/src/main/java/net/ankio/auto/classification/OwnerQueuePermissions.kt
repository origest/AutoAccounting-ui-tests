package net.ankio.auto.classification

import android.content.SharedPreferences
import kotlinx.coroutines.CancellationException

/** Owner-process permission boundary. A failed commit is NOT a durable revocation.
 * No provider HTTP request or worker mutex is awaited by this boundary.
 */
internal class OwnerQueuePermissions(private val prefs: SharedPreferences) {
    data class Stamp(val epoch: Long, val automaticGrant: Long)
    enum class DisableResult { STALE, DISABLED, STORAGE_FAILURE }
    data class StopResult(val settings: Boolean, val tasks: Boolean, val provider: Boolean, val work: Boolean, val server: Boolean = true) {
        val localComplete: Boolean get() = settings && tasks && provider && work
        val complete: Boolean get() = localComplete && server
    }
    class StorageFailure : IllegalStateException(FAILURE_MESSAGE)
    companion object {
        const val FAILURE_MESSAGE = "暂停或授权未能完整保存；本次运行已阻止队列继续处理。请重试暂停，成功前不要重新授权。重启后暂停状态无法保证。已发出的请求仍可能消耗额度或写回。"
    }
    @Volatile var blocked: Boolean = false
        private set
    @Volatile var warning: String? = null
        private set

    @Synchronized fun stamp() = Stamp(prefs.getLong("epoch", 0), prefs.getLong("automaticGrant", 0))
    /** Async grant completion may only adopt or revoke the permission intent that started it. */
    @Synchronized fun completeGrantIfCurrent(expected: Stamp, completion: () -> Unit): Boolean {
        if (stamp() != expected) return false
        completion()
        return true
    }
    private fun failed() { blocked = true; warning = FAILURE_MESSAGE }
    private fun commit(editor: SharedPreferences.Editor): Boolean = try {
        editor.commit().also { if (!it) failed() }
    } catch (e: Exception) {
        failed()
        if (e is CancellationException) throw e
        false
    }
    @Synchronized fun activate(cap: Int, source: String? = null, upper: Long = 0) {
        check(!blocked) { FAILURE_MESSAGE }
        require(cap in 1..60)
        try {
            val editor = prefs.edit().putBoolean("enabled", true).putInt("limit", cap)
            if (source != null) {
                editor.putString("source", source).putLong("cursor", upper).putBoolean("automatic", true)
                    .putLong("automaticGrant", Math.addExact(stamp().automaticGrant, 1))
            }
            if (!commit(editor)) throw StorageFailure()
        } catch (e: Exception) { failed(); throw e }
    }
    @Synchronized fun saveCursor(expected: Stamp, after: Long): Boolean {
        if (blocked || stamp() != expected) return false
        if (!commit(prefs.edit().putLong("cursor", after))) throw StorageFailure()
        return true
    }
    @Synchronized fun disableAutomaticIfCurrent(expected: Stamp): DisableResult {
        if (stamp() != expected) return DisableResult.STALE
        return if (commit(prefs.edit().putBoolean("automatic", false))) DisableResult.DISABLED
            else DisableResult.STORAGE_FAILURE
    }
    /** Always try all local cancellation boundaries, including after an unacknowledged write.
     * This cannot revoke an apply request already accepted by the remote host.
     */
    @Synchronized fun stop(cancelTasks: () -> Unit, pauseProvider: () -> Unit, cancelWork: () -> Unit): StopResult {
        blocked = true // fail closed in this process before touching either storage system
        var cancelled: CancellationException? = null
        fun attempt(action: () -> Boolean): Boolean = try { action() } catch (e: Exception) {
            if (e is CancellationException) cancelled = e
            false
        }
        val settings = attempt {
            commit(prefs.edit().putBoolean("enabled", false).putBoolean("automatic", false)
                .putLong("epoch", Math.addExact(stamp().epoch, 1)))
        }
        val tasks = attempt { cancelTasks(); true }
        val provider = attempt { pauseProvider(); true }
        val work = attempt { cancelWork(); true }
        val result = StopResult(settings, tasks, provider, work)
        if (result.complete) { blocked = false; warning = null } else failed()
        cancelled?.let { throw it }
        return result
    }
}
