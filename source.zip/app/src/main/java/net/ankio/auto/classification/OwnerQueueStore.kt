package net.ankio.auto.classification

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.gson.Gson
import org.ezbook.server.server.OwnerQueueInput
import java.io.File

/** The queue and attempt budget live only in the owner's no-backup directory. */
internal class OwnerQueueStore(context: Context, name: String = "owner-category-queue.db") : SQLiteOpenHelper(
    context, File(context.noBackupFilesDir, name).path, null, 2
) {
    companion object {
        internal const val MUTATION_WHERE = "key=? AND epoch=? AND state=?"
    }
    data class Task(val key: String, val input: OwnerQueueInput, val legacy: Boolean, val epoch: Long, val state: String, val response: String, val mode: String, val generation: Long? = null)
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE task (key TEXT PRIMARY KEY, payload TEXT NOT NULL, legacy INTEGER NOT NULL, epoch INTEGER NOT NULL, state TEXT NOT NULL, response TEXT NOT NULL DEFAULT '', mode TEXT NOT NULL, generation INTEGER)")
        db.execSQL("CREATE TABLE attempt (key TEXT PRIMARY KEY, sent INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        check(oldVersion == 1 && newVersion == 2)
        db.execSQL("ALTER TABLE task ADD COLUMN generation INTEGER")
        // No old task may inherit a new server grant. Never erase or replay the attempt ledger.
        db.execSQL("UPDATE task SET state=CASE WHEN state='DISPATCHED' THEN 'UNKNOWN' ELSE 'CANCELLED' END, payload='', response='' WHERE state IN ('READY','DISPATCHED','RESULT')")
    }
    fun key(input: OwnerQueueInput) = input.source + ":" + input.bill.id
    fun contains(input: OwnerQueueInput): Boolean {
        val cursor = readableDatabase.rawQuery("SELECT 1 FROM task WHERE key=? AND NOT (state IN ('CANCELLED','STALE') AND key NOT IN (SELECT key FROM attempt))", arrayOf(key(input)))
        try { return cursor.moveToFirst() } finally { cursor.close() }
    }
    fun enqueue(input: OwnerQueueInput, legacy: Boolean, epoch: Long, generation: Long? = null): Boolean {
        val json = Gson().toJson(input)
        if (json.length > 256_000) return false
        val values = ContentValues().apply {
            put("generation", generation); put("key", key(input)); put("payload", json); put("legacy", if (legacy) 1 else 0); put("epoch", epoch); put("state", "READY"); put("mode", net.ankio.auto.utils.PrefManager.workMode.name)
        }
        val db = writableDatabase
        db.beginTransaction()
        val inserted: Boolean
        try {
            if (android.database.DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM task WHERE state IN ('READY','DISPATCHED','RESULT','REVIEW')", null) >= 500) return false
            val changed = db.update("task", values, "key=? AND state IN ('CANCELLED','STALE') AND key NOT IN (SELECT key FROM attempt)", arrayOf(key(input)))
            inserted = changed == 1 || db.insertWithOnConflict("task", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return inserted
    }
    fun next(): Task? = readableDatabase.rawQuery("SELECT key,payload,legacy,epoch,state,response,mode,generation FROM task WHERE state IN ('READY','RESULT') ORDER BY rowid LIMIT 1", null).use {
        if (!it.moveToFirst()) null else Task(it.getString(0), Gson().fromJson(it.getString(1), OwnerQueueInput::class.java), it.getInt(2) == 1, it.getLong(3), it.getString(4), it.getString(5), it.getString(6), if (it.isNull(7)) null else it.getLong(7))
    }
    fun find(key: String): Task? = readableDatabase.rawQuery("SELECT key,payload,legacy,epoch,state,response,mode,generation FROM task WHERE key=? AND payload<>''", arrayOf(key)).use {
        if (!it.moveToFirst()) null else Task(it.getString(0), Gson().fromJson(it.getString(1), OwnerQueueInput::class.java), it.getInt(2) == 1,
            it.getLong(3), it.getString(4), it.getString(5), it.getString(6), if (it.isNull(7)) null else it.getLong(7))
    }
    /** A delayed worker must not resurrect a scrubbed task or mutate a reused key. */
    fun status(key: String, epoch: Long, expectedState: String, state: String, response: String = ""): Boolean =
        writableDatabase.update("task", ContentValues().apply { put("state", state); put("response", response); if (state !in setOf("READY", "DISPATCHED", "RESULT", "REVIEW")) put("payload", "") },
            MUTATION_WHERE, arrayOf(key, epoch.toString(), expectedState)) == 1
    /** CAS and rolling-hour budget debit are committed before invoking the provider, even if it fails. */
    fun dispatch(key: String, epoch: Long, limit: Int, now: Long): Boolean {
        require(limit in 1..60)
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cursor = db.rawQuery("SELECT COUNT(*) FROM attempt WHERE sent >= ?", arrayOf((now - 3600000).toString()))
            val used = try { cursor.moveToFirst(); cursor.getInt(0) } finally { cursor.close() }
            if (used >= limit) return false
            val changed = db.update("task", ContentValues().apply { put("state", "DISPATCHED") }, MUTATION_WHERE, arrayOf(key, epoch.toString(), "READY"))
            if (changed != 1) return false
            db.insertOrThrow("attempt", null, ContentValues().apply { put("key", key); put("sent", now) })
            db.setTransactionSuccessful()
            return true
        } finally { db.endTransaction() }
    }
    fun recover() { writableDatabase.execSQL("UPDATE task SET state='UNKNOWN', payload='' WHERE state='DISPATCHED'") }
    fun cancel() {
        writableDatabase.execSQL("UPDATE task SET state=CASE WHEN state='DISPATCHED' THEN 'UNKNOWN' ELSE 'CANCELLED' END, payload='', response='' WHERE state IN ('READY','DISPATCHED','RESULT','REVIEW')")
    }
    fun summary(): String {
        val cursor = readableDatabase.rawQuery("SELECT state,COUNT(*) FROM task GROUP BY state", null)
        try {
            val rows = mutableListOf<String>()
            while (cursor.moveToNext()) rows.add("${cursor.getString(0)}: ${cursor.getInt(1)}")
            return rows.joinToString("；")
        } finally { cursor.close() }
    }
}
