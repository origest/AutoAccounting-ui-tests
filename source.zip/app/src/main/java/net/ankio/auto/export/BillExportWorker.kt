package net.ankio.auto.export

import android.content.Context
import android.os.SystemClock
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import net.ankio.auto.storage.Logger

class BillExportWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val started = SystemClock.elapsedRealtime()
        val result = BillExporter.exportAll()
        return result.fold(
            onSuccess = {
                Logger.d(
                    "账单导出完成: scope=all states=${it.stateCounts} pulled=${it.pulled} " +
                        "posted=${it.posted} failed=0 elapsed_ms=${SystemClock.elapsedRealtime() - started}"
                )
                Result.success()
            },
            onFailure = { error ->
                val failure = error as? BillExportFailure
                Logger.e(
                    "账单导出失败: scope=all states=${failure?.stateCounts.orEmpty()} " +
                        "posted=${failure?.posted ?: 0} failed=1 " +
                        "error=${failure?.kind ?: "unknown"} " +
                        "elapsed_ms=${SystemClock.elapsedRealtime() - started}"
                )
                if (runAttemptCount < 5 && (failure?.kind == "network_io" ||
                        failure?.kind == "nas_http_429" || failure?.kind?.startsWith("nas_http_5") == true)) {
                    Result.retry()
                } else Result.failure()
            },
        )
    }

    companion object {
        const val KEY_DAY_OFFSET = "day_offset"
    }
}
