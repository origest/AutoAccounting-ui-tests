package net.ankio.auto.export

import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.ankio.auto.http.RequestsUtils
import net.ankio.auto.http.api.BillAPI
import net.ankio.auto.utils.PrefManager
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.ezbook.server.constant.BillState
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.tools.runCatchingExceptCancel
import android.content.Context
import net.ankio.auto.autoApp
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.TimeUnit

data class BillExportResult(val stateCounts: Map<String, Int>, val posted: Int) {
    val pulled: Int get() = stateCounts.values.sum()
}

class BillExportFailure(
    val kind: String,
    val stateCounts: Map<String, Int>,
    val posted: Int,
    cause: Throwable,
) : Exception(kind, cause)

object BillExporter {
    private val mutex = Mutex()
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
    private val states = listOf(BillState.Synced, BillState.Edited, BillState.Wait2Edit)

    suspend fun exportAll(): Result<BillExportResult> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val counts = linkedMapOf<String, Int>()
            var posted = 0
            runCatchingExceptCancel {
                check(PrefManager.billExportEnabled) { "disabled" }
                val endpoint = PrefManager.billExportUrl.trim()
                val token = PrefManager.billExportToken.trim()
                check(endpoint.startsWith("https://")) { "endpoint_must_be_https" }
                check(token.isNotEmpty()) { "token_missing" }

                val start = Long.MIN_VALUE
                val end = Long.MAX_VALUE
                // Separate checkpoints when changing destination or credentials; never store the token.
                val destination = IncrementalBillSync.digest(endpoint + "\n" + token)
                val journal = autoApp.getSharedPreferences("bill_export_" + destination, Context.MODE_PRIVATE)
                val sync = IncrementalBillSync(
                    read = { id -> journal.getString(id, null) },
                    save = { id, digest -> check(journal.edit().putString(id, digest).commit()) { "checkpoint_write_failed" } },
                )

                // Pull all three states before posting anything. An empty successful list is valid;
                // any failed local call aborts the entire run and leaves NAS files untouched.
                val bills = mutableListOf<BillInfoModel>()
                for (state in states) {
                    val stateBills = BillAPI.exportList(state, start, end).getOrThrow()
                    counts[state.name] = stateBills.size
                    bills += stateBills
                }

                for (bill in bills.distinctBy { it.id }) {
                    currentCoroutineContext().ensureActive()
                    check(PrefManager.billExportEnabled) { "disabled" }
                    val payload = gson.toJson(bill)
                    if (!sync.sendIfChanged(bill.id.toString(), payload) { digest ->
                        val request = Request.Builder()
                            .url(endpoint)
                            .header("Authorization", "Bearer $token")
                            .header("Content-Type", "application/json; charset=utf-8")
                            .header("Idempotency-Key", IncrementalBillSync.digest(destination + ":" + bill.id + ":" + digest))
                            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
                            .build()
                        client.newCall(request).execute().use { response ->
                            check(response.isSuccessful) { "nas_http_${response.code}" }
                            val acknowledgement = JsonParser.parseString(response.body?.string().orEmpty()).asJsonObject
                            check(acknowledgement.get("id")?.asString == bill.id.toString() &&
                                acknowledgement.get("status")?.asString in setOf("inserted", "updated", "unchanged")) {
                                "nas_ack_invalid"
                            }
                        }
                    }) continue
                    posted++
                }
                BillExportResult(counts.toMap(), posted)
            }.recoverCatching { error ->
                throw BillExportFailure(shortError(error), counts.toMap(), posted, error)
            }
        }
    }

    private fun shortError(error: Throwable): String = when {
        error.message in setOf("disabled", "endpoint_must_be_https", "token_missing", "checkpoint_write_failed", "nas_ack_invalid") -> error.message!!
        error.message?.startsWith("nas_http_") == true -> error.message!!
        error is RequestsUtils.HttpException -> "local_http_${error.code}"
        error is java.io.IOException -> "network_io"
        else -> error.javaClass.simpleName.take(40)
    }
}
