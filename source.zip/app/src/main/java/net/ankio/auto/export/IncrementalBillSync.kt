package net.ankio.auto.export

import java.security.MessageDigest

/** Acknowledged payloads only: interrupted or rejected uploads remain pending. */
internal class IncrementalBillSync(
    private val read: (String) -> String?,
    private val save: (String, String) -> Unit,
) {
    fun sendIfChanged(id: String, payload: String, send: (String) -> Unit): Boolean {
        val fingerprint = digest(payload)
        if (read(id) == fingerprint) return false
        send(fingerprint)
        save(id, fingerprint)
        return true
    }

    companion object {
        fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
