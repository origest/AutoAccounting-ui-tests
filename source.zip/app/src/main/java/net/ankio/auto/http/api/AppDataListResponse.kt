package net.ankio.auto.http.api

import kotlinx.coroutines.CancellationException
import org.ezbook.server.db.model.AppDataModel
import org.ezbook.server.models.ResultModel

/** A list failure must never masquerade as a successful, empty query. */
internal class AppDataListException(message: String) : Exception(message)

/**
 * Only fixed diagnostics cross this boundary. HTTP/JSON failures can contain a response body,
 * notification text or the search URL; never retain their message or cause for UI/logging.
 */
internal suspend fun fetchAppDataList(
    request: suspend () -> Result<ResultModel<List<AppDataModel>>?>
): List<AppDataModel> {
    try {
        val response = request().getOrThrow()
            ?: throw AppDataListException("App data response is missing")
        if (response.code != 200) {
            throw AppDataListException("App data query failed (code=${response.code})")
        }
        return response.data ?: throw AppDataListException("App data list is missing")
    } catch (error: CancellationException) {
        throw error
    } catch (error: AppDataListException) {
        throw error
    } catch (_: Exception) {
        throw AppDataListException("App data request failed")
    }
}
