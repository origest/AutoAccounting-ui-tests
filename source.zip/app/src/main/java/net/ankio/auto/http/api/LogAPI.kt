/*
 * Copyright (C) 2025 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.http.api

import android.net.Uri
import android.util.Log
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.ankio.auto.http.LocalNetwork
import net.ankio.auto.storage.Logger
import org.ezbook.server.constant.LogLevel
import org.ezbook.server.db.model.LogModel
import org.ezbook.server.tools.runCatchingExceptCancel

object LogAPI {
    // 日志缓冲队列
    private val buffer = mutableListOf<LogModel>()
    private var lastFlushTime = System.currentTimeMillis()

    // 批量发送参数：达到50条或超过3秒则发送
    private const val BATCH_SIZE = 50
    private const val FLUSH_INTERVAL = 3000L
    
    /**
     * 添加日志
     */
    suspend fun add(level: LogLevel, app: String, location: String, message: String) = withContext(Dispatchers.IO) {
        val log = LogModel(level = level, app = app, location = location, message = message)
        add(logModel = log)
    }

    /**
     * 添加日志（支持批量缓冲）
     * 当缓冲区达到BATCH_SIZE或距离上次发送超过FLUSH_INTERVAL时自动批量发送
     */
    suspend fun add(logModel: LogModel) = withContext(Dispatchers.IO) {
        val toSend = synchronized(buffer) {
            buffer.add(logModel)
            val shouldFlush = buffer.size >= BATCH_SIZE ||
                    System.currentTimeMillis() - lastFlushTime > FLUSH_INTERVAL
            if (shouldFlush) {
                val snapshot = buffer.toList()
                buffer.clear()
                lastFlushTime = System.currentTimeMillis()
                snapshot
            } else null
        }

        toSend?.let {
            runCatchingExceptCancel {
                // 批量发送日志，返回的是插入后的 ID 列表 List<Long>
                LocalNetwork.post<List<Long>>("log/addBatch", Gson().toJson(it)).getOrThrow()
            }.getOrElse { item ->
                // 批量发送失败，静默忽略
                Log.e(LogAPI.javaClass.name, item.message ?: "", item)
            }
        }
    }

    /**
     * 获取日志列表（支持筛选）
     * @param page 页码
     * @param limit 每页数量
     * @param appFilter 应用筛选，为空表示所有应用
     * @param levelFilter 日志级别筛选列表，为空表示所有级别
     * @return 日志列表
     */
    suspend fun list(
        page: Int = 1,
        limit: Int = 10,
        appFilter: String = "",
        levelFilter: List<String> = emptyList()
    ): List<LogModel> = withContext(Dispatchers.IO) {

        return@withContext runCatchingExceptCancel {
            val url = buildString {
                append("log/list?page=$page&limit=$limit")
                if (appFilter.isNotEmpty()) append("&app=${Uri.encode(appFilter)}")
                if (levelFilter.isNotEmpty()) append("&levels=${levelFilter.joinToString(",")}")
            }
            val resp = LocalNetwork.get<List<LogModel>>(url).getOrThrow()
            resp.data ?: emptyList()
        }.getOrElse {
            Logger.e("list error: ${it.message}", it)
            emptyList()
        }
    }

    /**
     * 获取所有应用列表（用于筛选器）
     * @return 应用包名列表
     */
    suspend fun getApps(): List<String> = withContext(Dispatchers.IO) {
        return@withContext runCatchingExceptCancel {
            val resp = LocalNetwork.get<List<String>>("log/apps").getOrThrow()
            resp.data ?: emptyList()
        }.getOrElse {
            Logger.e("getApps error: ${it.message}", it)
            emptyList()
        }
    }

    /**
     * 清空日志
     */
    suspend fun clear() = withContext(Dispatchers.IO) {

        runCatchingExceptCancel {
            LocalNetwork.post<String>("log/clear").getOrThrow()
        }.getOrElse {
            Logger.e("clear error: ${it.message}", it)

        }
    }
}