package net.ankio.auto.notification

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.ezbook.server.models.NotificationCaptureAck
import org.ezbook.server.models.NotificationCaptureProtocol
import org.ezbook.server.models.NotificationCaptureSettingsUpdate
import org.ezbook.server.models.NotificationCaptureSettings
import org.ezbook.server.models.NotificationCaptureRequest
import org.ezbook.server.models.ResultModel
import java.net.Proxy
import java.util.concurrent.TimeUnit

/** Dedicated short loopback call. No fallback to the non-idempotent /js/analysis endpoint. */
internal class NotificationCaptureTransport(
    private val baseUrl: String = "http://127.0.0.1:52045",
) {
    init {
        val uri = java.net.URI(baseUrl)
        require(uri.scheme == "http" && uri.host == "127.0.0.1" && uri.rawUserInfo == null &&
            uri.rawQuery == null && uri.rawFragment == null && uri.path.orEmpty().isEmpty())
    }
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .proxy(Proxy.NO_PROXY)
        .connectTimeout(1, TimeUnit.SECONDS)
        .callTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    fun deliver(capture: NotificationCaptureRequest): NotificationDeliveryOutcome {
        return try {
            val json = gson.toJson(capture)
            if (json.toByteArray(Charsets.UTF_8).size > NotificationCaptureProtocol.CAPTURE_BODY_BYTES) {
                return NotificationDeliveryOutcome.Rejected("invalid_request")
            }
            val request = Request.Builder()
                .url("$baseUrl/notification/capture")
                .header("Authorize", "")
                .post(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                if (response.code == 404) return NotificationDeliveryOutcome.Retry("server_upgrade_required")
                if (response.code == 400) return NotificationDeliveryOutcome.Rejected("invalid_request")
                if (response.code == 409) return NotificationDeliveryOutcome.Rejected("capture_id_conflict")
                if (!response.isSuccessful) return NotificationDeliveryOutcome.Retry("http_error")
                // ACKs are tiny. Never accept an unbounded/misrouted response into system_server memory.
                val body = response.body ?: return NotificationDeliveryOutcome.Retry("missing_ack")
                if (body.contentLength() > 4096) return NotificationDeliveryOutcome.Retry("invalid_response")
                val source = body.source()
                source.request(4097)
                if (source.buffer.size > 4096) return NotificationDeliveryOutcome.Retry("invalid_response")
                val type = object : TypeToken<ResultModel<NotificationCaptureAck>>() {}.type
                NotificationDeliveryOutcome.decode(capture.captureId, gson.fromJson(body.string(), type))
            }
        } catch (_: Exception) {
            // Exception messages can contain the request, response or other private content.
            NotificationDeliveryOutcome.Retry("transport_error")
        }
    }

    enum class SettingsOutcome { SAVED, RETRY, REJECTED }
    fun synchronize(expectedRevision: Long, settings: NotificationCaptureSettings): SettingsOutcome {
        return try {
            val json = gson.toJson(NotificationCaptureSettingsUpdate(expectedRevision, settings))
            if (json.toByteArray(Charsets.UTF_8).size > NotificationCaptureProtocol.SETTINGS_BODY_BYTES) return SettingsOutcome.REJECTED
            val request = Request.Builder()
                .url("$baseUrl/notification/settings")
                .header("Authorize", "")
                .post(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                if (response.code == 400) return SettingsOutcome.REJECTED
                if (!response.isSuccessful) return SettingsOutcome.RETRY
                val body = response.body ?: return SettingsOutcome.RETRY
                if (body.contentLength() > 4096) return SettingsOutcome.RETRY
                val source = body.source(); source.request(4097)
                if (source.buffer.size > 4096) return SettingsOutcome.RETRY
                val type = object : TypeToken<ResultModel<Long>>() {}.type
                val result = gson.fromJson<ResultModel<Long>>(body.string(), type) ?: return SettingsOutcome.RETRY
                when {
                    result.code == 200 && result.data == expectedRevision + 1 -> SettingsOutcome.SAVED
                    result.code == 400 -> SettingsOutcome.REJECTED
                    else -> SettingsOutcome.RETRY
                }
            }
        } catch (_: Exception) { SettingsOutcome.RETRY }
    }


    fun settingsVersion(): Long? {
        return try {
            val request = Request.Builder().url("$baseUrl/notification/settings/version").header("Authorize", "").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body ?: return null
                if (body.contentLength() > 4096) return null
                val source = body.source(); source.request(4097)
                if (source.buffer.size > 4096) return null
                val type = object : TypeToken<ResultModel<Long>>() {}.type
                val result = gson.fromJson<ResultModel<Long>>(body.string(), type) ?: return null
                val version = result.data
                if (result.code == 200 && version != null && version >= 0 && version < Long.MAX_VALUE) version else null
            }
        } catch (_: Exception) { null }
    }

}
