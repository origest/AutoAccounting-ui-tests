package net.ankio.auto.notification

import org.ezbook.server.models.NotificationCaptureAck
import org.ezbook.server.models.ResultModel

/** Server messages and notification text never become diagnostic messages. */
internal sealed class NotificationDeliveryOutcome(val reason: String) {
    class Delivered(val rawId: Long?, reason: String) : NotificationDeliveryOutcome(reason)
    class Retry(reason: String) : NotificationDeliveryOutcome(reason)
    class Rejected(reason: String) : NotificationDeliveryOutcome(reason)

    companion object {
        private val filterReasons = setOf("empty", "app_not_allowed", "keyword_not_allowed", "keyword_blocked")
        fun decode(captureId: String, result: ResultModel<NotificationCaptureAck>?): NotificationDeliveryOutcome {
            if (result == null) return Retry("invalid_response")
            if (result.code == 400) return Rejected("invalid_request")
            if (result.code == 409) return Rejected("capture_id_conflict")
            if (result.code != 200) return Retry(if (result.code == 503) "capture_unavailable" else "server_error")
            val ack = result.data ?: return Retry("missing_ack")
            if (ack.captureId != captureId) return Retry("ack_id_mismatch")
            val rawId = ack.rawId
            if (ack.disposition == "accepted" && rawId != null && rawId > 0 && ack.reason == "stored") {
                return Delivered(rawId, "stored")
            }
            if (ack.disposition == "filtered" && ack.rawId == null && ack.reason in filterReasons) {
                return Delivered(null, ack.reason)
            }
            return Retry("invalid_ack")
        }
    }
}
