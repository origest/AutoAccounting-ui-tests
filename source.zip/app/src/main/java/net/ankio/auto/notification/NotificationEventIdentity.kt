package net.ankio.auto.notification

/** Both NMS hooks use the same stable fields; unrelated notification IDs do not collide by text. */
internal object NotificationEventIdentity {
    fun of(pkg: String, userId: Int, notificationId: Int, tag: String?, notificationTime: Long): String =
        listOf(pkg, userId.toString(), notificationId.toString(), (tag == null).toString(), tag.orEmpty(), notificationTime.toString())
            .joinToString("") { "${it.length}:$it" }

    fun firstNonBlank(values: List<CharSequence?>, limit: Int): String {
        val selected = values.firstOrNull { !it.isNullOrBlank() } ?: return ""
        // Preserve an over-limit marker so the queue rejects rather than silently truncating a payment.
        return selected.take(limit + 1).toString()
    }

    fun joinLinesBounded(lines: List<CharSequence?>, limit: Int): String {
        val out = StringBuilder()
        for ((index, line) in lines.withIndex()) {
            if (index > 0) out.append('\n')
            if (out.length > limit) return out.toString()
            val remaining = limit + 1 - out.length
            if (line != null) out.append(line.take(remaining))
            if (out.length > limit) return out.toString()
        }
        return out.toString()
    }

}
