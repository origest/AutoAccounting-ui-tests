package net.ankio.auto.notification

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import net.ankio.auto.storage.Logger
import net.ankio.auto.utils.PrefManager
import org.ezbook.server.constant.Setting
import org.ezbook.server.models.NotificationCaptureSettings

/** Only the owner app reads its preferences. A single writer retries the latest atomic policy snapshot. */
internal object NotificationSettingsSync {
    private val keys = setOf(Setting.LISTENER_APP_LIST, Setting.DATA_FILTER, Setting.DATA_FILTER_BLACKLIST)
    private val wake = Channel<Unit>(Channel.CONFLATED)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val transport = NotificationCaptureTransport()
    fun handles(key: String): Boolean = key in keys
    fun request() { wake.trySend(Unit) }

    private fun snapshot() = NotificationCaptureSettings(
        apps = PrefManager.appWhiteList.joinToString(","),
        keywords = PrefManager.dataFilter.replace("\n", ","),
        blacklist = PrefManager.dataFilterBlacklist.replace("\n", ","),
    )

    init {
        scope.launch {
            for (ignored in wake) {
                var attempt = 0
                while (isActive) {
                    val version = transport.settingsVersion()
                    // Read the current persisted values after fetching the version, never replay a stale snapshot.
                    val policy = snapshot()
                    attempt++
                    val result = if (version == null) NotificationCaptureTransport.SettingsOutcome.RETRY
                        else transport.synchronize(version, policy)
                    if (result == NotificationCaptureTransport.SettingsOutcome.SAVED) {
                        // A setting may have changed while the HTTP call was in flight.
                        if (policy != snapshot()) continue
                        runCatching { Logger.i("NotificationCapture policy=synchronized") }
                        break
                    }
                    if (result == NotificationCaptureTransport.SettingsOutcome.REJECTED) {
                        runCatching { Logger.w("NotificationCapture policy=invalid_configuration") }
                        break
                    }
                    if (attempt == 1 || attempt % 20 == 0) {
                        runCatching { Logger.w("NotificationCapture policy=pending_sync attempt=$attempt") }
                    }
                    val delay = if (attempt < 3) 1_000L else if (attempt < 5) 5_000L else 30_000L
                    // A new local change wakes the retry immediately; never replay a stale snapshot.
                    withTimeoutOrNull(delay) { wake.receive() }
                }
            }
        }
    }
}
