package net.ankio.auto.notification

import org.ezbook.server.models.NotificationCaptureRequest
import java.security.MessageDigest
import java.util.UUID

/** Bounded system-process memory only. A failed delivery remains pending with the same ID and body. */
internal class PendingNotificationQueue(
    private val clock: () -> Long,
    private val idFactory: () -> String = { UUID.randomUUID().toString() },
    private val capacity: Int = 256,
    private val byteLimit: Int = 2 * 1024 * 1024,
    private val completedTtlMs: Long = 60_000,
) {
    enum class Offered { QUEUED, DUPLICATE, EMPTY, TOO_LARGE, FULL }
    data class Delivery(val request: NotificationCaptureRequest, val attempt: Int)
    private data class Entry(
        val key: String,
        val request: NotificationCaptureRequest,
        val bytes: Int,
        var attempts: Int = 0,
        var dueAt: Long = 0,
        var inFlight: Boolean = false,
    )
    private val pending = linkedMapOf<String, Entry>()
    private val completed = linkedMapOf<String, Long>()
    private var bytes = 0

    @Synchronized
    fun offer(identity: String, pkg: String, title: String, text: String, capturedAt: Long): Offered {
        if (title.isEmpty() && text.isEmpty()) return Offered.EMPTY
        if (pkg.length !in 1..255 || title.length > 4096 || text.length > 16384 || identity.length > 4096) return Offered.TOO_LARGE
        val key = fingerprint(listOf(identity, pkg, title, text))
        val now = clock()
        completed.entries.removeAll { now - it.value > completedTtlMs }
        if (completed.containsKey(key) || pending.values.any { it.key == key }) return Offered.DUPLICATE
        val size = (identity.length + pkg.length + title.length + text.length) * 2 + 256
        if (size > byteLimit) return Offered.TOO_LARGE
        if (pending.size >= capacity || bytes + size > byteLimit) return Offered.FULL
        val request = NotificationCaptureRequest(idFactory(), pkg, title, text, capturedAt)
        pending[request.captureId] = Entry(key, request, size, dueAt = now)
        bytes += size
        return Offered.QUEUED
    }

    @Synchronized
    fun takeReady(): Delivery? {
        val now = clock()
        val entry = pending.values.firstOrNull { !it.inFlight && it.dueAt <= now } ?: return null
        entry.inFlight = true
        entry.attempts++
        return Delivery(entry.request, entry.attempts)
    }

    @Synchronized
    fun retry(captureId: String) {
        val entry = pending[captureId] ?: return
        entry.inFlight = false
        val delays = longArrayOf(1_000, 2_000, 5_000, 10_000, 30_000)
        entry.dueAt = clock() + delays[(entry.attempts - 1).coerceIn(0, delays.lastIndex)]
    }

    /** Call only after a verified durable ACK or an explicit permanent server rejection. */
    @Synchronized
    fun finish(captureId: String) {
        val entry = pending.remove(captureId) ?: return
        bytes -= entry.bytes
        completed[entry.key] = clock()
        while (completed.size > capacity * 4) completed.remove(completed.keys.first())
    }

    @Synchronized
    fun waitMillis(): Long {
        val due = pending.values.filterNot { it.inFlight }.minOfOrNull { it.dueAt } ?: return 30_000
        return (due - clock()).coerceIn(1, 30_000)
    }

    @Synchronized
    fun size(): Int = pending.size

    companion object {
        fun fingerprint(fields: List<String>): String = MessageDigest.getInstance("SHA-256")
            .digest(fields.joinToString("") { "${it.length}:$it" }.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
