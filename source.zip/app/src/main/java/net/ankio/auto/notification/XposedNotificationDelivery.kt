package net.ankio.auto.notification

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import net.ankio.auto.xposed.core.logger.XposedLogger

/** One bounded queue/worker, not one suspended coroutine per notification. Never writes system files. */
internal object XposedNotificationDelivery {
    private val queue = PendingNotificationQueue(clock = SystemClock::elapsedRealtime)
    private val wake = Channel<Unit>(Channel.CONFLATED)
    private val transport = NotificationCaptureTransport()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        scope.launch {
            while (isActive) {
                val item = queue.takeReady()
                if (item == null) {
                    withTimeoutOrNull(queue.waitMillis()) { wake.receive() }
                    continue
                }
                val outcome = transport.deliver(item.request)
                when (outcome) {
                    is NotificationDeliveryOutcome.Delivered -> queue.finish(item.request.captureId)
                    is NotificationDeliveryOutcome.Rejected -> queue.finish(item.request.captureId)
                    is NotificationDeliveryOutcome.Retry -> queue.retry(item.request.captureId)
                }
                // Report first retry and sparse ongoing retries, not a log flood during a long outage.
                if (outcome !is NotificationDeliveryOutcome.Retry || item.attempt == 1 || item.attempt % 20 == 0) {
                    runCatching { XposedLogger.i("NotificationCapture event=${item.request.captureId} stage=${outcome.reason} attempt=${item.attempt} pending=${queue.size()}") }
                }
            }
        }
    }

    fun offer(identity: String, pkg: String, title: String, text: String) {
        val outcome = queue.offer(identity, pkg, title, text, System.currentTimeMillis())
        if (outcome == PendingNotificationQueue.Offered.QUEUED) wake.trySend(Unit)
        if (outcome == PendingNotificationQueue.Offered.FULL || outcome == PendingNotificationQueue.Offered.TOO_LARGE) {
            runCatching { XposedLogger.w("NotificationCapture stage=${outcome.name.lowercase()} pending=${queue.size()}") }
        }
    }
}
