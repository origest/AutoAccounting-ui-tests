package net.ankio.auto.service.ocr

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.dialog.BillEditorDialog
import net.ankio.auto.utils.PrefManager
import net.ankio.chatgpt.ChatGptAccounts
import org.ezbook.server.ai.tools.ChatGptCategoryGateway
import org.ezbook.server.ai.tools.OcrTextBillContract
import org.ezbook.server.constant.BillState
import org.ezbook.server.constant.DataType
import org.ezbook.server.db.Db
import org.ezbook.server.db.model.AppDataModel
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.resolveBookByNameOrDefault
import org.ezbook.server.tools.BillExportSignal
import org.ezbook.server.tools.BillService
import org.ezbook.server.tools.SettingUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Owner-only text path. Never installed in an HTTP route, Xposed host, or ordinary API provider. */
object ChatGptOcrTextPipeline {
    private val mutex = Mutex()
    @Volatile private var permissionWarning: String? = null
    fun warning(): String? = permissionWarning
    private fun prefs(context: Context) = context.getSharedPreferences("chatgpt-ocr-text", Context.MODE_PRIVATE)
    fun isSelected(context: Context): Boolean = prefs(context).getBoolean("selected", false)
    fun isEnabled(context: Context): Boolean = isSelected(context) && runCatching {
        ChatGptAccounts.get(context).ocrTextTicket() != null
    }.getOrDefault(false)
    /** Call only after the separate OCR-text disclosure and affirmative user consent. */
    fun enable(context: Context, model: String) {
        check(WorkMode.isOcr()) { "OCR_MODE_REQUIRED" }
        val accounts = ChatGptAccounts.get(context)
        try {
            accounts.enableOcrText(model)
            if (!prefs(context).edit().putBoolean("selected", true).commit()) {
                accounts.disableOcrText()
                error("OCR_SETTINGS_UNAVAILABLE")
            }
            permissionWarning = null
        } catch (e: Exception) {
            runCatching { accounts.disableOcrText() }
            permissionWarning = "本次运行已停止 OCR 发送，但授权保存未确认，重启后无法保证。请重试关闭 OCR 授权。"
            throw e
        }
    }
    /** Keep the route selected: pausing must never silently send text to another API provider. */
    fun disable(context: Context) {
        try { ChatGptAccounts.get(context).disableOcrText(); permissionWarning = null }
        catch (e: Exception) {
            permissionWarning = "本次运行已停止 OCR 发送，但撤销保存未确认，重启后无法保证。请重试关闭 OCR 授权。"
            throw e
        }
    }
    fun useLegacy(context: Context) {
        disable(context)
        if (!prefs(context).edit().putBoolean("selected", false).commit()) {
            permissionWarning = "OCR 发送已暂停，但返回旧路线未保存，请重试。"
            error("OCR_SETTINGS_UNAVAILABLE")
        }
    }
    fun hourlyLimit(context: Context) = prefs(context).getInt("limit", 10).coerceIn(1, 60)
    fun setHourlyLimit(context: Context, limit: Int) {
        require(limit in 1..60)
        check(prefs(context).edit().putInt("limit", limit).commit())
    }
    data class Outcome(val bill: BillInfoModel? = null, val message: String, val ticket: ChatGptAccounts.OcrTextTicket? = null, val reviewId: String? = null)

    /** Raw text remains in the existing local data view even when consent, inference, or parsing fails. */
    suspend fun analyze(context: Context, text: String, app: String, existingDataId: Long? = null,
        captureTicket: ChatGptAccounts.OcrTextTicket? = ChatGptAccounts.get(context).ocrTextTicket()
    ): Outcome = withContext(Dispatchers.IO) {
        if (!WorkMode.isOcr() || !ChatGptCategoryGateway.ownerReady || !Db.isAvailable())
            return@withContext Outcome(message = "ChatGPT 文字识别仅用于本应用 OCR 模式，请先启动本机服务。")
        if (!mutex.tryLock()) {
            val retained = runCatching {
                if (existingDataId == null) Db.get().dataDao().insert(AppDataModel().apply {
                    this.data = text; this.app = app; type = DataType.OCR; time = System.currentTimeMillis()
                })
            }.isSuccess
            return@withContext Outcome(message = if (retained) "正在处理上一笔 OCR。本条原文已保留在数据页，未发送。" else "正在处理上一笔 OCR，本条原文保存未确认，请稍后重新识别。")
        }
        var dispatchedKey: String? = null
        var reviewClaim: net.ankio.auto.ai.review.AiReviewClaim? = null
        try {
            val db = Db.get()
            val raw = if (existingDataId == null) AppDataModel().apply {
                this.data = text; this.app = app; type = DataType.OCR; time = System.currentTimeMillis()
                id = db.dataDao().insert(this)
            } else db.dataDao().queryId(existingDataId)?.takeIf { it.type == DataType.OCR && it.app == app && it.data == text }
                ?: return@withContext Outcome(message = "原始 OCR 数据已改变，请重新打开后再试。")
            val key = OcrTextAttemptStore.fingerprint(app, text)
            val draftKey = "owner_ocr_text_draft_$key"
            db.settingDao().query(draftKey)?.value?.toLongOrNull()?.let { id ->
                val existing = db.billInfoDao().queryId(id)
                return@withContext if (existing != null && existing.state == BillState.Wait2Edit)
                    Outcome(existing, "该 OCR 已识别，显示原建议，未重复处理。", reviewId = OcrReviewBridge.findReview(context, key))
                else Outcome(message = "该 OCR 已处理，请查看账单列表；未重复生成。")
            }
            OcrTextAttemptStore(context).use { store ->
                store.find(key)?.let { old ->
                    val bill = if (old.billId > 0) db.billInfoDao().queryId(old.billId) else null
                    return@withContext if (bill != null && bill.state == BillState.Wait2Edit)
                        Outcome(bill, "该 OCR 已识别，显示原建议，未重复发送。", reviewId = OcrReviewBridge.findReview(context, key))
                    else Outcome(message = "该 OCR 已尝试处理，未重复发送；结果未知时也不会自动重试。请检查待编辑账单或重新截取变化后的页面。")
                }
            }
            if (existingDataId != null && raw.isMatched()) return@withContext Outcome(message = "该原始记录已经处理，请从账单页打开，避免再次生成账单。")
            val rule = BillService().use { it.analyzeOcrRulesOnly(app, text) }
            if (rule.disabled) {
                return@withContext Outcome(message = "命中已禁用规则，已忽略，未发送到 ChatGPT。")
            }
            rule.bill?.let { bill ->
                bill.auto = false; bill.state = BillState.Wait2Edit
                db.withTransaction {
                    check(db.settingDao().query(draftKey) == null)
                    bill.id = db.billInfoDao().insert(bill)
                    db.settingDao().set(draftKey, bill.id.toString())
                    raw.match = true; raw.rule = bill.ruleName
                    db.dataDao().update(raw)
                }
                BillExportSignal.notifyCommitted()
                return@withContext Outcome(bill, "规则已识别账单，请核对；需要的分类建议将按现有授权处理。")
            }
            val accounts = ChatGptAccounts.get(context)
            val ticket = captureTicket?.takeIf(accounts::isOcrTextTicketCurrent)
                ?: return@withContext Outcome(message = "OCR 文字已保存在数据页。请先在 ChatGPT 设置中单独允许 OCR 文字分析。")
            if (!isSelected(context)) return@withContext Outcome(message = "尚未选择 ChatGPT OCR 文字识别。")
            if (SettingUtils.baseCurrency() != "CNY" || !OcrTextBillContract.supportsCurrency(text))
                return@withContext Outcome(message = "当前文字成单仅支持人民币账本和交易，不转换外币。原文已保留，请手动处理。")
            val book = resolveBookByNameOrDefault(SettingUtils.bookName())
            val categories = db.categoryDao().all().filter { it.remoteBookId == book.remoteId }
            val now = System.currentTimeMillis()
            if (!OcrTextBillContract.isSafeText(text)) return@withContext Outcome(message = "OCR 文字含疑似凭据或完整账户/卡号，已阻止发送。原文保留，请手动核对。")
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val payload = OcrTextBillContract.payload(text, categories, format.format(Date(now)))
                ?: return@withContext Outcome(message = "OCR 文字为空或过长，未发送。原文保留在数据页。")
            OcrTextAttemptStore(context).use { store ->
                if (!accounts.isOcrTextTicketCurrent(ticket)) return@withContext Outcome(message = "授权已改变，未发送。")
                when (store.claim(key, raw.id, now, hourlyLimit(context))) {
                    OcrTextAttemptStore.Claim.LIMIT -> return@withContext Outcome(message = "已达本小时识别次数或本机记录上限，未发送。原文已保留。")
                    OcrTextAttemptStore.Claim.DUPLICATE -> return@withContext Outcome(message = "同一 OCR 正在处理或已处理，未重复发送。")
                    OcrTextAttemptStore.Claim.ACCEPTED -> dispatchedKey = key
                }
                reviewClaim = OcrReviewBridge.begin(context, key)
                val response = accounts.recognizeOcrText(OcrTextBillContract.PROMPT, payload, ticket)
                if (!accounts.isOcrTextTicketCurrent(ticket) || !isSelected(context) || !WorkMode.isOcr()) {
                    store.finish(key, "CANCELLED")
                    OcrReviewBridge.fail(context, reviewClaim, "AUTH_CHANGED")
                    return@withContext Outcome(message = "授权或模式已改变，本次结果未应用。")
                }
                val suggestion = OcrTextBillContract.parse(response, categories)
                if (suggestion == null) {
                    store.finish(key, "NO_RESULT")
                    OcrReviewBridge.fail(context, reviewClaim, "NO_RESULT")
                    return@withContext Outcome(message = "ChatGPT 未识别到明确的单笔账单，原文已保留，请检查 OCR 内容。")
                }
                val bill = suggestion.toBill().apply {
                    this.app = app; bookName = book.name
                    time = if (suggestion.timeText.isEmpty()) now else format.parse(suggestion.timeText)?.time ?: now
                    ruleName = "ChatGPT 文字生成"
                    remark = "ChatGPT OCR 文字建议，请核对金额、时间与分类"
                }
                accounts.commitOcrText(ticket) { kotlinx.coroutines.runBlocking { db.withTransaction {
                    check(isSelected(context) && WorkMode.isOcr() && SettingUtils.baseCurrency() == "CNY")
                    check(db.settingDao().query(draftKey) == null)
                    bill.id = db.billInfoDao().insert(bill)
                    db.settingDao().set(draftKey, bill.id.toString())
                    raw.match = true; raw.rule = bill.ruleName
                    db.dataDao().update(raw)
                } } }
                // A crash here may leave a draft, but never causes a repeated provider call.
                check(store.finish(key, "SUCCEEDED", bill.id))
                OcrReviewBridge.ready(context, reviewClaim!!, bill.id)
                BillExportSignal.notifyCommitted()
                Outcome(bill, "ChatGPT 已生成待确认建议，请核对后保存。", ticket, reviewClaim!!.id)
            }
        } catch (e: Exception) {
            dispatchedKey?.let { key -> runCatching { OcrTextAttemptStore(context).use { it.finish(key, "UNKNOWN") } } }
            runCatching { OcrReviewBridge.fail(context, reviewClaim, if (e is CancellationException) "CANCELLED" else "REQUEST_FAILED") }
            if (e is CancellationException) throw e
            Outcome(message = OcrFailureHints.message(e))
        } finally { mutex.unlock() }
    }
    /** Always open the editor, never the floating-tip auto-save/countdown route. */
    suspend fun present(context: Context, result: Outcome): Boolean = withContext(Dispatchers.Main) {
        val bill = result.bill ?: return@withContext false
        val ticket = result.ticket
        if (!isSelected(context) || !WorkMode.isOcr() || (ticket != null && !ChatGptAccounts.get(context).isOcrTextTicketCurrent(ticket))) return@withContext false
        try {
            OcrReviewBridge.show(context, bill, result.reviewId)
            true
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            false
        }
    }
}
