package net.ankio.auto.service.ocr

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.ankio.auto.constant.WorkMode
import net.ankio.chatgpt.ChatGptAccounts
import org.ezbook.server.ai.tools.ChatGptCategoryGateway
import org.ezbook.server.ai.tools.OcrTextBillContract
import org.ezbook.server.db.Db
import org.ezbook.server.db.model.AppDataModel
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.CategoryModel
import org.ezbook.server.server.resolveBookByNameOrDefault
import org.ezbook.server.tools.BillExportSignal
import org.ezbook.server.tools.SettingUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Manual per-record text analysis. It never inherits persistent category/OCR send permissions. */
object ChatGptRawRecordAnalysis {
    data class Plan internal constructor(val id: Long, val text: String, val app: String, val type: String,
        val book: String, val bookId: String, val categories: List<CategoryModel>, val payload: String, val key: String)
    data class Prepared(val plan: Plan? = null, val message: String = "")
    data class Outcome(val bill: BillInfoModel? = null, val message: String, val reviewId: String? = null)
    private fun ownerReady() = WorkMode.isOcrOrLSPatch() && ChatGptCategoryGateway.ownerReady && Db.isAvailable()
    suspend fun prepare(context: Context, row: AppDataModel): Prepared = withContext(Dispatchers.IO) {
        if (!ownerReady()) return@withContext Prepared(message = "当前仅支持 OCR/LSPatch 本机服务模式的数据 AI 成单。普通 Xposed 请先使用原规则或账单页 AI 分类。")
        try {
            val db = Db.get()
            val raw = db.dataDao().queryId(row.id)
                ?: return@withContext Prepared(message = "原始记录已删除，请刷新。")
            if (raw.data.isBlank()) return@withContext Prepared(message = "该记录没有可分析文字。暂不上传或识别图片。")
            if (!OcrTextBillContract.isSafeText(raw.data)) return@withContext Prepared(message = "记录含疑似凭据、完整账户/卡号或图片编码，已在本机阻止发送。请先手动提取不含这些内容的交易文字。")
            if (SettingUtils.baseCurrency() != "CNY" || !OcrTextBillContract.supportsCurrency(raw.data))
                return@withContext Prepared(message = "当前文字成单仅支持人民币账本和交易，不转换外币。请手动处理该记录。")
            if (raw.data != row.data || raw.type != row.type || raw.app != row.app)
                return@withContext Prepared(message = "记录已变化，请刷新后重试。")
            val key = OcrTextAttemptStore.fingerprint(raw.app, raw.data, raw.type.name)
            if (raw.isMatched() || db.settingDao().query("owner_ocr_text_draft_$key") != null)
                return@withContext Prepared(message = "该记录已经生成或匹配账单，请到对应账单使用 AI 分类，避免重复成单。")
            if (OcrTextAttemptStore(context).use { it.find(key) } != null)
                return@withContext Prepared(message = "该记录已经尝试 AI 识别，不会重复发送。结果未知也不会自动重试，请检查待编辑账单。")
            val book = resolveBookByNameOrDefault(SettingUtils.bookName())
            val categories = db.categoryDao().all().filter { it.remoteBookId == book.remoteId }
            val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val payload = OcrTextBillContract.payload(raw.data, categories, now)
                ?: return@withContext Prepared(message = "文字为空、过长或包含不支持的控制字符，未发送。")
            Prepared(Plan(raw.id, raw.data, raw.app, raw.type.name, book.name, book.remoteId, categories, payload, key))
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Prepared(message = "无法读取本机记录或类别，请检查服务后重试。")
        }
    }
    fun approve(context: Context, plan: Plan): ChatGptAccounts.OneTimeTextApproval =
        ChatGptAccounts.get(context).approveTextOnce(OcrTextBillContract.PROMPT, plan.payload)

    suspend fun execute(context: Context, plan: Plan, approval: ChatGptAccounts.OneTimeTextApproval): Outcome = withContext(Dispatchers.IO) {
        if (!ownerReady()) return@withContext Outcome(message = "模式或服务已改变，未发送。")
        val accounts = ChatGptAccounts.get(context)
        var dispatched = false
        var reviewClaim: net.ankio.auto.ai.review.AiReviewClaim? = null
        try {
            val db = Db.get()
            val raw = db.dataDao().queryId(plan.id)
                ?: return@withContext Outcome(message = "记录已删除，未发送。")
            if (raw.data != plan.text || raw.app != plan.app || raw.type.name != plan.type || raw.isMatched() ||
                !accounts.isTextApprovalFor(approval, OcrTextBillContract.PROMPT, plan.payload)) return@withContext Outcome(message = "记录或账号授权已变化，未发送。")
            OcrTextAttemptStore(context).use { store ->
                when (store.claim(plan.key, raw.id, System.currentTimeMillis(), ChatGptOcrTextPipeline.hourlyLimit(context))) {
                    OcrTextAttemptStore.Claim.DUPLICATE -> return@withContext Outcome(message = "该记录已在处理，未重复发送。")
                    OcrTextAttemptStore.Claim.LIMIT -> return@withContext Outcome(message = "已达识别次数或本机记录上限，未发送。")
                    OcrTextAttemptStore.Claim.ACCEPTED -> dispatched = true
                }
                reviewClaim = OcrReviewBridge.begin(context, plan.key)
                val response = accounts.recognizeApprovedText(approval)
                if (!ownerReady() || !accounts.isTextApprovalCurrent(approval)) {
                    store.finish(plan.key, "CANCELLED")
                    OcrReviewBridge.fail(context, reviewClaim, "AUTH_CHANGED")
                    return@withContext Outcome(message = "模式或账号授权已改变，结果未应用。")
                }
                val suggestion = OcrTextBillContract.parse(response, plan.categories)
                if (suggestion == null) {
                    store.finish(plan.key, "NO_RESULT")
                    OcrReviewBridge.fail(context, reviewClaim, "NO_RESULT")
                    return@withContext Outcome(message = "未识别到明确的单笔交易。原始数据保留，未生成账单。")
                }
                val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                val bill = suggestion.toBill().apply {
                    app = plan.app; bookName = plan.book
                    time = if (suggestion.timeText.isEmpty()) raw.time else format.parse(suggestion.timeText)?.time ?: raw.time
                    ruleName = "ChatGPT 文字生成"; remark = "ChatGPT 数据建议，请核对后确认"
                }
                accounts.commitApprovedText(approval) { kotlinx.coroutines.runBlocking { db.withTransaction {
                    check(ownerReady() && SettingUtils.baseCurrency() == "CNY")
                    val current = db.dataDao().queryId(plan.id)
                    check(current != null && current.data == plan.text && current.type.name == plan.type && current.app == plan.app && !current.isMatched())
                    val key = "owner_ocr_text_draft_${plan.key}"
                    check(db.settingDao().query(key) == null)
                    bill.id = db.billInfoDao().insert(bill)
                    db.settingDao().set(key, bill.id.toString())
                    current.match = true; current.rule = bill.ruleName; db.dataDao().update(current)
                } } }
                check(store.finish(plan.key, "SUCCEEDED", bill.id))
                OcrReviewBridge.ready(context, reviewClaim!!, bill.id)
                BillExportSignal.notifyCommitted()
                Outcome(bill, "已生成待确认账单，关闭或取消会保留在待编辑列表。", reviewClaim!!.id)
            }
        } catch (e: Exception) {
            if (dispatched) runCatching { OcrTextAttemptStore(context).use { it.finish(plan.key, "UNKNOWN") } }
            runCatching { OcrReviewBridge.fail(context, reviewClaim, if (e is CancellationException) "CANCELLED" else "REQUEST_FAILED") }
            if (e is CancellationException) throw e
            Outcome(message = OcrFailureHints.message(e))
        }
    }
}
