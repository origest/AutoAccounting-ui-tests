package net.ankio.auto.service.ocr

import net.ankio.chatgpt.AccountFailure
import net.ankio.chatgpt.DiagnosticFailure
import net.ankio.chatgpt.DiagnosticCode

/** A fixed allowlist: never display provider bodies, exception messages or raw request content. */
object OcrFailureHints {
    fun message(error: Exception): String {
        val reason = when (error) {
            is AccountFailure -> when (error.code) {
                "SIGN_IN_REQUIRED" -> "请先登录 ChatGPT。"
                "MODEL_REQUIRED" -> "请先刷新并保存可用模型。"
                "CANCELLED", "OCR_TEXT_PAUSED" -> "授权已暂停或改变，结果未应用。"
                "BUSY" -> "账号正在处理另一项请求。"
                "APPROVAL_ALREADY_USED" -> "本次许可已经使用，未重复发送。"
                else -> "账号状态不允许本次识别。"
            }
            is DiagnosticFailure -> when {
                error.http == 401 -> "ChatGPT 认证已失效（401），请重新登录。"
                error.http == 403 -> "ChatGPT 拒绝访问（403），请检查账号及模型权限。"
                error.http == 429 -> "ChatGPT 额度或速率受限（429）。"
                error.code == DiagnosticCode.TIMEOUT -> "ChatGPT 请求超时，结果未知。"
                else -> "ChatGPT 请求未完成（${error.code.name}）。"
            }
            else -> "本次文字分析未完成。"
        }
        return reason + "原始记录已保留；请求可能已使用额度，不会自动重试或切换服务商。"
    }
}
