package net.ankio.auto.service.ocr

import android.content.Context
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import kotlinx.coroutines.*
import net.ankio.auto.ai.review.*
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.ui.utils.ToastUtils
import org.ezbook.server.ai.tools.CategoryTool
import org.ezbook.server.ai.tools.ChatGptCategoryGateway
import org.ezbook.server.ai.tools.HistoryCategoryTool
import org.ezbook.server.constant.BillState
import org.ezbook.server.db.Db
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.CategorySuggestionConfirmation
import org.ezbook.server.server.OwnerQueueInput
import org.ezbook.server.server.confirmCategorySuggestion
import org.ezbook.server.server.ownerQueueInput

/** Resolves an already-generated local suggestion. Never sends text or invokes a model. */
object OcrPendingCategoryReview {
    fun eligible(bill: BillInfoModel) = bill.ruleName == "ChatGPT 文字生成" &&
        WorkMode.isOcrOrLSPatch() && ChatGptCategoryGateway.ownerReady && Db.isAvailable()
    private fun target(input: OwnerQueueInput) = AiReviewTarget(input.source, input.bill.id,
        input.bill.categoryRevision, input.bill.hash())

    suspend fun prepare(context: Context, snapshot: BillInfoModel): AiReviewRecord? = withContext(Dispatchers.IO) {
        if (!eligible(snapshot)) return@withContext null
        val input = ownerQueueInput(snapshot.id) ?: return@withContext null
        val bill = input.bill
        if (bill.categoryRevision != snapshot.categoryRevision || bill.pendingCategory != snapshot.pendingCategory ||
            bill.bookName != snapshot.bookName || bill.type != snapshot.type || bill.cateName != snapshot.cateName ||
            bill.state != BillState.Wait2Edit || !HistoryCategoryTool.validProposal(bill.pendingCategory)) return@withContext null
        val path = CategoryTool.resolveCategoryPath(bill.pendingCategory, input.categories)
        val changes = listOf(AiReviewChange("CATEGORY", bill.cateName, path ?: bill.pendingCategory, path == null))
        AiReviewStore(context).use { store ->
            val record = store.create(target(input), AiReviewKind.OCR_CATEGORY)
            when (record.state) {
                AiReviewState.WAITING -> {
                    val claim = store.claim(record.id) ?: return@use null
                    check(store.review(claim, changes))
                }
                AiReviewState.FAILED -> {
                    if (record.errorCode != "REQUEST_INTERRUPTED" || !store.recoverReview(record.id, changes)) return@use null
                }
                AiReviewState.REVIEW -> if (record.changes != changes) return@use null
                else -> return@use null
            }
            store.get(record.id)
        }
    }

    suspend fun resolve(context: Context, record: AiReviewRecord, snapshot: BillInfoModel,
        existingPath: String = "", automatic: Boolean = false): BillInfoModel? = withContext(Dispatchers.IO) {
        if (!eligible(snapshot) || record.kind != AiReviewKind.OCR_CATEGORY || record.state != AiReviewState.REVIEW)
            return@withContext null
        val policy = AiReviewPolicy(context)
        if (automatic && !policy.canAutoApply(record)) return@withContext null
        var token: String? = null
        var dispatched = false
        try {
            token = withContext(NonCancellable) { AiReviewStore(context).use { it.beginApply(record.id, record.changes) } }
                ?: return@withContext null
            currentCoroutineContext().ensureActive()
            val commit = {
                dispatched = true
                runBlocking { Db.get().withTransaction {
                    val current = ownerQueueInput(snapshot.id) ?: return@withTransaction null
                    if (target(current) != record.target || !eligible(current.bill)) return@withTransaction null
                    confirmCategorySuggestion(Db.get(), CategorySuggestionConfirmation(snapshot.id, snapshot.bookName,
                        snapshot.type.name, snapshot.pendingCategory, existingPath.isEmpty(), snapshot.categoryRevision, existingPath))
                } }
            }
            // The policy monitor protects this local-only commit from a simultaneous setting revoke.
            val updated = if (automatic) policy.withAutomaticApply(record, commit) else commit()
            withContext(NonCancellable) { AiReviewStore(context).use { store ->
                if (!dispatched) store.returnToReview(record.id, token!!)
                else if (updated == null) store.finishApply(record.id, token!!, AiReviewState.STALE)
                else {
                    val changes = listOf(AiReviewChange("CATEGORY", record.changes.single().before, updated.cateName,
                        createsNew = existingPath.isEmpty() && record.changes.single().createsNew))
                    check(store.finishApply(record.id, token!!, if (existingPath.isEmpty()) AiReviewState.APPLIED else AiReviewState.MANUAL, changes))
                }
            } }
            if (updated != null) org.ezbook.server.tools.BillExportSignal.notifyCommitted()
            updated
        } catch (e: Exception) {
            withContext(NonCancellable) { runCatching { AiReviewStore(context).use { store ->
                token?.let { if (dispatched) store.finishApply(record.id, it, AiReviewState.FAILED) else store.returnToReview(record.id, it) }
            } } }
            if (e is CancellationException) throw e
            null
        }
    }

    fun register() {
        AiReviewRegistry.register(AiReviewKind.OCR_CATEGORY) { host, record ->
            host.lifecycleScope.launch {
                val input = withContext(Dispatchers.IO) { if (Db.isAvailable()) ownerQueueInput(record.target.billId) else null }
                if (record.state != AiReviewState.REVIEW || input == null || target(input) != record.target || !eligible(input.bill))
                    ToastUtils.error("账单或建议已变化，未创建类别。请从账单页核对，不会重发 GPT。")
                else OcrReviewBridge.show(host, input.bill)
            }
        }
    }
}
