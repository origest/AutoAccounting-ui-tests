package net.ankio.auto.service.ocr

import android.content.Context
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import net.ankio.auto.ai.review.*
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.dialog.BillEditorDialog
import net.ankio.auto.ui.utils.ToastUtils
import org.ezbook.server.constant.BillState
import org.ezbook.server.db.Db
import org.ezbook.server.db.model.BillInfoModel

/** History contains only a one-way capture fingerprint and local draft ID, never bill text. */
object OcrReviewBridge {
    fun begin(context: Context, fingerprint: String): AiReviewClaim = AiReviewStore(context).use {
        val record = it.create(AiReviewTarget("ocr-local", 0, 0, fingerprint), AiReviewKind.OCR)
        it.claim(record.id) ?: error("OCR_REVIEW_ALREADY_STARTED")
    }
    fun ready(context: Context, claim: AiReviewClaim, billId: Long) = AiReviewStore(context).use {
        check(it.review(claim, listOf(AiReviewChange("OCR_BILL", "", billId.toString()))))
    }
    fun fail(context: Context, claim: AiReviewClaim?, code: String) {
        if (claim != null) AiReviewStore(context).use { it.fail(claim, code) }
    }
    fun findReview(context: Context, fingerprint: String): String? = AiReviewStore(context).use {
        it.findOcrReview(fingerprint)
    }
    /** A numeric row ID alone is not identity after a local database reset or replacement. */
    internal fun matchesLocalDraft(record: AiReviewRecord, mappedId: Long?, draftId: Long): Boolean =
        record.kind == AiReviewKind.OCR && record.target.source == "ocr-local" && draftId > 0 && mappedId == draftId &&
            (record.changes.isEmpty() || record.changes.singleOrNull()?.let {
                it.field == "OCR_BILL" && it.after == draftId.toString()
            } == true)

    fun register() {
        OcrPendingCategoryReview.register()
        AiReviewRegistry.register(AiReviewKind.OCR) { host, record ->
            host.lifecycleScope.launch {
                val bill = withContext(Dispatchers.IO) {
                    if (!Db.isAvailable()) null else {
                        // A process death after Room commit but before history update must not resend.
                        val mappedId = Db.get().settingDao().query("owner_ocr_text_draft_${record.target.fingerprint}")?.value?.toLongOrNull()
                        val id = record.changes.singleOrNull()?.takeIf { it.field == "OCR_BILL" }?.after?.toLongOrNull() ?: mappedId
                        val draft = (if (id != null) Db.get().billInfoDao().queryId(id) else null)
                            ?.takeIf { matchesLocalDraft(record, mappedId, it.id) }
                        if (draft != null) {
                            AiReviewStore(host).use { it.reconcileOcrDraft(record.id, draft.id,
                                draft.state == BillState.Edited || draft.state == BillState.Synced) }
                        }
                        draft
                    }
                }
                if (bill == null) ToastUtils.error("没有可恢复的账单草稿。原始记录仍可在数据页查看；不会自动重发。")
                else if (bill.state != BillState.Wait2Edit) {
                    markSaved(host, record.id, false)
                    ToastUtils.info("该账单已在本机确认，请到对应账单查看。")
                } else show(host, bill, record.id)
            }
        }
    }
    fun show(context: Context, bill: BillInfoModel, reviewId: String? = null) {
        val original = bill.copy()
        var confirmed = false
        BaseSheetDialog.create<BillEditorDialog>(context).setBillInfo(bill)
            .setOnConfirm { saved ->
                confirmed = true
                if (reviewId != null) markSaved(context, reviewId,
                    saved.type != original.type || saved.money != original.money || saved.time != original.time ||
                        saved.cateName != original.cateName || saved.bookName != original.bookName ||
                        saved.accountNameFrom != original.accountNameFrom || saved.accountNameTo != original.accountNameTo)
            }
            .setOnDismiss {
                if (!confirmed && reviewId != null) runCatching { AiReviewStore(context).use { it.defer(reviewId) } }
            }.show()
    }
    private fun markSaved(context: Context, id: String, manual: Boolean) {
        runCatching {
            AiReviewStore(context).use {
                val token = it.beginApply(id) ?: return@use
                check(it.finishApply(id, token, if (manual) AiReviewState.MANUAL else AiReviewState.APPLIED))
            }
        }.onFailure { ToastUtils.error("账单已保存，但 AI 历史状态更新未确认，请检查列表。") }
    }
}
