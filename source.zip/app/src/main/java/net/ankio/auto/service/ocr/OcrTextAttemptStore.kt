package net.ankio.auto.service.ocr

import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.security.MessageDigest

/** No OCR text, model output or credentials. Dispatch is durable before a possibly billable call. */
internal class OcrTextAttemptStore(context: Context, name: String = "ocr-text-attempts.db") :
    SQLiteOpenHelper(context, File(context.noBackupFilesDir, name).path, null, 1) {
    data class Attempt(val state: String, val rawId: Long, val billId: Long)
    enum class Claim { ACCEPTED, DUPLICATE, LIMIT }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE attempt (fingerprint TEXT PRIMARY KEY, state TEXT NOT NULL, sent INTEGER NOT NULL, raw_id INTEGER NOT NULL, bill_id INTEGER NOT NULL DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = error("Unsupported attempt migration")
    fun find(key: String): Attempt? = readableDatabase.rawQuery(
        "SELECT state,raw_id,bill_id FROM attempt WHERE fingerprint=?", arrayOf(key)
    ).use { if (it.moveToFirst()) Attempt(it.getString(0), it.getLong(1), it.getLong(2)) else null }
    fun claim(key: String, rawId: Long, now: Long, limit: Int): Claim {
        require(limit in 1..60)
        val db = writableDatabase
        db.beginTransaction()
        try {
            if (find(key) != null) return Claim.DUPLICATE
            val used = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM attempt WHERE sent>=?", arrayOf((now - 3_600_000).toString()))
            if (used >= limit || DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM attempt", null) >= 10_000) return Claim.LIMIT
            db.insertOrThrow("attempt", null, ContentValues().apply {
                put("fingerprint", key); put("state", "DISPATCHED"); put("sent", now); put("raw_id", rawId)
            })
            db.setTransactionSuccessful()
            return Claim.ACCEPTED
        } finally { db.endTransaction() }
    }
    fun finish(key: String, state: String, billId: Long = 0): Boolean {
        require(state in setOf("SUCCEEDED", "NO_RESULT", "UNKNOWN", "CANCELLED"))
        return writableDatabase.update("attempt", ContentValues().apply {
            put("state", state); put("bill_id", billId)
        }, "fingerprint=? AND state='DISPATCHED'", arrayOf(key)) == 1
    }
    companion object {
        fun fingerprint(app: String, text: String, type: String = "OCR"): String = MessageDigest.getInstance("SHA-256")
            .digest((type + "\u0000" + app + "\u0000" + text.trim()).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}
