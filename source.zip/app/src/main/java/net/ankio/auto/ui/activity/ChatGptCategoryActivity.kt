package net.ankio.auto.ui.activity

import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import net.ankio.chatgpt.*
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.ai.review.AiReviewActivity
import net.ankio.auto.ai.review.AiReviewPolicy
import net.ankio.auto.ai.review.AssetAutomaticConsent
import net.ankio.auto.service.ocr.ChatGptOcrTextPipeline
import net.ankio.auto.ui.api.BaseActivity
import net.ankio.auto.ui.utils.SettingsPage
import net.ankio.auto.utils.PrefManager
import java.util.concurrent.Executors

/** Dedicated account UI: credentials never enter general API-key settings, logs or intents. */
class ChatGptCategoryActivity : BaseActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var destroyed = false
    @Volatile private var loginPending = false
    private val modelRefreshRequests = ModelRefreshRequests()
    private var busy = false
    private var accounts: ChatGptAccounts? = null
    private var rows = emptyList<ChatGptAccounts.AccountView>()
    private var models = emptyList<ProbeModel>()
    private lateinit var status: TextView
    private lateinit var accountPicker: Spinner
    private lateinit var modelPicker: Spinner
    private lateinit var modelStatus: TextView
    private lateinit var sendingToggle: MaterialSwitch
    private lateinit var sendingStatus: TextView
    private lateinit var ocrToggle: MaterialSwitch
    private lateinit var ocrStatus: TextView
    private lateinit var ocrRetry: Button
    private var ocrWarning: String? = null
    private lateinit var assetSendingToggle: MaterialSwitch
    private lateinit var assetSendingStatus: TextView
    private lateinit var assetRetry: Button
    private var assetWarning: String? = null
    private val reviewPolicy by lazy { AiReviewPolicy(this) }
    private val policyToggles = linkedMapOf<AiReviewPolicy.Key, MaterialSwitch>()
    private lateinit var policyStatus: TextView
    private var policyWarning: String? = null
    private val actions = mutableListOf<Button>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val page = SettingsPage(this, "ChatGPT 设置")
        fun button(text: String, primary: Boolean = false, click: () -> Unit) = page.button(text, primary, click).also { actions.add(it) }
        page.section("ChatGPT 服务", "分类数据与 OCR 完整文字分别授权。OCR 先在本机识别并匹配规则，只有规则无法生成账单时才使用已单独授权的文字分析；不上传截图。资产映射和月度总结仍需单独配置。")
        val mode = "${PrefManager.workMode.name}：规则优先，仅“其他／其它”进入 AI 分类"
        page.text(mode)
        status = page.text("正在读取本地账号…")
        status.accessibilityLiveRegion = android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE
        page.section("1 · 登录账号", "登录只建立账号连接，不会发送账单。凭据加密保存在主应用中。")
        accountPicker = page.spinner("当前账号")
        button("切换到所选账号（先暂停分类）") {
            val key = rows.getOrNull(accountPicker.selectedItemPosition)?.key ?: return@button
            runTask {
                stopQueue(); accounts!!.select(key); models = emptyList()
                refreshModels("已切换账号并更新模型；请重新确认数据发送。")
            }
        }
        button("Continue with ChatGPT", true) { confirmLogin(false) }
        button("添加其他 ChatGPT 账号") { confirmLogin(true) }
        page.section("2 · 模型与发送授权", "登录完成返回后自动刷新模型，也可手动刷新。开关显示实际许可；登录不会开启发送。允许发送数据后，还需单独选择自动处理或历史批次。")
        button("刷新可用模型") { runTask("正在刷新可用模型…") { refreshModels() } }
        modelPicker = page.spinner("当前账号模型（分类与 OCR 文字共用）")
        modelStatus = page.text("登录完成后自动读取模型。")
        button("保存模型，不开启发送") {
            val model = models.getOrNull(modelPicker.selectedItemPosition) ?: return@button
            runTask {
                stopQueue()
                accounts!!.selectModel(model.slug)
                render("模型已保存，发送许可保持关闭。可对单条原始数据逐次确认 AI 识别。")
            }
        }
        sendingToggle = page.toggle("允许发送账单分类数据") { enabled ->
            if (enabled) confirmSending() else pauseClassification()
        }
        sendingStatus = page.text("未开启：不会发送账单分类数据。")
        page.section("OCR 文字识别许可", "仅 OCR 模式。此开关与账单分类发送许可独立；关闭后不会自动改用其他服务商。")
        ocrToggle = page.toggle("允许发送 OCR 文字生成账单") { enabled ->
            if (enabled) confirmOcrSending() else pauseOcrSending()
        }
        ocrStatus = page.text("未开启：不向 ChatGPT 发送 OCR 原文。")
        ocrRetry = page.button("重试保存 OCR 暂停状态") { pauseOcrSending() }
        ocrRetry.visibility = android.view.View.GONE
        button("改回原有规则／API 识别路线") {
            MaterialAlertDialogBuilder(this).setTitle("停止 ChatGPT OCR 文字路线？")
                .setMessage("先撤销 OCR 文字许可，再恢复原有规则及 API 配置。此操作本身不发送账单；之后的处理取决于你已有的 API 与识别开关。")
                .setNegativeButton("取消", null).setPositiveButton("切换") { _, _ -> runTask {
                    ChatGptOcrTextPipeline.useLegacy(applicationContext)
                    ocrWarning = null
                    render("已恢复原有识别路线，请检查原 API 与识别设置。")
                } }.show()
        }
        page.section("自动资产线索发送许可", "仅在已经授权的自动队列范围内处理原类别为“其他／其它”的账单。支付方式信息须单独同意；生成建议不代表自动应用或自动创建资产。")
        assetSendingToggle = page.toggle("允许自动发送支付方式线索") { enabled ->
            if (enabled) confirmAssetSending() else pauseAssetSending()
        }
        assetSendingStatus = page.text("未开启：不会自动发送支付方式线索。")
        assetRetry = page.button("重试关闭自动资产发送") { pauseAssetSending() }
        assetRetry.visibility = android.view.View.GONE
        page.section("3 · 选择处理范围", "自动任务默认关闭；历史账单需先预览数量并确认。已有结果、新建项目如何应用由下方独立开关决定。")
        button("自动识别队列：等待／正在识别", true) { openReview() }
        button("待确认") { openReview("pending") }
        button("识别与修改历史") { openReview("history") }
        button("自动分类来源与历史补识别") { startActivity(Intent(this, net.ankio.auto.classification.OwnerCategoryActivity::class.java)) }
        page.button("暂停 ChatGPT 分类") { pauseClassification() }
        page.section("4 · 识别结果处理", "发送许可与结果应用分别控制。默认不自动修改已有分类或资产，新建项目默认逐次确认。自动处理仅适用于通过校验的识别结果，操作保留在历史中。")
        fun policy(key: AiReviewPolicy.Key, label: String) {
            policyToggles[key] = page.toggle(label) { enabled -> changeReviewPolicy(key, enabled) }
        }
        policy(AiReviewPolicy.Key.AUTO_APPLY_CATEGORY, "自动应用已有分类建议")
        policy(AiReviewPolicy.Key.AUTO_APPLY_ASSETS, "自动应用已有资产建议")
        policy(AiReviewPolicy.Key.PROMPT_NEW_CATEGORY, "创建新类别前弹窗确认")
        policy(AiReviewPolicy.Key.PROMPT_NEW_ASSET, "创建新资产前弹窗确认")
        policyStatus = page.text("已有分类与资产默认待确认；新建类别与资产默认弹窗确认。")
        page.section("账号与控制", "暂停不会删除账单，也不会自动改用其他服务商。")
        button("退出当前账号并尝试撤销授权") {
            MaterialAlertDialogBuilder(this).setMessage("停止分类并清除本地令牌，尝试撤销当前会话。网络失败时需在 ChatGPT 设置中断开应用；不会删除任何账单。")
                .setPositiveButton("退出") { _, _ -> runTask {
                    stopQueue()
                    val revoked = accounts!!.signOut()
                    models = emptyList()
                    render(if (revoked) "本地已退出，ChatGPT 已确认撤销会话。"
                        else "本地凭据已清除；ChatGPT 远程撤销未确认，请在 ChatGPT 设置中断开应用。")
                } }
                .setNegativeButton("取消", null).show()
        }
        button("打开 ChatGPT 用量与授权设置") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/#settings"))) }
        button("取消正在进行的登录") {
            if (loginPending) { accounts?.cancel(); loginPending = false; modelRefreshRequests.complete(); render("登录已取消，旧授权页不再有效。") }
        }.also { actions.remove(it) }
        page.section("高级操作", "仅在确有需要时重置凭据。截图不外发；其他 AI 功能仍使用普通 API 配置。")
        button("改用 API 服务分类") {
            MaterialAlertDialogBuilder(this).setTitle("切换分类服务？").setMessage("暂停 ChatGPT 队列并撤销其分类许可，改用 AI 配置中的 API 服务。历史数据发送授权会关闭，需要重新确认。不会发送测试账单。")
                .setNegativeButton("取消", null).setPositiveButton("切换") { _, _ -> runTask {
                    stopQueue()
                    accounts!!.pause()
                    PrefManager.aiCategoryChatGpt = false; PrefManager.aiCategoryHistory = false
                    render("已改用 API 分类；请返回 AI 助理检查 API 配置及分类开关。")
                } }.show()
        }
        button("重置本地 ChatGPT 凭据（存储损坏时）") {
            MaterialAlertDialogBuilder(this).setMessage("只删除本应用的 ChatGPT 账号与本地令牌，不删除账单。远程撤销无法保证，请在 ChatGPT 设置中断开应用。确定重置？")
                .setPositiveButton("重置") { _, _ -> runTask {
                    stopQueue()
                    ChatGptAccounts.clearLocalCredentials(applicationContext)
                    accounts = ChatGptAccounts.get(applicationContext); models = emptyList(); render("本地已重置；远程授权请自行断开。")
                } }.setNegativeButton("取消", null).show()
        }.also { actions.remove(it) }
        runTask("正在读取本地账号…") { accounts = ChatGptAccounts.get(applicationContext); render() }
    }
    private fun openReview(tab: String? = null) {
        startActivity(Intent(this, AiReviewActivity::class.java).apply { if (tab != null) putExtra("tab", tab) })
    }
    private fun changeReviewPolicy(key: AiReviewPolicy.Key, enabled: Boolean) {
        fun save() {
            val saved = runCatching { reviewPolicy.set(key, enabled) }.getOrDefault(false)
            policyWarning = if (saved) null else "设置未能完整保存；请重试。当前显示运行中读取的状态，不代表重启后已保存。"
            updatePolicySwitches()
        }
        val message = when {
            key == AiReviewPolicy.Key.AUTO_APPLY_CATEGORY && enabled ->
                "校验通过的已有类别建议将自动应用到允许处理的账单，不再逐笔等待确认。不会借此创建新类别，也不会扩大账单发送范围。修改会记录到历史。"
            key == AiReviewPolicy.Key.AUTO_APPLY_ASSETS && enabled ->
                "校验通过的已有资产建议将自动应用到允许处理的账单，不再逐笔等待确认。不会借此创建新资产，也不会扩大数据发送范围。修改会记录到历史。"
            key == AiReviewPolicy.Key.PROMPT_NEW_CATEGORY && !enabled ->
                "关闭确认后，通过校验的新类别建议将自动创建为本地类别并应用，操作保留在历史中。不再逐次弹窗；外部记账应用可能仍需单独同步。是否允许自动创建？"
            key == AiReviewPolicy.Key.PROMPT_NEW_ASSET && !enabled ->
                "关闭确认后，通过校验的新资产建议将自动创建为本地资产并应用，操作保留在历史中。不再逐次弹窗；不会开立真实金融账户，外部记账应用可能仍需单独同步。是否允许自动创建？"
            else -> null
        }
        if (message == null) save() else MaterialAlertDialogBuilder(this).setTitle("确认改变自动处理规则")
            .setMessage(message).setNegativeButton("取消", null).setPositiveButton("确认启用") { _, _ -> save() }.show()
    }
    private fun updatePolicySwitches() {
        policyToggles.forEach { (key, toggle) ->
            toggle.isChecked = reviewPolicy.get(key)
            toggle.isEnabled = !busy
        }
        policyStatus.text = reviewPolicy.warning() ?: policyWarning ?: "关闭自动应用：结果进入待确认。开启新建弹窗：逐次确认；关闭新建弹窗：仅对通过校验的建议自动创建，并记录历史。"
    }
    private fun confirmSending() {
        if (busy) return
        val model = selectedModelForConsent() ?: return
        val consentStamp = net.ankio.auto.classification.OwnerCategoryQueue.stamp()
        val accountKey = accounts?.view()?.active
        MaterialAlertDialogBuilder(this).setTitle("确认发送账单信息并使用计划额度")
            .setMessage("将向 OpenAI 发送当前账单的商户、商品、收支类型、可用类别，以及同账本同类型最多 20 条相关历史的商户、商品和分类。不发送金额、账号、订单号、备注或原始通知字段；文字仍可能含个人信息。会消耗 ChatGPT 计划额度。只用于历史辅助分类，结果应用与新类别创建遵循下方独立开关，默认待确认。开启前会暂停当前任务及 OCR 文字发送，并关闭其他 AI 识别与总结开关；若需两者同时使用，请先开启分类，再单独开启 OCR 文字许可。可随时暂停；不会自动启用其他 AI 功能。")
            .setPositiveButton("同意发送分类数据") { _, _ -> runTask {
                synchronized(net.ankio.auto.classification.OwnerCategoryQueue) {
                    check(consentStamp == net.ankio.auto.classification.OwnerCategoryQueue.stamp())
                    check(accountKey == accounts!!.view().active)
                    stopQueue()
                    accounts!!.enable(model.slug)
                    PrefManager.aiCategoryChatGpt = true
                    PrefManager.aiCategoryHistory = true
                    PrefManager.aiCategoryRecognition = true
                    PrefManager.aiBillRecognition = false
                    PrefManager.aiVisionRecognition = false
                    PrefManager.aiAssetMapping = false
                    PrefManager.aiMonthlySummary = false
                    PrefManager.featureAiAvailable = true
                    render("账号分类许可已开启；请进入队列页确认自动处理或历史批次。")
                }
            } }.setNegativeButton("取消", null).show()
    }
    private fun confirmOcrSending() {
        if (busy) return
        if (!WorkMode.isOcr()) { status.text = "OCR 文字识别仅在 OCR 工作模式下启用。"; return }
        val model = selectedModelForConsent() ?: return
        val accountKey = accounts?.view()?.active
        val consentStamp = net.ankio.auto.classification.OwnerCategoryQueue.stamp()
        val cap = ChatGptOcrTextPipeline.hourlyLimit(this)
        MaterialAlertDialogBuilder(this).setTitle("单独允许发送 OCR 完整文字？")
            .setMessage("仅在 OCR 模式中，先使用本机规则；规则无法生成账单时，向 OpenAI 发送本机 OCR 识别的完整文字和当前账本可用类别，用于生成账单及类别建议。文字可能含金额、商户、商品、交易时间、收付款方式、账号、订单及其他个人信息。不会上传截图。\n\n会使用 ChatGPT 计划额度，每小时最多 $cap 次尝试，失败也计数，不自动重试。生成的账单保留待确认；新类别创建遵循独立开关，默认逐次确认。该许可不包含在分类发送授权中。\n\n开启会取消正在处理的请求。切换账号、退出、暂停或关闭本功能会停止后续发送；已发出的请求不能撤回，也可能已消耗额度。关闭后不会自动回退其他服务商。")
            .setNegativeButton("取消", null).setPositiveButton("同意发送 OCR 文字") { _, _ -> runTask {
                synchronized(net.ankio.auto.classification.OwnerCategoryQueue) {
                    check(accountKey == accounts!!.view().active)
                    check(consentStamp == net.ankio.auto.classification.OwnerCategoryQueue.stamp())
                    check(cap == ChatGptOcrTextPipeline.hourlyLimit(this))
                    ChatGptOcrTextPipeline.enable(applicationContext, model.slug)
                    ocrWarning = null
                    render("OCR 文字许可已更新；请查看当前开关。截图仍只保存在本机。")
                }
            } }.show()
    }
    private fun confirmAssetSending() {
        if (busy || !sendingToggle.isChecked || !PrefManager.featureAssetManage) return
        val model = selectedModelForConsent() ?: return
        val accountKey = accounts?.view()?.active
        val stamp = net.ankio.auto.classification.OwnerCategoryQueue.stamp()
        MaterialAlertDialogBuilder(this).setTitle("单独允许自动发送支付方式？")
            .setMessage("仅对已授权队列中原类别为“其他／其它”的规则待编辑主账单，在本机把明确支付方式转成现金、微信余额、支付宝余额、储蓄卡、信用卡或花呗，再只向 OpenAI 发送这项支付方式。不会发送原始账户名、卡号、商户、金额、余额、账本、币种或历史。线索不明确、有多个可能或不能区分银行卡时不猜测。\n\n每笔最多额外一次，资产识别另限每滚动小时最多 10 次，失败也计数，不自动重试；会额外使用当前 ChatGPT 计划额度。不扩大自动队列授权范围。建议默认进入待确认，是否自动应用或新建由下方独立开关决定。\n\n许可绑定当前账号、模型、模式与队列授权。暂停、切换或退出后需重新同意；已发请求不能撤回。")
            .setNegativeButton("取消", null).setPositiveButton("同意发送支付方式") { _, _ -> runTask {
                synchronized(net.ankio.auto.classification.OwnerCategoryQueue) {
                    check(accountKey == accounts!!.view().active)
                    check(stamp == net.ankio.auto.classification.OwnerCategoryQueue.stamp())
                    check(AssetAutomaticConsent.enable(applicationContext, model.slug))
                    assetWarning = null
                    render("自动资产线索许可已更新；请查看当前开关。处理范围仍由自动队列决定。")
                }
            } }.show()
    }
    private fun pauseAssetSending() {
        val stopped = runCatching { AssetAutomaticConsent.disable(applicationContext) }.getOrDefault(false)
        assetWarning = if (stopped) null else "自动资产发送暂停未能完整保存，请重试关闭；不要把当前暂停视为重启后已保存。"
        render(assetWarning ?: "已阻止后续资产发送与自动应用；已发请求不能撤回，仍可能消耗额度。")
    }
    private fun selectedModelForConsent(): ProbeModel? {
        val model = models.getOrNull(modelPicker.selectedItemPosition)
        if (model == null) { status.text = "请先登录并刷新、选择模型。"; return null }
        val view = accounts?.view()
        val active = view?.accounts?.firstOrNull { it.key == view.active }
        if ((active?.enabled == true || active?.ocrEnabled == true) && active?.model != model.slug) {
            status.text = "当前授权模型已不在可用列表。请先关闭全部发送许可，再选择新模型。"
            return null
        }
        return model
    }
    private fun pauseOcrSending() {
        // Independent revocation stays available while network/model work is busy.
        try {
            ChatGptOcrTextPipeline.disable(applicationContext)
            ocrWarning = null
            render("OCR 文字发送已暂停；已发请求不能撤回，不会自动改用其他服务商。")
        } catch (_: Exception) {
            ocrWarning = "本次运行已阻止 OCR 发送，但暂停未能完整保存；重启后无法保证。请重试关闭，成功前不要重新开启。"
            render(ocrWarning)
        }
    }
    private fun pauseClassification() {
        // Never enqueue stop behind the account/provider worker or disable it while busy.
        modelRefreshRequests.complete()
        try { stopQueue(); render(net.ankio.auto.classification.OwnerCategoryQueue.warning() ?: "本机已暂停，服务端已确认撤销后续写回。") }
        catch (_: Exception) { render(net.ankio.auto.classification.OwnerCategoryQueue.warning() ?: "暂停未完成，请重试。") }
    }
    private fun confirmLogin(new: Boolean) {
        MaterialAlertDialogBuilder(this).setTitle("在系统浏览器授权")
            .setMessage("仅在 auth.openai.com 登录并确认权限。此操作不发送账单；返回后仍需单独同意数据发送。不要复制或分享授权链接。")
            .setPositiveButton("继续") { _, _ ->
                val key = if (new) null else rows.getOrNull(accountPicker.selectedItemPosition)?.key
                loginPending = true
                models = emptyList()
                runTask("正在登录；授权完成后请返回应用，模型将自动刷新。") {
                    try {
                        stopQueue()
                        accounts!!.signIn(key) { url -> runOnUiThread {
                            if (!destroyed && loginPending) {
                                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)) }
                                catch (_: Exception) { accounts?.cancel(); status.text = "无法打开系统浏览器。" }
                            } else accounts?.cancel()
                        } }
                        refreshModels("登录成功，模型已自动更新。发送许可保持关闭，请选择模型并单独开启。")
                    } finally { loginPending = false; modelRefreshRequests.complete() }
                }
            }.setNegativeButton("取消", null).show()
    }
    private fun stopQueue() {
        check(net.ankio.auto.classification.OwnerCategoryQueue.stop(this).localComplete) {
            net.ankio.auto.classification.OwnerQueuePermissions.FAILURE_MESSAGE
        }
    }
    private fun refreshModels(message: String = "模型已更新；开启发送前请确认所选模型。") {
        models = emptyList()
        try {
            models = accounts!!.models()
            render(if (models.isEmpty()) "账号未返回可用模型，请稍后手动刷新。" else message)
        } finally {
            // A return while this request was in flight is satisfied by the same result.
            // Failure remains visible and never causes an automatic retry loop.
            modelRefreshRequests.complete()
        }
    }
    private fun refreshModelsIfNeeded() {
        if (destroyed) return
        val view = accounts?.view()
        val signedIn = view?.accounts?.any { it.key == view.active && it.signedIn } == true
        if (!modelRefreshRequests.takeIfReady(busy, signedIn)) return
        runTask("正在自动刷新可用模型…") { refreshModels() }
    }
    private fun runTask(progress: String = "正在处理…", task: () -> Unit) {
        if (busy) return
        busy = true; actions.forEach { it.isEnabled = false }
        updateSwitches()
        status.text = progress
        worker.execute {
            try { task() } catch (e: Exception) {
                val message = when (e) {
                    is AccountFailure -> when (e.code) {
                        "SIGN_IN_REQUIRED" -> "请先登录 ChatGPT 账号，再刷新模型。"
                        "MODEL_REQUIRED" -> "请刷新模型列表并选择可用模型。"
                        "CLASSIFICATION_PAUSED" -> "分类已暂停，请重新确认发送授权。"
                        "OCR_TEXT_PAUSED" -> "OCR 文字识别已暂停，请单独确认 OCR 文字发送许可。"
                        "CANCELLED" -> "操作已取消；不会自动重试。"
                        "BUSY" -> "账号正在处理其他操作，请稍后再试。"
                        "ACCOUNT_LIMIT" -> "已达到 10 个账号上限，请先退出不再使用的账号。"
                        "ACCOUNT_CHANGED" -> "登录账号与原账号不一致，请使用“添加其他账号”。"
                        "STORE_UNAVAILABLE" -> "本地凭据无法读取；可在高级操作中重置凭据，账单不会删除。"
                        else -> "账号操作未完成（${e.code}），请检查账号状态。"
                    }
                    is DiagnosticFailure -> accounts?.view()?.diagnostic?.takeIf { it.isNotEmpty() } ?: Diagnostics.render(ProbeStage.CALLBACK, e)
                    else -> "操作未完成；未输出异常内容。"
                }
                render(net.ankio.auto.classification.OwnerCategoryQueue.warning() ?: message)
            } finally { runOnUiThread { if (!destroyed) {
                busy = false; actions.forEach { it.isEnabled = accounts != null }
                updateSwitches()
                refreshModelsIfNeeded()
            } } }
        }
    }
    private fun updateSwitches() {
        val view = accounts?.view()
        val active = view?.accounts?.firstOrNull { it.key == view.active }
        val enabled = active?.signedIn == true && active.enabled && PrefManager.aiCategoryChatGpt &&
            PrefManager.featureAiAvailable && PrefManager.aiCategoryRecognition && PrefManager.aiCategoryHistory
        sendingToggle.isChecked = enabled
        // Revocation remains available during a slow model request.
        sendingToggle.isEnabled = enabled || (!busy && active?.signedIn == true && models.isNotEmpty())
        sendingStatus.text = net.ankio.auto.classification.OwnerCategoryQueue.warning() ?: if (enabled)
            "已开启：允许使用 ${active?.model.orEmpty()} 发送分类数据。自动处理需另行开启。关闭会暂停剩余分类任务和 OCR 文字发送；关闭全部许可后可更换模型。"
        else "未开启：不会发送账单分类数据。开启时仍需确认数据范围与额度使用。"
        val ocrEnabled = ChatGptOcrTextPipeline.isEnabled(this)
        val ocrProblem = ChatGptOcrTextPipeline.warning() ?: ocrWarning
        ocrToggle.isChecked = ocrEnabled
        ocrToggle.isEnabled = ocrEnabled || (!busy && WorkMode.isOcr() && active?.signedIn == true && models.isNotEmpty() && ocrProblem == null)
        ocrStatus.text = ocrProblem ?: when {
            ocrEnabled && !WorkMode.isOcr() -> "已保留文字许可；当前不是 OCR 模式，不会发送。可关闭以撤销许可。"
            ocrEnabled -> "已开启：规则无法生成账单时发送 OCR 文字，不发送截图。每小时最多 ${ChatGptOcrTextPipeline.hourlyLimit(this)} 次尝试。生成后仍待确认。"
            ChatGptOcrTextPipeline.isSelected(this) -> "已暂停 OCR 文字发送；原文保留在本机，不自动改用其他服务商。"
            else -> "未开启：不向 ChatGPT 发送 OCR 原文。"
        }
        ocrRetry.visibility = if (ocrProblem == null) android.view.View.GONE else android.view.View.VISIBLE
        val assetEnabled = AssetAutomaticConsent.isEnabled(this)
        val assetProblem = AssetAutomaticConsent.warning() ?: assetWarning
        assetSendingToggle.isChecked = assetEnabled
        assetSendingToggle.isEnabled = assetEnabled || (!busy && enabled && PrefManager.featureAssetManage && models.isNotEmpty() && assetProblem == null)
        assetSendingStatus.text = assetProblem ?: when {
            assetEnabled -> "已开启：仅发送本机归一后的明确支付方式。资产结果是否自动应用或创建，由独立开关决定。"
            !PrefManager.featureAssetManage -> "未开启：请先启用本应用的资产管理功能，再确认自动资产线索发送。"
            !enabled -> "未开启：需先开启分类发送许可，再单独确认支付方式信息发送。"
            else -> "未开启：不会自动发送支付方式线索。"
        }
        assetRetry.visibility = if (assetProblem == null) android.view.View.GONE else android.view.View.VISIBLE
        accountPicker.isEnabled = !busy
        modelPicker.isEnabled = !busy && models.isNotEmpty() && !enabled && !ocrEnabled && !assetEnabled
        updatePolicySwitches()
    }
    private fun render(message: String? = null) {
        runOnUiThread {
            if (destroyed) return@runOnUiThread
            // Read here, not before posting: a later pause must win over a queued render.
            val view = accounts?.view()
            rows = view?.accounts.orEmpty()
            accountPicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rows.map { it.label }.ifEmpty { listOf("尚未登录") })
            val selected = rows.indexOfFirst { it.key == view?.active }
            if (selected >= 0) accountPicker.setSelection(selected)
            modelPicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, models.map { it.toString() }.ifEmpty { listOf("登录后刷新模型") })
            val active = rows.getOrNull(selected)
            val currentModel = models.indexOfFirst { it.slug == active?.model }
            if (currentModel >= 0) modelPicker.setSelection(currentModel)
            modelStatus.text = when {
                models.isEmpty() && active?.signedIn == true -> "尚无可用模型；自动刷新失败时可使用上方按钮重试。"
                models.isEmpty() -> "登录完成后自动读取模型。"
                (active?.enabled == true || active?.ocrEnabled == true) && currentModel < 0 ->
                    "当前授权模型 ${active?.model.orEmpty()} 已不在本次列表。请关闭全部发送许可后选择新模型。"
                active?.enabled == true || active?.ocrEnabled == true -> "当前授权模型：${active?.model.orEmpty()}。更换前请先关闭全部发送许可。"
                else -> "选择模型后，分别确认需要开启的发送许可。"
            }
            updateSwitches()
            val queueWarning = net.ankio.auto.classification.OwnerCategoryQueue.warning()
            val detail = message ?: view?.diagnostic.orEmpty()
            status.text = (net.ankio.auto.classification.OwnerCategoryQueue.warning() ?: message ?: view?.diagnostic.orEmpty().ifEmpty { "尚未授权。" }) +
                (if (queueWarning != null && detail.isNotBlank() && detail != queueWarning) "\n$detail" else "") +
                (active?.let { "\n当前：${it.label}；${if (it.signedIn) "已登录" else "未登录"}；${if (sendingToggle.isChecked) "已允许发送分类数据" else "未允许发送分类数据"}" } ?: "") +
                "\n自动任务：" + if (net.ankio.auto.classification.OwnerCategoryQueue.enabled(this) && net.ankio.auto.classification.OwnerCategoryQueue.prefs(this).getBoolean("automatic", false)) "已授权" else "未授权或已暂停"
        }
    }
    override fun onResume() {
        super.onResume()
        // Covers an existing account, browser return and Activity recreation. Busy login
        // defers this refresh until completion, rather than dropping the resume event.
        modelRefreshRequests.request()
        if (accounts != null) render()
        refreshModelsIfNeeded()
    }
    override fun onDestroy() {
        destroyed = true
        if (loginPending) accounts?.cancel()
        worker.shutdownNow()
        super.onDestroy()
    }
}
