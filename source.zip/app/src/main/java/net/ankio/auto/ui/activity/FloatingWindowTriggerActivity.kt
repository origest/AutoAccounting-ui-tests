package net.ankio.auto.ui.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import net.ankio.auto.R
import net.ankio.auto.service.CoreService
import net.ankio.auto.storage.Constants
import net.ankio.auto.storage.Logger
import net.ankio.auto.ui.api.BaseActivity

class FloatingWindowTriggerActivity : BaseActivity() {

    companion object {
        private const val WINDOW_SIZE = 1
        private const val INTENT_TYPE_KEY = "intentType"
    }

    private var confirmingOcr = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.TransparentActivityTheme)
        createOnePxWindow()
    }

    private fun createOnePxWindow() {
        window.apply {
            setGravity(Gravity.START or Gravity.TOP)
            attributes = attributes.apply {
                x = 0
                y = 0
                width = WINDOW_SIZE
                height = WINDOW_SIZE
                type =
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            }
        }
    }

    override fun onStart() {
        super.onStart()
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        // 处理创建快捷方式的请求（兼容老式启动器）
        if (intent.action == Intent.ACTION_CREATE_SHORTCUT) {
            createShortcutResult()
            return
        }

        val type = intent.getStringExtra(INTENT_TYPE_KEY)
        Logger.i("处理Intent: 类型=$type")

        // This Activity is exported. An external caller's manual=true is not user consent
        // to capture/send screen text or consume the signed-in account's plan.
        if (type == "OCR" && net.ankio.auto.constant.WorkMode.isOcr() &&
            net.ankio.auto.service.ocr.ChatGptOcrTextPipeline.isSelected(this)) {
            if (confirmingOcr) return
            confirmingOcr = true
            window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("开始 OCR 文字识别？")
                .setMessage("返回支付页面后截取当前屏幕。若规则无法识别且你已单独授权，将把识别文字发送给 OpenAI 生成账单建议并使用 ChatGPT 额度，不上传图片。")
                .setPositiveButton("开始") { _, _ ->
                    // Only a visible affirmative action reaches the protected new path.
                    val appContext = applicationContext
                    val safeIntent = Intent(appContext, CoreService::class.java).apply {
                        putExtra(INTENT_TYPE_KEY, "OCR"); putExtra("manual", true)
                    }
                    exitActivity()
                    // Let the confirmation window leave before capturing the underlying page.
                    android.os.Handler(mainLooper).postDelayed({
                        runCatching { appContext.startForegroundService(safeIntent) }
                    }, 350)
                }
                .setNegativeButton("取消") { _, _ -> exitActivity() }
                .setOnCancelListener { exitActivity() }
                .show()
            return
        }

        // https://stackoverflow.com/questions/46173460/why-does-settings-candrawoverlays-method-in-android-8-returns-false-when-use
        // 应该是安卓的历史遗留问题
        // 取消悬浮窗权限检查，直接在服务里面catch权限异常进行跳转

        // 3. 确保服务就绪后启动服务
        Logger.i("服务就绪，启动CoreService")
        try {
            CoreService.start(this, intent)
            Logger.i("成功启动CoreService")
        } catch (e: Exception) {
            Logger.e("启动服务失败: ${e.message}", e)
        } finally {
            exitActivity()
        }
    }

    /**
     * 创建快捷方式的返回结果
     * 用于兼容老式启动器的 CREATE_SHORTCUT 机制
     */
    @Suppress("DEPRECATION")
    private fun createShortcutResult() {
        // 创建启动 OCR 功能的 Intent
        val launchIntent = Intent(this, FloatingWindowTriggerActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            putExtra(INTENT_TYPE_KEY, "OCR")
            putExtra("manual", true)
        }

        // 创建快捷方式的 Intent
        val shortcutIntent = Intent().apply {
            putExtra(Intent.EXTRA_SHORTCUT_INTENT, launchIntent)
            putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.ocr_shortcut_short_label))
            putExtra(
                Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                Intent.ShortcutIconResource.fromContext(
                    this@FloatingWindowTriggerActivity,
                    R.drawable.ic_ocr
                )
            )
        }

        setResult(RESULT_OK, shortcutIntent)
        finish()
    }

    private fun exitActivity() {
        finish()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // API 34+：新接口，第 3 个参数是背景色，传 0 表示不覆盖默认
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
        } else {
            @Suppress("DEPRECATION")
            // 旧接口：禁用入/出场动画
            overridePendingTransition(0, 0)
        }
        window.setWindowAnimations(0)
    }


}
