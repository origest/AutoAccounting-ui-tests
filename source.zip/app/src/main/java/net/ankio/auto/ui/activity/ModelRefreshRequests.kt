package net.ankio.auto.ui.activity

/** Coalesces lifecycle returns without losing one while account loading/login is busy. */
internal class ModelRefreshRequests {
    private var pending = false

    @Synchronized fun request() { pending = true }

    @Synchronized fun takeIfReady(busy: Boolean, signedIn: Boolean): Boolean {
        if (busy || !pending) return false
        pending = false
        return signedIn
    }

    /** A completed attempt, including failure or cancellation, must not auto-retry. */
    @Synchronized fun complete() { pending = false }
}
