package net.ankio.auto.ui.api

import android.os.Bundle
import android.os.Parcelable
import android.view.View
import androidx.core.os.BundleCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.viewbinding.ViewBinding
import net.ankio.auto.R
import net.ankio.auto.storage.Logger
import net.ankio.auto.ui.components.StatusPage
import net.ankio.auto.ui.theme.DynamicColors
import net.ankio.auto.ui.utils.canPreserveLiveScroll
import net.ankio.auto.utils.CoroutineUtils.withIO
import kotlin.coroutines.cancellation.CancellationException

/**
 * 基础分页Fragment抽象类
 *
 * 提供通用的分页加载功能，包括：
 * - 下拉刷新
 * - 上拉加载更多
 * - 加载状态管理
 * - 错误处理和空状态显示
 *
 * @param T 数据项的类型
 * @param VB ViewBinding的类型
 */
abstract class BasePageFragment<T, VB : ViewBinding> : BaseFragment<VB>() {

    /** 当前页码，从1开始 */
    var page = 1

    /** 每页数据条数 */
    open val pageSize = 100

    /**
     * 加载数据的抽象方法，子类需要实现
     * @return 返回当前页的数据列表
     */
    abstract suspend fun loadData(): List<T>

    /**
     * 创建RecyclerView适配器的抽象方法，子类需要实现
     * @return 返回适配器实例
     */
    abstract fun onCreateAdapter(): RecyclerView.Adapter<*>

    /** 是否正在加载数据 */
    protected var isLoading = false

    protected var loadJob: Job? = null

    // A cancelled request may still complete in a transport that ignores cancellation.
    private var loadGeneration = 0L

    protected open val loadOnViewCreated = true

    // Only pages that reload their saved prefix should restore pagination across instances.
    protected open val restorePageState = false

    /** Capture mutable filter/page inputs on the UI thread before dispatching to IO. */
    protected open fun createDataLoader(): suspend () -> List<T> = { loadData() }

    protected open fun itemKey(item: T): Any? = null

    protected open fun sameItems(old: List<T>, new: List<T>): Boolean = old == new

    /** 是否还有更多数据可以加载 */
    private var hasMoreData = true

    /** 状态页面组件，用于显示加载、错误、空状态 */
    private var _statusPage: StatusPage? = null

    /** 下拉刷新组件 */
    private var _swipeRefreshLayout: SwipeRefreshLayout? = null

    /** RecyclerView实例 */
    private var recyclerView: RecyclerView? = null

    /** 适配器实例 */
    private var adapter: RecyclerView.Adapter<*>? = null

    private var baseAdapter: BaseAdapter<*, T>? = null

    /** RecyclerView滚动位置状态 */
    private var recyclerViewState: Parcelable? = null

    private companion object {
        const val STATE_PAGE = "BasePageFragment.page"
        const val STATE_SCROLL = "BasePageFragment.scroll"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (restorePageState && savedInstanceState != null) {
            page = savedInstanceState.getInt(STATE_PAGE, 1).coerceAtLeast(1)
            recyclerViewState = BundleCompat.getParcelable(
                savedInstanceState, STATE_SCROLL, Parcelable::class.java
            )
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (restorePageState) {
            saveScrollPosition()
            outState.putInt(STATE_PAGE, page.coerceAtLeast(1))
            outState.putParcelable(STATE_SCROLL, recyclerViewState)
        }
    }

    /** 状态页面的公共访问器 */
    val statusPage get() = _statusPage!!

    /** 下拉刷新组件的公共访问器 */
    val swipeRefreshLayout get() = _swipeRefreshLayout!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 初始化核心UI组件
        initializeComponents(view)

        // 设置适配器和数据绑定
        setupAdapter()

        // 配置事件监听器
        setupEventListeners()

        // 如果已有数据（例如从其他Fragment返回后视图重建），直接展示并恢复滚动位置
        if (baseAdapter?.itemCount ?: 0 > 0) {
            Logger.d("检测到已有数据，跳过初始加载")
            restoreScrollPosition()
        } else if (loadOnViewCreated) {
            // 启动首次数据加载
            resetPage()
            loadDataInside()
        }
    }

    /**
     * 初始化核心UI组件
     * 获取StatusPage和SwipeRefreshLayout的引用并配置关联关系
     */
    private fun initializeComponents(view: View) {
        _statusPage = view.findViewById(R.id.status_page)
        _swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout)
        _swipeRefreshLayout?.setColorSchemeColors(
            DynamicColors.Primary,
            DynamicColors.PrimaryContainer
        )
        // 关联下拉刷新组件到状态页面
        statusPage.swipeRefreshLayout = _swipeRefreshLayout
        statusPage.showLoading()
    }

    /**
     * 设置RecyclerView适配器
     * 创建适配器实例并绑定到RecyclerView
     */
    private fun setupAdapter() {
        adapter = onCreateAdapter()
        recyclerView = statusPage.contentView
        recyclerView?.adapter = adapter
        @Suppress("UNCHECKED_CAST")
        baseAdapter = adapter as? BaseAdapter<*, T>
    }

    /**
     * 配置所有事件监听器
     * 包括下拉刷新和上拉加载更多
     */
    private fun setupEventListeners() {
        bindLoadDataEvent()
        bindLoadMoreEvent()
    }

    override fun onDestroyView() {
        // 彻底清理资源，防止内存泄漏
        cleanupResources()
        super.onDestroyView()
    }

    /**
     * 清理所有资源引用
     * 移除监听器并置空引用，确保Fragment销毁时无内存泄漏
     */
    private fun cleanupResources() {
        cancelPendingLoad()
        _swipeRefreshLayout?.setOnRefreshListener(null)
        _statusPage?.swipeRefreshLayout = null
        recyclerView?.clearOnScrollListeners()
        // 断开适配器引用，避免 Adapter 持有 Fragment/Activity 导致泄漏
        recyclerView?.adapter = null
        _statusPage = null
        _swipeRefreshLayout = null
        recyclerView = null
        adapter = null
        baseAdapter = null
    }

    /**
     * 重置分页状态
     * 清空页码、数据和适配器，为新的数据加载做准备
     */
    protected fun resetPage() {
        Logger.d("重置分页状态：清空页码和数据")
        page = 1
        baseAdapter?.updateItems(emptyList())
    }

    /**
     * 重新加载数据
     * 重置分页状态并重新开始加载，通常用于下拉刷新
     */
    fun reload() {
        if (!uiReady()) return
        cancelPendingLoad()
        resetPage()
        recyclerViewState = null
        hasMoreData = true
        statusPage.showLoading()
        loadDataInside()
    }

    /** Keep the current content until the new first page has arrived. */
    fun reloadSilently() {
        if (!uiReady()) return
        cancelPendingLoad()
        page = 1
        recyclerViewState = null
        hasMoreData = true
        loadDataInside()
    }

    /** Invalidates both successful and failed late completions, including old callbacks. */
    protected fun cancelPendingLoad(expected: Job? = loadJob) {
        if (expected !== loadJob) return
        loadGeneration++
        loadJob?.cancel()
        loadJob = null
        isLoading = false
        _swipeRefreshLayout?.isRefreshing = false
    }

    /**
     * Refresh an already loaded prefix without resetting pagination or blanking the adapter.
     * The caller supplies an immutable query, and should avoid starting this during a scroll.
     */
    protected fun refreshLoadedData(
        limit: Int,
        loader: suspend () -> List<T>,
        deferWhileScrolling: Boolean = true,
        callback: ((success: Boolean, hasMore: Boolean) -> Unit)? = null
    ): Job? {
        if (!uiReady() || isLoading) {
            callback?.invoke(false, hasMoreData)
            return null
        }
        return startLoad(
            page, limit, replace = true, preservePosition = true, loader = loader,
            deferWhileScrolling = deferWhileScrolling, callback = callback
        )
    }

    protected open fun loadDataInside(callback: ((success: Boolean, hasMore: Boolean) -> Unit)? = null) {
        if (!uiReady() || isLoading) {
            callback?.invoke(false, hasMoreData)
            return
        }
        startLoad(
            page, pageSize, replace = page == 1, preservePosition = false,
            loader = createDataLoader(), callback = callback
        )
    }

    private fun startLoad(
        requestPage: Int,
        limit: Int,
        replace: Boolean,
        preservePosition: Boolean,
        loader: suspend () -> List<T>,
        deferWhileScrolling: Boolean = false,
        callback: ((success: Boolean, hasMore: Boolean) -> Unit)? = null
    ): Job {
        val generation = ++loadGeneration
        isLoading = true
        // LAZY ensures even immediately completed requests see their own installed job.
        val job = viewLifecycleOwner.lifecycleScope.launch(start = CoroutineStart.LAZY) {
            try {
                val result = withIO { loader() }
                coroutineContext.ensureActive()
                if (generation != loadGeneration || !uiReady()) return@launch

                if (deferWhileScrolling && recyclerView?.scrollState != RecyclerView.SCROLL_STATE_IDLE) {
                    return@launch
                }
                val current = baseAdapter?.getItems().orEmpty()
                if (replace) {
                    if (!sameItems(current, result)) {
                        replaceKeepingPosition(result, preservePosition)
                    }
                    if (preservePosition) {
                        page = maxOf(1, (result.size + pageSize - 1) / pageSize)
                    }
                } else {
                    baseAdapter?.submitItems(result)
                }
                hasMoreData = result.size >= limit
                if (getItemCount() == 0) statusPage.showEmpty() else statusPage.showContent()
                callback?.invoke(true, hasMoreData)
                if ((!preservePosition && requestPage == 1) || (preservePosition && current.isEmpty())) {
                    restoreScrollPosition()
                }
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                if (generation != loadGeneration || !uiReady()) return@launch
                // Keep known rows on a passive refresh failure; initial/manual failures have
                // their own error state and are never presented as an empty successful list.
                if (getItemCount() == 0 || !preservePosition && requestPage == 1) {
                    statusPage.showError()
                }
                callback?.invoke(false, hasMoreData)
            } finally {
                if (generation == loadGeneration) {
                    isLoading = false
                    loadJob = null
                    _swipeRefreshLayout?.isRefreshing = false
                }
            }
        }
        loadJob = job
        job.start()
        return job
    }

    private fun replaceKeepingPosition(items: List<T>, preserve: Boolean) {
        val layout = recyclerView?.layoutManager as? LinearLayoutManager
        val first = layout?.findFirstVisibleItemPosition() ?: RecyclerView.NO_POSITION
        val oldItems = baseAdapter?.getItems().orEmpty()
        val oldItem = oldItems.getOrNull(first)
        val key = oldItem?.let(::itemKey)
        val top = layout?.findViewByPosition(first)?.top ?: 0
        val atTop = recyclerView?.canScrollVertically(-1) == false
        baseAdapter?.replaceItems(items)
        // On a new list there is no live anchor. An explicit scroll-to-zero here would
        // invalidate LinearLayoutManager's subsequently restored saved anchor.
        val preserveLivePosition = preserve && canPreserveLiveScroll(
            oldItems.size, first, hasSavedLayout = recyclerViewState != null
        )
        if (preserveLivePosition && layout != null && items.isNotEmpty()) {
            if (atTop) {
                layout.scrollToPositionWithOffset(0, 0)
            } else if (key != null) {
                val anchor = items.indexOfFirst { itemKey(it) == key }
                if (anchor >= 0) {
                    layout.scrollToPositionWithOffset(anchor, top - (recyclerView?.paddingTop ?: 0))
                }
            }
        }
    }


    /**
     * 绑定下拉刷新事件
     * 设置合理的触发距离和防重复处理
     */
    private fun bindLoadDataEvent() {
        statusPage.findViewById<View>(R.id.group_error)?.setOnClickListener { reload() }
        swipeRefreshLayout.setDistanceToTriggerSync(200)
        swipeRefreshLayout.setOnRefreshListener {
            Logger.d("触发下拉刷新")
            reload()
        }
    }

    /**
     * 绑定上拉加载更多事件
     * 智能预加载：距离底部5个item时触发加载
     */
    private fun bindLoadMoreEvent() {
        val recyclerView = statusPage.contentView ?: return
        recyclerView.clearOnScrollListeners()
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                // 快速退出：无更多数据、正在加载或非向下滚动
                if (!hasMoreData || isLoading || dy <= 0) return

                val layoutManager = rv.layoutManager as? LinearLayoutManager ?: return
                val totalItemCount = layoutManager.itemCount
                val lastVisibleItem = layoutManager.findLastVisibleItemPosition()

                // 预加载阈值：距离底部5个item时触发
                if (lastVisibleItem >= totalItemCount - 5) {
                    Logger.d("触发加载更多：当前位置${lastVisibleItem}，总数${totalItemCount}")

                    page++
                    loadDataInside { success, hasMore ->
                        if (!success) {
                            Logger.d("加载更多失败：回退页码")
                            page--
                        }
                        hasMoreData = hasMore
                    }
                }
            }
        })
    }

    // ================================
    // 列表操作辅助函数
    // ================================

    /**
     * 添加单个数据项到列表末尾
     * @param item 要添加的数据项
     */
    protected fun addItem(item: T) {
        baseAdapter?.submitItems(listOf(item))
    }

    /**
     * 添加多个数据项到列表末尾
     * @param items 要添加的数据项列表
     */
    protected fun addItems(items: List<T>) {
        baseAdapter?.submitItems(items)
    }


    /**
     * 移除指定数据项
     * @param item 要移除的数据项
     * @return 是否移除成功
     */
    protected fun removeItem(item: T): Boolean {
        val boolean = baseAdapter?.removeItem(item) ?: false
        if (getItemCount() == 0) {
            statusPage.showEmpty()
        }
        return boolean
    }

    /**
     * 移除指定位置的数据项
     * @param index 要移除的位置
     * @return 被移除的数据项，如果位置无效则返回null
     */
    protected fun removeItemAt(index: Int): T? {
        val item = baseAdapter?.index(index)
        baseAdapter?.removeItem(index)
        if (getItemCount() == 0) {
            statusPage.showEmpty()
        }
        return item
    }

    /**
     * 更新指定位置的数据项
     * @param index 要更新的位置
     * @param item 新的数据项
     * @return 是否更新成功
     */
    protected fun updateItem(index: Int, item: T): Boolean {
        return baseAdapter?.updateItem(index, item) ?: false
    }

    /**
     * 清空所有数据
     */
    protected fun clearItems() {
        baseAdapter?.replaceItems(listOf())
        statusPage.showEmpty()
        Logger.d("清空所有数据项")
    }

    /**
     * 获取数据项数量
     * @return 当前数据项总数
     */
    protected fun getItemCount(): Int = baseAdapter?.itemCount ?: 0

    /**
     * 获取指定位置的数据项
     * @param index 位置索引
     * @return 数据项，如果位置无效则返回null
     */
    protected fun getItem(index: Int): T? {
        return baseAdapter?.index(index)
    }

    /**
     * Fragment暂停时保存滚动位置
     */
    override fun onPause() {
        super.onPause()
        saveScrollPosition()
    }

    private fun saveScrollPosition() {
        val list = recyclerView ?: return
        // Do not replace a pending restored position with an empty, still-loading layout.
        if (getItemCount() > 0 || recyclerViewState == null) {
            recyclerViewState = list.layoutManager?.onSaveInstanceState() ?: recyclerViewState
        }
    }

    /**
     * 恢复滚动位置
     */
    private fun restoreScrollPosition() {
        val state = recyclerViewState ?: return
        statusPage.contentView?.layoutManager?.onRestoreInstanceState(state)
        recyclerViewState = null
    }
}
