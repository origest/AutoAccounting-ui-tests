package net.ankio.auto.ui.dialog

import android.content.Context
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import net.ankio.auto.ai.review.*
import net.ankio.auto.classification.OwnerCategoryQueue
import net.ankio.auto.http.api.AssetsAPI
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.utils.ToastUtils
import net.ankio.auto.utils.PrefManager
import net.ankio.chatgpt.ChatGptAccounts
import org.ezbook.server.ai.tools.AssetSuggestionPolicy
import org.ezbook.server.constant.AssetsType
import org.ezbook.server.constant.Currency
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.AssetSuggestionPreview
import org.ezbook.server.server.AssetSuggestionPreviewRequest

/** Per-request sending consent, durable pending/history, and separately authorized automatic application. */
class AssetSuggestionDialog(
    private val owner: View,
    private val scope: CoroutineScope,
    private val current: () -> BillInfoModel?,
    private val applied: (BillInfoModel) -> Unit
) {
    private val context: Context get() = owner.context
    private var dialog: AlertDialog? = null
    private var selector: AssetsSelectorDialog? = null
    private var task: Job? = null
    private var running = false
    private var generation = 0L
    private var reviewId: String? = null
    private var requestConsent: List<Any?>? = null

    private val attachListener = object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) = Unit
        override fun onViewDetachedFromWindow(v: View) = close()
    }
    init { owner.addOnAttachStateChangeListener(attachListener) }
    fun dispose() { close(); owner.removeOnAttachStateChangeListener(attachListener) }

    fun close() {
        generation++
        reviewId?.let { id -> runCatching { AiReviewStore(context).use { it.defer(id) } } }
        task?.cancel(); task = null
        dialog?.dismiss(); dialog = null
        val previousSelector = selector; selector = null; previousSelector?.dismiss()
        running = false
    }

    private fun consentStamp(): List<Any?> {
        check(PrefManager.featureAiAvailable && PrefManager.aiCategoryChatGpt && PrefManager.aiCategoryHistory &&
            PrefManager.aiCategoryRecognition && PrefManager.featureAssetManage)
        val view = ChatGptAccounts.get(context).view()
        val active = view.accounts.singleOrNull { it.key == view.active && it.enabled } ?: error("ChatGPT is paused")
        return listOf(view.active, active.model, active.enabled, PrefManager.workMode, OwnerCategoryQueue.stamp())
    }
    private fun unchanged(snapshot: BillInfoModel, operation: Long): Boolean =
        operation == generation && owner.isAttachedToWindow && current() == snapshot && PrefManager.featureAssetManage

    fun show() {
        if (running || !owner.isAttachedToWindow) return
        val snapshot = current()?.copy()?.takeIf(AssetSuggestionPolicy::eligible) ?: return
        val stamp = runCatching { consentStamp() }.getOrElse {
            ToastUtils.error("请先登录 ChatGPT 并开启分类许可。资产建议仍会逐次询问数据发送。")
            return
        }
        requestConsent = stamp
        running = true
        val operation = ++generation
        val kinds = AssetSuggestionPolicy.Kind.entries
        val currencies = Currency.entries
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (24 * resources.displayMetrics.density).toInt(); setPadding(padding, 0, padding, 0)
        }
        fun label(value: String) = layout.addView(TextView(context).apply { text = value; setPadding(0, 16, 0, 8) })
        label("核实支付方式，不根据商户猜测账户。只支持普通与信用资产。")
        val kindPicker = Spinner(context).apply {
            contentDescription = "支付方式"
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, listOf("请选择支付方式") + kinds.map { it.title })
            layout.addView(this)
        }
        label("请选择资产币种，不从账单金额或汇率推断。")
        val currencyPicker = Spinner(context).apply {
            contentDescription = "资产币种"
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, listOf("请选择资产币种") + currencies.map { it.name })
            layout.addView(this)
        }
        label("只向 OpenAI 发送所选支付方式枚举，不发送原始账户名、卡号、商户、金额、余额、账本、币种或历史。消耗当前 ChatGPT 额度；是否自动应用/创建遵循你在设置中的明确授权。未确认建议进入统一待确认列表。")
        dialog = MaterialAlertDialogBuilder(context).setTitle("获取一次 AI 资产建议").setView(layout)
            .setNegativeButton("取消") { _, _ -> close() }
            .setPositiveButton("发送支付方式") { _, _ ->
                val kind = kinds.getOrNull(kindPicker.selectedItemPosition - 1)
                val currency = currencies.getOrNull(currencyPicker.selectedItemPosition - 1)
                if (kind == null || currency == null) {
                    running = false; ToastUtils.error("请明确选择支付方式和币种后重试。")
                } else if (!unchanged(snapshot, operation) || runCatching { consentStamp() != stamp }.getOrDefault(true)) {
                    running = false; ToastUtils.error("账单或发送许可已改变，请重新打开建议。")
                } else request(snapshot, stamp, kind, currency, operation)
            }.setOnCancelListener { close() }.show()
    }

    private fun request(snapshot: BillInfoModel, stamp: List<Any?>, kind: AssetSuggestionPolicy.Kind, currency: Currency, operation: Long) {
        dialog = MaterialAlertDialogBuilder(context).setTitle("正在获取资产建议")
            .setMessage("取消后不自动重发；已发出的请求仍可能消耗额度。")
            .setNegativeButton("取消") { _, _ -> close() }.setOnCancelListener { close() }.show()
        task = scope.launch {
            var claim: AiReviewClaim? = null
            try {
                check(unchanged(snapshot, operation) && consentStamp() == stamp)
                val first = AssetsAPI.previewSuggestion(AssetSuggestionPreviewRequest(snapshot.id, snapshot.hash(), kind.name,
                    currency.name, snapshot.categoryRevision)) ?: error("STALE")
                val record = AiReviewStore(context).use { it.create(AiReviewTarget(first.source, snapshot.id,
                    snapshot.categoryRevision, snapshot.hash()), AiReviewKind.ASSET) }
                reviewId = record.id
                if (record.state == AiReviewState.REVIEW) {
                    dialog?.dismiss(); loadReview(snapshot, record, operation); return@launch
                }
                if (record.state == AiReviewState.FAILED && record.errorCode == "APPLY_UNCONFIRMED") error("APPLY_UNCONFIRMED")
                claim = AiReviewStore(context).use { it.claim(record.id, explicitRetry = record.state == AiReviewState.FAILED) }
                    ?: error("BUSY")
                check(unchanged(snapshot, operation) && consentStamp() == stamp)
                val response = ChatGptAccounts.get(context).classify(AssetSuggestionPolicy.PROMPT, AssetSuggestionPolicy.input(kind))
                check(unchanged(snapshot, operation) && consentStamp() == stamp)
                check(AssetSuggestionPolicy.parse(response, kind) != null)
                val preview = AssetsAPI.previewSuggestion(AssetSuggestionPreviewRequest(snapshot.id, snapshot.hash(), kind.name,
                    currency.name, snapshot.categoryRevision)) ?: error("STALE")
                check(preview.source == first.source)
                val change = AiReviewChange("ASSET_FROM", preview.beforeId?.toString().orEmpty(), preview.existingId?.toString().orEmpty(),
                    createsNew = preview.existingId == null, kind = if (preview.existingId == null) kind.name else "",
                    currency = if (preview.existingId == null) currency.name else "")
                val ready = AiReviewStore(context).use { store ->
                    check(store.review(requireNotNull(claim), listOf(change)))
                    requireNotNull(store.get(record.id))
                }
                claim = null
                dialog?.dismiss()
                if (unchanged(snapshot, operation)) loadReview(snapshot, ready, operation)
            } catch (e: CancellationException) {
                claim?.let { value -> runCatching { AiReviewStore(context).use { it.fail(value, "CANCELLED") } } }
                throw e
            } catch (_: Exception) {
                claim?.let { value -> runCatching { AiReviewStore(context).use { it.fail(value, "REQUEST_FAILED") } } }
                if (operation == generation) {
                    dialog?.dismiss(); running = false
                    ToastUtils.error("请求未完成或已有待处理任务。请在统一任务列表检查；不会自动重试。")
                }
            }
        }
    }

    /** Reopens a durable proposal without another model request or consuming quota. */
    fun resume(record: AiReviewRecord) {
        if (running || !owner.isAttachedToWindow) return
        if (record.state != AiReviewState.REVIEW) {
            ToastUtils.info("此任务不是待确认状态。结果未知时请先核对账单与资产，不要重复创建。")
            return
        }
        val snapshot = current()?.copy() ?: return
        running = true; reviewId = record.id
        val operation = ++generation
        task = scope.launch { loadReview(snapshot, record, operation, allowAutomatic = false) }
    }

    private suspend fun loadReview(snapshot: BillInfoModel, record: AiReviewRecord, operation: Long, allowAutomatic: Boolean = true) {
        try {
            val missingCurrency = record.changes.singleOrNull()?.let { it.createsNew && it.currency.isEmpty() } == true
            if (missingCurrency) {
                if (unchanged(snapshot, operation)) chooseCurrency(snapshot, record, operation)
                return
            }
            val preview = AssetReviewActions.preview(record, snapshot) ?: error("STALE")
            if (!unchanged(snapshot, operation)) return
            if (allowAutomatic && AiReviewPolicy(context).canAutoApply(record)) {
                confirm(snapshot, record, operation, automatic = true)
            } else review(snapshot, record, preview, operation)
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) {
            if (operation == generation) { running = false; ToastUtils.error("建议已失效或账户有歧义，请查看最新账单。原记录仍保留。") }
        }
    }

    private fun chooseCurrency(snapshot: BillInfoModel, record: AiReviewRecord, operation: Long) {
        val currencies = Currency.entries
        var selected = -1
        dialog = MaterialAlertDialogBuilder(context).setTitle("资产建议需确认币种")
            .setSingleChoiceItems(currencies.map { it.name }.toTypedArray(), -1) { _, which -> selected = which }
            .setNegativeButton("取消，保留待确认") { _, _ -> close() }
            .setPositiveButton("使用所选币种") { _, _ ->
                val currency = currencies.getOrNull(selected)
                if (currency == null || !unchanged(snapshot, operation)) { close(); return@setPositiveButton }
                task = scope.launch {
                    try {
                        val revised = AiReviewStore(context).use { store ->
                            check(store.amendReview(record.id, listOf(record.changes.single().copy(currency = currency.name))))
                            requireNotNull(store.get(record.id))
                        }
                        loadReview(snapshot, revised, operation, allowAutomatic = false)
                    } catch (_: Exception) { running = false; ToastUtils.error("币种选择未保存，请重新打开任务。") }
                }
            }.setOnCancelListener { close() }.show()
    }

    private fun review(snapshot: BillInfoModel, record: AiReviewRecord, preview: AssetSuggestionPreview, operation: Long) {
        val existing = preview.existingId != null
        val type = if (preview.type == "CREDIT") "信用资产" else "普通资产"
        dialog = MaterialAlertDialogBuilder(context).setTitle(if (existing) "待确认：使用已有资产" else "待确认：创建本地资产")
            .setMessage("$type · ${preview.name} · ${preview.currency}\n\n用于账本「${preview.book}」的本笔待编辑账单，替换当前账户「${snapshot.accountNameFrom.ifBlank { "未选择" }}」。资产是全局共享的。\n\n不建立真实金融账户，不设置余额、额度、卡号或凭据，不自动建立映射。请检查是否已有不同名称的同一账户；外部记账应用仍可能需手动创建或同步。取消/关闭保留到待确认列表。")
            .setNegativeButton("取消，稍后确认") { _, _ -> close() }
            .setNeutralButton("手动更改") { _, _ -> manual(snapshot, record, operation) }
            .setPositiveButton(if (existing) "确认使用" else "确认创建并使用") { _, _ ->
                if (unchanged(snapshot, operation)) confirm(snapshot, record, operation, automatic = false)
                else { running = false; ToastUtils.error("账单已改变，请重新打开待确认任务。") }
            }.setOnCancelListener { close() }.show()
    }

    private fun manual(snapshot: BillInfoModel, record: AiReviewRecord, operation: Long) {
        var selected = false
        selector = BaseSheetDialog.create<AssetsSelectorDialog>(context)
            .setFilter(listOf(AssetsType.NORMAL, AssetsType.CREDIT))
            .setCallback { asset ->
                if (!unchanged(snapshot, operation)) return@setCallback
                selected = true
                task = scope.launch {
                    try {
                        val revised = AiReviewStore(context).use { store ->
                            check(store.amendReview(record.id, listOf(AiReviewChange("ASSET_FROM", record.changes.single().before, asset.id.toString()))))
                            requireNotNull(store.get(record.id))
                        }
                        loadReview(snapshot, revised, operation, allowAutomatic = false)
                    } catch (_: Exception) { running = false; ToastUtils.error("手动选择未保存，请重新打开任务。") }
                }
            }.also { sheet ->
                sheet.setOnDismiss { if (!selected) close() }
                sheet.show()
            }
    }

    private fun confirm(snapshot: BillInfoModel, record: AiReviewRecord, operation: Long, automatic: Boolean) {
        dialog = MaterialAlertDialogBuilder(context).setTitle(if (automatic) "按已授权设置保存资产" else "保存已确认的资产")
            .setMessage("连接中断时请先刷新资产及账单查看结果，不要重复创建。")
            .setCancelable(false).show()
        task = scope.launch {
            try {
                check(unchanged(snapshot, operation))
                val manual = AiReviewStore(context).use { store -> store.latestEvent(record.id, setOf("MANUAL_CHANGED", "REVIEW_READY"))?.action == "MANUAL_CHANGED" }
                val result = AssetReviewActions.apply(context, record, snapshot, automatic, manual) {
                    unchanged(snapshot, operation) && runCatching { requestConsent == consentStamp() }.getOrDefault(false)
                }
                if (result != null) {
                    reviewId = null
                    if (unchanged(snapshot, operation)) applied(result)
                    else ToastUtils.info("已保存，请刷新账单查看账户关联。")
                } else ToastUtils.info("未应用。设置或账单可能已变化，请在任务列表查看待确认记录。")
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (operation == generation) ToastUtils.error("保存结果未知，请先核对资产和账单；不会自动重试。") }
            finally { if (operation == generation) { dialog?.dismiss(); running = false } }
        }
    }
}
