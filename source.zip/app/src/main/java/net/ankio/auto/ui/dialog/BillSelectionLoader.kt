package net.ankio.auto.ui.dialog

import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout

/** Local empty is a completed read. External empty is still waiting for the requested sync. */
internal suspend fun <T> loadBillSelectionCandidates(
    local: Boolean,
    supported: Boolean,
    readLocal: suspend () -> List<T>,
    prepareExternal: suspend () -> Unit,
    readExternal: suspend () -> List<T>,
    timeoutMillis: Long = 30_000L,
    pollMillis: Long = 500L,
): List<T> = withTimeout(timeoutMillis) {
    if (!supported) throw UnsupportedOperationException("Bill selection is not supported by this source")
    if (local) return@withTimeout readLocal()
    prepareExternal()
    while (true) {
        val result = readExternal()
        if (result.isNotEmpty()) return@withTimeout result
        delay(pollMillis)
    }
    @Suppress("UNREACHABLE_CODE")
    emptyList()
}
