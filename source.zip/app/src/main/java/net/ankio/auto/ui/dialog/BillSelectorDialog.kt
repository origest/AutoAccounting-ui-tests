/*
 * Copyright (C) 2025 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.ui.dialog

import android.view.View
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import net.ankio.auto.R
import net.ankio.auto.adapter.AppAdapterManager
import net.ankio.auto.adapter.AutoAdapter
import net.ankio.auto.adapter.QianJiAdapter
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.databinding.DialogBillSelectBinding
import net.ankio.auto.http.api.BillAPI
import net.ankio.auto.http.api.BookBillAPI
import net.ankio.auto.storage.Logger
import net.ankio.auto.ui.adapter.BillSelectorAdapter
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.components.WrapContentLinearLayoutManager
import org.ezbook.server.constant.BillAction
import org.ezbook.server.constant.BillType
import org.ezbook.server.constant.Setting
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.db.model.BookBillModel

/** Selection is provisional until Confirm. Empty results and errors never erase saved links. */
class BillSelectorDialog internal constructor(context: android.content.Context) :
    BaseSheetDialog<DialogBillSelectBinding>(context) {
    private var selectedBills = mutableListOf<String>()
    private var billType = BillAction.SYNC_REIMBURSE_BILL
    private var bookName = ""
    private var billInfo: BillInfoModel? = null
    private var callback: ((List<String>) -> Unit)? = null
    private lateinit var adapter: BillSelectorAdapter
    private var loading = false

    fun setSelectedBills(bills: MutableList<String>) = apply { selectedBills = bills.toMutableList() }
    fun setBillInfo(bill: BillInfoModel) = apply { billInfo = bill.copy() }
    fun setBillType(type: BillAction, bookName: String) = apply { billType = type; this.bookName = bookName }
    fun setCallback(callback: (List<String>) -> Unit) = apply { this.callback = callback }

    override fun onViewCreated(view: View?) {
        super.onViewCreated(view)
        binding.statusPage.contentView!!.apply {
            layoutManager = WrapContentLinearLayoutManager(ctx)
            adapter = BillSelectorAdapter(selectedBills, billType == BillAction.SYNC_REIMBURSE_BILL)
                .also { this@BillSelectorDialog.adapter = it }
        }
        binding.confirmButton.setOnClickListener {
            if (!loading) { callback?.invoke(selectedBills.toList()); dismiss() }
        }
        binding.retryButton.setOnClickListener { loadBillData() }
        binding.clearSelectionButton.setOnClickListener {
            if (!loading) {
                selectedBills.clear()
                adapter.notifyDataSetChanged()
                binding.clearSelectionButton.visibility = View.GONE
                binding.confirmButton.isEnabled = true
            }
        }
        // BaseSheetDialog calls onViewCreated before super.show(); even an immediate
        // unsupported-source error must be rendered only after the window is shown.
        binding.root.post { if (uiReady()) loadBillData() }
    }

    private fun loadBillData() {
        if (loading) return
        loading = true
        binding.confirmButton.isEnabled = false
        binding.clearSelectionButton.isEnabled = false
        binding.clearSelectionButton.visibility = if (selectedBills.isEmpty()) View.GONE else View.VISIBLE
        binding.retryButton.visibility = View.GONE
        binding.statusMessage.setText(R.string.refund_loading)
        binding.statusPage.showLoading()
        launch {
            try {
                // Includes preparation and the first HTTP request, not just the polling loop.
                val bills = loadCandidates()
                if (!uiReady()) return@launch
                if (bills.isEmpty()) {
                    binding.statusMessage.setText(R.string.refund_candidates_empty)
                    binding.statusPage.showEmpty()
                    // No implicit unlink when the source is empty, stale or unavailable.
                } else {
                    binding.statusMessage.setText(if (AppAdapterManager.adapter() is AutoAdapter)
                        R.string.refund_local_candidates else R.string.refund_external_candidates)
                    binding.statusPage.showContent()
                    adapter.updateItems(bills)
                    binding.confirmButton.isEnabled = true
                }
            } catch (e: TimeoutCancellationException) {
                showLoadError(R.string.refund_load_timeout)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Logger.e("加载可关联账单失败", e)
                showLoadError(if (e is UnsupportedOperationException) R.string.refund_source_unsupported
                    else R.string.refund_load_failed)
            } finally {
                loading = false
                if (uiReady()) {
                    binding.retryButton.visibility = View.VISIBLE
                    binding.clearSelectionButton.isEnabled = true
                }
            }
        }
    }

    private fun showLoadError(message: Int) {
        if (!uiReady()) return
        binding.statusMessage.setText(message)
        binding.statusPage.showError()
        binding.confirmButton.isEnabled = false
    }

    private suspend fun loadCandidates(): List<BookBillModel> {
        val source = AppAdapterManager.adapter()
        val local = source is AutoAdapter
        val supported = if (local) billInfo?.type == BillType.IncomeRefund
            else source is QianJiAdapter && WorkMode.isXposedOrLSPatch()
        val typeKey = if (billType == BillAction.SYNC_RECENT_EXPENSE_BILL) Setting.HASH_BILL else Setting.HASH_BAOXIAO_BILL
        return loadBillSelectionCandidates(
            local = local,
            supported = supported,
            readLocal = { BillAPI.localRefundCandidates(requireNotNull(billInfo)) },
            prepareExternal = {
                BookBillAPI.putConfirmed(arrayListOf(), "", typeKey)
                source.syncWaitBills(billType, bookName)
            },
            readExternal = { BookBillAPI.listConfirmed(typeKey) },
        )
    }
}
