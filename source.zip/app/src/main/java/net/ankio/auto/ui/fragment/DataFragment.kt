/*
 * Copyright (C) 2025 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.ui.fragment

import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.core.net.toUri
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import net.ankio.auto.service.ocr.ChatGptRawRecordAnalysis
import net.ankio.chatgpt.ChatGptAccounts
import net.ankio.auto.BuildConfig
import net.ankio.auto.R
import net.ankio.auto.databinding.FragmentPluginDataBinding
import net.ankio.auto.http.api.AppDataAPI
import net.ankio.auto.http.api.JsAPI
import net.ankio.auto.storage.Logger
import net.ankio.auto.ui.adapter.AppDataAdapter
import net.ankio.auto.ui.api.BasePageFragment
import net.ankio.auto.ui.api.BaseSheetDialog
import net.ankio.auto.ui.components.WrapContentLinearLayoutManager
import net.ankio.auto.ui.dialog.BillEditorDialog
import net.ankio.auto.ui.dialog.BottomSheetDialogBuilder
import net.ankio.auto.ui.dialog.DataEditorDialog
import net.ankio.auto.ui.dialog.EditorDialogBuilder
import net.ankio.auto.http.Pastebin
import net.ankio.auto.ui.components.MaterialSearchView
import net.ankio.auto.ui.utils.LoadingUtils
import net.ankio.auto.ui.utils.load
import net.ankio.auto.ui.utils.ListPopupUtilsGeneric
import net.ankio.auto.ui.utils.ToastUtils
import net.ankio.auto.ui.utils.sameAppData
import net.ankio.auto.utils.CustomTabsHelper
import net.ankio.auto.utils.PrefManager
import net.ankio.auto.utils.SystemUtils
import net.ankio.auto.utils.getAppInfoFromPackageName
import org.ezbook.server.constant.DataType
import org.ezbook.server.db.model.AppDataModel

/**
 * 插件数据管理Fragment
 *
 * 该Fragment负责展示和管理应用数据，包括：
 * - 顶部筛选（应用、数据类型、匹配状态）
 * - 搜索功能
 * - 数据清理功能
 *
 * @author ankio
 */
class DataFragment : BasePageFragment<AppDataModel, FragmentPluginDataBinding>(),
    Toolbar.OnMenuItemClickListener {

    // The list belongs to the HTTP server, which may run in another process/context.
    // Do not observe or initialize a client-side Room database here.
    override val loadOnViewCreated = false
    override val restorePageState = true
    private var visibleRefreshJob: Job? = null

    /** 应用包名筛选（空字符串表示全部） */
    var app: String = ""

    /** 数据类型筛选（NOTICE/DATA/OCR，空字符串表示全部） */
    var type: String = ""

    /** 匹配状态：null=全部，true=已匹配，false=未匹配 */
    var match: Boolean? = null

    /** 搜索关键词 */
    var searchData = ""

    /**
     * 应用列表缓存
     * 格式：Map<包名, 应用名>
     * 按照Linus原则：最简单的数据结构解决问题
     */
    private val appMap = linkedMapOf<String, String>()
    private var rawAiBusy = false

    companion object {
        private const val STATE_APP = "DataFragment.app"
        private const val STATE_TYPE = "DataFragment.type"
        private const val STATE_MATCH = "DataFragment.match"
        private const val STATE_SEARCH = "DataFragment.search"
        private const val VISIBLE_REFRESH_INTERVAL_MS = 5_000L
        private const val MAX_AUTOMATIC_REFRESH_ITEMS = 2_000
        private const val GITHUB_ISSUE_URL =
            "https://github.com/AutoAccountingOrg/AutoRuleSubmit/issues"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedInstanceState?.let { state ->
            app = state.getString(STATE_APP, "")
            type = state.getString(STATE_TYPE, "")
            searchData = state.getString(STATE_SEARCH, "")
            match = when (state.getInt(STATE_MATCH, -1)) {
                1 -> true
                0 -> false
                else -> null
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(STATE_APP, app)
        outState.putString(STATE_TYPE, type)
        outState.putString(STATE_SEARCH, searchData)
        outState.putInt(STATE_MATCH, when (match) {
            true -> 1
            false -> 0
            null -> -1
        })
    }

    /**
     * 加载数据的主要方法
     * 根据当前筛选条件从API获取应用数据列表
     *
     * @return 应用数据模型列表
     */
    override suspend fun loadData(): List<AppDataModel> = createDataLoader().invoke()

    override fun createDataLoader(): suspend () -> List<AppDataModel> =
        dataLoader(page, pageSize)

    override fun loadDataInside(callback: ((success: Boolean, hasMore: Boolean) -> Unit)?) {
        if (page <= 1) {
            super.loadDataInside(callback)
        } else {
            // Offset pages shift when new notifications arrive. Reconcile the loaded prefix
            // instead of appending overlapping rows (or skipping rows after a deletion).
            val limit = (page.toLong() * pageSize).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            refreshLoadedData(limit, dataLoader(1, limit), deferWhileScrolling = false, callback = callback)
        }
    }

    private fun dataLoader(requestPage: Int, limit: Int): suspend () -> List<AppDataModel> {
        val selectedApp = app
        val selectedType = type
        val selectedMatch = match
        val search = searchData
        return { AppDataAPI.list(selectedApp, selectedType, selectedMatch, requestPage, limit, search) }
    }

    override fun itemKey(item: AppDataModel): Any = item.id

    override fun sameItems(old: List<AppDataModel>, new: List<AppDataModel>): Boolean =
        old.size == new.size && old.indices.all { sameAppData(old[it], new[it]) }

    /**
     * 创建数据适配器
     * 配置RecyclerView的布局管理器和适配器，并设置事件监听器
     *
     * @return 配置好的AppDataAdapter实例
     */
    override fun onCreateAdapter(): RecyclerView.Adapter<*> {
        val recyclerView = binding.statusPage.contentView!!
        recyclerView.layoutManager = WrapContentLinearLayoutManager(requireContext())

        return AppDataAdapter().apply {
            onTestRuleClick = ::handleTestRuleClick
            onAiClick = ::handleAiClick
            onContentClick = ::handleContentClick
            onImageClick = ::handleImageClick
            onCreateRuleClick = ::handleCreateRuleClick
            onUploadDataClick = ::handleUploadDataClick
            onDeleteClick = ::handleDeleteClick
        }
    }

    /**
     * 处理测试规则点击事件
     */
    private fun handleTestRuleClick(item: AppDataModel) {
        launch {
            val loading = LoadingUtils(requireContext())
            loading.show(R.string.rule_testing)

            try {
                // A prior unknown save is recovered locally; reopening never reruns rule/AI analysis.
                val entry = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    net.ankio.auto.utils.BillCreationJournal.forRawRecord(item,
                        net.ankio.auto.http.api.BillAPI.createSource())
                }
                val recovered = if (entry.pendingBill != null)
                    net.ankio.auto.http.api.BillAPI.createReceipt(entry.target) else null
                val bill = recovered ?: entry.pendingBill ?: run {
                    val image = if (PrefManager.aiVisionRecognition && item.image.isNotBlank()) item.image else item.data
                    val result = JsAPI.analysis(item.type, image, item.app, fromAppData = true, manual = true)
                    result.data?.let { it.parentInfoModel ?: it.billInfoModel }
                        ?: throw IllegalStateException(result.msg.ifBlank { getString(R.string.no_rule_hint) })
                }
                BaseSheetDialog.create<BillEditorDialog>(requireContext())
                    .setBillInfo(bill)
                    .apply { if (bill.id == 0L) bindCreation(entry.target) }
                    .setOnConfirm { }
                    .setOnCancel { _ -> }
                    .show()
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                ToastUtils.error(error.message ?: "无法恢复账单草稿，请先核对账单列表")
            } finally { loading.close() }
        }
    }

    /** The visible AI action grants exactly one text request, not background permission. */
    private fun handleAiClick(item: AppDataModel) {
        if (rawAiBusy) return
        rawAiBusy = true
        launch {
            var handedToDialog = false
            try {
                val context = requireContext()
                val prepared = ChatGptRawRecordAnalysis.prepare(context, item)
                val plan = prepared.plan ?: run { ToastUtils.error(prepared.message); return@launch }
                var approved = false
                MaterialAlertDialogBuilder(context)
                    .setTitle("使用 ChatGPT 分析这一条？")
                    .setMessage("仅此次将本条完整文字或 JSON、当前账本分类名称和当前时间发给 OpenAI，使用已登录 ChatGPT 账号及所选模型。原文可能含金额、商户、账户标识及其他隐私，请先点正文检查。不会上传图片。\n\n仅识别明确的单笔交易，生成待确认草稿；不会直接入账，不开启后续自动发送。请求可能使用额度，失败不会自动重试。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("同意并分析一次") { _, _ ->
                        approved = true
                        launch {
                            val loading = LoadingUtils(context)
                            try {
                                val approval = ChatGptRawRecordAnalysis.approve(context, plan)
                                loading.show(R.string.rule_testing)
                                val outcome = ChatGptRawRecordAnalysis.execute(context, plan, approval)
                                if (outcome.bill != null && ChatGptAccounts.get(context).isTextApprovalCurrent(approval) && isAdded) {
                                    net.ankio.auto.service.ocr.OcrReviewBridge.show(context, outcome.bill, outcome.reviewId)
                                } else ToastUtils.error(outcome.message)
                            } catch (e: Exception) {
                                if (e is CancellationException) throw e
                                ToastUtils.error(net.ankio.auto.service.ocr.OcrFailureHints.message(e))
                            } finally { loading.close(); rawAiBusy = false }
                        }
                    }
                    .setOnDismissListener { if (!approved) rawAiBusy = false }
                    .show()
                handedToDialog = true
            } finally { if (!handedToDialog) rawAiBusy = false }
        }
    }

    /**
     * 处理文本内容点击事件
     */
    private fun handleContentClick(item: AppDataModel) {
        BaseSheetDialog.create<BottomSheetDialogBuilder>(requireContext())
            .setTitle(getString(R.string.content_title))
            .setMessage(item.data)
            .setNegativeButton(getString(R.string.cancel_msg)) { _, _ -> }
            .setPositiveButton(getString(R.string.copy)) { _, _ ->
                SystemUtils.copyToClipboard(item.data)
                ToastUtils.info(R.string.copy_command_success)
            }
            .show()
    }

    /**
     * 处理图片内容点击事件，单独弹窗展示大图
     */
    private fun handleImageClick(item: AppDataModel) {
        val imageView =
            com.google.android.material.imageview.ShapeableImageView(requireContext()).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = resources.getDimensionPixelSize(R.dimen.padding)
                    bottomMargin = resources.getDimensionPixelSize(R.dimen.padding)
                }
                maxHeight = resources.getDimensionPixelSize(R.dimen.image_preview_max_height)
                adjustViewBounds = true
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            }
        imageView.load(item.image)
        BaseSheetDialog.create<BottomSheetDialogBuilder>(requireContext())
            .setTitle(getString(R.string.image_preview_title))
            .addCustomView(imageView)
            .setNegativeButton(getString(R.string.cancel_msg)) { _, _ -> }
            .show()
    }

    /**
     * 处理创建规则点击事件
     */
    private fun handleCreateRuleClick(item: AppDataModel) {
        val args = Bundle().apply {
            putString("data", Gson().toJson(item))
        }
        findNavController().navigate(R.id.RuleEditV3Fragment, args)
    }

    /**
     * 处理上传数据点击事件
     */
    private fun handleUploadDataClick(item: AppDataModel) {
        BaseSheetDialog.create<DataEditorDialog>(requireContext())
            .setData(item.data)
            .setOnConfirm { result ->
                launch {
                    val loading = LoadingUtils(requireContext())
                    loading.show(R.string.upload_waiting)

                    // AI 生成视为未匹配：当规则为空、未匹配，或规则字符串标记为“生成”时，都走适配帮助
                    if (!item.hasValidMatch() || item.isAiGeneratedRule()) {
                        requestRuleHelp(item, result)
                    } else {
                        showRuleBugDialog(item, result)
                    }

                    loading.close()
                }
            }
            .show()
    }

    /**
     * 处理删除点击事件
     */
    private fun handleDeleteClick(item: AppDataModel) {
        BaseSheetDialog.create<BottomSheetDialogBuilder>(requireContext())
            .setTitle(getString(R.string.delete_title))
            .setMessage(getString(R.string.delete_data_message))
            .setPositiveButton(getString(R.string.btn_confirm)) { _, _ ->
                removeItem(item)  // 使用基类的辅助函数
                launch {
                    AppDataAPI.delete(item.id)
                }
            }
            .setNegativeButton(getString(R.string.btn_cancel)) { _, _ -> }
            .show()
    }

    /**
     * 显示规则Bug反馈对话框
     */
    private fun showRuleBugDialog(item: AppDataModel, result: String) {
        BaseSheetDialog.create<EditorDialogBuilder>(requireContext())
            .setTitleInt(R.string.rule_issue)
            .setMessage("")
            .setEditorPositiveButton(R.string.btn_confirm) { description ->
                launch {
                    requestRuleBug(item, result, description)
                }
            }
            .setNegativeButton(R.string.btn_cancel) { _, _ -> }
            .show()
    }

    /**
     * Fragment视图创建完成后的初始化
     * 设置过滤器按钮和搜索功能
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupFilterButtons()
        binding.toolbar.setOnMenuItemClickListener(this)
        setUpSearch()
    }

    /**
     * Refresh immediately on entry/resume, then every five seconds only while visible.
     * Keep loaded pages and the visible row, and skip requests during paging/scrolling.
     * A successful unchanged snapshot performs no adapter update or rebind.
     */
    override fun onResume() {
        super.onResume()
        visibleRefreshJob?.cancel()
        visibleRefreshJob = viewLifecycleOwner.lifecycleScope.launch {
            this.launch { loadAppList() }
            var entering = true
            while (isActive) {
                val list = binding.statusPage.contentView
                if (!isLoading && list?.scrollState == RecyclerView.SCROLL_STATE_IDLE) {
                    val limit = (page.coerceAtLeast(1).toLong() * pageSize)
                        .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    // Bound repeated reads of image-heavy histories, not access to older pages.
                    if (entering || limit <= MAX_AUTOMATIC_REFRESH_ITEMS) {
                        entering = false
                        val request = refreshLoadedData(limit, dataLoader(1, limit))
                        try {
                            request?.join()
                        } finally {
                            // The request is view-scoped; also stop it when the page is paused.
                            if (request != null) cancelPendingLoad(request)
                        }
                    }
                }
                delay(VISIBLE_REFRESH_INTERVAL_MS)
            }
        }
    }

    override fun onPause() {
        visibleRefreshJob?.cancel()
        visibleRefreshJob = null
        super.onPause()
    }

    override fun onDestroyView() {
        visibleRefreshJob?.cancel()
        visibleRefreshJob = null
        super.onDestroyView()
    }

    /**
     * 加载应用列表
     * Linus式简化：纯数据加载，无UI耦合
     * @return 是否加载成功
     */
    private suspend fun loadAppList(): Boolean {
        return try {
            val apiResult = AppDataAPI.apps()
            Logger.d("Loaded ${apiResult.size()} apps for filter")

            val updatedApps = linkedMapOf<String, String>()
            // 单次遍历构建应用映射
            for (packageName in apiResult.keySet()) {
                val appInfo = getAppInfoFromPackageName(packageName)
                if (appInfo != null) {
                    updatedApps[packageName] = appInfo.name
                }
            }
            appMap.clear()
            appMap.putAll(updatedApps)
            true
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            Logger.e("Error loading app filter list")
            false
        }
    }

    /**
     * 设置过滤按钮：应用、类型、匹配状态
     */
    private fun setupFilterButtons() {
        setupAppButton()
        setupTypeButton()
        setupMatchButton()
    }

    /**
     * 配置"应用"筛选按钮：全部/具体应用
     * Linus式简化：点击时动态加载应用列表，确保数据最新
     * 显示应用名，但筛选使用包名
     */
    private fun setupAppButton() {
        val allLabel = resources.getStringArray(R.array.rule_type_options)[0]
        binding.appButton.text = if (app.isEmpty()) allLabel else
            appMap[app] ?: getAppInfoFromPackageName(app)?.name ?: app

        binding.appButton.setOnClickListener { anchorView ->
            viewLifecycleOwner.lifecycleScope.launch {
                // 确保应用列表已加载
                if (appMap.isEmpty()) {
                    loadAppList()
                }

                // 动态构建筛选项：显示应用名，值为包名
                val items = linkedMapOf<String, String>().apply {
                    put(allLabel, "")  // 全部
                    // appMap: 包名 → 应用名，需要反转为 应用名 → 包名
                    appMap.forEach { (packageName, appName) ->
                        put(appName, packageName)
                    }
                }

                ListPopupUtilsGeneric.create<String>(requireContext())
                    .setAnchor(anchorView)
                    .setList(items)
                    .setOnItemClick { _, key, value ->
                        app = value  // 使用包名筛选
                        binding.appButton.text = key  // 显示应用名
                        Logger.d("App filter updated")
                        reload()
                    }
                    .show()
            }
        }
    }

    /**
     * 配置"类型"筛选按钮：全部/通知/数据/OCR
     */
    private fun setupTypeButton() {
        val labels = resources.getStringArray(R.array.rule_type_options)
        val items = linkedMapOf(
            labels[0] to "",
            labels[1] to DataType.NOTICE.name,
            labels[2] to DataType.DATA.name,
            labels[3] to DataType.OCR.name
        )
        binding.typeButton.text = items.entries.firstOrNull { it.value == type }?.key ?: labels[0]

        // 统一风格：点击主按钮弹出菜单
        binding.typeButton.setOnClickListener { anchorView ->
            ListPopupUtilsGeneric.create<String>(requireContext())
                .setAnchor(anchorView)
                .setList(items)
                .setOnItemClick { _, key, value ->
                    type = value
                    binding.typeButton.text = key
                    Logger.d("Data type filter updated: type='$type'")
                    reload()
                }
                .show()
        }
    }

    /**
     * 配置"匹配状态"筛选按钮：全部/已匹配/未匹配
     */
    private fun setupMatchButton() {
        val labels = resources.getStringArray(R.array.match_options)
        val items = linkedMapOf<String, Boolean?>(
            labels[0] to null,
            labels[1] to true,
            labels[2] to false
        )
        binding.matchButton.text = items.entries.firstOrNull { it.value == match }?.key ?: labels[0]

        // 统一风格：点击主按钮弹出菜单
        binding.matchButton.setOnClickListener { anchorView ->
            ListPopupUtilsGeneric.create<Boolean?>(requireContext())
                .setAnchor(anchorView)
                .setList(items)
                .setOnItemClick { _, key, value ->
                    match = value
                    binding.matchButton.text = key
                    Logger.d("Match filter updated: match=$match")
                    reload()
                }
                .show()
        }
    }

    /**
     * 设置搜索功能
     * 配置搜索视图的查询文本监听器
     */
    private fun setUpSearch() {

        val searchItem = binding.toolbar.menu.findItem(R.id.action_search)
        if (searchItem != null) {
            val searchView = searchItem.actionView as MaterialSearchView
            if (searchData.isNotEmpty()) {
                searchItem.expandActionView()
                searchView.setQuery(searchData, false)
            }
            searchView.setOnQueryTextListener(object :
                androidx.appcompat.widget.SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean = true
                override fun onQueryTextChange(newText: String?): Boolean {
                    val query = newText ?: ""
                    if (searchData == query) return true
                    searchData = query
                    reload()
                    return true
                }
            })
        }
    }

    /**
     * 工具栏菜单项点击处理
     * 处理数据清理等菜单操作
     *
     * @param item 被点击的菜单项
     * @return 是否处理了菜单点击事件
     */
    override fun onMenuItemClick(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.item_clear -> {
                // 检查Fragment View是否仍然有效
                if (!uiReady()) {
                    return true
                }

                BaseSheetDialog.create<BottomSheetDialogBuilder>(requireContext())
                    .setTitle(getString(R.string.delete_data))
                    .setMessage(getString(R.string.delete_msg))
                    .setPositiveButton(getString(R.string.sure_msg)) { _, _ ->
                        launch {
                            AppDataAPI.clear()
                            Logger.i("Data cleared successfully")
                            page = 1
                            reload()
                        }
                    }
                    .setNegativeButton(requireActivity().getString(R.string.cancel_msg)) { _, _ ->
                        Logger.d("User cancelled data clear")
                    }
                    .show()
                return true
            }

            else -> {
                Logger.d("Unknown menu item clicked: ${item?.itemId}")
                return false
            }
        }
    }

    /**
     * 请求规则适配帮助
     * 原 AppDataRepository.requestRuleHelp 方法
     */
    private suspend fun requestRuleHelp(item: AppDataModel, result: String) {
        val type = item.type.name
        val title = "[Adaptation Request][$type]${item.app}"

        val (url, timeout) = Pastebin.add(result).getOrThrow()
        val localRuleVersion = PrefManager.ruleVersion.ifEmpty { "未知" }
        val body = """
<!------ 
 1. 请不要手动复制数据，下面的链接中已包含数据；
 2. 您可以新增信息，但是不要删除本页任何内容；
 3. 一般情况下，您直接划到底部点击submit即可。
 ------>
## 自动记账版本
${BuildConfig.VERSION_NAME}
## 本地规则版本
$localRuleVersion
## 数据链接
[数据过期时间：${timeout}](${url})
## 其他信息
<!------ 
 1. 您可以在下面添加说明信息。
 ------>

                """.trimIndent()

        submitGithub(title, body)
    }

    /**
     * 反馈规则Bug
     * 原 AppDataRepository.requestRuleBug 方法
     */
    private suspend fun requestRuleBug(item: AppDataModel, result: String, desc: String) {
        val type = item.type.name
        val title = "[Bug Report][$type]${item.app}"

        val (url, timeout) = Pastebin.add(result).getOrThrow()
        val body = """
<!------ 
 1. 请不要手动复制数据，下面的链接中已包含数据；
 2. 该功能是反馈规则识别错误的，请勿写其他无关内容；
 ------>
## 自动记账版本
${BuildConfig.VERSION_NAME}
## 规则
${item.rule}${if (item.version.isNotEmpty()) " (规则版本: ${item.version})" else ""}
## 数据
[数据过期时间：${timeout}](${url})
## 说明
$desc

                         
                                            """.trimIndent()

        submitGithub(title, body)
    }

    /**
     * 通过Github提交Issue
     * 原 AppDataRepository.submitGithub 方法
     */
    private fun submitGithub(title: String, body: String) {
        CustomTabsHelper.launchUrl(
            "$GITHUB_ISSUE_URL/new?title=${Uri.encode(title)}&body=${Uri.encode(body)}".toUri()
        )
    }

}
