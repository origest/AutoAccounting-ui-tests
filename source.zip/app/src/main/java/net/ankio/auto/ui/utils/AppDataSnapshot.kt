package net.ankio.auto.ui.utils

import org.ezbook.server.db.model.AppDataModel

/** AppDataModel uses reference equality; compare all persisted fields without logging content. */
internal fun sameAppData(old: AppDataModel, new: AppDataModel): Boolean =
    old.id == new.id && old.data == new.data && old.type == new.type &&
        old.app == new.app && old.time == new.time && old.match == new.match &&
        old.rule == new.rule && old.issue == new.issue && old.version == new.version &&
        old.image == new.image
