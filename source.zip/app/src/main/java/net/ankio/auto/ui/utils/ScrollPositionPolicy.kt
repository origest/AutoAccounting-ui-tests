package net.ankio.auto.ui.utils

/** A saved layout must take precedence over commands that preserve a live list. */
internal fun canPreserveLiveScroll(
    oldItemCount: Int,
    firstVisiblePosition: Int,
    hasSavedLayout: Boolean
): Boolean = !hasSavedLayout && firstVisiblePosition in 0 until oldItemCount
