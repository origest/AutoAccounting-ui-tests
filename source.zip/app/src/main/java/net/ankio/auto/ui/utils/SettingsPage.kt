package net.ankio.auto.ui.utils

import android.content.Context
import android.view.View
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.NestedScrollView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import net.ankio.auto.R
import net.ankio.auto.ui.api.BaseActivity

/** Shared Material settings scaffold; inherits the app's palette, night mode and type scaling. */
class SettingsPage(private val activity: BaseActivity, title: String) {
    val root = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
    private val content = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
    private var section: LinearLayout = content
    private val scroller = NestedScrollView(activity).apply { isFillViewport = true; addView(content) }
    init {
        root.setBackgroundColor(MaterialColors.getColor(root, com.google.android.material.R.attr.colorSurface))
        val toolbar = MaterialToolbar(activity).apply {
            this.title = title
            setNavigationIcon(R.drawable.ic_arrow_back)
            navigationContentDescription = "返回"
            setNavigationOnClickListener { activity.finish() }
        }
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        activity.setContentView(root)
        ViewCompat.requestApplyInsets(root)
    }
    fun scrollPosition(): Int = scroller.scrollY
    fun restoreScrollPosition(position: Int) {
        scroller.post { if (scroller.isAttachedToWindow) scroller.scrollTo(0, position.coerceAtLeast(0)) }
    }
    fun section(title: String, description: String? = null) {
        val card = MaterialCardView(activity).apply {
            radius = dp(20).toFloat(); cardElevation = 0f
            setCardBackgroundColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurfaceVariant))
            strokeWidth = 0
        }
        section = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        card.addView(section)
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        text(title).apply { setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium) }
        description?.let { text(it) }
    }
    fun text(value: String): TextView = TextView(activity).apply {
        text = value
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium)
        setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface))
        setPadding(0, dp(6), 0, dp(6)); setLineSpacing(dp(3).toFloat(), 1f)
        section.addView(this, LinearLayout.LayoutParams(-1, -2))
    }
    fun button(value: String, primary: Boolean = false, action: () -> Unit): MaterialButton =
        MaterialButton(activity, null, if (primary) com.google.android.material.R.attr.materialButtonStyle else com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = value; isAllCaps = false; maxLines = 3; minHeight = dp(48)
            setOnClickListener { action() }
            section.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        }
    /** A tap requests a change; only the caller's verified state may move the switch. */
    fun toggle(value: String, action: (Boolean) -> Unit): MaterialSwitch = MaterialSwitch(activity).apply {
        text = value; minHeight = dp(48)
        setOnClickListener {
            val requested = isChecked
            isChecked = !requested
            action(requested)
        }
        section.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
    }
    fun spinner(label: String): Spinner {
        text(label)
        return androidx.appcompat.widget.AppCompatSpinner(activity).apply {
            contentDescription = label; minimumHeight = dp(48)
            section.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
    }
    fun number(label: String, value: String): EditText {
        val field = TextInputLayout(activity).apply {
            hint = label; boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
        }
        val edit = TextInputEditText(field.context).apply {
            setText(value); inputType = android.text.InputType.TYPE_CLASS_NUMBER; setSingleLine()
        }
        // TextInputLayout uses these params for its internal LinearLayout child.
        field.addView(edit, LinearLayout.LayoutParams(-1, -2))
        section.addView(field, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })
        return edit
    }
    fun dp(value: Int): Int = (value * activity.resources.displayMetrics.density + .5f).toInt()
}
