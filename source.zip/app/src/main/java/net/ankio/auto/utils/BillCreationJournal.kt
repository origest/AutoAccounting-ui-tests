package net.ankio.auto.utils

import com.google.gson.Gson
import net.ankio.auto.autoApp
import org.ezbook.server.db.model.AppDataModel
import org.ezbook.server.db.model.BillInfoModel
import org.ezbook.server.server.BillCreateTarget
import org.ezbook.server.server.BillCreationProtocol
import java.util.UUID
import android.util.AtomicFile
import java.io.File

/** App-private, no-backup local recovery. Stores the pending bill, never raw capture text or AI credentials. */
object BillCreationJournal {
    data class Entry(val target: BillCreateTarget, val pendingBill: BillInfoModel? = null, val generation: Long = 0)
    data class Dispatch(val generation: Long, val mayRelease: Boolean)
    private data class Journal(val origins: MutableMap<String, String> = mutableMapOf(),
        val entries: MutableMap<String, Entry> = mutableMapOf())
    private val gson = Gson()
    private val file get() = AtomicFile(File(autoApp.noBackupFilesDir, "bill_create_recovery_v1.json"))
    private fun read(): Journal {
        val current = file
        if (!current.baseFile.exists() && !File(current.baseFile.path + ".bak").exists()) return Journal()
        return checkNotNull(gson.fromJson(current.readFully().toString(Charsets.UTF_8), Journal::class.java))
    }
    private fun write(journal: Journal) {
        val current = file
        val bytes = gson.toJson(journal).toByteArray(Charsets.UTF_8)
        val output = current.startWrite()
        try {
            output.write(bytes)
            output.fd.sync()
            current.finishWrite(output)
            check(current.readFully().contentEquals(bytes)) { "创建请求日志写入未确认；尚未发送" }
        } catch (error: Exception) {
            current.failWrite(output)
            throw error
        }
    }

    /** A raw row is an origin, not its content alone. Equal content in distinct rows remains distinct. */
    @Synchronized fun forRawRecord(raw: AppDataModel, source: String): Entry {
        require(raw.id > 0 && BillCreationProtocol.validId(source))
        val fingerprint = BillCreationProtocol.rawFingerprint(raw)
        val origin = "origin:$fingerprint"
        val journal = read()
        val existing = journal.origins[origin]
        if (existing != null) return checkNotNull(journal.entries[existing]).also {
            check(it.target.source == source) { "账单来源已切换或恢复；旧草稿不能在新来源重建，请先核对列表" }
        }
        val result = Entry(BillCreateTarget(source, UUID.randomUUID().toString(), raw.id, fingerprint))
        journal.origins[origin] = result.target.requestId
        journal.entries[result.target.requestId] = result
        write(journal)
        return result
    }

    /** Must durably succeed before the create POST. Unknown outcomes never replace this payload or ID. */
    @Synchronized fun beforeDispatch(target: BillCreateTarget, bill: BillInfoModel): Dispatch {
        val journal = read()
        val previous = checkNotNull(journal.entries[target.requestId]) { "创建身份已丢失；禁止重发" }
        check(previous.target == target) { "创建来源不匹配" }
        previous.pendingBill?.let {
            check(BillCreationProtocol.fingerprint(it) == BillCreationProtocol.fingerprint(bill)) {
                "上次保存结果未明，不能换内容重发；请从原始记录重新打开并核对"
            }
        }
        val dispatch = Dispatch(Math.addExact(previous.generation, 1L), previous.pendingBill == null)
        journal.entries[target.requestId] = Entry(target, bill.copy(), dispatch.generation)
        write(journal)
        return dispatch
    }

    /** Only an explicit server-side pre-commit validation rejection may unlock editing the request. */
    @Synchronized fun rejectedBeforeCommit(target: BillCreateTarget, dispatch: Dispatch) {
        val journal = read()
        val previous = checkNotNull(journal.entries[target.requestId]) { "创建身份已丢失；禁止重发" }
        check(previous.target == target)
        // An older rejection cannot erase a newer attempt, and a retry cannot disprove an earlier unknown outcome.
        if (!dispatch.mayRelease || previous.generation != dispatch.generation) return
        journal.entries[target.requestId] = Entry(target, generation = previous.generation)
        write(journal)
    }
}
