/*
 * Copyright (C) 2024 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.utils

import android.net.Uri
import androidx.core.content.ContextCompat
import com.google.android.material.textview.MaterialTextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import net.ankio.auto.App
import net.ankio.auto.BuildConfig
import net.ankio.auto.R
import net.ankio.auto.adapter.AppAdapterManager
import net.ankio.auto.adapter.QianJiAdapter
import net.ankio.auto.autoApp
import net.ankio.auto.constant.WorkMode
import net.ankio.auto.http.api.BillAPI
import net.ankio.auto.storage.Logger
import net.ankio.auto.ui.utils.ToastUtils
import org.ezbook.server.constant.BillState
import org.ezbook.server.constant.BillType
import org.ezbook.server.db.model.BillInfoModel
import java.util.Locale
import kotlin.time.Duration.Companion.milliseconds

object BillTool {

    /**
     * 获取页面显示颜色
     */
    fun getColor(type: BillType): Int {
        val isExpenseRed = PrefManager.isExpenseRed

        return when (type) {
            BillType.Expend -> if (isExpenseRed) R.color.danger else R.color.success
            BillType.Income -> if (isExpenseRed) R.color.success else R.color.danger
            BillType.Transfer -> R.color.info
            else -> R.color.danger
        }
    }

    /**
     * 获取箭头图标
     */
    fun getIcon(type: BillType): Int {
        val isIncomeUp = PrefManager.isIncomeUp

        return when (type) {
            BillType.Income -> if (isIncomeUp) R.drawable.ic_trending_up else R.drawable.ic_trending_down
            BillType.Expend -> if (isIncomeUp) R.drawable.ic_trending_down else R.drawable.ic_trending_up
            BillType.Transfer -> R.drawable.ic_swap_horiz
            else -> R.drawable.ic_trending_down
        }
    }

    /**
     * 获取背景drawable
     */
    fun getBackground(type: BillType): Int {
        val isExpenseRed = PrefManager.isExpenseRed

        return when (type) {
            BillType.Expend -> if (isExpenseRed) R.drawable.bg_danger_icon else R.drawable.bg_success_icon
            BillType.Income -> if (isExpenseRed) R.drawable.bg_success_icon else R.drawable.bg_danger_icon

            else -> R.drawable.bg_danger_icon
        }
    }

    /**
     * 获取账单类型的完整样式信息
     * @return Triple(colorRes, iconRes, backgroundRes)
     */
    fun getStyle(type: BillType): Triple<Int, Int, Int> {
        return Triple(getColor(type), getIcon(type), getBackground(type))
    }

    /**
     * 格式化金额显示
     * 只显示数字，不带货币符号
     */
    fun formatAmount(amount: Double): String {
        return String.format(Locale.getDefault(), "%.2f", amount)
    }

    fun getType(type: BillType): BillType {
        return when (type) {
            BillType.ExpendReimbursement -> BillType.Expend
            BillType.ExpendLending -> BillType.Expend
            BillType.ExpendRepayment -> BillType.Expend
            BillType.IncomeLending -> BillType.Income
            BillType.IncomeRepayment -> BillType.Income
            BillType.IncomeReimbursement -> BillType.Income
            BillType.IncomeRefund -> BillType.Income
            else -> type
        }
    }


    fun setTextViewPrice(
        price: Double,
        type: BillType,
        view: MaterialTextView,
        currencyUnit: String? = null
    ) {
        val t = getType(type)
        val color = ContextCompat.getColor(view.context, getColor(t))
        view.setTextColor(color)
        // 有货币单位则追加到金额后面，如 "- 100.0 USD"
        val suffix = if (currencyUnit.isNullOrEmpty()) "" else " $currencyUnit"
        val sign = when (t) {
            BillType.Expend, BillType.ExpendReimbursement, BillType.ExpendLending, BillType.ExpendRepayment -> {
                "- "
            }

            BillType.Income, BillType.IncomeLending, BillType.IncomeRepayment, BillType.IncomeReimbursement -> {
                "+ "
            }

            else -> ""
        }
        view.text =
            view.context.getString(R.string.bill_amount_format, sign, price.toString(), suffix)
    }

    /**
     * 获取多币种转换提示文本
     *
     * 当启用多币种且账单币种与本位币不同时，返回 "≈ 72.30 CNY" 格式的文本；
     * 否则返回 null。
     *
     * @param bill 账单信息
     * @return 转换文本或 null
     */
    fun getConversionText(bill: BillInfoModel): String? {
        if (!PrefManager.featureMultiCurrency) return null
        val model = bill.currencyModel()
        val baseCurrency = PrefManager.baseCurrency
        if (model.code == baseCurrency || model.code.isEmpty()) return null
        if (model.rate <= 0) return null
        val converted = bill.money * model.rate
        return "≈ ${formatAmount(converted)} $baseCurrency"
    }

    fun getCateName(category1: String, category2: String? = null): String {

        if (category2 === null) {
            return category1
        }
        return "$category1 - $category2"
    }

    fun syncBills() {
        App.launch {
            // 开始同步提示
            ToastUtils.info(R.string.sync_starting)

            // 获取所有未同步的账单
            val billsToSync = BillAPI.sync()

            if (billsToSync.isEmpty()) {
                ToastUtils.info(R.string.sync_no_bills)
                return@launch
            }

            var syncedCount = 0

            // 逐个同步账单
            billsToSync.forEach { bill ->
                try {
                    val adapter = AppAdapterManager.adapter()
                    // 不走 syncBill，避免与 adapter.sleep() 叠加延迟
                    adapter.syncBill(prepareBillForSync(bill))
                    if (adapter is QianJiAdapter && WorkMode.isXposedOrLSPatch()) {
                        waitSynced(bill.id)
                    } else {
                        delay(3000L.milliseconds)
                    }
                    syncedCount++
                } catch (e: Exception) {
                    Logger.e("同步账单失败: ${bill.id}", e)
                    // 继续同步其他账单，不因单个失败而中断
                }
            }

            ToastUtils.info(
                autoApp.resources.getQuantityString(R.plurals.sync_completed, syncedCount, syncedCount)
            )


        }
    }

    /**
     * 按功能开关裁剪发往记账软件的账单副本。
     *
     * 本地库中的原始字段保持不变；只影响同步出去的内容：
     * - 关闭手续费/优惠：不传 fee
     * - 关闭资产管理：不传账户，且 Transfer 降级为 Expend
     */
    fun prepareBillForSync(bill: BillInfoModel): BillInfoModel {
        require(!org.ezbook.server.tools.LocalRefunds.isLocal(bill.extendData) ||
            AppAdapterManager.adapter() is net.ankio.auto.adapter.AutoAdapter) {
            "这是本地原单关联，不能直接同步为外部退款；请先选择外部原单"
        }
        val syncBill = bill.copy()
        if (!PrefManager.featureFee) {
            syncBill.fee = 0.0
        }
        if (!PrefManager.featureAssetManage) {
            if (syncBill.type == BillType.Transfer) {
                syncBill.type = BillType.Expend
            }
            syncBill.accountNameFrom = ""
            syncBill.accountNameTo = ""
        }
        return syncBill
    }

    /**
     * 等待账单被标记为已同步，超时即放弃。
     *
     * 钱迹写库成功后才回写状态；不等回执就拉起下一笔，
     * 多笔账单会在钱迹内并发处理，Hook 上下文互相覆盖导致串单、漏单。
     */
    private suspend fun waitSynced(id: Long) {
        withTimeoutOrNull(5000L.milliseconds) {
            while (BillAPI.get(id)?.state != BillState.Synced) {
                delay(200L.milliseconds)
            }
        }
    }

    suspend fun syncBill(billInfoModel: BillInfoModel) {
        AppAdapterManager.adapter().syncBill(prepareBillForSync(billInfoModel))
        delay(AppAdapterManager.adapter().sleep())
    }

    /** Copy the authoritative saved/reconciled row, never stale pre-timeout fields. */
    private fun copySavedBillInto(target: BillInfoModel, saved: BillInfoModel) {
        target.id = saved.id
        target.type = saved.type
        target.currency = saved.currency
        target.money = saved.money
        target.fee = saved.fee
        target.time = saved.time
        target.shopName = saved.shopName
        target.shopItem = saved.shopItem
        target.cateName = saved.cateName
        target.extendData = saved.extendData
        target.bookName = saved.bookName
        target.accountNameFrom = saved.accountNameFrom
        target.accountNameTo = saved.accountNameTo
        target.app = saved.app
        target.groupId = saved.groupId
        target.channel = saved.channel
        target.state = saved.state
        target.remark = saved.remark
        target.auto = saved.auto
        target.ruleName = saved.ruleName
        target.tags = saved.tags
        target.flag = saved.flag
        target.rawAccountNameFrom = saved.rawAccountNameFrom
        target.rawAccountNameTo = saved.rawAccountNameTo
        target.pendingCategory = saved.pendingCategory
        target.categoryOrigin = saved.categoryOrigin
        target.categoryRevision = saved.categoryRevision
    }

    // Preserve existing positional/trailing-lambda success callbacks.
    fun saveBill(bill: BillInfoModel, onComplete: (() -> Unit)? = null) =
        saveBill(bill, onComplete, null)

    fun saveBill(bill: BillInfoModel, onComplete: (() -> Unit)?,
        onFailure: (() -> Unit)?) {
        saveBillInternal(bill, onComplete, onFailure, null)
    }

    /** Reports the confirmed local write, separately from best-effort external sync. */
    fun saveBillWithResult(bill: BillInfoModel,
        target: org.ezbook.server.server.ManualBillEditTarget? = null,
        createTarget: org.ezbook.server.server.BillCreateTarget? = null,
        onSaved: (Boolean) -> Unit) =
        saveBillInternal(bill, { onSaved(true) }, { onSaved(false) }, target, createTarget)

    private fun saveBillInternal(bill: BillInfoModel, onComplete: (() -> Unit)?,
        onFailure: (() -> Unit)?, target: org.ezbook.server.server.ManualBillEditTarget?,
        createTarget: org.ezbook.server.server.BillCreateTarget? = null) {
        if (bill.pendingCategory.isNotEmpty()) {
            ToastUtils.error("请先确认或拒绝 AI 新类别建议")
            onFailure?.invoke()
            return
        }
        // Never mutate the caller's draft until the server confirms the local write.
        val snapshot = bill.copy(state = BillState.Edited)
        if (target != null) snapshot.auto = false
        App.launchIO {
            var creation: org.ezbook.server.server.BillCreateResult? = null
            var creationDispatch: BillCreationJournal.Dispatch? = null
            val savedId = try {
                kotlinx.coroutines.withTimeout(30_000L) {
                    if (target != null) {
                        check(BillAPI.putConfirmed(snapshot, target)) { "BILL_WRITE_UNCONFIRMED" }
                        snapshot.id
                    } else if (snapshot.id == 0L) {
                        val identity = checkNotNull(createTarget) { "新建草稿没有稳定来源，请从原始记录重新打开" }
                        check(BillAPI.createSource() == identity.source) { "创建来源已变化，禁止重发旧草稿" }
                        creationDispatch = BillCreationJournal.beforeDispatch(identity, snapshot)
                        creation = BillAPI.createConfirmed(identity, snapshot)
                        creation!!.bill.id
                    } else BillAPI.putAndGetId(snapshot)
                }
            } catch (e: Exception) {
                if (e is BillAPI.CreateRejected && createTarget != null && creationDispatch != null)
                    runCatching { BillCreationJournal.rejectedBeforeCommit(createTarget, creationDispatch!!) }
                if (e is kotlinx.coroutines.CancellationException && e !is kotlinx.coroutines.TimeoutCancellationException) throw e
                Logger.e("账单保存未确认", e)
                App.launch {
                    ToastUtils.error("保存未确认：${e.message ?: "连接失败"}。请重新打开账单核对后再试")
                    onFailure?.invoke()
                }
                return@launchIO
            }
            val wasExisting = snapshot.id > 0
            snapshot.id = savedId
            if (wasExisting) snapshot.categoryRevision += 1
            snapshot.categoryOrigin = "MANUAL"
            creation?.let { copySavedBillInto(snapshot, it.bill) }
            kotlinx.coroutines.withContext(Dispatchers.Main) {
                copySavedBillInto(bill, snapshot)
                if (PrefManager.showSuccessPopup) ToastUtils.info(autoApp.getString(R.string.auto_success, snapshot.money.toString()))
                onComplete?.invoke()
            }
            // Reconciliation returns today's row, never replays an external synchronization effect.
            if (creation?.replayed == true) return@launchIO
            // Saving succeeded. A later external synchronization failure must not masquerade as a failed local write.
            try {
                if (!PrefManager.manualSync && !snapshot.isChild()) {
                    val threshold = PrefManager.delayedSyncThreshold
                    if (threshold == 0) syncBill(snapshot)
                    else if (BillAPI.sync().size >= threshold) syncBills()
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                Logger.e("账单已保存，但同步失败", e)
                App.launch { ToastUtils.error("账单已保存，但同步失败，请稍后重试同步") }
            }
        }
    }

}

/** Uri.Builder 扩展：仅在 value 非空时追加参数 */
fun Uri.Builder.appendIfNotBlank(key: String, value: String) {
    if (value.isNotEmpty()) appendQueryParameter(key, value)
}
