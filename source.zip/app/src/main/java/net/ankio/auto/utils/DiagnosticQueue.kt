package net.ankio.auto.utils

import kotlinx.coroutines.channels.Channel
import java.util.concurrent.atomic.AtomicLong

/** Lossy diagnostics only: never use this for bills or payment events. */
internal class DiagnosticQueue<T>(capacity: Int = 64) {
    val messages = Channel<T>(capacity)
    val dropped = AtomicLong()
    fun offer(value: T): Boolean = messages.trySend(value).isSuccess.also { if (!it) dropped.incrementAndGet() }
}
