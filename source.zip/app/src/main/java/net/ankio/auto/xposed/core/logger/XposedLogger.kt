/*
 * Copyright (C) 2024 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.xposed.core.logger

import net.ankio.auto.utils.DiagnosticQueue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import net.ankio.auto.http.api.LogAPI
import net.ankio.auto.xposed.core.utils.AppRuntime
import org.ezbook.server.constant.LogLevel
import org.ezbook.server.db.model.LogModel
import org.ezbook.server.log.BaseLogger

/**
 * Xposed日志工具
 *
 */
object XposedLogger : BaseLogger() {
    var app = "unknown"

    private val scope = CoroutineScope(SupervisorJob())

    private val queue = DiagnosticQueue<LogModel>()
    init {
        scope.launch(Dispatchers.IO) {
            for (log in queue.messages) {
                try { LogAPI.add(log) }
                catch (error: kotlinx.coroutines.CancellationException) { throw error }
                catch (_: Exception) { /* Never recursively log transport failures. */ }
            }
        }
    }


    override fun logcatFormater(
        priority: LogLevel,
        file: String,
        line: Int,
        msg: String,
        tr: Throwable?
    ): String {
        var prefix = "[ 自动记账X ][ $app ]"
        if (line != -1) prefix = "$prefix($file:$line) "
        return "$prefix $msg\n${tr?.stackTrace?.joinToString("\n") ?: ""}".trimEnd()
    }

    override fun logModelFormater(
        priority: LogLevel, className: String, file: String, line: Int, msg: String, tr: Throwable?
    ): LogModel = LogModel(
        level = priority,
        app = this@XposedLogger.app,
        // location 统一为 "类名(File.kt:行号)"
        location = className + if (line != -1) "($file:$line)" else "",
        message = "$msg\n${tr?.stackTrace?.joinToString("\n") ?: ""}".trimEnd()
    )

    override fun onLogModel(model: LogModel) {
        // Diagnostics must not create one suspended coroutine per message during an outage.
        if (app == "android") return
        queue.offer(model.copy(message = model.message.take(4096), location = model.location.take(256)))
    }

    override fun isDebugMode(): Boolean = AppRuntime.isDebugMode()
}