package net.ankio.auto.xposed.core.utils

import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

/** Hook callbacks only read memory. Refresh failures default to off. */
internal class AsyncDebugFlag(private val scope: CoroutineScope, private val load: suspend () -> Boolean) {
    @Volatile private var enabled = false
    private val refreshing = AtomicBoolean(false)
    fun get(): Boolean = enabled
    fun refresh() {
        if (!refreshing.compareAndSet(false, true)) return
        scope.launch {
            try { enabled = load() }
            catch (error: Exception) {
                enabled = false
                if (error is CancellationException) throw error
            } finally { refreshing.set(false) }
        }
    }
}
