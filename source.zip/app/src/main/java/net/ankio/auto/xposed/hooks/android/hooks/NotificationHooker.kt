package net.ankio.auto.xposed.hooks.android.hooks

import android.app.Notification
import android.service.notification.StatusBarNotification
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import net.ankio.auto.notification.NotificationEventIdentity
import net.ankio.auto.notification.XposedNotificationDelivery
import net.ankio.auto.xposed.core.api.PartHooker
import net.ankio.auto.xposed.core.hook.Hooker

/** NMS callbacks only extract bounded text and enqueue; filtering and durable ACK live on the server. */
class NotificationHooker : PartHooker() {
    override fun hook() {
        val nms = runCatching { Hooker.loader("com.android.server.notification.NotificationManagerService") }
            .getOrElse { e("NotificationCapture stage=nms_unavailable"); return }
        hookEnqueue(nms)
        hookPosted(nms)
    }

    private fun hookEnqueue(nms: Class<*>) {
        var installed = 0
        for (method in nms.declaredMethods.filter { it.name == "enqueueNotificationInternal" }) {
            val types = method.parameterTypes
            val index = types.indexOfFirst { Notification::class.java.isAssignableFrom(it) }
            // Validate AOSP's tag/id/Notification/userId group. Never guess unknown ROM argument slots.
            if (index < 2 || index + 1 >= types.size || types.firstOrNull() != String::class.java ||
                types[index - 2] != String::class.java || types[index - 1] != Int::class.javaPrimitiveType ||
                types[index + 1] != Int::class.javaPrimitiveType) continue
            runCatching {
                XposedBridge.hookMethod(method, object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        runCatching {
                            val pkg = param.args[0] as? String ?: return
                            val notification = param.args[index] as? Notification ?: return
                            val userId = param.args[index + 1] as Int
                            val id = param.args[index - 1] as Int
                            val tag = param.args[index - 2] as? String
                            process(pkg, userId, id, tag, notification)
                        }.onFailure { e("NotificationCapture stage=enqueue_callback_error") }
                    }
                })
                installed++
            }.onFailure { e("NotificationCapture stage=enqueue_hook_error") }
        }
        if (installed == 0) w("NotificationCapture stage=enqueue_hook_unavailable")
        else i("NotificationCapture stage=enqueue_hook_installed count=$installed")
    }

    private fun hookPosted(nms: Class<*>) {
        var installed = 0
        for (method in nms.declaredMethods.filter { it.name == "notifyCallNotificationEventListenerOnPosted" }) {
            runCatching {
                XposedBridge.hookMethod(method, object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        runCatching {
                            val record = param.args.firstOrNull() ?: return
                            val sbn = XposedHelpers.getObjectField(record, "sbn") as? StatusBarNotification ?: return
                            val userId = (XposedHelpers.callMethod(sbn.user, "getIdentifier") as Number).toInt()
                            process(sbn.packageName, userId, sbn.id, sbn.tag, sbn.notification)
                        }.onFailure { e("NotificationCapture stage=posted_callback_error") }
                    }
                })
                installed++
            }.onFailure { e("NotificationCapture stage=posted_hook_error") }
        }
        if (installed == 0) w("NotificationCapture stage=posted_hook_unavailable")
        else i("NotificationCapture stage=posted_hook_installed count=$installed")
    }

    private fun process(pkg: String, userId: Int, id: Int, tag: String?, notification: Notification) {
        val extras = notification.extras
        fun value(name: String): CharSequence? = runCatching { extras.getCharSequence(name) }.getOrNull()
        val title = NotificationEventIdentity.firstNonBlank(
            listOf(value(Notification.EXTRA_TITLE), value(Notification.EXTRA_TITLE_BIG)), 4096)
        var text = NotificationEventIdentity.firstNonBlank(
            listOf(value(Notification.EXTRA_BIG_TEXT), value(Notification.EXTRA_TEXT)), 16384)
        if (text.isEmpty()) {
            val lines = runCatching { extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES) }.getOrNull()
            // Traverse only until the total budget is exceeded; never discard a later payment line.
            val joined = lines?.let { NotificationEventIdentity.joinLinesBounded(it.asList(), 16384) }
            text = NotificationEventIdentity.firstNonBlank(listOf(joined, value(Notification.EXTRA_SUB_TEXT)), 16384)
        }
        val identity = NotificationEventIdentity.of(pkg, userId, id, tag, notification.`when`)
        XposedNotificationDelivery.offer(identity, pkg, title, text)
    }
}
