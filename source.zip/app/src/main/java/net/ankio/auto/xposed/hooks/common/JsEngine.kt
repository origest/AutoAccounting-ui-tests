/*
 * Copyright (C) 2024 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.xposed.hooks.common

import android.os.Build
import net.ankio.auto.xposed.core.logger.XposedLogger
import net.ankio.auto.xposed.core.utils.AppRuntime


object JsEngine {
    private fun initSoDir() {
        val framework = when {
            Build.SUPPORTED_64_BIT_ABIS.contains("arm64-v8a") -> "arm64"
            Build.SUPPORTED_64_BIT_ABIS.contains("x86_64") -> "x86_64"
            Build.SUPPORTED_32_BIT_ABIS.contains("armeabi-v7a") -> "arm"
            Build.SUPPORTED_32_BIT_ABIS.contains("x86") -> "x86"
            else -> "unsupported"
        }

        if (framework == "unsupported") {
            XposedLogger.d("JsEngine: unsupported arch, ABIs=${Build.SUPPORTED_64_BIT_ABIS.toList() + Build.SUPPORTED_32_BIT_ABIS.toList()}")
            return
        }

        AppRuntime.moduleSoPath =
            AppRuntime.modulePath.replace("/base.apk", "") + "/lib/$framework/"

        XposedLogger.d("JsEngine: so path=$framework")
    }

    fun init() {
        initSoDir()

        AppRuntime.load("mimalloc")
        AppRuntime.load("quickjs-android")
    }
}