/*
 * Copyright (C) 2024 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.xposed.hooks.wechat.hooks

import net.ankio.auto.xposed.core.api.PartHooker
import net.ankio.auto.xposed.core.hook.Hooker
import net.ankio.auto.xposed.hooks.wechat.models.LuckMoneyModel
import net.ankio.auto.xposed.hooks.wechat.models.WechatUserModel
import org.ezbook.server.constant.DataType
import org.json.JSONObject


class RedPackageHooker: PartHooker() {
    override fun hook() {
        val clazz = LuckMoneyModel.clazz()
        //  public void onGYNetEnd(int v, String s, JSONObject jSONObject0) {
        Hooker.before(clazz,
            "onGYNetEnd",
            Int::class.javaPrimitiveType!!,
            String::class.java,
            JSONObject::class.java
        ){ param ->
            val json = param.args[2] as JSONObject
            d("Red package hooked: $json")
            json.put(WechatUserModel.CHAT_USER, WechatUserModel.get(json.getString("sendUserName")))
            analysisData(DataType.DATA, json.toString())
        }
    }
}