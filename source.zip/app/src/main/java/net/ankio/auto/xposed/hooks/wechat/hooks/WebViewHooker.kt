/*
 * Copyright (C) 2024 ankio(ankio@ankio.net)
 * Licensed under the Apache License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-3.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package net.ankio.auto.xposed.hooks.wechat.hooks

import com.google.gson.Gson
import com.google.gson.JsonObject
import net.ankio.auto.xposed.core.api.PartHooker
import net.ankio.auto.xposed.core.hook.Hooker
import org.ezbook.server.tools.MD5HashTable
import org.ezbook.server.constant.DataType

class WebViewHooker:PartHooker() {
    private val md5HashTable = MD5HashTable()
    override fun hook() {
       Hooker.after("com.tencent.xweb.WebView", "evaluateJavascript", String::class.java, android.webkit.ValueCallback::class.java) {
           val json = it.args[0] as String
           if (json.contains("nativeWXPayCgiTunnel:ok")) {
              // val index = json.indexOf("javascript:WeixinJSBridge._handleMessageFromWeixin({")
               val jsonStr = json.substring("javascript:WeixinJSBridge._handleMessageFromWeixin(".length, json.length - 1)
               //AppRuntime.manifest.logD("Wechat WebViewHooker hook： $jsonStr")
              kotlin.runCatching {
                  val jsonObject = Gson().fromJson(jsonStr, JsonObject::class.java)
                  val params = jsonObject.getAsJsonObject("__json_message").getAsJsonObject("__params")
                  val respbuf = params.get("respbuf").asString
                  var __json = Gson().fromJson(respbuf, JsonObject::class.java)
                  //删除entrances节点
                  __json.remove("entrances")
                  __json.remove("service_module")
                  val md5 = MD5HashTable.md5(__json.toString())
                  if (md5HashTable.contains(md5)) {
                      d("Wechat WebViewHooker exist: $__json")
                      return@runCatching
                  }
                  md5HashTable.put(md5)
                  d("Wechat WebViewHooker hook: $__json")
                  analysisData(DataType.DATA, __json.toString())
              }.onFailure { e ->
                  e(e)
              }
           }
       }
    }
}