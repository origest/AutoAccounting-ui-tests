package net.ankio.chatgpt

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import java.util.concurrent.locks.ReentrantLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** All credentials remain in the owner application's UID. Network work must run off the UI thread. */
class ChatGptAccounts internal constructor(context: Context, private val clientFactory: () -> ProbeClient = { ProbeClient() }, storeName: String = "chatgpt-session") {
    private val store = CredentialStore(context.applicationContext, storeName)
    private var state = store.load()
    private var epoch = 0L
    private val operation = ReentrantLock()
    @Volatile private var activeClient: ProbeClient? = null
    @Volatile private var listener: LoopbackListener? = null
    private val requests = Executors.newSingleThreadExecutor()
    private var lastDiagnostic = ""
    private var catalog: Set<String> = emptySet()
    init { store.save(state) }

    data class AccountView(val key: String, val label: String, val signedIn: Boolean, val enabled: Boolean, val model: String, val ocrEnabled: Boolean = false)
    data class View(val accounts: List<AccountView>, val active: String, val diagnostic: String)
    /** No credentials or OCR content. Bind capture and result handling to this exact consent grant. */
    data class OcrTextTicket(val account: String, val model: String, val epoch: Long)
    /** Ephemeral, single-use approval for exactly the displayed raw record. Never serialize it. */
    class OneTimeTextApproval internal constructor(
        internal val account: String, internal val model: String, internal val epoch: Long,
        internal val system: String, internal val input: String
    ) { internal val consumed = java.util.concurrent.atomic.AtomicBoolean(false) }

    /** Invoke only from the affirmative action of the per-record text disclosure. */
    @Synchronized fun approveTextOnce(system: String, input: String): OneTimeTextApproval {
        val record = account()
        if (record.access.isEmpty() || !OAuthProtocol.canInfer(record.scopes)) throw AccountFailure("SIGN_IN_REQUIRED")
        if (record.model.isBlank()) throw AccountFailure("MODEL_REQUIRED")
        if (system.length > 8192 || input.length > 65536) throw AccountFailure("INPUT_TOO_LARGE")
        return OneTimeTextApproval(record.client, record.model, epoch, system, input)
    }
    @Synchronized fun isTextApprovalCurrent(approval: OneTimeTextApproval): Boolean =
        state.active == approval.account && epoch == approval.epoch &&
            state.accounts.any { it.client == approval.account && it.model == approval.model &&
                it.access.isNotEmpty() && OAuthProtocol.canInfer(it.scopes) }
    @Synchronized fun isTextApprovalFor(approval: OneTimeTextApproval, system: String, input: String): Boolean =
        isTextApprovalCurrent(approval) && approval.system == system && approval.input == input

    suspend fun recognizeApprovedText(approval: OneTimeTextApproval): String {
        synchronized(this) {
            if (!isTextApprovalCurrent(approval)) throw AccountFailure("CANCELLED")
            if (!approval.consumed.compareAndSet(false, true)) throw AccountFailure("APPROVAL_ALREADY_USED")
        }
        return requestText(TextPurpose.APPROVED_TEXT, approval.system, approval.input, oneTime = approval)
    }
    @Synchronized fun view() = View(state.accounts.map {
        AccountView(it.client, "ChatGPT 账号 ${it.label}", it.access.isNotEmpty(), it.consent && it.paused.isEmpty(), it.model,
            it.ocrTextConsent && it.paused.isEmpty())
    }, state.active, lastDiagnostic)
    @Synchronized fun ocrTextTicket(): OcrTextTicket? {
        val record = state.accounts.firstOrNull { it.client == state.active } ?: return null
        if (record.access.isEmpty() || !OAuthProtocol.canInfer(record.scopes) || !record.permits(TextPurpose.OCR_TEXT)) return null
        return OcrTextTicket(record.client, record.model, epoch)
    }
    @Synchronized fun isOcrTextTicketCurrent(ticket: OcrTextTicket): Boolean = ocrTextTicket() == ticket
    /** Local bounded commits only, never network or UI. Revocation waits for this commit to finish. */
    @Synchronized fun <T> commitOcrText(ticket: OcrTextTicket, commit: () -> T): T {
        if (!isOcrTextTicketCurrent(ticket)) throw AccountFailure("CANCELLED")
        return commit()
    }
    @Synchronized fun <T> commitApprovedText(approval: OneTimeTextApproval, commit: () -> T): T {
        if (!isTextApprovalCurrent(approval)) throw AccountFailure("CANCELLED")
        return commit()
    }
    @Synchronized private fun account(): AccountRecord = state.accounts.firstOrNull { it.client == state.active }
        ?: throw AccountFailure("SIGN_IN_REQUIRED")
    private fun AccountRecord.session() = ProbeSession(client, subjectHash, access, scopes, expiresAt, refresh, idToken)
    private fun AccountRecord.update(session: ProbeSession) {
        access = session.accessToken; refresh = session.refreshToken; idToken = session.idToken
        scopes = session.scopes; expiresAt = session.expiresAt
    }
    @Synchronized fun cancel() {
        epoch++
        activeClient?.close(); listener?.close(); listener = null
    }
    @Synchronized fun select(key: String) {
        cancel()
        catalog = emptySet()
        if (state.accounts.none { it.client == key }) throw AccountFailure("SIGN_IN_REQUIRED")
        state.accounts.forEach { it.consent = false; it.ocrTextConsent = false }
        state.active = key
        account() // Validate selection, never create a registration from UI data.
        store.save(state)
    }
    @Synchronized fun pause() {
        cancel()
        state.accounts.forEach { it.consent = false; it.ocrTextConsent = false }
        store.save(state)
    }
    /** Pause OCR text only; category-only consent remains unchanged. */
    @Synchronized fun disableOcrText() {
        cancel()
        state.accounts.forEach { it.ocrTextConsent = false }
        store.save(state); lastDiagnostic = "已暂停 OCR 文字识别。"
    }
    private inline fun <T> exclusive(block: () -> T): T {
        if (!operation.tryLock()) throw AccountFailure("BUSY")
        try { return block() } finally { activeClient = null; operation.unlock() }
    }
    /** null = new account. Existing registrations cannot be overwritten by a different identity. */
    fun signIn(key: String?, browser: (String) -> Unit) = exclusive {
        val snapshot = synchronized(this) {
            cancel()
            state.accounts.forEach { it.consent = false; it.ocrTextConsent = false }
            store.save(state)
            if (key == null && state.accounts.size >= 10) throw AccountFailure("ACCOUNT_LIMIT")
            val old = key?.let { k -> state.accounts.firstOrNull { it.client == k } ?: throw AccountFailure("SIGN_IN_REQUIRED") }
            Triple(epoch, old?.client.orEmpty(), old?.subjectHash.orEmpty())
        }
        val client = clientFactory(); activeClient = client
        val receiver = LoopbackListener(); listener = receiver
        try {
            val attempt = OAuthProtocol.Attempt(receiver.redirect, synchronized(this) { state.host }, snapshot.second)
            browser(attempt.authorizationUrl())
            val callback = receiver.use { it.await(attempt) }
            val session = client.signIn(attempt, callback, snapshot.third)
            synchronized(this) {
                if (epoch != snapshot.first) throw AccountFailure("CANCELLED")
                val existing = state.accounts.firstOrNull { it.client == session.clientId }
                if (existing != null && existing.subjectHash != session.subjectHash) throw AccountFailure("ACCOUNT_CHANGED")
                val record = existing ?: AccountRecord().also {
                    it.label = (state.accounts.maxOfOrNull { a -> a.label } ?: 0) + 1
                    it.client = session.clientId; it.subjectHash = session.subjectHash
                    state.accounts.add(it)
                }
                state.accounts.forEach { it.consent = false; it.ocrTextConsent = false }
                record.update(session); record.paused = ""; record.model = ""
                catalog = emptySet()
                state.active = record.client
                store.save(state); lastDiagnostic = "身份已验证；请选模型并单独确认账单数据发送。"
            }
        } catch (e: Exception) { recordFailure(client, e, snapshot.first, invalidateActive = false); throw safe(e) }
        finally { receiver.close(); listener = null; client.close() }
    }
    private fun fresh(client: ProbeClient, ticket: Long): ProbeSession {
        val original = synchronized(this) {
            if (epoch != ticket) throw AccountFailure("CANCELLED")
            account().session()
        }
        if (original.accessToken.isEmpty()) throw AccountFailure("SIGN_IN_REQUIRED")
        if (original.expiresAt > System.currentTimeMillis() + 60000) return original
        val renewed = client.refresh(original)
        synchronized(this) {
            if (epoch != ticket || account().client != original.clientId) throw AccountFailure("CANCELLED")
            account().update(renewed)
            store.save(state) // Persist rotated token before any inference, never replay refresh after failure.
        }
        return renewed
    }
    fun models(): List<ProbeModel> = exclusive {
        val ticket = synchronized(this) { epoch }
        val client = clientFactory(); activeClient = client
        try {
            val choices = client.models(fresh(client, ticket))
            synchronized(this) {
                if (epoch != ticket) throw AccountFailure("CANCELLED")
                catalog = choices.map { it.slug }.toSet()
            }
            choices
        }
        catch (e: Exception) { recordFailure(client, e, ticket); throw safe(e) }
        finally { client.close() }
    }
    /** Call only after explicit per-account category data/plan consent and a current model selection. */
    @Synchronized fun enable(model: String) {
        val record = requireModel(model)
        if (record.model != model) { cancel(); record.ocrTextConsent = false }
        record.model = model; record.consent = true; record.paused = ""
        store.save(state); lastDiagnostic = "已开启历史辅助分类。可随时暂停或退出账号。"
    }
    /** Select a model without granting permission to send any bill or OCR data. */
    @Synchronized fun selectModel(model: String) {
        val record = requireModel(model)
        if (record.model != model) {
            cancel(); record.consent = false; record.ocrTextConsent = false
            record.model = model
        }
        store.save(state)
    }
    /** Call only after separate, explicit per-account consent to send local OCR text. Never sends images. */
    @Synchronized fun enableOcrText(model: String) {
        val record = requireModel(model)
        cancel() // A new grant never adopts text captured or queued under an earlier grant.
        if (record.model != model) record.consent = false
        record.model = model; record.ocrTextConsent = true; record.paused = ""
        try { store.save(state) }
        catch (e: Exception) { record.ocrTextConsent = false; cancel(); throw e }
        lastDiagnostic = "已开启 OCR 文字识别；不发送图片。可随时暂停或退出账号。"
    }
    private fun requireModel(model: String): AccountRecord {
        val record = account()
        if (record.access.isEmpty() || !OAuthProtocol.canInfer(record.scopes)) throw AccountFailure("SIGN_IN_REQUIRED")
        if (model.isBlank() || model.length > 200 || model !in catalog) throw AccountFailure("MODEL_REQUIRED")
        return record
    }
    private enum class TextPurpose(val pausedCode: String) {
        CLASSIFICATION("CLASSIFICATION_PAUSED"), OCR_TEXT("OCR_TEXT_PAUSED"), APPROVED_TEXT("SIGN_IN_REQUIRED")
    }
    private fun AccountRecord.permits(purpose: TextPurpose) = (purpose == TextPurpose.APPROVED_TEXT || paused.isEmpty()) && model.isNotEmpty() &&
        when (purpose) { TextPurpose.CLASSIFICATION -> consent; TextPurpose.OCR_TEXT -> ocrTextConsent; TextPurpose.APPROVED_TEXT -> access.isNotEmpty() && OAuthProtocol.canInfer(scopes) }
    suspend fun classify(system: String, input: String): String = requestText(TextPurpose.CLASSIFICATION, system, input)
    suspend fun recognizeOcrText(system: String, input: String): String = requestText(TextPurpose.OCR_TEXT, system, input)
    suspend fun recognizeOcrText(system: String, input: String, ticket: OcrTextTicket): String =
        requestText(TextPurpose.OCR_TEXT, system, input, ticket)
    private suspend fun requestText(purpose: TextPurpose, system: String, input: String, expectedTicket: OcrTextTicket? = null,
        oneTime: OneTimeTextApproval? = null): String = suspendCancellableCoroutine { continuation ->
        // Bind queued text to the consent epoch at submission, not whichever account is active later.
        val ticket = synchronized(this) {
            if (expectedTicket != null && !isOcrTextTicketCurrent(expectedTicket)) throw AccountFailure("CANCELLED")
            if (purpose == TextPurpose.APPROVED_TEXT && (oneTime == null || !isTextApprovalCurrent(oneTime))) throw AccountFailure("CANCELLED")
            if (!account().permits(purpose)) throw AccountFailure(purpose.pausedCode)
            epoch
        }
        val client = clientFactory()
        val cancelled = java.util.concurrent.atomic.AtomicBoolean(false)
        val future = requests.submit {
            try {
                val output = exclusive {
                    synchronized(this) {
                        if (epoch != ticket) throw AccountFailure("CANCELLED")
                        val record = account()
                        if (!record.permits(purpose)) throw AccountFailure(purpose.pausedCode)
                        activeClient = client
                    }
                    try {
                        val session = fresh(client, ticket)
                        val model = synchronized(this) {
                            if (epoch != ticket || !account().permits(purpose)) throw AccountFailure("CANCELLED")
                            account().model
                        }
                        val result = client.classify(session, ProbeModel(model, model), system, input)
                        synchronized(this) {
                            if (epoch != ticket || !account().permits(purpose)) throw AccountFailure("CANCELLED")
                        }
                        result
                    } catch (e: Exception) {
                        // Cancelling a dialog/coroutine closes the transport and can surface as an
                        // IOException/diagnostic, not CancellationException. It is not revocation.
                        if (cancelled.get() || continuation.isCancelled || e is CancellationException ||
                            (e is AccountFailure && e.code == "CANCELLED")) throw CancellationException("Request cancelled")
                        synchronized(this) {
                            if (epoch == ticket) {
                                account().consent = false; account().ocrTextConsent = false; account().paused = "REQUEST_FAILED"
                                store.save(state)
                            }
                        }
                        recordFailure(client, e, ticket); throw safe(e)
                    }
                }
                if (continuation.isActive) continuation.resume(output)
            } catch (e: Exception) { if (continuation.isActive) continuation.resumeWithException(safe(e)) }
            finally { client.close() }
        }
        continuation.invokeOnCancellation { cancelled.set(true); client.close(); future.cancel(true) }
    }
    /** Clear locally first, stop in-flight work, then make one best-effort revocation attempt. */
    fun signOut(): Boolean {
        val interrupted = operation.isLocked
        val session = synchronized(this) {
            cancel()
            val record = account()
            val previous = record.session()
            record.consent = false; record.ocrTextConsent = false; record.access = ""; record.refresh = ""; record.idToken = ""
            record.scopes = emptySet(); record.expiresAt = 0; record.paused = "SIGNED_OUT"
            store.save(state)
            previous
        }
        val client = clientFactory()
        val confirmed = if (operation.tryLock()) {
            try { client.revoke(session) && !interrupted } catch (_: Exception) { false }
            finally { operation.unlock(); client.close() }
        } else { client.close(); false }
        synchronized(this) { lastDiagnostic = if (confirmed) "已退出并撤销会话。" else "本地凭据已清除；远程撤销未确认，请在 ChatGPT 设置中断开应用。" }
        return confirmed
    }
    @Synchronized private fun recordFailure(client: ProbeClient, error: Exception, ticket: Long, invalidateActive: Boolean = true) {
        // An old account's late failure must not mutate a newly selected account.
        if (epoch != ticket) return
        lastDiagnostic = if (error is AccountFailure) error.code else Diagnostics.render(client.stage, error)
        val failure = error as? DiagnosticFailure
        state.accounts.firstOrNull { it.client == state.active }?.let {
            it.consent = false; it.ocrTextConsent = false; it.paused = "REQUEST_FAILED"
            if (invalidateActive && (failure?.http == 401 || failure?.oauth in setOf(KnownOAuthError.INVALID_GRANT, KnownOAuthError.INVALID_CLIENT) || failure?.code == DiagnosticCode.SCOPE_MISSING)) {
                it.access = ""; it.refresh = ""; it.idToken = ""; it.paused = "SIGN_IN_REQUIRED"
            }
            store.save(state)
        }
    }
    private fun safe(error: Exception): Exception = if (error is AccountFailure) error else Diagnostics.normalize(error)
    companion object {
        fun pauseIfInitialized() { instance?.pause() }
        fun cancelIfInitialized() { instance?.cancel() }
        fun clearLocalCredentials(context: Context) = synchronized(this) {
            instance?.cancel()
            instance?.requests?.shutdownNow()
            CredentialStore(context.applicationContext).clear()
            instance = null
        }
        @Volatile private var instance: ChatGptAccounts? = null
        fun get(context: Context): ChatGptAccounts = instance ?: synchronized(this) {
            instance ?: ChatGptAccounts(context.applicationContext).also { instance = it }
        }
    }
}
