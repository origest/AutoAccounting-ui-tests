package net.ankio.chatgpt

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import com.google.gson.Gson
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class AccountFailure(val code: String) : Exception() // Callers use fixed codes only; no causes or payloads.

internal class AccountRecord {
    var label: Int = 0
    var client = ""
    var subjectHash = ""
    var access = ""
    var refresh = ""
    var idToken = ""
    var scopes: Set<String> = emptySet()
    var expiresAt = 0L
    var model = ""
    var consent = false
    // Independent opt-in: existing category consent never authorizes raw OCR text.
    // Gson leaves this false when loading records created before this field existed.
    var ocrTextConsent = false
    var paused = ""
}
internal class AccountState {
    var host = "urn:uuid:${UUID.randomUUID()}"
    var active = ""
    var accounts = mutableListOf<AccountRecord>()
}

/** Never enters database exports, preferences, cloud backup or device transfer. */
internal class CredentialStore(context: Context, name: String = "chatgpt-session") {
    private val file = AtomicFile(File(context.noBackupFilesDir, "$name.enc"))
    private val alias = "${context.packageName}.$name.aes.v1"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build())
        }.generateKey()
    }
    @Synchronized fun load(): AccountState = try {
        if (!file.baseFile.exists() && !File(file.baseFile.path + ".bak").exists()) AccountState() else {
            if (file.baseFile.length() > 131072) throw AccountFailure("STORE_UNAVAILABLE")
            val bytes = file.openRead().use { it.readBytes() }
            if (bytes.size !in 30..131072 || bytes[0] != 1.toByte()) throw AccountFailure("STORE_UNAVAILABLE")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(1, 13)))
            }
            val plain = cipher.doFinal(bytes.copyOfRange(13, bytes.size))
            try {
                Gson().fromJson(String(plain, Charsets.UTF_8), AccountState::class.java).also {
                    require(it.host.startsWith("urn:uuid:") && it.accounts.size <= 10)
                    require(it.accounts.map { a -> a.client }.distinct().size == it.accounts.size)
                }
            } finally { plain.fill(0) }
        }
    } catch (_: Exception) { throw AccountFailure("STORE_UNAVAILABLE") }
    @Synchronized fun save(state: AccountState) {
        var stream: java.io.FileOutputStream? = null
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
            val plain = Gson().toJson(state).toByteArray(Charsets.UTF_8)
            val encrypted = try { cipher.doFinal(plain) } finally { plain.fill(0) }
            require(encrypted.size <= 131059 && cipher.iv.size == 12)
            stream = file.startWrite()
            stream.write(byteArrayOf(1)); stream.write(cipher.iv); stream.write(encrypted)
            file.finishWrite(stream)
        } catch (_: Exception) { file.failWrite(stream); throw AccountFailure("STORE_UNAVAILABLE") }
    }
    @Synchronized fun clear() {
        file.delete()
        try { KeyStore.getInstance("AndroidKeyStore").apply { load(null); deleteEntry(alias) } }
        catch (_: Exception) { throw AccountFailure("STORE_UNAVAILABLE") }
    }
}
