package net.ankio.chatgpt

import com.google.gson.JsonParser
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.UnknownHostException
import javax.net.ssl.*
import java.security.cert.*

enum class ProbeStage(val label: String) {
    CALLBACK("接收浏览器回调"), DISCOVERY("读取官方授权配置"), TOKEN_EXCHANGE("交换授权码"),
    JWKS("读取签名公钥"), ID_TOKEN("验证身份签名和声明"), ACCOUNT("核对返回账号"),
    TOKEN_FIELDS("检查推理凭据与权限"), MODELS("读取模型列表"), INFERENCE("Hello 测试")
}
enum class DiagnosticCode(val hint: String) {
    CALLBACK_FORMAT("回调格式不符合预期"), CALLBACK_STATE("回调 state 不匹配；没有交换凭据"),
    CALLBACK_DUPLICATE("回调含重复参数"), CALLBACK_CLIENT("注册 ID 缺失或不匹配"), CALLBACK_CODE("回调缺少授权码"),
    OAUTH_RETURNED_ERROR("官方授权返回错误；未交换凭据"),
    DISCOVERY_MISMATCH("官方配置与固定安全端点不一致；停止验证，不降低校验"),
    JSON_SCHEMA("服务响应结构不符合预期"), RESPONSE_TOO_LARGE("服务响应超过安全上限"),
    ID_TOKEN_MISSING("交换结果缺少身份凭据"), JWT_FORMAT("身份凭据格式不符合预期"),
    JWT_ALGORITHM("身份签名算法不受此验证版支持"), JWT_KEY("未找到唯一可用签名公钥"),
    JWT_SIGNATURE("身份签名未通过验证"), JWT_ISSUER("身份签发方不匹配"), JWT_AUDIENCE("身份受众或授权方不匹配"),
    JWT_TIME("身份时间校验失败；检查手机是否使用自动日期与时间"), JWT_NONCE("身份 nonce 不匹配；不能跳过验证"),
    JWT_SUBJECT("身份缺少有效主体"), ACCOUNT_CHANGED("返回账号与原注册不一致；需要换账号时使用忘记注册"),
    TOKEN_TYPE("访问凭据类型不符合预期"), TOKEN_EXPIRY("凭据有效期字段不符合预期"),
    ACCESS_MISSING("已获推理权限但缺少访问凭据"), SCOPE_MISSING("未获所需计划用量权限；不会发送模型请求"),
    EXPIRED("本次访问凭据已过期"), MODEL_SCHEMA("模型目录格式不符；不会猜测模型或自动发请求"),
    HTTP_ERROR("服务返回失败；请报告阶段、HTTP 状态和下方安全代码，不要反复登录"),
    DNS("域名解析失败；检查此应用的网络可达性"), TLS("TLS 证书或安全连接失败；不要关闭证书验证"),
    TLS_CERT_TIME("证书时间校验失败；核对自动日期时间，不关闭校验"),
    TLS_CERT_CHAIN("证书链校验失败；不安装未知 CA 或关闭校验"),
    TLS_PEER("TLS 对端身份校验失败；保留主机名与证书校验"),
    TLS_HANDSHAKE("TLS 握手失败；该代码本身不能确定是证书问题"),
    TLS_PROTOCOL("TLS 协议处理失败"), TLS_IO("加密连接发生异常；结合传输阶段判断"),
    STREAM_CONTENT_TYPE("响应不是预期的 SSE 类型；未当作推理成功"),
    STREAM_EMPTY("响应正文为空；未收到完成事件"), STREAM_FORMAT("缺少类型声明且正文不符合 SSE 帧格式"),
    STREAM_BODY_MISSING("推理响应缺少正文"), STREAM_LINE("SSE 行过长或结尾截断"),
    STREAM_EVENT_LIMIT("SSE 单个事件超过上限"), STREAM_JSON("SSE 事件不是有效 JSON 对象"),
    STREAM_SCHEMA("SSE 事件结构不符合预期"), STREAM_COMPLETION("完成事件状态不符合预期"),
    STREAM_ENDED("响应流结束但未收到完整成功事件"),
    INVALID_ARGUMENT("内部参数或响应值不符合预期"), INVALID_STATE("本阶段状态不符合预期"),
    NULL_VALUE("本阶段缺少必要值"), UNSUPPORTED_OPERATION("本阶段遇到不支持的操作"),
    TIMEOUT("本阶段超时；未自动重试"), CONNECTION("网络连接失败"), NETWORK_IO("网络传输中断"),
    CANCELLED("操作已取消"), SECURITY("系统安全或权限限制阻止操作"),
    UNEXPECTED("本阶段发生未分类错误；仅报告安全阶段代码即可"), STREAM_FAILED("模型响应未完成"),
    ALREADY_TESTED("本会话已尝试测试；未重复提交")
}
enum class KnownOAuthError(val wire: String) {
    ACCESS_DENIED("access_denied"), INVALID_GRANT("invalid_grant"), INVALID_CLIENT("invalid_client"),
    INVALID_SCOPE("invalid_scope"), INVALID_REQUEST("invalid_request"), UNAUTHORIZED_CLIENT("unauthorized_client"),
    SERVER_ERROR("server_error"), TEMPORARILY_UNAVAILABLE("temporarily_unavailable"),
    NOT_ELIGIBLE("subscription_sharing_user_not_eligible"), LIMIT_EXCEEDED("subscription_sharing_usage_limit_exceeded"),
    USAGE_UNAVAILABLE("subscription_sharing_usage_unavailable"), UNSUPPORTED("subscription_sharing_unsupported_capability"),
    ROUTE_UNSUPPORTED("subscription_sharing_route_not_supported"), INVALID_USER("subscription_sharing_invalid_user"),
    SCOPE_UNAUTHORIZED("chatpass_v2_scope_not_authorized"), AUTH_CONTEXT("chatpass_v2_invalid_authorization_context"),
    USER_UNAVAILABLE("subscription_sharing_user_unavailable"), UNKNOWN("unrecognized_error");
    companion object { fun of(value: String?) = entries.firstOrNull { it != UNKNOWN && it.wire == value } ?: UNKNOWN }
}
enum class TransportPhase { REQUEST_STARTED, CONNECTING, TLS_HANDSHAKE, TLS_ESTABLISHED, CONNECTION_READY, SENDING_HEADERS, SENDING_BODY, WAITING_HEADERS, RESPONSE_HEADERS, READING_BODY }
enum class ErrorShape { OAUTH_STRING, API_ERROR_OBJECT, DETAIL, RESPONSE_OBJECT, OTHER }
enum class ResponseType { SSE, JSON, HTML, TEXT, MISSING, CONFLICTING, OTHER }
open class DiagnosticFailure(val code: DiagnosticCode, val http: Int? = null,
    val oauth: KnownOAuthError? = null, val shape: ErrorShape? = null, val transport: TransportPhase? = null, val responseType: ResponseType? = null) : Exception()
fun verifyProbe(condition: Boolean, code: DiagnosticCode) { if (!condition) throw DiagnosticFailure(code) }

/** Never concatenate exception messages, payloads, URLs, JWT claims or identifiers. */
object Diagnostics {
    fun normalize(error: Exception): DiagnosticFailure = when (error) {
        is DiagnosticFailure -> error
        is UnknownHostException -> DiagnosticFailure(DiagnosticCode.DNS)
        is SSLException -> DiagnosticFailure(tlsCode(error))
        is InterruptedIOException -> DiagnosticFailure(DiagnosticCode.TIMEOUT)
        is ConnectException -> DiagnosticFailure(DiagnosticCode.CONNECTION)
        is IOException -> DiagnosticFailure(DiagnosticCode.NETWORK_IO)
        is SecurityException -> DiagnosticFailure(DiagnosticCode.SECURITY)
        is com.google.gson.JsonParseException -> DiagnosticFailure(DiagnosticCode.JSON_SCHEMA)
        is NullPointerException -> DiagnosticFailure(DiagnosticCode.NULL_VALUE)
        is IllegalArgumentException -> DiagnosticFailure(DiagnosticCode.INVALID_ARGUMENT)
        is IllegalStateException -> DiagnosticFailure(DiagnosticCode.INVALID_STATE)
        is UnsupportedOperationException -> DiagnosticFailure(DiagnosticCode.UNSUPPORTED_OPERATION)
        else -> DiagnosticFailure(DiagnosticCode.UNEXPECTED)
    }
    private fun tlsCode(error: SSLException): DiagnosticCode {
        var cause: Throwable? = error
        repeat(8) {
            when (cause) {
                is CertificateExpiredException, is CertificateNotYetValidException -> return DiagnosticCode.TLS_CERT_TIME
                is CertPathValidatorException -> return if ((cause as CertPathValidatorException).reason in
                    setOf(CertPathValidatorException.BasicReason.EXPIRED, CertPathValidatorException.BasicReason.NOT_YET_VALID))
                    DiagnosticCode.TLS_CERT_TIME else DiagnosticCode.TLS_CERT_CHAIN
                is CertificateException -> return DiagnosticCode.TLS_CERT_CHAIN
            }
            cause = cause?.cause
        }
        return when (error) {
            is SSLPeerUnverifiedException -> DiagnosticCode.TLS_PEER
            is SSLProtocolException -> DiagnosticCode.TLS_PROTOCOL
            is SSLHandshakeException -> DiagnosticCode.TLS_HANDSHAKE
            else -> DiagnosticCode.TLS_IO
        }
    }
    fun render(stage: ProbeStage, error: Exception): String {
        val e = normalize(error)
        return (if (stage == ProbeStage.MODELS || stage == ProbeStage.INFERENCE) "身份已校验，后续步骤未完成" else "验证未通过") + " [ChatGPT ${stage.name}/${e.code.name}]\n阶段：${stage.label}\n${e.code.hint}" +
            (e.http?.takeIf { it in 100..599 }?.let { "\nHTTP：$it" } ?: "") +
            (e.oauth?.let { "\n安全错误码：${it.wire}" } ?: "") +
            (e.transport?.let { "\n传输阶段：${it.name}（不代表服务器未处理或未计用量）" } ?: "") +
            (e.responseType?.let { "\n响应类型：${it.name}" } ?: "") +
            (e.shape?.let { "\n响应形状：${it.name}" } ?: "") +
            "\n无需发送授权链接、code、令牌或账号信息。"
    }
    fun responseType(values: List<String>): ResponseType {
        if (values.isEmpty()) return ResponseType.MISSING
        val types = values.map { it.substringBefore(';').trim().lowercase(java.util.Locale.ROOT) }.distinct()
        if (types.size != 1) return ResponseType.CONFLICTING
        return when (val type = types.single()) {
            "text/event-stream" -> ResponseType.SSE
            "application/json" -> ResponseType.JSON
            "text/html", "application/xhtml+xml" -> ResponseType.HTML
            "text/plain" -> ResponseType.TEXT
            "" -> ResponseType.MISSING
            else -> if (type.startsWith("application/") && type.endsWith("+json")) ResponseType.JSON else ResponseType.OTHER
        }
    }
    fun httpFailure(status: Int, body: String): DiagnosticFailure {
        var shape = ErrorShape.OTHER
        var code: String? = null
        runCatching {
            val root = JsonParser.parseString(body).asJsonObject
            val error = root["error"]
            when {
                error?.isJsonPrimitive == true && error.asJsonPrimitive.isString -> { shape = ErrorShape.OAUTH_STRING; code = error.asString }
                error?.isJsonObject == true -> { shape = ErrorShape.API_ERROR_OBJECT; code = error.asJsonObject["code"]?.asString }
                root.has("detail") -> shape = ErrorShape.DETAIL
                root["object"]?.let { it.isJsonPrimitive && it.asJsonPrimitive.isString && it.asString == "response" } == true -> shape = ErrorShape.RESPONSE_OBJECT
            }
        }
        return DiagnosticFailure(DiagnosticCode.HTTP_ERROR, status, KnownOAuthError.of(code), shape)
    }
}
