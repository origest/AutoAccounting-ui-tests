package net.ankio.chatgpt

import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.io.ByteArrayOutputStream

/** Bound only to IPv4 loopback; no logs, request bodies or URLs are retained. */
class LoopbackListener : AutoCloseable {
    private val server = ServerSocket().apply {
        bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 1)
        soTimeout = 1000
    }
    val redirect = "http://127.0.0.1:${server.localPort}/auth/callback"
    fun await(attempt: OAuthProtocol.Attempt, timeoutMs: Long = 300_000, onRejected: (DiagnosticFailure) -> Unit = {}): OAuthProtocol.Callback {
        val deadline = System.nanoTime() + timeoutMs * 1_000_000
        while (!server.isClosed && System.nanoTime() < deadline) {
            val socket = try { server.accept() } catch (_: SocketTimeoutException) { continue }
            socket.use {
                it.soTimeout = 2000
                var result: OAuthProtocol.Callback? = null
                var denied: OAuthProtocol.Denied? = null
                try {
                    val bytes = ByteArrayOutputStream()
                    while (bytes.size() < 8192) {
                        val b = it.getInputStream().read()
                        if (b < 0) break
                        bytes.write(b)
                        if (b == 10 && bytes.toString("US-ASCII").endsWith("\r\n\r\n")) break
                    }
                    val lines = bytes.toString("US-ASCII").split("\r\n")
                    verifyProbe(bytes.size() < 8192 && lines.first().startsWith("GET /auth/callback?"), DiagnosticCode.CALLBACK_FORMAT)
                    val hostHeaders = lines.filter { line -> line.startsWith("Host:", true) }
                    verifyProbe(hostHeaders.size == 1 && hostHeaders[0].substringAfter(':').trim() == "127.0.0.1:${server.localPort}", DiagnosticCode.CALLBACK_FORMAT)
                    result = OAuthProtocol.callback(lines.first().split(' ')[1], attempt)
                } catch (e: OAuthProtocol.Denied) { denied = e } catch (e: Exception) { onRejected(Diagnostics.normalize(e)) }
                val body = when { denied != null -> "Authorization returned an error. Return to AutoAccounting for a safe diagnostic."; result != null -> "Callback received. Sign-in is not yet verified. Return to AutoAccounting."; else -> "Invalid callback. Return to the app for a safe diagnostic." }
                val status = if (result != null || denied != null) "200 OK" else "400 Bad Request"
                runCatching {
                    it.getOutputStream().write(("HTTP/1.1 $status\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nConnection: close\r\nContent-Length: ${body.toByteArray().size}\r\n\r\n$body").toByteArray())
                }
                if (denied != null) throw denied
                if (result != null) return result
            }
        }
        throw SocketTimeoutException()
    }
    override fun close() = server.close()
}
