package net.ankio.chatgpt

import com.google.gson.JsonObject
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.crypto.ECDSAVerifier
import com.nimbusds.jose.crypto.RSASSAVerifier
import com.nimbusds.jose.jwk.JWKSet
import com.nimbusds.jose.jwk.ECKey
import com.nimbusds.jose.jwk.RSAKey
import com.nimbusds.jwt.SignedJWT
import okhttp3.HttpUrl.Companion.toHttpUrl
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** No Android dependencies: test the security boundaries without a real account. */
object OAuthProtocol {
    const val ISSUER = "https://auth.openai.com"
    const val AUTH = "$ISSUER/api/accounts/authorize"
    const val TOKEN = "$ISSUER/api/accounts/oauth/token"
    const val JWKS = "$ISSUER/.well-known/jwks.json"
    const val RESOURCE = "https://api.openai.com/v1"
    const val PLAN_SCOPE = "chatgpt.tokens.use.direct"
    const val DYNAMIC = "dynamic_agent_client"
    val scopes = "openid profile email offline_access resource.invoke $PLAN_SCOPE"
    fun random(): String = Base64.getUrlEncoder().withoutPadding().encodeToString(ByteArray(32).also(SecureRandom()::nextBytes))
    fun digest(text: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.US_ASCII)))
    fun equal(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    class Attempt(val redirect: String, val host: String, val savedClient: String = "") {
        val state = random()
        val nonce = random()
        val verifier = random()
        fun authorizationUrl(): String = AUTH.toHttpUrl().newBuilder().apply {
            addQueryParameter("client_id", savedClient.ifEmpty { DYNAMIC })
            if (savedClient.isEmpty()) addQueryParameter("agent_name_hint", "AutoAccounting")
            addQueryParameter("ext_agent_host_id", host)
            addQueryParameter("response_type", "code")
            addQueryParameter("redirect_uri", redirect)
            addQueryParameter("scope", scopes)
            addQueryParameter("resource", RESOURCE)
            addQueryParameter("state", state)
            addQueryParameter("nonce", nonce)
            addQueryParameter("code_challenge_method", "S256")
            addQueryParameter("code_challenge", digest(verifier))
        }.build().toString()
    }
    class Callback(val code: String, val client: String)
    fun callback(target: String, attempt: Attempt): Callback {
        val uri = ("http://127.0.0.1" + target).toHttpUrl()
        verifyProbe(uri.encodedPath == "/auth/callback", DiagnosticCode.CALLBACK_FORMAT)
        verifyProbe(uri.queryParameterNames.all { uri.queryParameterValues(it).size == 1 }, DiagnosticCode.CALLBACK_DUPLICATE)
        verifyProbe(equal(uri.queryParameter("state").orEmpty(), attempt.state), DiagnosticCode.CALLBACK_STATE)
        if (uri.queryParameter("error") != null) throw Denied(KnownOAuthError.of(uri.queryParameter("error")))
        val client = uri.queryParameter("client_id") ?: attempt.savedClient
        verifyProbe(client.matches(Regex("oaiapp_[A-Za-z0-9_-]+")), DiagnosticCode.CALLBACK_CLIENT)
        verifyProbe(attempt.savedClient.isEmpty() || client == attempt.savedClient, DiagnosticCode.CALLBACK_CLIENT)
        val code = uri.queryParameter("code").orEmpty()
        verifyProbe(code.isNotBlank() && code.length <= 4096, DiagnosticCode.CALLBACK_CODE)
        return Callback(code, client)
    }
    class Denied(error: KnownOAuthError = KnownOAuthError.ACCESS_DENIED) : DiagnosticFailure(DiagnosticCode.OAUTH_RETURNED_ERROR, oauth = error)

    fun validateIdToken(token: String, keys: String, client: String, nonce: String, now: Long = System.currentTimeMillis() / 1000): String {
        verifyProbe(token.length <= 32768, DiagnosticCode.JWT_FORMAT)
        val jwt = try { SignedJWT.parse(token) } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.JWT_FORMAT) }
        verifyProbe(jwt.header.criticalParams.isNullOrEmpty(), DiagnosticCode.JWT_ALGORITHM)
        verifyProbe(jwt.header.algorithm in setOf(JWSAlgorithm.RS256, JWSAlgorithm.ES256), DiagnosticCode.JWT_ALGORITHM)
        val key = try { JWKSet.parse(keys).keys.single { it.keyID == jwt.header.keyID && it.keyID != null } } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.JWT_KEY) }
        verifyProbe(key.keyUse == null || key.keyUse.identifier() == "sig", DiagnosticCode.JWT_KEY)
        verifyProbe(key.algorithm == null || key.algorithm == jwt.header.algorithm, DiagnosticCode.JWT_KEY)
        val verified = try { when {
            key is RSAKey && jwt.header.algorithm == JWSAlgorithm.RS256 -> jwt.verify(RSASSAVerifier(key.toRSAPublicKey()))
            key is ECKey && jwt.header.algorithm == JWSAlgorithm.ES256 -> jwt.verify(ECDSAVerifier(key.toECPublicKey()))
            else -> false
        } } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.JWT_SIGNATURE) }
        verifyProbe(verified, DiagnosticCode.JWT_SIGNATURE)
        val c = try { jwt.jwtClaimsSet } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.JWT_FORMAT) }
        verifyProbe(c.issuer == ISSUER, DiagnosticCode.JWT_ISSUER)
        verifyProbe(client in c.audience, DiagnosticCode.JWT_AUDIENCE)
        if (c.audience.size > 1 || c.getStringClaim("azp") != null) verifyProbe(c.getStringClaim("azp") == client, DiagnosticCode.JWT_AUDIENCE)
        verifyProbe(c.expirationTime != null && c.expirationTime.time / 1000 > now, DiagnosticCode.JWT_TIME)
        verifyProbe(c.issueTime != null && c.issueTime.time / 1000 <= now + 5, DiagnosticCode.JWT_TIME)
        verifyProbe(c.notBeforeTime == null || c.notBeforeTime.time / 1000 <= now + 5, DiagnosticCode.JWT_TIME)
        verifyProbe(equal(c.getStringClaim("nonce").orEmpty(), nonce), DiagnosticCode.JWT_NONCE)
        verifyProbe(!c.subject.isNullOrBlank(), DiagnosticCode.JWT_SUBJECT)
        return c.subject
    }
    fun canInfer(scopes: Set<String>) = PLAN_SCOPE in scopes && "resource.invoke" in scopes
    fun testInput(model: String): JsonObject = JsonObject().apply {
        addProperty("model", model)
        addProperty("store", false)
        addProperty("stream", true)
        add("input", com.google.gson.JsonArray().apply { add(JsonObject().apply {
            addProperty("role", "user"); addProperty("content", "Reply with only the word Hello.")
        }) })
    }
}
