package net.ankio.chatgpt

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import java.util.concurrent.TimeUnit

class ProbeSession(val clientId: String, val subjectHash: String, val accessToken: String, val scopes: Set<String>, val expiresAt: Long, val refreshToken: String = "", val idToken: String = "") {
    var tested = false
}
class ProbeModel(val slug: String, private val label: String) { override fun toString() = label.take(80) }

class ProbeClient(
    private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false).build()
) {
    @Volatile var stage = ProbeStage.CALLBACK
        private set
    var progress: (ProbeStage) -> Unit = {}
    private fun enter(next: ProbeStage) { stage = next; progress(next) }
    @Volatile private var closed = false
    @Volatile private var active: Call? = null
    fun close() { closed = true; active?.cancel(); http.dispatcher.cancelAll(); http.connectionPool.evictAll() }
    private fun <T> execute(request: Request, block: (Response, () -> Unit) -> T): T {
        if (closed) throw DiagnosticFailure(DiagnosticCode.CANCELLED)
        var transport = TransportPhase.REQUEST_STARTED
        // Keep only fixed progress enums; never store/log requests, headers, addresses or certificates.
        val observer = object : EventListener() {
            override fun connectStart(call: Call, address: java.net.InetSocketAddress, proxy: java.net.Proxy) { transport = TransportPhase.CONNECTING }
            override fun secureConnectStart(call: Call) { transport = TransportPhase.TLS_HANDSHAKE }
            override fun secureConnectEnd(call: Call, handshake: Handshake?) { transport = TransportPhase.TLS_ESTABLISHED }
            override fun connectionAcquired(call: Call, connection: Connection) { transport = TransportPhase.CONNECTION_READY }
            override fun requestHeadersStart(call: Call) { transport = TransportPhase.SENDING_HEADERS }
            override fun requestHeadersEnd(call: Call, request: Request) { transport = TransportPhase.WAITING_HEADERS }
            override fun requestBodyStart(call: Call) { transport = TransportPhase.SENDING_BODY }
            override fun requestBodyEnd(call: Call, byteCount: Long) { transport = TransportPhase.WAITING_HEADERS }
            override fun responseBodyStart(call: Call) { transport = TransportPhase.READING_BODY }
            override fun responseHeadersEnd(call: Call, response: Response) { transport = TransportPhase.RESPONSE_HEADERS }
        }
        val call = http.newBuilder().eventListener(observer).build().newCall(request)
        active = call
        if (closed) call.cancel()
        try { return call.execute().use { response ->
            transport = TransportPhase.RESPONSE_HEADERS
            try {
                if (!response.isSuccessful) throw responseFailure(response, DiagnosticCode.HTTP_ERROR)
                block(response) { transport = TransportPhase.READING_BODY }
            } catch (error: Exception) {
                // Snapshot before use() closes/discards the body: cleanup can emit responseBodyStart.
                val safe = Diagnostics.normalize(error)
                throw DiagnosticFailure(safe.code, safe.http ?: response.code, safe.oauth, safe.shape,
                    safe.transport ?: transport, safe.responseType ?: Diagnostics.responseType(response.headers.values("Content-Type")))
            }
        } } catch (error: Exception) {
            val safe = Diagnostics.normalize(error)
            throw DiagnosticFailure(safe.code, safe.http, safe.oauth, safe.shape, safe.transport ?: transport, safe.responseType)
        }
    }
    private fun responseFailure(response: Response, code: DiagnosticCode): DiagnosticFailure {
        val type = Diagnostics.responseType(response.headers.values("Content-Type"))
        // No new request. Inspect at most 4096 bytes of JSON, retain only fixed shapes/error codes.
        val raw = if (type == ResponseType.JSON || type == ResponseType.MISSING)
            runCatching { response.peekBody(4096).string() }.getOrDefault("") else ""
        val shape = Diagnostics.httpFailure(response.code, raw)
        return DiagnosticFailure(code, response.code, shape.oauth, shape.shape, TransportPhase.RESPONSE_HEADERS, type)
    }

    private fun json(request: Request): JsonObject = execute(request) { response, reading ->
        reading()
        val source = response.body?.source() ?: throw DiagnosticFailure(DiagnosticCode.JSON_SCHEMA)
        source.request(1_048_577)
        verifyProbe(source.buffer.size <= 1_048_576, DiagnosticCode.RESPONSE_TOO_LARGE)
        val raw = source.readUtf8()
        try { JsonParser.parseString(raw).asJsonObject } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.JSON_SCHEMA) }
    }
    private fun checkDiscovery() {
        enter(ProbeStage.DISCOVERY)
        val discovery = json(Request.Builder().url("${OAuthProtocol.ISSUER}/.well-known/openid-configuration").build())
        verifyProbe(discovery["issuer"]?.asString == OAuthProtocol.ISSUER, DiagnosticCode.DISCOVERY_MISMATCH)
        verifyProbe(discovery["authorization_endpoint"]?.asString == OAuthProtocol.AUTH, DiagnosticCode.DISCOVERY_MISMATCH)
        verifyProbe(discovery["token_endpoint"]?.asString == OAuthProtocol.TOKEN, DiagnosticCode.DISCOVERY_MISMATCH)
        verifyProbe(discovery["jwks_uri"]?.asString == OAuthProtocol.JWKS, DiagnosticCode.DISCOVERY_MISMATCH)
    }
    /** Public metadata only: lets the user diagnose app networking without repeating OAuth. */
    fun preflight() {
        checkDiscovery()
        enter(ProbeStage.JWKS)
        val keys = json(Request.Builder().url(OAuthProtocol.JWKS).build())
        val parsed = try { com.nimbusds.jose.jwk.JWKSet.parse(keys.toString()) }
            catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.JWT_KEY) }
        verifyProbe(parsed.keys.any { it.keyID != null && (it is com.nimbusds.jose.jwk.RSAKey || it is com.nimbusds.jose.jwk.ECKey) }, DiagnosticCode.JWT_KEY)
    }
    fun signIn(attempt: OAuthProtocol.Attempt, callback: OAuthProtocol.Callback, oldSubjectHash: String): ProbeSession {
        checkDiscovery()
        val body = FormBody.Builder().add("grant_type", "authorization_code")
            .add("client_id", callback.client).add("code", callback.code)
            .add("code_verifier", attempt.verifier).add("redirect_uri", attempt.redirect)
            .add("resource", OAuthProtocol.RESOURCE).build()
        enter(ProbeStage.TOKEN_EXCHANGE)
        val tokens = json(Request.Builder().url(OAuthProtocol.TOKEN).post(body).build())
        verifyProbe(tokens["id_token"]?.let { it.isJsonPrimitive && it.asJsonPrimitive.isString && it.asString.isNotBlank() } == true, DiagnosticCode.ID_TOKEN_MISSING)
        enter(ProbeStage.JWKS)
        val jwks = json(Request.Builder().url(OAuthProtocol.JWKS).build()).toString()
        enter(ProbeStage.ID_TOKEN)
        val subject = OAuthProtocol.validateIdToken(tokens["id_token"].asString, jwks, callback.client, attempt.nonce)
        enter(ProbeStage.ACCOUNT)
        val hash = OAuthProtocol.digest(subject)
        if (oldSubjectHash.isNotEmpty()) verifyProbe(OAuthProtocol.equal(hash, oldSubjectHash), DiagnosticCode.ACCOUNT_CHANGED)
        enter(ProbeStage.TOKEN_FIELDS)
        val scopes = tokens["scope"]?.asString.orEmpty().split(' ').filter(String::isNotBlank).toSet()
        val access = tokens["access_token"]?.asString.orEmpty()
        if (access.isNotEmpty()) verifyProbe(tokens["token_type"]?.asString.equals("Bearer", true), DiagnosticCode.TOKEN_TYPE)
        val ttl = try { (tokens["expires_in"]?.asLong ?: 0L).coerceIn(0L, 86400L) } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.TOKEN_EXPIRY) }
        if (OAuthProtocol.canInfer(scopes)) {
            verifyProbe(access.isNotEmpty(), DiagnosticCode.ACCESS_MISSING)
            verifyProbe(ttl > 0, DiagnosticCode.TOKEN_EXPIRY)
        }
        // Refresh and ID tokens are deliberately not persisted by this single-session probe.
        return ProbeSession(callback.client, hash, access, scopes, System.currentTimeMillis() + ttl * 1000, tokens["refresh_token"]?.asString.orEmpty(), tokens["id_token"].asString)
    }
    fun refresh(session: ProbeSession): ProbeSession {
        verifyProbe(session.refreshToken.isNotEmpty(), DiagnosticCode.EXPIRED)
        enter(ProbeStage.TOKEN_EXCHANGE)
        val body = FormBody.Builder().add("grant_type", "refresh_token").add("client_id", session.clientId)
            .add("refresh_token", session.refreshToken).add("resource", OAuthProtocol.RESOURCE).build()
        val tokens = json(Request.Builder().url(OAuthProtocol.TOKEN).post(body).build())
        verifyProbe(tokens["token_type"]?.asString.equals("Bearer", true), DiagnosticCode.TOKEN_TYPE)
        val access = tokens["access_token"]?.asString.orEmpty()
        val refresh = tokens["refresh_token"]?.asString.orEmpty().ifEmpty { session.refreshToken }
        val scopes = tokens["scope"]?.asString?.split(' ')?.filter(String::isNotBlank)?.toSet() ?: session.scopes
        val ttl = tokens["expires_in"]?.asLong ?: 0
        verifyProbe(access.isNotBlank() && ttl in 1..86400, DiagnosticCode.TOKEN_EXPIRY)
        verifyProbe(OAuthProtocol.canInfer(scopes), DiagnosticCode.SCOPE_MISSING)
        // The refresh token is bound to this validated registration. Ignore optional refreshed ID token;
        // retain the originally validated ID token and never switch identities during refresh.
        return ProbeSession(session.clientId, session.subjectHash, access, scopes, System.currentTimeMillis() + ttl * 1000, refresh, session.idToken)
    }
    fun revoke(session: ProbeSession): Boolean {
        if (session.refreshToken.isEmpty()) return false
        checkDiscovery()
        val discovery = json(Request.Builder().url("${OAuthProtocol.ISSUER}/.well-known/openid-configuration").build())
        val endpoint = discovery["revocation_endpoint"]?.asString.orEmpty()
        val uri = endpoint.toHttpUrl()
        verifyProbe(uri.scheme == "https" && uri.host == "auth.openai.com" && uri.port == 443 && uri.username.isEmpty() && uri.password.isEmpty() && uri.query == null && uri.fragment == null, DiagnosticCode.DISCOVERY_MISMATCH)
        val body = FormBody.Builder().add("token", session.refreshToken).add("token_type_hint", "refresh_token").add("client_id", session.clientId).build()
        return execute(Request.Builder().url(uri).post(body).build()) { response, _ -> response.code == 200 }
    }
    fun models(session: ProbeSession): List<ProbeModel> {
        enter(ProbeStage.MODELS)
        requireReady(session)
        val result = json(Request.Builder().url("${OAuthProtocol.RESOURCE}/models")
            .header("Authorization", "Bearer ${session.accessToken}").build())
        verifyProbe(result["models"]?.isJsonArray == true, DiagnosticCode.MODEL_SCHEMA)
        return result.getAsJsonArray("models").filter {
            it.asJsonObject["visibility"]?.asString == "list"
        }.take(100).map {
            val obj = it.asJsonObject
            ProbeModel(obj["slug"].asString, obj["display_name"].asString)
        }
    }
    private fun requireReady(session: ProbeSession) {
        verifyProbe(OAuthProtocol.canInfer(session.scopes), DiagnosticCode.SCOPE_MISSING)
        verifyProbe(session.accessToken.isNotEmpty(), DiagnosticCode.ACCESS_MISSING)
        if (session.expiresAt <= System.currentTimeMillis()) throw DiagnosticFailure(DiagnosticCode.EXPIRED)
    }
    fun test(session: ProbeSession, model: ProbeModel) { infer(session, model, null, null) }
    fun classify(session: ProbeSession, model: ProbeModel, system: String, input: String): String = infer(session, model, system, input)
    private fun infer(session: ProbeSession, model: ProbeModel, system: String?, input: String?): String {
        enter(ProbeStage.INFERENCE)
        requireReady(session)
        verifyProbe(!session.tested, DiagnosticCode.ALREADY_TESTED)
        session.tested = true // Never silently retry a possibly billable request.
        val payload = OAuthProtocol.testInput(model.slug)
        if (system != null && input != null) {
            verifyProbe(system.length <= 8192 && input.length <= 65536, DiagnosticCode.RESPONSE_TOO_LARGE)
            payload.add("input", com.google.gson.JsonArray().apply {
                add(JsonObject().apply { addProperty("role", "developer"); addProperty("content", system) })
                add(JsonObject().apply { addProperty("role", "user"); addProperty("content", input) })
            })
        }
        val request = Request.Builder().url("${OAuthProtocol.RESOURCE}/responses")
            .header("Authorization", "Bearer ${session.accessToken}")
            .header("Accept", "text/event-stream")
            .post(payload.toString().toRequestBody("application/json".toMediaType())).build()
        return execute(request) { response, reading ->
            val declaredType = Diagnostics.responseType(response.headers.values("Content-Type"))
            // A missing declaration is not proof that the body is not SSE. Only HTTP 200 may
            // enter strict framing validation; conflicting or explicitly wrong types still fail.
            val missingType = declaredType == ResponseType.MISSING && response.code == 200
            if (declaredType != ResponseType.SSE && !missingType)
                throw responseFailure(response, DiagnosticCode.STREAM_CONTENT_TYPE)
            reading()
            val source = response.body?.source() ?: throw DiagnosticFailure(DiagnosticCode.STREAM_BODY_MISSING)
            val events = SseCompletion(strictEnvelope = missingType, collectOutput = system != null)
            var bytes = 0
            if (source.exhausted()) throw DiagnosticFailure(DiagnosticCode.STREAM_EMPTY)
            while (!source.exhausted()) {
                val line = try { source.readUtf8LineStrict(65536) } catch (_: java.io.EOFException) { throw DiagnosticFailure(DiagnosticCode.STREAM_LINE) }
                bytes += line.length
                verifyProbe(bytes <= 1_048_576, DiagnosticCode.RESPONSE_TOO_LARGE)
                if (events.line(line)) return@execute events.output()
            }
            throw DiagnosticFailure(DiagnosticCode.STREAM_ENDED)
        }
    }
}

/** SSE framing + terminal-event validation; deliberately discard model text. */
class SseCompletion(private val strictEnvelope: Boolean = false, private val collectOutput: Boolean = false) {
    private var result = ""
    fun output(): String = result
    private val data = StringBuilder()
    fun line(line: String): Boolean {
        if (strictEnvelope && line.isNotEmpty()) {
            verifyProbe(line.startsWith(":") || line.substringBefore(':') in setOf("data", "event", "id", "retry"), DiagnosticCode.STREAM_FORMAT)
        }
        if (line.startsWith("data:")) {
            if (data.isNotEmpty()) data.append('\n')
            data.append(line.removePrefix("data:").trimStart())
            verifyProbe(data.length <= 65536, DiagnosticCode.STREAM_EVENT_LIMIT)
        }
        if (line.isNotEmpty() || data.isEmpty()) return false
        val payload = data.toString(); data.setLength(0)
        if (payload == "[DONE]") return false
        val event = try { JsonParser.parseString(payload).asJsonObject } catch (_: Exception) { throw DiagnosticFailure(DiagnosticCode.STREAM_JSON) }
        val type = event["type"]
        verifyProbe(type?.isJsonPrimitive == true && type.asJsonPrimitive.isString, DiagnosticCode.STREAM_SCHEMA)
        if (strictEnvelope) verifyProbe(type.asString.startsWith("response.") || type.asString == "error", DiagnosticCode.STREAM_SCHEMA)
        return when (type.asString) {
            "response.completed" -> {
                val response = event["response"]
                verifyProbe(response?.isJsonObject == true, DiagnosticCode.STREAM_SCHEMA)
                val status = response.asJsonObject["status"]
                verifyProbe(status?.isJsonPrimitive == true && status.asJsonPrimitive.isString && status.asString == "completed", DiagnosticCode.STREAM_COMPLETION)
                if (collectOutput) result = completedText(response.asJsonObject)
                true
            }
            "response.failed", "response.incomplete", "error" -> throw DiagnosticFailure(DiagnosticCode.STREAM_FAILED)
            else -> false
        }
    }
    private fun completedText(response: JsonObject): String {
        val output = response["output"]
        verifyProbe(output?.isJsonArray == true, DiagnosticCode.STREAM_SCHEMA)
        val text = StringBuilder()
        for (item in output.asJsonArray) {
            verifyProbe(item.isJsonObject, DiagnosticCode.STREAM_SCHEMA)
            val obj = item.asJsonObject
            if (obj["type"]?.asString != "message") continue
            verifyProbe(obj["role"]?.asString == "assistant" && obj["content"]?.isJsonArray == true, DiagnosticCode.STREAM_SCHEMA)
            for (part in obj.getAsJsonArray("content")) {
                verifyProbe(part.isJsonObject, DiagnosticCode.STREAM_SCHEMA)
                val p = part.asJsonObject
                if (p["type"]?.asString == "refusal") throw DiagnosticFailure(DiagnosticCode.STREAM_FAILED)
                if (p["type"]?.asString == "output_text") {
                    verifyProbe(p["text"]?.isJsonPrimitive == true && p["text"].asJsonPrimitive.isString, DiagnosticCode.STREAM_SCHEMA)
                    text.append(p["text"].asString)
                    verifyProbe(text.length <= 2048, DiagnosticCode.RESPONSE_TOO_LARGE)
                }
            }
        }
        verifyProbe(text.isNotBlank(), DiagnosticCode.STREAM_SCHEMA)
        return text.toString()
    }

}
