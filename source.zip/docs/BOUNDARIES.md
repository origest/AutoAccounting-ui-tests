# Test-only integration boundaries

The candidate replaces no test target and no assertion. The following integrations are outside all 19 tests and have been removed from the dependency graph:

| Original dependency | New app-owned adapter | Affected production file |
| --- | --- | --- |
| :ocr / paddleocr4android | UnavailableOcrProcessor | service/OcrService.kt, import alias only |
| :tap / vendor algorithms and models | UnavailableBackTapDetector and UnavailableTapLogger | service/BackTapOcrTriggerService.kt, import aliases only |
| Bugly SDK | UnavailableCrashReporter | App.kt and utils/ExceptionHandler.kt, import aliases only; App telemetry ID replaced |

All adapters live in app/src/isolatedUi/java/net/ankio/auto/isolated/boundaries/UnavailableIntegrations.kt. Construction or every integration method throws UnsupportedOperationException. They do not emulate OCR, sensor readings, logging, or crash reporting and never return a fake success result. They cannot be compiled into an enabled production variant because this project enables only isolatedUi.

The inherited isolated OcrVibration adapter remains unchanged; it already omits real hardware feedback for these permission-free tests.

MMKV is not replaced. PrefManager, IsolatedUiApplication, LocalNetwork, SyntheticUiBackend, the test fixture, all UI tests, all UI production source files, and all server model/DAO/transaction source files remain identical to their corresponding baseline bytes. The real Room/refund/idempotency operations therefore remain under test, although successful compilation does not establish runtime success.

Unrelated history is excluded rather than redacted into public patches. Four source-comment removals and the layout preview attribute removal contain no behavior changes. Build configuration changes are documented in NOTICE.md. The protected-source checksum list lets a reviewer detect accidental changes to the retained target code without publishing removed content.
