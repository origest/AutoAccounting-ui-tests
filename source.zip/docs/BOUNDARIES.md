# Test-only integration boundaries

The candidate retains all 19 test methods and strengthens C05 refresh/row-identity assertions. The following integrations are outside all 19 tests and have been removed from the dependency graph:

| Original dependency | New app-owned adapter | Affected production file |
| --- | --- | --- |
| :ocr / paddleocr4android | UnavailableOcrProcessor | service/OcrService.kt, import alias only |
| :tap / vendor algorithms and models | UnavailableBackTapDetector and UnavailableTapLogger | service/BackTapOcrTriggerService.kt, import aliases only |
| Bugly SDK | UnavailableCrashReporter | App.kt and utils/ExceptionHandler.kt, import aliases only; App telemetry ID replaced |

All adapters live in app/src/isolatedUi/java/net/ankio/auto/isolated/boundaries/UnavailableIntegrations.kt. Construction or every integration method throws UnsupportedOperationException. They do not emulate OCR, sensor readings, logging, or crash reporting and never return a fake success result. They cannot be compiled into an enabled production variant because this project enables only isolatedUi.

The inherited isolated OcrVibration adapter remains unchanged; it already omits real hardware feedback for these permission-free tests.

MMKV is not replaced. PrefManager, LocalNetwork, all UI production source files, and all server model/DAO/transaction source files remain identical to the frozen baseline bytes. The isolated application explicitly enables the asset-management prerequisite in its package-guarded synthetic settings store so the existing refund picker can be reached. The production default and production visibility gate remain unchanged. The real Room/refund/idempotency operations therefore remain under test, although successful compilation does not establish runtime success.

The local lifecycle/C05 revision changes test code only: UiTestDeadline tracks Callable start/cancel/finish atomically; the fixture retains all teardown checks and makes post-gesture global idle optional; C05 observes its real blocked request and exact persisted row IDs. SyntheticUiBackend adds observation-only gate/request/Job identities, removed in finally, without replacing requests, gates or database operations. Cancellation-tail request totals are diagnostic only; the same active request identity establishes that the second gesture did not replace the first refresh. No timeout, pass gate, test method or production behavior is relaxed. The local verification scripts run real JVM helper concurrency checks and source-linked C05 contracts; neither is Android/device execution.

Unrelated history is excluded rather than redacted into public patches. Four source-comment removals and the layout preview attribute removal contain no behavior changes. Build configuration changes are documented in NOTICE.md. The protected-source checksum list lets a reviewer detect accidental changes to the retained target code without publishing removed content.

The refund-fixture revision directly encodes only SETTING_ASSET_MANAGER=true in the existing guarded synthetic MMKV reset, without using the server-synchronizing preference setter. C14 and C18 retain their real repeated-touch gestures and all assertions, but obtain injected coordinates through the existing screenBounds helper, including the window origin. No production code, network allowlist, test method, timeout, or 19-case pass gate changes. Local Kotlin source-contract checks cover enabled/disabled/type/reset boundaries and coordinate conversion; they do not establish Android rendering, actual touch interception, candidate loading, or a 19-case device pass.
