#!/usr/bin/env python3
"""Source-linked C05 contract checks, NOT an Android/runtime gesture test."""
import hashlib
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ISO = ROOT / "app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated"
C05 = (ISO / "DataPageIsolatedUiTest.kt").read_text().split(
    "@Test fun actualRepeatedSwipesDoNotDuplicateRowsOrLeaveSpinnerRunning()", 1)[1].split("\n    @Test", 1)[0]
FIXTURE = (ISO / "IsolatedUiFixture.kt").read_text()
BACKEND = (ISO / "SyntheticUiBackend.kt").read_text()
PAGE = (ROOT / "app/src/main/java/net/ankio/auto/ui/api/BasePageFragment.kt").read_text()
ADAPTER = (ROOT / "app/src/main/java/net/ankio/auto/ui/api/BaseAdapter.kt").read_text()
DATA = (ROOT / "app/src/main/java/net/ankio/auto/ui/fragment/DataFragment.kt").read_text()
NETWORK = (ROOT / "app/src/main/java/net/ankio/auto/http/LocalNetwork.kt").read_text()


class SourceContract(unittest.TestCase):
    def test_adapter_observation_uses_actual_synchronous_items(self):
        code = ADAPTER.split("private fun applyListUpdate", 1)[1].split("\n    /**", 1)[0]
        self.assertLess(code.index("items.clear()"), code.index("items.addAll(newList)"))
        self.assertLess(code.index("items.addAll(newList)"), code.index("diffResult.dispatchUpdatesTo(this)"))
        self.assertIn("fun getItems(): List<E> = items.toList()", ADAPTER)
        self.assertIn("getItems().map { it.id }", (ISO / "DataPageIsolatedUiTest.kt").read_text())

    def test_reload_cancels_old_job_before_reset_and_new_load(self):
        code = PAGE.split("fun reload()", 1)[1].split("\n    /**", 1)[0]
        calls = ["cancelPendingLoad()", "resetPage()", "statusPage.showLoading()", "loadDataInside()"]
        positions = [code.index(call) for call in calls]
        self.assertEqual(positions, sorted(positions))
        self.assertIn("loadJob?.cancel()", PAGE)
        self.assertIn("baseAdapter?.updateItems(emptyList())", PAGE)

    def test_passive_poll_preserves_rows_and_skips_during_refresh(self):
        self.assertIn("if (!isLoading && list?.scrollState == RecyclerView.SCROLL_STATE_IDLE)", DATA)
        self.assertIn("refreshLoadedData(limit, dataLoader(1, limit))", DATA)
        refresh = PAGE.split("protected fun refreshLoadedData", 1)[1].split("protected open fun loadDataInside", 1)[0]
        self.assertNotIn("resetPage()", refresh)
        self.assertIn("preservePosition = true", refresh)

    def test_backend_identity_is_the_real_structured_request_job(self):
        code = BACKEND.split('"GET data/list" -> {', 1)[1].split('"GET data/apps"', 1)[0]
        self.assertIn("GatedDataRead(gate, currentCoroutineContext().job)", code)
        self.assertRegex(code, r"try\s*\{\s*gate.await\(\)\s*\}\s*finally\s*\{\s*gatedDataReads.remove\(requestId\)")
        self.assertIn("it.value.gate === gate", BACKEND)
        self.assertIn("it.value.job.isActive", BACKEND)
        self.assertIn("withContext(Dispatchers.IO)", NETWORK)
        self.assertNotIn("GlobalScope", NETWORK)

    def test_initial_and_final_ids_are_persisted_insert_results(self):
        self.assertIn("val firstId = step", C05)
        self.assertIn("secondId = step", C05)
        self.assertIn("rowIds(fragment) == listOf(firstId) && count(fragment) == 1", C05)
        self.assertIn("ids.size == 2 && ids.toSet() == setOf(firstId, secondId) && count(fragment) == 2", C05)
        self.assertIn("!visible(fragment, R.id.group_error)", C05)
        self.assertIn("!fragment.swipeRefreshLayout.isRefreshing", C05)

    def test_first_reload_cannot_be_satisfied_by_passive_or_cancelled_poll(self):
        self.assertIn("count(fragment) == 0 && rowIds(fragment).isEmpty()", C05)
        self.assertIn("fragment.swipeRefreshLayout.isRefreshing", C05)
        self.assertIn("backend.dataReadsAtGate(gate).filterValues { it }", C05)
        self.assertIn("reads.size == 1 && reads.keys.single() > before", C05)
        self.assertIn("blockedRead = reads.keys.single()", C05)
        self.assertNotIn("fragment.reload()", C05)
        self.assertNotIn("setOnRefreshListener", C05)

    def test_second_gesture_keeps_same_live_identity_before_and_after(self):
        self.assertIn("mapOf(blockedRead to true), backend.dataReadsAtGate(gate).filterValues { it }", C05)
        self.assertGreaterEqual(C05.count("assertSameBlockedRead()"), 4)
        self.assertEqual(C05.count("swipeRefresh(fragment, waitForIdleAfter = false)"), 2)
        # An inactive old poll may increment the diagnostic count late. Do not compare totals.
        self.assertNotIn("blockedRequestCount", C05)
        self.assertIn('await("Second gesture animation finished without replacing the blocked read")', C05)

    def test_wait_is_local_view_animation_not_global_idle_or_arbitrary_delay(self):
        code = (ISO / "DataPageIsolatedUiTest.kt").read_text()
        self.assertIn("fragment.swipeRefreshLayout.getChildAt(it).animation == null", code)
        self.assertNotIn("hasEnded", code.replace("not hasEnded", ""))
        self.assertNotIn("SystemClock.sleep", C05)
        self.assertNotIn("waitForUiIdle", C05)
        self.assertIn("waitForIdleAfter: Boolean = true", FIXTURE)
        self.assertIn("if (waitForIdleAfter) waitForUiIdle()", FIXTURE)
        self.assertIn("instrumentation.sendPointerSync(event)", FIXTURE)
        self.assertIn("MotionEvent.ACTION_CANCEL", FIXTURE)
        self.assertIn('"UI_TEST_GESTURE_ON_MAIN"', FIXTURE)

    def test_all_original_cleanup_checks_and_gate_release_remain(self):
        for expression in ["host.finish()", 'await("Host destroyed")', "backend.activeRequests.get() == 0",
                           "backend.unexpectedRequests.isEmpty()", "unexpectedDatabases.isEmpty()", "backend.close()",
                           "deadlineWait.preventFurtherActions()", 'error("Between tests; no backend")']:
            self.assertIn(expression, FIXTURE)
        self.assertRegex(C05, r"finally\s*\{[\s\S]*backend.dataGate = null[\s\S]*gate.complete\(Unit\)")

    def test_original_19_test_method_names_retained(self):
        import json
        expected = json.loads((ROOT / "verification/protected-source.json").read_text())["tests"]
        actual = []
        for cls in ["DataPageIsolatedUiTest", "RefundIsolatedUiTest"]:
            actual.extend(f"net.ankio.auto.isolated.{cls}#{method}" for method in
                          re.findall(r"@Test\s+fun\s+(\w+)", (ISO / (cls + ".kt")).read_text()))
        self.assertEqual(actual, expected)
        self.assertEqual(len(actual), 19)


if __name__ == "__main__":
    unittest.main(verbosity=2)
