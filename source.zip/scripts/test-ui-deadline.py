#!/usr/bin/env python3
"""Compile/run the real deadline and immutable baseline with the installed JDK compiler module."""
import hashlib
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT.parent / "source.zip"
assert hashlib.sha256(BASELINE.read_bytes()).hexdigest() == "a0352fcf35b668d1ff1cb41e14b5fe6320dde9054c70f861d2c8029e8e7419df"
REL = "app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/UiTestDeadline.java"
with tempfile.TemporaryDirectory(prefix="deadline-regression-") as temporary:
    temp = Path(temporary)
    with zipfile.ZipFile(BASELINE) as archive:
        baseline = archive.read(REL).decode()
    # Class rename only, so both current and actual original code run in one JVM.
    original = temp / "OriginalUiTestDeadline.java"
    original.write_text(baseline.replace("UiTestDeadline", "OriginalUiTestDeadline"))
    subprocess.run(["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-d", str(temp),
                    str(ROOT / REL), str(original),
                    str(ROOT / "verification/java/UiTestDeadlineRegression.java")], check=True)
    subprocess.run(["java", "-cp", str(temp), "net.ankio.auto.isolated.UiTestDeadlineRegression"], check=True, timeout=45)
