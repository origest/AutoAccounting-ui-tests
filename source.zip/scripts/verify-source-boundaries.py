#!/usr/bin/env python3
"""Verify the protected UI/data/test source identities; no network or external commands."""
import hashlib, json, re
from pathlib import Path
root = Path(__file__).resolve().parents[1]
expected = json.loads((root / "verification/protected-source.json").read_text())
for item in expected["files"]:
    path = root / item["path"]
    assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"], item["path"]
actual = []
for name in ("DataPageIsolatedUiTest", "RefundIsolatedUiTest"):
    path = root / f"app/src/androidTestIsolatedUi/java/net/ankio/auto/isolated/{name}.kt"
    actual.extend(f"net.ankio.auto.isolated.{name}#{method}" for method in re.findall(r"@Test\s+fun\s+(\w+)", path.read_text()))
assert actual == expected["tests"] and len(actual) == 19
for excluded in ("ocr", "tap", "assets", ".idea", ".git", "test", ".github", "app/src/main/assets"):
    assert not (root / excluded).exists(), excluded
for path in root.rglob("*"):
    if path.is_file() and "build" not in path.parts and ".gradle" not in path.parts:
        assert path.suffix.lower() not in (".tflite", ".ncnn", ".apk", ".aab", ".jks", ".keystore"), str(path)
print(f"Protected source verified: {len(expected['files'])} protected files; 19 unchanged UI test method names. Device execution is not implied.")
