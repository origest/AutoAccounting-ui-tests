package org.ezbook.server.ai.providers

/** Preserve transport status without retaining a provider body, URL, key, or echoed bill. */
class AiRequestFailure(val status: Int) : Exception("AI_HTTP_${status.takeIf { it in 100..599 } ?: 502}")

data class AiFailureHint(val code: Int, val message: String) {
    companion object {
        fun from(error: Throwable): AiFailureHint = when (error) {
            is AiRequestFailure -> when (error.status) {
                401 -> AiFailureHint(401, "AI 服务认证失败（401）。请检查当前 API 服务商和密钥；登录 ChatGPT 不会替代旧 API 密钥。原始数据已保留。")
                403 -> AiFailureHint(403, "AI 服务拒绝访问（403），请检查模型和账号权限。原始数据已保留。")
                429 -> AiFailureHint(429, "AI 服务额度或速率受限（429），未自动重试。原始数据已保留。")
                in 500..599 -> AiFailureHint(502, "AI 服务暂时失败，未自动重试。原始数据已保留。")
                else -> AiFailureHint(502, "AI 请求未被服务接受，请检查服务商和模型设置。原始数据已保留。")
            }
            is java.net.SocketTimeoutException -> AiFailureHint(504, "AI 请求超时，结果未知，未自动重试。原始数据已保留。")
            is java.io.IOException -> AiFailureHint(503, "无法完成 AI 网络请求，请检查网络。结果未知，未自动重试。原始数据已保留。")
            else -> AiFailureHint(502, "AI 返回结果无法识别，未生成账单。原始数据已保留。")
        }
    }
}
