/*
* Copyright (C) 2025 ankio(ankio@ankio.net)
* Licensed under the Apache License, Version 3.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*         http://www.apache.org/licenses/LICENSE-3.0
*
*  Unless required by applicable law or agreed to in writing, software
*  distributed under the License is distributed on an "AS IS" BASIS,
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*  See the License for the specific language governing permissions and
*   limitations under the License.
*/

package org.ezbook.server.ai.providers

/**
 * OpenRouter API提供商实现
 */
class OpenRouterProvider : BaseOpenAIProvider() {
    override val name: String = "openrouter"

    override val createKeyUri: String = "https://openrouter.ai/keys"

    override val apiUri: String = "https://openrouter.ai/api"

    override var model: String = "openai/gpt-3.5-turbo"
}