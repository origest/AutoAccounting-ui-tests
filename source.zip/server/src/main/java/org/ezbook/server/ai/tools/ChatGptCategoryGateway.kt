package org.ezbook.server.ai.tools

/** Installed only by AutoAccounting's own Application. Never serialize credentials into settings/HTTP. */
object ChatGptCategoryGateway {
    @Volatile var ownerReady = false
    @Volatile var isSelected: (() -> Boolean)? = null
    suspend fun selected(): Boolean = isSelected?.invoke() ?: org.ezbook.server.tools.SettingUtils.aiCategoryChatGpt()
    @Volatile var request: (suspend (String, String) -> String)? = null
    suspend fun classify(system: String, input: String): String =
        (request ?: error("CHATGPT_LOCAL_PROCESS_REQUIRED"))(system, input)
}
