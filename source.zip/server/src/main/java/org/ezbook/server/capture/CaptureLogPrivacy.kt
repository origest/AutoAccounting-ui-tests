package org.ezbook.server.capture

import kotlinx.coroutines.asContextElement

/** Scope existing server diagnostics out of capture analysis, including dispatcher switches. */
object CaptureLogPrivacy {
    private val active = ThreadLocal.withInitial { false }
    fun isActive(): Boolean = active.get() == true
    fun context() = active.asContextElement(true)
}
