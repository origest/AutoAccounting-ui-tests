package org.ezbook.server.capture

import kotlinx.coroutines.CancellationException
import org.ezbook.server.models.NotificationCaptureAck
import org.ezbook.server.models.NotificationCaptureRequest
import java.security.MessageDigest

class CaptureConflict : Exception("capture_id_conflict")
class InvalidCapture : Exception("invalid_request")

interface NotificationCaptureStore {
    /** Atomic policy read + unique receipt + optional raw insertion. Must roll back together. */
    suspend fun accept(request: NotificationCaptureRequest, digest: String): NotificationCaptureAck
    suspend fun recoverInterrupted(): Int
    /** Atomically claims one pending receipt before any analysis side effect. */
    suspend fun claimNext(): Pair<String, Long>?
    suspend fun finish(id: String, state: String)
}

/** No automatic analysis replay, even when failure might have happened before bill insertion. */
class NotificationCaptureCoordinator(
    private val store: NotificationCaptureStore,
    private val analyze: suspend (Long) -> Unit,
    private val diagnostic: (String) -> Unit = {},
) {
    suspend fun accept(request: NotificationCaptureRequest): NotificationCaptureAck {
        validate(request)
        return store.accept(request, digest(request))
    }

    suspend fun recover() {
        val count = store.recoverInterrupted()
        if (count > 0) diagnostic("notification_capture uncertain_after_restart count=$count")
    }

    suspend fun drainOne(): Boolean {
        val (id, rawId) = store.claimNext() ?: return false
        try {
            analyze(rawId)
            store.finish(id, "completed")
            diagnostic("notification_capture analysis_finished rawId=$rawId")
        } catch (cancelled: CancellationException) {
            // Leave processing on cancellation; next start marks uncertain, never reruns.
            throw cancelled
        } catch (_: Exception) {
            // Analysis may already have committed a bill. Never guess or replay.
            store.finish(id, "uncertain")
            diagnostic("notification_capture uncertain_analysis rawId=$rawId")
        }
        return true
    }

    companion object {
        fun validate(r: NotificationCaptureRequest) {
            // Gson may populate null into non-null Kotlin properties, so guard at runtime.
            if ((r.captureId as String?).isNullOrBlank() || !r.captureId.matches(Regex("[A-Za-z0-9_-]{16,128}")) ||
                (r.packageName as String?).isNullOrBlank() || !r.packageName.matches(Regex("[A-Za-z0-9_.]{1,255}")) ||
                (r.title as String?) == null || (r.text as String?) == null ||
                r.title.length > 4_096 || r.text.length > 16_384 || r.capturedAt <= 0
            ) throw InvalidCapture()
        }

        fun digest(r: NotificationCaptureRequest): String {
            // Length framing prevents ambiguous concatenations. ID identifies delivery; digest verifies content.
            val framed = listOf(r.packageName, r.title, r.text, r.capturedAt.toString())
                .joinToString("") { "${it.length}:$it" }
            return MessageDigest.getInstance("SHA-256").digest(framed.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        }
    }
}
