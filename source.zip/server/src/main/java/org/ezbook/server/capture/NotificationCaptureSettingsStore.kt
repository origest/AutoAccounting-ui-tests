package org.ezbook.server.capture

import androidx.room.withTransaction
import org.ezbook.server.constant.Setting
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.models.NotificationCaptureSettings
import org.ezbook.server.models.NotificationCaptureSettingsUpdate

fun isNotificationCaptureSetting(key: String): Boolean = key == Setting.LISTENER_APP_LIST ||
    key == Setting.DATA_FILTER || key == Setting.DATA_FILTER_BLACKLIST

suspend fun notificationSettingsVersion(db: AppDatabase): Long =
    NotificationSettingsRevision.parse(db.settingDao().query(NotificationSettingsRevision.KEY)?.value)

private fun validateSettings(settings: NotificationCaptureSettings) {
    if ((settings.apps as String?) == null || (settings.keywords as String?) == null ||
        (settings.blacklist as String?) == null || settings.apps.length > 65_536 ||
        settings.keywords.length > 65_536 || settings.blacklist.length > 65_536) throw InvalidCapture()
}

suspend fun saveNotificationCaptureSettings(db: AppDatabase, update: NotificationCaptureSettingsUpdate): Long {
    val expected = update.expectedRevision ?: throw InvalidCapture()
    if (expected < 0 || (update.settings as NotificationCaptureSettings?) == null) throw InvalidCapture()
    validateSettings(update.settings)
    return db.withTransaction {
        val next = NotificationSettingsRevision.next(notificationSettingsVersion(db), expected)
        db.settingDao().set(Setting.LISTENER_APP_LIST, update.settings.apps)
        db.settingDao().set(Setting.DATA_FILTER, update.settings.keywords)
        db.settingDao().set(Setting.DATA_FILTER_BLACKLIST, update.settings.blacklist)
        db.settingDao().set(NotificationSettingsRevision.KEY, next.toString())
        next
    }
}

/** Legacy per-key writes remain supported, but invalidate every previously read snapshot revision. */
suspend fun saveLegacyNotificationSetting(db: AppDatabase, key: String, value: String) {
    require(isNotificationCaptureSetting(key))
    db.withTransaction {
        val current = notificationSettingsVersion(db)
        val next = NotificationSettingsRevision.next(current, current)
        db.settingDao().set(key, value)
        db.settingDao().set(NotificationSettingsRevision.KEY, next.toString())
    }
}
