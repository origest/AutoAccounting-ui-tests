package org.ezbook.server.capture

class CaptureSettingsConflict : Exception("settings_revision_conflict")

/** Pure compare-and-swap policy. The DB caller must read, compare and write in one transaction. */
object NotificationSettingsRevision {
    const val KEY = "__notification_capture_settings_revision"

    fun parse(stored: String?): Long {
        if (stored == null) return 0L
        return stored.toLongOrNull()?.takeIf { it >= 0 } ?: throw CaptureConfigurationUnavailable()
    }

    fun next(current: Long, expected: Long): Long {
        if (expected < 0) throw InvalidCapture()
        if (current != expected) throw CaptureSettingsConflict()
        if (current < 0 || current == Long.MAX_VALUE) throw CaptureConfigurationUnavailable()
        return current + 1
    }
}
