# Notification capture reliability boundary

`POST /notification/capture` accepts the shared `NotificationCaptureRequest`. The hook must create an ID and timestamp once and reuse the entire request for every delivery attempt.

- `200` returns `NotificationCaptureAck`: accepted + stored + rawId, or filtered + a fixed reason + null rawId. Both are durable terminal delivery decisions.
- `400 invalid_request` and `409 capture_id_conflict` are terminal rejections.
- `503 configuration_unavailable` or `capture_unavailable` is retryable. A transport timeout is also retryable with the same ID/body.
- All three configuration rows must exist. An absent row is not an empty user setting. Empty app/keyword allowlists explicitly allow nothing; an empty blacklist blocks nothing.
- A Room transaction reads configuration, inserts the raw notification, and inserts its unique receipt. Existing receipts are returned before looking at current settings. Changed content or timestamp with the same ID is rejected.
- Capture is not bill recognition. ACK says the raw notification was saved (or explicitly filtered), not that a bill was generated.

The worker claims pending receipts before analysis. It reuses the raw row but preserves normal external-data bill creation and floating-window behavior. It does not set `fromAppData=true`. A failed or cancelled analysis is never automatically replayed. On startup, processing rows become uncertain; only pending rows run. An uncertain row can already have a committed bill. Review it before taking manual action.

The coordinator emits only fixed stage/reason diagnostics and database IDs. Capture analysis runs within a coroutine-propagated ServerLog privacy scope, preserving ordinary `/js/analysis` diagnostics. This scope covers the synchronous/coroutine analysis chain, not unrelated detached work or platform/native logging. Existing AI settings still govern the first analysis; this change does not enable AI or retry external AI calls.

Delivery receipts are intentionally retained: deleting them would remove duplicate protection. Raw-data deletion does not replay old receipts. The hook's bounded in-memory outbox does not survive system_server death before ACK. This is not an exactly-once bill lifecycle implementation.

## Migration integration

This isolated branch migrates database 23 to 24, adding NotificationCaptureModel and its pending-state index only. The verified local-refund patch uses the existing BillInfoModel.extendData field and retains schema 23; it adds no migration or entity columns. Combining that exact patch preserves this notification migration and all older migrations. Validate the resulting Room schema and each supported upgrade path before installation.

## Verification

Run `:server:testDebugUnitTest :server:compileDebugAndroidTestKotlin`. `NotificationCaptureCoordinatorTest` is pure JVM and uses only synthetic memory stores. `NotificationCaptureDeviceTest` uses isolated in-memory databases and a uniquely named synthetic migration database, never the user's database. NotificationCaptureMigrationDeviceTest builds the complete frozen v23 schema, opens it with Room migration validation, and checks old raw data plus new receipts after close/reopen. The fixtures do not instantiate BillService, invoke AI, or read real notifications. Device tests require a separate explicit test run; compiling them is not execution or migration certification.

## Atomic configuration snapshot with compare-and-swap

The main app reads `GET /notification/settings/version` (data is a Long; absent revision starts at zero), then reads its latest local preferences and posts `NotificationCaptureSettingsUpdate(expectedRevision, settings)` to `/notification/settings`. The nested settings contains apps, keywords and blacklist CSV strings. All three values are saved verbatim, together with an incremented revision, in one Room transaction. Success returns the new Long revision. A late old request cannot overwrite a committed newer snapshot: mismatched revision returns `409 settings_revision_conflict`. After a conflict or uncertain response, the sender rereads the version AND its latest local preferences rather than resending an obsolete policy.

The hidden SettingModel key `__notification_capture_settings_revision` is not exposed through generic setting get/list/set. Legacy `/setting/set` writes for any of the three notification keys remain supported and increment the same revision in their transaction. Other setting writes are unchanged. Missing configuration rows are still not treated as a complete initialized snapshot. A malformed or exhausted persistent revision fails closed.

Database failure is fixed `503 configuration_unavailable`; invalid input returns `400 invalid_request`. Streamed body limits use NotificationCaptureProtocol (settings 1200000 bytes, capture 131072 bytes) to cover worst-case Gson escaping. Each settings field is limited to 64 Ki characters; capture bounds title/text at 4096/16384 characters. All three notification endpoints independently require a loopback remote address even in debug mode.

This protects committed updates against stale requests; it does NOT make unsynchronized UI edits immediately effective. Until a fresh snapshot commits, a complete previous policy may still filter a notification. Delivery receipts, including filtered receipts, are retained indefinitely in this patch. There is no automatic TTL cleanup: removing a receipt could let a very late duplicate create a second raw record or bill. Metadata therefore grows over time and requires a separately designed retention policy.
