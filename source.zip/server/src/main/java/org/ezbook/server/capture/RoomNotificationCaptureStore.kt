package org.ezbook.server.capture

import androidx.room.withTransaction
import com.google.gson.JsonObject
import org.ezbook.server.constant.DataType
import org.ezbook.server.constant.Setting
import org.ezbook.server.db.AppDatabase
import org.ezbook.server.db.model.AppDataModel
import org.ezbook.server.db.model.NotificationCaptureModel
import org.ezbook.server.models.NotificationCaptureAck
import org.ezbook.server.models.NotificationCaptureRequest

class CaptureConfigurationUnavailable : Exception("configuration_unavailable")

class RoomNotificationCaptureStore(private val db: AppDatabase) : NotificationCaptureStore {
    override suspend fun accept(request: NotificationCaptureRequest, digest: String): NotificationCaptureAck = db.withTransaction {
        val dao = db.notificationCaptureDao()
        dao.find(request.captureId)?.let {
            if (it.payloadDigest != digest) throw CaptureConflict()
            return@withTransaction NotificationCaptureAck(it.captureId, it.rawId, it.disposition, it.reason)
        }
        // All required keys must have synced. Explicit empty values are preserved; DB failures propagate.
        suspend fun setting(key: String) = db.settingDao().query(key)?.value ?: throw CaptureConfigurationUnavailable()
        fun tokens(value: String) = value.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        val apps = tokens(setting(Setting.LISTENER_APP_LIST))
        val whitelist = tokens(setting(Setting.DATA_FILTER))
        val blacklist = tokens(setting(Setting.DATA_FILTER_BLACKLIST))
        val sms = request.packageName == "com.android.mms"
        val payload = JsonObject().apply {
            if (sms) { addProperty("sender", ""); addProperty("body", request.text) }
            else { addProperty("title", request.title); addProperty("text", request.text) }
            addProperty("t", request.capturedAt)
        }.toString()
        val reason = when {
            request.title.isEmpty() && request.text.isEmpty() -> "empty"
            request.packageName !in apps -> "app_not_allowed"
            // Empty keyword allowlist means no allowed keywords, consistent with existing analysis filter.
            whitelist.none { payload.contains(it) } -> "keyword_not_allowed"
            blacklist.any { payload.contains(it) } -> "keyword_blocked"
            else -> "stored"
        }
        val accepted = reason == "stored"
        val rawId = if (accepted) db.dataDao().insert(AppDataModel().apply {
            data = payload
            app = if (sms) "com.android.phone" else request.packageName
            type = if (sms) DataType.DATA else DataType.NOTICE
            time = request.capturedAt
        }) else null
        val receipt = NotificationCaptureModel(request.captureId, digest, rawId,
            if (accepted) "accepted" else "filtered", reason,
            if (accepted) "pending" else "filtered", System.currentTimeMillis())
        dao.insert(receipt)
        NotificationCaptureAck(receipt.captureId, rawId, receipt.disposition, reason)
    }

    override suspend fun recoverInterrupted() = db.notificationCaptureDao().recoverInterrupted()
    override suspend fun claimNext(): Pair<String, Long>? = db.withTransaction {
        val dao = db.notificationCaptureDao()
        val next = dao.nextPending() ?: return@withTransaction null
        if (dao.claim(next.captureId) != 1) return@withTransaction null
        val rawId = next.rawId
        if (rawId == null) { dao.finish(next.captureId, "uncertain"); return@withTransaction null }
        next.captureId to rawId
    }
    override suspend fun finish(id: String, state: String) = db.notificationCaptureDao().finish(id, state)
}
