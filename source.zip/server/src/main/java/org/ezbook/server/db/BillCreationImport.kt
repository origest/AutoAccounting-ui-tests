package org.ezbook.server.db

import android.database.sqlite.SQLiteDatabase
import org.ezbook.server.server.BillCreationProtocol
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Rotate in the staged incoming DB BEFORE replacement, closing the crash/rollback replay window. */
internal fun prepareBillCreationImport(input: File, directory: File): File {
    val staged = File.createTempFile("bill-import-", ".db", directory)
    try {
        input.copyTo(staged, overwrite = true)
        val newSource = UUID.randomUUID().toString()
        SQLiteDatabase.openDatabase(staged.absolutePath, null, SQLiteDatabase.OPEN_READWRITE).use { imported ->
            imported.beginTransaction()
            try {
                imported.execSQL("INSERT OR REPLACE INTO SettingModel (`key`, value) VALUES (?, ?)",
                    arrayOf(BillCreationProtocol.SOURCE_KEY, newSource))
                imported.setTransactionSuccessful()
            } finally { imported.endTransaction() }
            imported.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use {
                check(it.moveToFirst() && it.getInt(0) == 0 && it.getInt(1) == it.getInt(2)) { "导入数据库检查点未完成" }
            }
        }
        SQLiteDatabase.openDatabase(staged.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { verify ->
            verify.rawQuery(BillCreationProtocol.RECEIPT_QUERY, arrayOf(BillCreationProtocol.SOURCE_KEY)).use {
                check(it.moveToFirst() && it.getString(0) == newSource) { "导入来源代际未持久保存" }
            }
        }
        FileOutputStream(staged, true).use { it.fd.sync() }
        return staged
    } catch (error: Exception) {
        staged.delete()
        throw error
    }
}

internal fun publishBillCreationImport(staged: File, destination: File) {
    check(staged.parentFile?.canonicalFile == destination.parentFile?.canonicalFile)
    android.system.Os.rename(staged.absolutePath, destination.absolutePath)
    // O_DIRECTORY is not exposed by Android's public SDK. Validate the opened
    // descriptor instead, preserving directory fsync and propagating failures.
    val directory = android.system.Os.open(destination.parentFile!!.absolutePath,
        android.system.OsConstants.O_RDONLY, 0)
    try {
        check(android.system.OsConstants.S_ISDIR(android.system.Os.fstat(directory).st_mode)) {
            "导入数据库父路径不是目录"
        }
        android.system.Os.fsync(directory)
    } finally { android.system.Os.close(directory) }
}
