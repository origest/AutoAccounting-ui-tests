package org.ezbook.server.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import org.ezbook.server.db.model.NotificationCaptureModel

@Dao
interface NotificationCaptureDao {
    @Query("SELECT * FROM NotificationCaptureModel WHERE captureId = :id")
    suspend fun find(id: String): NotificationCaptureModel?
    @Insert
    suspend fun insert(receipt: NotificationCaptureModel)
    @Query("SELECT * FROM NotificationCaptureModel WHERE state = 'pending' ORDER BY receivedAt, captureId LIMIT 1")
    suspend fun nextPending(): NotificationCaptureModel?
    @Query("UPDATE NotificationCaptureModel SET state = 'processing' WHERE captureId = :id AND state = 'pending'")
    suspend fun claim(id: String): Int
    @Query("UPDATE NotificationCaptureModel SET state = :state WHERE captureId = :id AND state = 'processing'")
    suspend fun finish(id: String, state: String)
    @Query("UPDATE NotificationCaptureModel SET state = 'uncertain' WHERE state = 'processing'")
    suspend fun recoverInterrupted(): Int
}
